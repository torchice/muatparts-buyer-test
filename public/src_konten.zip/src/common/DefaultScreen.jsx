import LocationNavbarMobile from "@/container/LocationNavbarMobile/LocationNavbarMobile";
import SearchNavbarMobile from "../container/SearchNavbarMobile/SearchNavbarMobile";
import OtherNavbarMobile from "@/container/OtherNavbarMobile/OtherNavbarMobile";

export const RegisterDefaultScreen = {
    "default_search_navbar_mobile":<SearchNavbarMobile/>,
    "default_location_navbar_mobile":<LocationNavbarMobile/>,
    "default_other_navbar_mobile":<OtherNavbarMobile/>,
}

function DefaultScreen(type) {
  return RegisterDefaultScreen?.[type]
}

export default DefaultScreen
