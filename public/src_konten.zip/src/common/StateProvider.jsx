"use client";
import React, { useState,useEffect } from "react";
import { StateContext } from "./StateContext";

function StateProvider({ children }) {
  const [getModal, setModal] = useState({
    modalId: "",
    isLoading: false,
    withHeader: true,
    closeArea: true,
    hideCloseButton: false,
    isBlueClose: false,
    sizeHeader: "small",
    top:null,
    onClose:null,
    props: null,
  });
  const [getScreen,setScreen]=useState('')
  const handleScreen=(val)=>setScreen(val)
  const handleModal = ({
    modalId,
    isLoading,
    withHeader,
    closeArea,
    hideCloseButton,
    isBlueClose,
    sizeHeader,
    top,
    onClose,
    props,
  }) => {
    setModal(() => ({
      modalId: modalId ? modalId : "",
      isLoading: typeof isLoading === "boolean" ? isLoading : false,
      withHeader: typeof withHeader === "boolean" ? withHeader : true,
      closeArea: typeof closeArea === "boolean" ? closeArea : true,
      hideCloseButton:
        typeof hideCloseButton === "boolean" ? hideCloseButton : false,
      isBlueClose:typeof isBlueClose==='boolean'?isBlueClose:false,
      sizeHeader: sizeHeader ? sizeHeader : "small",
      top:top?top:null,
      onClose:onClose?onClose:null,
      props: props ? props : null,
    }));
  };
  const closeModal = () => {
    setModal({
      modalId: "",
      isLoading: false,
      withHeader: true,
      closeArea: true,
      hideCloseButton: false,
      isBlueClose:false,
      sizeHeader: "small",
      top:null,
      onClose:null,
      props: null,
    });
  };
  
  return (
    <StateContext.Provider
      value={{
        modalId:getModal.modalId,
        isLoading: getModal.isLoading,
        withHeader:getModal.withHeader,
        closeArea: getModal.closeArea,
        hideCloseButton: getModal.hideCloseButton,
        isBlueClose:getModal?.isBlueClose,
        sizeHeader: getModal.sizeHeader,
        top:getModal.top,
        screen:getScreen,
        onClose:getModal.onClose,
        props:getModal.props,
        handleModal,
        handleScreen,
        closeModal,
      }}
    >
      {children}
    </StateContext.Provider>
  );
}

export default StateProvider;
