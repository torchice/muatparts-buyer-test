'use client'
import { createContext } from "react"

export const StateContext = createContext(null)
export const StateConsumer = StateContext.Consumer