import { authZustand } from '@/store/authZustand'
import React from 'react'

const ProtectComponent = function ProtectComponent(Component) {
  const WrappedComponent = (props) => {
    const { token } = authZustand()
    return <Component {...props} />
  }
  
  // Add display name
  WrappedComponent.displayName = `ProtectComponent(${Component.displayName || Component.name || 'Component'})`
  
  return WrappedComponent
}

export default ProtectComponent