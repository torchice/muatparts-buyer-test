"use client";

import React, { useState, useEffect, useRef } from "react";
import StateProvider from "./StateProvider";
import ModalWindow from "@/container/ModalWindow/ModalWindow";
import ModalComponentsIndex from "@/ModalComponents";
import BrowserCheck from "@/libs/versionBrowser";
import Backdrop from "@/components/Backdrop/Backdrop";
import toast from "@/store/zustand/toast";
import SidebarContainer from "@/container/SidebarContainer/SidebarContainer";
import { sideMenu } from "@/libs/linkServices";
import NavigationMenu from "@/components/Bottomsheet/NavigationMenu";
import { usePathname, useSearchParams } from "next/navigation";
import ResponsiveProvider from "./ResponsiveContext";
import Modal from "@/components/AI/Modal";
import headerZustand from "@/store/zustand/header";
import SWRHandler from "@/services/useSWRHook";
import { authZustand } from "@/store/auth/authZustand";
import { userZustand } from "@/store/auth/userZustand";
import { headerProps } from "@/container/HeaderContainer/headerProps";
import { useCustomRouter } from "@/libs/CustomRoute";
import usePrevious from "@/libs/usePrevious";
import isEmpty from "lodash/isEmpty";
import FloatingButton from "@/components/FloatingButton/FloatingButton";
import otpRegisterZustand from "@/store/zustand/otpRegister";
import { TranslationProvider } from "../context/TranslationProvider";

const baseUrl = `${process.env.NEXT_PUBLIC_GLOBAL_API}v1/`;

function MainApp({ children }) {
  const { useSWRMutateHook, useSWRHook } = SWRHandler;
  const link = usePathname();
  const router = useCustomRouter();
  const searchParams = useSearchParams();
  const { header } = headerZustand();
  const { setUser, setDataUser, setDataMatrixLS } = userZustand();
  // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0487
  const { successVerifyOtp, isModalOpen } = otpRegisterZustand();
  const { headerHeight } = headerProps();
  const { showBottomsheet, setShowSidebar, showNavMenu } = toast();
  const [isSetMatrix, setIsSetMatrix] = useState(false);
  const [isSetToken, setIsSetToken] = useState(false);
  const [isClient, setIsClient] = useState(false);
  const accessTokenParam = searchParams.get("accessToken");

  useEffect(() => {
    setIsClient(true);
  }, []);

  // URL yang tidak membutuhkan sidebar
  const urlWithoutSidebar = [
    "/kelolaproduk/tambahproduk",
    "/landing",
    "/register",
    "/register/otp",
    "/notifikasi",
    "/pengaturanmerchant/rekeningpencairan/otp",
    "/etalase",
    "/promotions/mobile",
    "/daftaretalase/mobile",
  ];

  const isLogin = authZustand?.getState()?.accessToken;
  const token = authZustand.getState().accessToken;
  const isVerifSellerMuatparts =
    userZustand.getState().dataMatrix?.isVerifSellerMuatparts;
  const [sidebarConfig, setSidebarConfig] = useState({
    show: true,
    hide: false,
  });
  const apiCallRef = useRef(false);

  const { data: dataCheckMatrix, isLoading: isLoadingCheckMatrix } = useSWRHook(
    isLogin && !apiCallRef.current ? `${baseUrl}register/checkmatrix` : null
  );

  const { data: dataLoginUser, trigger: triggerDataLoginUser } =
    useSWRMutateHook(`${baseUrl}user/getUserStatusV3`);

  const previousIsLoadingCheckMatrix = usePrevious(isLoadingCheckMatrix);

  // auth
  // const [getUrlToken, setUrlToken] = useState({
  //   accessToken: "",
  //   refreshToken: "",
  // });
  const {
    data: auth,
    isLoading: isLoadingAuth,
    error: errorAuth,
  } = useSWRHook(
    authZustand.getState().accessToken
      ? `${baseUrl}muatparts/auth/credential-check`
      : null,
    null,
    null,
    {
      headers: {
        Authorization: "Bearer " + authZustand.getState().accessToken,
      },
    }
  );

  const isErrorAuth = !isEmpty(errorAuth);
  const { accessToken, setToken } = authZustand();
  const previousIsLoadingAuth = usePrevious(isLoadingAuth);

  useEffect(() => {
    if (
      previousIsLoadingCheckMatrix === true &&
      isLoadingCheckMatrix === false
    ) {
      if (dataCheckMatrix?.Data) {
        setDataMatrixLS(dataCheckMatrix.Data);
        apiCallRef.current = true;
      }
      setIsSetMatrix(true);
    }
  }, [dataCheckMatrix, isLoadingCheckMatrix]);

  // Handle dataLoginUser
  useEffect(() => {
    if (dataLoginUser?.data?.Data) {
      setDataUser(dataLoginUser.data.Data);
    }
  }, [dataLoginUser]);

  // Trigger getUserStatus saat login
  useEffect(() => {
    if (isLogin && !apiCallRef.current) {
      triggerDataLoginUser();
    }
  }, [isLogin]);

  useEffect(() => {
    if ((accessTokenParam && isSetMatrix && isSetToken) || !accessTokenParam) {
      if (!token) {
        if (!link.includes("/landing") && !successVerifyOtp) {
          console.log("tendang1");
          router.push("/landing");
        }
      } else {
        if (
          userZustand.getState().dataMatrix?.isVerifSellerMuatparts === false
        ) {
          if (!link.includes("/landing") && !link.includes("/register")) {
            console.log("tendang2");
            router.push("/landing");
          }
        } else if (
          userZustand.getState().dataMatrix?.isVerifSellerMuatparts === true
        ) {
          if (link.includes("/register")) {
            console.log("tendang3");
            router.push("/landing");
          }
        }
      }
    }
  }, [
    token,
    link,
    userZustand.getState().dataMatrix?.isVerifSellerMuatparts,
    isSetMatrix,
    isSetToken,
    accessTokenParam,
    successVerifyOtp,
  ]);

  useEffect(() => {
    if (isErrorAuth && !link.includes("/landing")) {
      console.log("tendang4");
      router.push("/landing");
    }
  }, [isErrorAuth, link]);

  useEffect(() => {
    if (typeof window !== "undefined") {
      const isUrlBlocked = urlWithoutSidebar.some((url) => link.includes(url));
      const savedConfig = localStorage.getItem("sidebarConfig");

      if (isUrlBlocked) {
        setSidebarConfig({
          show: false,
          hide: true,
        });
        setShowSidebar(false);
      } else {
        const parsedConfig = savedConfig
          ? JSON.parse(savedConfig)
          : { hide: false };
        setSidebarConfig({
          show: true,
          hide: parsedConfig.hide,
        });
        setShowSidebar(true);
      }
    }
  }, [link]);

  useEffect(() => {
    if (typeof window !== "undefined" && isClient && sidebarConfig.show) {
      localStorage.setItem("sidebarConfig", JSON.stringify(sidebarConfig));
    }
  }, [sidebarConfig, isClient]);

  const handleToggleSidebar = (hideState) => {
    setSidebarConfig((prev) => ({
      show: true,
      hide: hideState,
    }));
  };

  useEffect(() => {
    if (
      previousIsLoadingAuth === true &&
      isLoadingAuth === false &&
      auth?.Data
    ) {
      console.log("heres 2");
      let data = auth?.Data;
      // setToken({
      //   accessToken: searchParams.get("accessToken"),
      //   refreshToken: searchParams.get("refreshToken"),
      // });
      delete data.accessToken;
      delete data.refreshToken;
      setUser(data);
      setIsSetToken(true);
    }
  }, [auth, isLoadingAuth]);

  // LB - 0282 / 25.03
  useEffect(() => {
    const accessToken = searchParams.get("accessToken");
    const refreshToken = searchParams.get("refreshToken");

    if (accessToken && refreshToken) {
      console.log("reget token");
      authZustand.getState().setToken({ accessToken, refreshToken });

      if (typeof window !== "undefined") {
        const url = new URL(window.location.href);
        url.searchParams.delete("accessToken");
        url.searchParams.delete("refreshToken");
        window.history.replaceState({}, document.title, url.toString());
        // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0390
        // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0487
        if (!successVerifyOtp || !isModalOpen) {
          window.location.reload();
        }
      }
    }
  }, [searchParams, successVerifyOtp, isModalOpen]);
  // end auth

  if (!isClient) {
    return null;
  }

  return (
    <TranslationProvider>
      <ResponsiveProvider>
        <div
          className={`sm:px-0 sm:pt-[52px] ${
            !header ? `sm:!pt-[${headerHeight}px] sm:overflow-x-hidden` : ""
          }
          bg-neutral-100 w-full h-full sm:h-lvh`}
          // ${backgroundClassname}
        >
          <Modal />
          <FloatingButton />
          {/* {showBottomsheet && <Backdrop />} */}
          {sidebarConfig.show && (
            <SidebarContainer
              setHide={handleToggleSidebar}
              hide={sidebarConfig.hide}
              classname="mt-14"
              menuParent={sideMenu}
            />
          )}

          {showNavMenu && <NavigationMenu />}
          <StateProvider>
            <BrowserCheck />
            <main
              className={`main-container my-20 ${
                sidebarConfig.show && !sidebarConfig.hide
                  ? "pl-[220px] pr-6 mb-5"
                  : "pl-[50px] pr-4 mb-5"
              } ${!sidebarConfig.show && "!p-0"} ${
                link === "/landing" && "!pl-0"
              } sm:!px-0 sm:mt-0 ${
                link.includes("/register/otp") ||
                link.includes("/pengaturanmerchant/rekeningpencairan/otp")
                  ? "!mb-0"
                  : ""
              }`}
            >
              {children}
            </main>
            <ModalWindow>
              <ModalComponentsIndex />
            </ModalWindow>
          </StateProvider>
        </div>
      </ResponsiveProvider>
    </TranslationProvider>
  );
}

export default MainApp;
