"use client";
import { HeaderContainer as HeaderLawas } from "@/container/HeaderContainer/HeaderContainer";
import { createContext, useContext, useState, useEffect } from "react";

export const ResponsiveContext = createContext(null);

import DefaultScreen from "./DefaultScreen";
import viewport from "@/store/zustand/common";
import { headerProps } from "@/container/HeaderContainer/headerProps";
import HeaderContainer from "@/container/HeaderContainer";
import { useCustomRouter } from "@/libs/CustomRoute";

function ResponsiveProvider({ children }) {
  const router = useCustomRouter();
  const [getHeader, setHeader] = useState({
    onBack: null,
    onAction: null,
    title: "",
    showBackButton: true,
    appBarType: "",
    renderBack: null,
    componentBackType: "back",
    renderActionButton: null,
    renderAppBar: null,
    renderHeader: null,
    shadow: true,
    showReset: true,
    defaultType: "",
    withSearchBottom: "",
    blankBackground: false,
  });
  const [search, editSearch] = useState({
    placeholder: "muatparts",
    value: "",
    tmp: "",
    type: "text",
    minLen: 0,
    onSubmitForm: false,
  });

  const [screen, setScreen] = useState("");
  const [getGlobalPadding, setGlobalPadding] = useState(true);
  const { setIsMobile, isMobile } = viewport();
  const { headerHeight } = headerProps();
  const renderAppBarMobile = (elm) =>
    setHeader((prev) => ({ ...prev, renderAppBar: elm }));
  const renderHeader = (elm) =>
    setHeader((prev) => ({ ...prev, renderHeader: elm }));
  const setAppBar = ({
    onBack = null,
    onAction = null,
    title = "",
    showBackButton = true,
    appBarType = "",
    renderBack = null,
    componentBackType = "back",
    renderActionButton = null,
    renderAppBar = null,
    renderHeader = null,
    shadow = true,
    showReset = true,
    defaultType = "",
    withSearchBottom = "",
    blankBackground = false,
  }) => {
    setHeader({
      onBack: onBack,
      onAction: onAction,
      title: title,
      showBackButton: showBackButton,
      appBarType: appBarType,
      renderBack: renderBack,
      componentBackType: componentBackType,
      renderActionButton: renderActionButton,
      renderAppBar: renderAppBar,
      renderHeader: renderHeader,
      shadow: shadow,
      showReset: showReset,
      defaultType: defaultType,
      withSearchBottom: withSearchBottom,
      blankBackground: blankBackground,
    });
  };
  const setSearch = (val) => editSearch((prev) => ({ ...prev, ...val }));
  const clearScreen = () => {
    setScreen("");
    setAppBar({
      onBack: null,
      title: "",
      showBackButton: true,
      appBarType: "",
      renderAppBar: null,
      renderHeader: null,
      renderBack: null,
      renderActionButton: null,
      shadow: true,
      defaultType: "",
      componentBackType: "back",
      withSearchBottom: "",
      blankBackground: false,
    });
  };
  const handleBack = () => {
    if (getHeader.onBack) {
      getHeader.onBack();
    } else {
      router.back();
    }
  };
  const handleAction = () => {
    if (getHeader.onAction) {
      getHeader.onAction();
    } else {
      console.log("do something");
    }
  };

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 500);
    };

    if (typeof window !== "undefined") {
      handleResize();
    }

    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  // umpomo SSR
  if (typeof window === "undefined") {
    return null;
  }

  return (
    <ResponsiveContext.Provider
      value={{
        appBarType: getHeader.appBarType,
        appBar: getHeader,
        renderAppBarMobile,
        renderHeader,
        setAppBar,
        clearScreen,
        handleBack,
        setScreen,
        screen,
        setSearch,
        showReset: getHeader.showReset,
        handleAction,
        setGlobalPadding,
        search,
        componentBackType: getHeader?.componentBackType,
        shadow: getHeader.shadow,
      }}
    >
      {(getHeader.appBarType || getHeader.renderAppBar) && isMobile ? (
        <HeaderContainer />
      ) : (
        <HeaderLawas />
      )}

      {DefaultScreen(getHeader.defaultType) ? (
        <div
          style={{ marginTop: `${headerHeight}px` }}
          className={`w-full ${getGlobalPadding ? "max-w-7xl mx-auto" : ""}`}
        >
          {DefaultScreen(getHeader.defaultType)}
        </div>
      ) : (
        children
      )}
      {/* <BottomTabNavigation /> */}
      {/* {isMobile == null ? <></> : isMobile ? <></> : <FooterContainer />} */}
    </ResponsiveContext.Provider>
  );
}

export default ResponsiveProvider;

export const useHeader = () => useContext(ResponsiveContext);
