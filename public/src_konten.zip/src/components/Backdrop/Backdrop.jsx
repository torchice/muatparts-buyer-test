import React from "react";

const Backdrop = () => {
  return (
    <div className="h-screen w-screen backdrop-brightness-50 fixed z-[89] left-0 top-0"></div>
  );
};

export default Backdrop;
