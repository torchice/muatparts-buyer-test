
'use client';
import { viewport } from '@/store/viewport';
import IconComponent from '../IconComponent/IconComponent';
import style from './ButtonAddAddressProduct.module.scss'
function ButtonAddAddressProduct({number,onAddAddress,address,onDelete,isError={index:null,text:''}}) {
    const {isMobile}=viewport()
    return (
        <div className='flex flex-col gap-3'>
            <div className={`py-4 px-3 rounded-md border ${(typeof isError?.index==='number')?'border-error-400':'border-neutral-400'} flex justify-between text-neutral-900 gap-2`}>
                {
                    !isMobile?<>
                        <div className=' flex flex-col gap-3 w-full'>
                            <div className='flex justify-between w-full gap-2 items-center'>
                                <span className=' text-neutral-50 font-bold text-[10px] rounded-full grid place-content-center bg-primary-700 px-2 py-1'>{number}</span>
                                
                                {address?.ID?
                                <div className='flex w-full justify-between'>
                                    <span className='medium-sm'>Dikirim ke:</span>
                                    <div className='flex gap-2 items-center'>
                                        <span className='cursor-pointer medium-xs select-none text-primary-700' onClick={onAddAddress}>Ubah Alamat Tujuan </span>
                                        <span className='cursor-pointer' onClick={onDelete}>
                                            <IconComponent src={'/icons/trash-az.svg'} classname={'icon-error-400'} width={20} height={20} />
                                        </span>
                                    </div>
                                </div>
                                :<div className='flex w-full justify-between'>
                                    <span className='medium-sm'>Dikirim ke:</span>
                                    <span className='text-primary-700 medium-sm cursor-pointer' onClick={onAddAddress}>Tambah Alamat</span>
                                </div>}
                            </div>
                            {
                                address?.ID?
                                <div className='flex flex-col gap-3'>
                                    <span className='bold-xs'>{address?.Name}</span>
                                    <span className='medium-xs'>{address?.PicName} ({address?.PicNoTelp})</span>
                                    <span className='medium-xs'>{address?.Address}</span>
                                    {address?.Notes?<span className='medium-xs'>Catatan : {address?.Notes}</span>:''}
                                </div>:''
                            }
                        </div>
                    </>
                    :<>
                        <span className=' text-neutral-50 font-bold text-[10px] rounded-full h-fit px-2 py-1 bg-primary-700 '>{number}</span>
                        {address?.ID?
                        <div className='flex w-full justify-between'>
                            {isMobile&&<span className='semi-sm'>{address?.Address}</span>}
                            <div className='flex gap-2'>
                                <span className='cursor-pointer'>
                                    <IconComponent src={'/icons/edit-gray.svg'} width={20} height={20} />
                                </span>
                                <span className='cursor-pointer' onClick={onDelete}>
                                    <IconComponent src={'/icons/trash-az.svg'} classname={'icon-error-400'} width={20} height={20} />
                                </span>
                            </div>
                        </div>
                        :<span className='text-primary-700 medium-sm cursor-pointer' onClick={onAddAddress}>Tambah Alamat</span>}
                    </>
                }
            </div>
            {isError?.text&&<span className='medium-xs text-error-400'>{isError?.text}</span>}
        </div>
    );
}

export default ButtonAddAddressProduct;
  