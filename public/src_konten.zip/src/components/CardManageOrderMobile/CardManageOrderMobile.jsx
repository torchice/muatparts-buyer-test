
'use client';
import Image from 'next/image';
import style from './CardManageOrderMobile.module.scss'
import Button from '../Button/Button';
import Checkbox from '../Checkbox/Checkbox';
import IconComponent from '../IconComponent/IconComponent';
import CountDownMobile from '../CountDownMobile/CountDownMobile';
import { formatDate } from '@/libs/DateFormat';
import { numberFormatMoney } from '@/libs/NumberFormat';
function CardManageOrderMobile({
    id,
    statusOrder,
    total_amount,
    shipping,
    invoice_number,
    products,
    expired_at,
    customer,
    paymentLimit,
    response_limit,
    date,
    // 25. 07 - QC Plan - Web Apps - Marketing Muatparts - LB - 0041
    image='',
    productName,
    invoice,
    courier,
    buyerName,
    amount,
    amountOfAllProduct,
    totalOrder,
    onClick,
    withCheckBox,
    isChecked,
    onChecked,
    valueChecked,
    status,
    textButton='Detail',
    twoButton,
    onClickMenu,
    onClickLeft,
    textButtonLeft,
    onClickRight,
    textButtonRight,
    colorButtonLeft='primary',
    colorButtonRight='primary_secondary',
    colorButton='primary',
}) {
    return (
        <div className={`${style.main} flex gap-3 items-start w-full bg-neutral-50 py-3 px-4 relative`}>
            {
                withCheckBox&&<Checkbox checked={isChecked} value={id} onChange={onChecked} label='' />
            }
            <div className={`flex flex-col gap-5 text-neutral-900 bg-neutral-50 w-full`}>
                {!withCheckBox?<div className='w-full justify-between flex items-center'>
                    {(!withCheckBox)&&<span className='medium-xs'>Batas pembayaran : {formatDate(expired_at)}</span>}
                    {/* {(!withCheckBox&&responseLimit&&!statusOrder)&&<span className='medium-xs'>Batas Respon</span>}
                    {(!withCheckBox&&responseLimit&&statusOrder)&&<span className='medium-xs'>{statusOrder}</span>} */}
                    {/* {
                        <span onClick={onClickMenu}><IconComponent src={'/icons/three-dots.svg'} /></span>
                    } */}
                </div>:''}

                {products?.slice(0,1)?.map(val => <div key={id} className='flex gap-3'>
                    <span className='w-[68px] h-[68px] rounded border border-ne'>
                        <Image width={68} height={68} src={val?.image_url} alt='img' className='rounded w-full h-full' />
                    </span>
                    <div className='flex flex-col flex-1 gap-3'>
                        <span className='flex w-full justify-between'>
                            <span className='bold-sm'>{val?.name}</span>
                            {val?.quantity>1&&<span className='medium-xs text-neutral-600'>+{val?.quantity-1}</span>}
                        </span>
                        {/* {
                            !withCheckBox&&status==='Menunggu Pembayaran'?<>
                                <span className='medium-xs'>{invoice}</span>
                                {products?.length>1&&<span className='medium-xs text-primary-700'>+{products?.length-1} produk lainnya</span>}
                            </>
                            :status==='menunggPembayaran'?<div className='flex flex-col gap-3 w-1/2'>
                                <span className='text-neutral-600 medium-xs'>Batas Pembayaran</span>
                                <span className='semi-xs line-clamp-1'>{paymentLimit}</span>
                            </div>
                            :''
                        }
                         */}
                        {
                            !withCheckBox?<>
                                <span className='medium-xs'>{invoice_number}</span>
                                {products?.length>1&&<span className='medium-xs text-primary-700'>+{products?.length-1} produk lainnya</span>}
                                {/* <span className={`w-full rounded-md bg-error-50 text-error-400 semi-sm flex justify-center`}><CountDownMobile withoutIcon date={response_limit} /></span> */}
                            </>
                            :withCheckBox?<>
                                <span className='medium-xs text-neutral-600'>Batas Pembayaran</span>
                                <span className={`w-full rounded-md semi-xs flex`}>{formatDate(response_limit)}</span>
                            </>
                            // :status!=='menunggPembayaran'?<div className='flex flex-col gap-3 w-1/2'>
                            //     <span className='text-neutral-600 medium-xs'>Batas Pembayaran</span>
                            //     <span className='semi-xs line-clamp-1'>{paymentLimit}</span>
                            // </div>
                            :''
                        }
                    </div>
                </div>)}
                <div className={`grid ${withCheckBox&&status!=='Menunggu Pembayaran'?'grid-cols-3':'grid-cols-2'} gap-2`}>
                    <div className='flex flex-col gap-3 w-full'>
                        <span className='text-neutral-600 medium-xs'>Kurir</span>
                        <span className='semi-xs line-clamp-1'>{shipping?.courier}</span>
                    </div>
                    <div className='flex flex-col gap-3 items-start w-full'>
                        <span className='text-neutral-600 medium-xs'>Pembeli</span>
                        <span className='semi-xs line-clamp-1'>{customer?.name}</span>
                    </div>
                    {(!withCheckBox)&&<div className='flex flex-col gap-3 w-full'>
                        <span className='text-neutral-600 medium-xs'>Jumlah Produk</span>
                        <span className='semi-xs line-clamp-1'>{products.length}</span>
                    </div>}
                    <div className='flex flex-col gap-3 items-start w-full'>
                        <span className='text-neutral-600 medium-xs'>Total Pesanan</span>
                        <span className='semi-xs line-clamp-1'>{numberFormatMoney(total_amount)}</span>
                    </div>
                </div>
                {(!withCheckBox&&!twoButton)&&<Button onClick={()=>onClick(id)} color={colorButton} Class='!max-w-full !h-8'>{textButton}</Button>}
                {(!withCheckBox&&twoButton)&&<div className='flex justify-between gap-2'>
                    <Button onClick={onClickLeft} color={colorButtonLeft} Class='!max-w-full !w-full !h-8'>{textButtonLeft}</Button>
                    <Button onClick={onClickRight} color={colorButtonRight} Class='!max-w-full !w-full !h-8'>{textButtonRight}</Button>
                    </div>}
            </div>
            {!withCheckBox&&<span className='w-2 h-6 rounded-xl bg-muat-parts-member-800 absolute top-0 -left-1'></span>}
        </div>
    );
}

export default CardManageOrderMobile;


export const CardManageOrderDetailMobile=({
    image='/img/chopper.png',
    productName,
    amount,
    SKU,
    tipe,
    beforePrice,
    afterPrice,
    discount
})=>{
    return (
        <div className={`flex flex-col gap-5 text-neutral-900 bg-neutral-50 w-full`}>
            <div className='flex gap-3'>
                <span className='w-[68px] h-[68px]'>
                    <Image width={68} height={68} src={image} alt='img' className='rounded w-full h-full' />
                </span>
                <div className='flex flex-col w-full'>
                    <div className='flex w-full justify-between items-center'>
                        <span className='bold-sm'>{productName}</span>
                        <span className='medium-xs text-neutral-600'>X {amount}</span>
                    </div>
                    {SKU&&<span className='medium-xs'>SKU : {SKU}</span>}
                    {tipe&&<span className='medium-xs'>Tipe : {tipe}</span>}
                    {!!(discount)&&<>
                        <strike className='medium-xs !text-[10px] text-neutral-600'>{numberFormatMoney(beforePrice)}</strike>
                        <span className='semi-sm text-error-400'>{numberFormatMoney(afterPrice)}</span>
                    </>}
                    {!discount&&<span className='semi-sm'>{numberFormatMoney(afterPrice)}</span>}
                </div>
            </div>
        </div>
    )
}