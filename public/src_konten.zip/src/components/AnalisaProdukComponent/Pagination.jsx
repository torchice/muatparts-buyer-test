import React from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useTranslation } from '@/context/TranslationProvider';
import TranslationSkeleton from '../Skeleton/TranslationSkeleton';

export const Pagination = ({ currentPage, totalPages, onPageChange, onItemsPerPageChange, itemsPerPage }) => {
  // Improvement fix wording pak Bryan
  const {t} = useTranslation()
  const pageNumbers = Array.from({ length: totalPages }, (_, i) => i + 1);

  return (
    <div className="flex items-center justify-between px-[0px] mt-[0px]">
      <div className="flex items-center gap-2">
        <button 
          className="inline-flex items-center justify-center h-[24px] w-[24px] rounded-md"
          onClick={() => onPageChange(Math.max(1, currentPage - 1))}
          disabled={currentPage === 1}
        >
          <ChevronLeft className="h-4 w-4" />
        </button>
        
        {pageNumbers.map((page) => (
          <button
            key={page}
            onClick={() => onPageChange(page)}
            className={`inline-flex items-center justify-center h-[32px] w-[32px] rounded-md ${
              page === currentPage
                ? 'BgC22716 ColorFFFFFF'
                : ''
            }`}
          >
            {page}
          </button>
        ))}
        
        <button 
          className="inline-flex items-center justify-center h-[24px] w-[24px] rounded-md"
          onClick={() => onPageChange(Math.min(totalPages, currentPage + 1))}
          disabled={currentPage === totalPages}
        >
          <ChevronRight className="h-4 w-4" />
        </button>
      </div>
      
      <div className="flex items-center gap-4">
        {/* Improvement fix wording pak Bryan */}
        <TranslationSkeleton
          parentClassName="max-w-[150px] min-h-4"
          className="AvenirDemi12px Color7B7B7B"
          label="WebKelolaPesananSellerMuatpartspesananMenungguPembayaranTampilkanJumlahDetail"
        />
        <div className="flex items-center gap-2">
          {[10, 20, 40].map((size) => (
            <button
              key={size}
              onClick={() => onItemsPerPageChange(size)}
              className={`inline-flex items-center justify-center h-[32px] w-[32px] px-3 rounded-md ${
                size === itemsPerPage
                  ? 'BgC22716 ColorFFFFFF'
                  : ''
              }`}
            >
              {size}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};