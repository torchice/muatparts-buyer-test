'use client'
import React, { forwardRef } from 'react'
import style from './Input.module.scss'
import PropTypes from 'prop-types'
import IconComponent from "../IconComponent/IconComponent"

const Input = forwardRef(({
  name,
  type = 'text',
  placeholder = 'Placeholder',
  disabled = false,
  status = null,
  icon = {left: '', right: ''},
  text = {left: '', right: ''},
  supportiveText = {title: '', desc: ''},
  width = {width: '', maxWidth: '', minWidth: ''},
  onChange = () => {},
  onKeyUp = () => {},
  onFocus = () => {},
  value = '',
  classname = '',
  classInput = '',
  startAdornment,
  endAdornment,
  ...props
}, ref) => {

  return (
    <div className={`flex flex-col gap-[4px] ${classname}`} style={{width: width.width, maxWidth: width.maxWidth, minWidth: width.minWidth}}>
      <div className={`flex items-center w-[242px] h-[32px] gap-[8px] ${disabled && style.input_disabled} ${style.input_style}
      ${status === 'error' ? style.border_red :
        status === 'success' ? style.border_success :
        ''
      }`}>
        {startAdornment}
        {typeof icon.left === 'string' ? 
          <IconComponent 
            loader={false} 
            src={{src: icon.left}} 
            height={16} 
            width={16}
            classname={status === 'error' ? style.icon_danger :
              status === 'success' ? style.icon_success : ''
            }
          /> : icon.left}
        {text.left}
        <input 
          {...props}
          type={type}
          onChange={onChange}
          onKeyUp={onKeyUp} 
          ref={ref}
          name={name}
          value={value}
          placeholder={placeholder}
          onFocus={onFocus}
          className={`grow outline-none bg-transparent ${style.input} ${classInput}`}
          disabled={disabled}
        />
        {endAdornment}
        {typeof icon.right === 'string' ? 
          <IconComponent 
            loader={false} 
            src={{src: icon.right}} 
            height={16} 
            width={16}
            classname={status === 'error' ? style.icon_danger :
              status === 'success' ? style.icon_success : ''
            }
          /> : icon.right}
        {text.right}
      </div>
      {(supportiveText.title || supportiveText.desc) && (
        <div className={`flex justify-between ${style.supportive_text}
        ${status === 'error' ? style.text_danger :
          status === 'success' ? style.text_success : ''
        }`}>
          <span>{supportiveText.title}</span>
          <span>{supportiveText.desc}</span>
        </div>
      )}
    </div>
  )
})

Input.displayName = "Input"

Input.propTypes = {
  placeholder: PropTypes.string,
  type: PropTypes.oneOf(['text', 'number', 'email', 'password']),
  name: PropTypes.string,
  classname: PropTypes.string,
  disabled: PropTypes.bool,
  status: PropTypes.oneOf(['success', 'error', null]),
  icon: PropTypes.object,
  text: PropTypes.object,
  supportiveText: PropTypes.object,
  width: PropTypes.object,
  onChange: PropTypes.func,
  onKeyUp: PropTypes.func,
  onFocus: PropTypes.func,
  value: PropTypes.string,
  startAdornment: PropTypes.node,
  endAdornment: PropTypes.node
}

export default Input