import React from 'react';
import Button from '@/components/Button/Button';
import SWRHandler from '@/services/useSWRHook';
import IconComponent from "@/components/IconComponent/IconComponent";

const { useSWRMutateHook } = SWRHandler;
const API_URL = `${process.env.NEXT_PUBLIC_GLOBAL_API}v1/`;

export const Header = ({ onFilterChange = () => { }, filters = {} }) => {
    // Inisialisasi mutation hook untuk fungsi export
    const { trigger: triggerExport, isMutating: isExporting } = useSWRMutateHook(
        `${API_URL}/product-analysis/export`,
        "POST"
    );

    const handlePeriodChange = (e) => {
        onFilterChange({ period: e.target.value });
    };

    // Fungsi untuk menangani proses export
    const handleExport = async () => {
        try {
            const response = await triggerExport(filters);

            // Pastikan response mengandung data yang diperlukan
            if (response?.data?.Data) {
                // Buka URL unduhan di tab baru
                window.open(response.data.Data, '_blank');
            }
        } catch (error) {
            console.error('Gagal mengunduh data:', error);
            // Di sini Anda bisa menambahkan notifikasi error jika diperlukan
        }
    };

    return (
        <div className="flex flex-col gap-4">
            <div className="flex items-center justify-between">
                <h1 className="AvenirBold20px">Analisa Produk</h1>
                <div className='flex gap-[12px] items-center'>
                    <select
                        className="w-[200px] h-10 px-3 rounded-md border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        onChange={handlePeriodChange}
                        value={filters.period || 'all'}
                    >
                        <option value="all">Semua Periode</option>
                        <option value="this-month">Bulan Ini</option>
                        <option value="last-month">Bulan Lalu</option>
                        <option value="custom">Kustom</option>
                    </select>
                    <Button
                        Class="!font-medium"
                        iconLeft={
                            // Improvement fix wording pak Bryan
                            <IconComponent
                                src={"/icons/download.svg"}
                                classname={isExporting ? "icon-gray" : "icon-white"}
                            />}
                        onClick={handleExport}
                        disabled={isExporting}
                    >
                        {isExporting ? 'Mengunduh...' : 'Unduh'}
                    </Button>
                </div>
            </div>
        </div>
    );
};