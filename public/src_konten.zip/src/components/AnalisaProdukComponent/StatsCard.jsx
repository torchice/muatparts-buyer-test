import React from 'react';
import Tooltip from "@/components/AnalisaProdukComponent/TooltipAnalisa";

export const StatsCard = ({ 
    title, 
    value, 
    icon,
    className="",
    variant="biru",
    isLoading = false
}) => {
    const baseStyles = "rounded-[6px] border border-gray-200 min-w-[167px] w-fit";

    const variants = {
        biru: "BgE2F2FF Color176CF7",
        hijau: "BgE3F5ED Color0FBBB1",
        kuning: "BgFFF9C1 ColorFF7A00",
    };

    const tooltipContent = {
        'Produk Dilihat': 'Total halaman produk yang dibuka melalui aplikasi dan website muatparts',
        'Produk di Troli': 'Total produk yang dimasukkan ke troli oleh pembeli',
        'Total Pesanan': 'Total pesanan yang masuk ke toko',
        'Total Pendapatan': 'Total pendapatan kotor dari seluruh pesanan',
        'Konversi': 'Persentase pembeli yang melakukan pembelian dari total pengunjung',
        'Produk Terjual': 'Total Produk dari pesanan yang telah selesai'
    };

    // Improvement fix wording pak Bryan
    if (isLoading) {
        return (
            <div className={`${className} ${baseStyles} ${variants[variant]}`}>
                <div className="flex justify-between p-[12px]">
                    <div className="space-y-1">
                        <div className="h-4 w-24 bg-gray-200 rounded animate-pulse"></div>
                        <div className="h-6 w-16 bg-gray-200 rounded animate-pulse"></div>
                    </div>
                    <div className="h-[16px] w-[16px] rounded-full bg-gray-200 animate-pulse"></div>
                </div>
            </div>
        );
    }

    return (
        <div className={`${className} ${baseStyles} ${variants[variant]}`}>
            <div className="flex justify-between p-[12px]">
                <div className="space-y-1">
                    <p className="AvenirDemi12px Color000000">{title}</p>
                    <p className="AvenirBold16px">{value}</p>
                </div>
                {icon && (
                    <Tooltip
                        text={tooltipContent[title]}
                        position={title === 'Produk Terjual' ? 'bottomright' : 'bottom'}
                    >
                        <div className="h-[16px] w-[16px] rounded-full bg-gray-100 flex items-center justify-center">
                            {icon}
                        </div>
                    </Tooltip>
                )}
            </div>
        </div>
    );
};