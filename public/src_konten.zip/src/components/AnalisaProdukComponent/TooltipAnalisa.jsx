"use client"

import React from 'react'
import style from '@/components/Tooltip/Tooltip.module.scss'
import IconComponent from "@/components/IconComponent/IconComponent"

const Tooltip = ({ classname, text, children, title, icon, position = 'bottom', ...props}) => {
  const getPositionStyles = () => {
    switch (position) {
      case 'bottomright':
        return {
          tooltipContainer: "right-[-20px] top-5",
          arrow: "-top-2 left-[278px]"
        };
      case 'bottom':
      default:
        return {
          tooltipContainer: "-left-[146px] top-5",
          arrow: "-top-2 left-[146px]"
        };
    }
  };

  const positionStyles = getPositionStyles();

  return (
    <div className="group relative inline-flex cursor-pointer" {...props}>
        {children}
        <div className={`absolute hidden group-hover:block w-[312px] ${positionStyles.tooltipContainer}`}>
            <div className="flex flex-col relative justify-start items-center">
                <div className={`w-[15px] h-[15px] absolute ${positionStyles.arrow} bg-neutral-50 rotate-45`}></div>
                <div className="flex gap-[8px] bg-neutral-50 rounded-[12px] z-[1] p-[12px] cursor-default shadow-md">
                    <div className="w-[16px] mt-[2px]">
                        {icon && (
                            <IconComponent 
                                loader={false} 
                                src={{src: '/icons/info.svg'}} 
                                height={16} 
                                width={16} 
                                classname={style.fill_black}
                            />
                        )}
                    </div>
                    <div className='flex flex-col gap-[8px]'>
                        {title && <div className={`${style.title}`}>{title}</div>}
                        {text && <div className={`${style.text} ${classname}`}>{text}</div>}
                    </div>
                </div>
            </div>
        </div>
    </div>
  );
};

export default Tooltip;