export const products = [
{
    id: 1,
    name: "Peralatan Angkutan 1",
    sku: "19827381823499",
    brand: "UD Truck",
    image: "https://cdn.builder.io/api/v1/image/assets/60cdcdaf919148d9b5b739827a6f5b2a/4fbe7b1cb9f0275d1e9c06d488fa8975edea381f705caef9c638ed0d8111beae",
    category: "Produk Lainnya",
    views: 5,
    orders: 1,
    conversion: "20%",
    complaints: 0,
    sold: 1,
    revenue: "Rp500.000",
    cart: 0,
    favorites: 1,
    status: "Aktif"
},
{
    id: 2,
    name: "Spare Part Motor 2",
    sku: "19827381823500",
    brand: "Honda",
    image: "https://cdn.builder.io/api/v1/image/assets/60cdcdaf919148d9b5b739827a6f5b2a/4fbe7b1cb9f0275d1e9c06d488fa8975edea381f705caef9c638ed0d8111beae",
    category: "Otomotif",
    views: 15,
    orders: 3,
    conversion: "20%",
    complaints: 1,
    sold: 3,
    revenue: "Rp750.000",
    cart: 2,
    favorites: 4,
    status: "Aktif"
},
{
    id: 3,
    name: "Spare Part Motor 3",
    sku: "19827381823500",
    brand: "Honda",
    image: "https://cdn.builder.io/api/v1/image/assets/60cdcdaf919148d9b5b739827a6f5b2a/4fbe7b1cb9f0275d1e9c06d488fa8975edea381f705caef9c638ed0d8111beae",
    category: "Otomotif",
    views: 15,
    orders: 3,
    conversion: "20%",
    complaints: 1,
    sold: 3,
    revenue: "Rp750.000",
    cart: 2,
    favorites: 4,
    status: "Aktif"
},
{
    id: 4,
    name: "Spare Part Motor 4",
    sku: "19827381823500",
    brand: "Honda",
    image: "https://cdn.builder.io/api/v1/image/assets/60cdcdaf919148d9b5b739827a6f5b2a/4fbe7b1cb9f0275d1e9c06d488fa8975edea381f705caef9c638ed0d8111beae",
    category: "Otomotif",
    views: 15,
    orders: 3,
    conversion: "20%",
    complaints: 1,
    sold: 3,
    revenue: "Rp750.000",
    cart: 2,
    favorites: 4,
    status: "Aktif"
},
// Add more mock products...
];

export const ITEMS_PER_PAGE = 10;

export const getTotalPages = (totalItems) => Math.ceil(totalItems / ITEMS_PER_PAGE);

export const paginateProducts = (items, currentPage) => {
    const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
    return items.slice(startIndex, startIndex + ITEMS_PER_PAGE);
};



export const mockCategories = [
    { id: 1, name: 'Elektronik' },
    { id: 2, name: 'Fashion' },
    { id: 3, name: 'Makanan & Minuman' },
    { id: 4, name: 'Kesehatan' },
    { id: 5, name: 'Peralatan Rumah' }
];
  
export const mockBrands = [
    { id: 1, name: 'Samsung' },
    { id: 2, name: 'Apple' },
    { id: 3, name: 'Nike' },
    { id: 4, name: 'Adidas' },
    { id: 5, name: 'Unilever' }
];
  
export const mockProducts = Array(50).fill(null).map((_, index) => ({
    id: index + 1,
    name: `Product ${index + 1}`,
    sku: `SKU${Math.random().toString(36).substr(2, 9)}`,
    category: mockCategories[Math.floor(Math.random() * mockCategories.length)],
    brand: mockBrands[Math.floor(Math.random() * mockBrands.length)],
    status: ['active', 'inactive', 'out_of_stock', 'draft'][Math.floor(Math.random() * 4)],
    views: Math.floor(Math.random() * 1000),
    cart: Math.floor(Math.random() * 100),
    orders: Math.floor(Math.random() * 50),
    revenue: Math.floor(Math.random() * 1000000),
    sold: Math.floor(Math.random() * 30)
}));
  
export const mockFilterService = {
    getFilteredProducts: ({
      search = '',
      category = '',
      brand = '',
      status = '',
      page = 1,
      limit = 10
    }) => {
      let filteredProducts = [...mockProducts];
  
      // Apply search filter
      if (search) {
        const searchLower = search.toLowerCase();
        filteredProducts = filteredProducts.filter(product => 
          product.name.toLowerCase().includes(searchLower) ||
          product.sku.toLowerCase().includes(searchLower)
        );
      }
  
      // Apply category filter
      if (category) {
        filteredProducts = filteredProducts.filter(product => 
          product.category.id.toString() === category
        );
      }
  
      // Apply brand filter
      if (brand) {
        filteredProducts = filteredProducts.filter(product => 
          product.brand.id.toString() === brand
        );
      }
  
      // Apply status filter
      if (status) {
        filteredProducts = filteredProducts.filter(product => 
          product.status === status
        );
      }
  
      // Calculate pagination
      const startIndex = (page - 1) * limit;
      const endIndex = startIndex + limit;
      const paginatedProducts = filteredProducts.slice(startIndex, endIndex);
  
      // Calculate summary statistics from filtered products
      const summary = filteredProducts.reduce((acc, product) => ({
        totalViews: acc.totalViews + product.views,
        totalCart: acc.totalCart + product.cart,
        totalOrders: acc.totalOrders + product.orders,
        totalRevenue: acc.totalRevenue + product.revenue,
        totalSold: acc.totalSold + product.sold
      }), {
        totalViews: 0,
        totalCart: 0,
        totalOrders: 0,
        totalRevenue: 0,
        totalSold: 0
      });
  
      // Add conversion rate
      summary.conversionRate = ((summary.totalOrders / summary.totalViews) * 100).toFixed(1);
  
      return {
        products: paginatedProducts,
        totalProducts: filteredProducts.length,
        summary
      };
    }
};