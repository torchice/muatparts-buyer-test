import SWRHandler from '@/services/useSWRHook';
const { useSWRHook } = SWRHandler;

const API_URL = `${process.env.NEXT_PUBLIC_GLOBAL_API}v1/`;

// Hook untuk mengambil analisa produk
export function useProductAnalysis(params = {}) {
    const queryString = new URLSearchParams(params).toString();
    
    const {
        data: productAnalysis,
        error: productAnalysisError,
        isLoading: productAnalysisLoading,
        mutate: productAnalysisMutate
    } = useSWRHook(
        `${API_URL}product-analysis?${queryString}`,
        null,
        (error) => {
            console.log("Error in product analysis:", error);
        }
    );
    console.log("productAnalysis");
    console.log(productAnalysis?.Data.summary.totalProducts);

    return {
        data: productAnalysis?.Data.products || [], // Mengambil data dari properti products
        summary: {
            totalViews: productAnalysis?.Data.summary.productViews || 0,
            totalOrders: productAnalysis?.Data.summary.totalOrders || 0,
            totalRevenue: productAnalysis?.Data.summary.totalRevenue || 0,
            totalCart: productAnalysis?.Data.summary.cartAdds || 0,
            totalSold: productAnalysis?.Data.summary.productsSold || 0,
            conversionRate: productAnalysis?.Data.summary.conversionRate || 0
        },
        totalProducts: productAnalysis?.Data.summary.totalProducts || 0,
        isLoading: productAnalysisLoading,
        isError: productAnalysisError,
        mutate: productAnalysisMutate
    };
    
}

// Hook untuk mengambil kategori
export function useProductCategories() {
    const {
        data: categories,
        error: categoriesError,
        isLoading: categoriesLoading,
        mutate: categoriesMutate
    } = useSWRHook(
        `${API_URL}product-categories`,
        null,
        (error) => {
            console.log("Error in categories:", error);
        }
    );

    return {
        categories: categories?.data || [],
        isLoading: categoriesLoading,
        isError: categoriesError,
        mutate: categoriesMutate
    };
}

// Hook untuk mengambil brand
export function useProductBrands() {
    const {
        data: brands,
        error: brandsError,
        isLoading: brandsLoading,
        mutate: brandsMutate
    } = useSWRHook(
        `${API_URL}product-brands`,
        null,
        (error) => {
            console.log("Error in brands:", error);
        }
    );

    return {
        brands: brands?.data || [],
        isLoading: brandsLoading,
        isError: brandsError,
        mutate: brandsMutate
    };
}

// Fungsi untuk mengekspor data
export async function exportProductAnalysis(params = {}) {
    try {
        const response = await fetch(`${API_URL}product-analysis/export`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(params)
        });

        if (!response.ok) throw new Error('Export gagal');

        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'analisa-produk.xlsx';
        document.body.appendChild(a);
        a.click();
        a.remove();

        return { success: true, message: 'Export berhasil' };
    } catch (error) {
        console.error('Error exporting:', error);
        return { success: false, message: 'Gagal mengekspor data' };
    }
}