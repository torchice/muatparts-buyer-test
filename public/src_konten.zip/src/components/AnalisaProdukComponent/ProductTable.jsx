import React, { useState } from 'react';
import IconComponent from "@/components/IconComponent/IconComponent";

export const ProductTable = ({ products = [], loading = true }) => {
  const [sortConfig, setSortConfig] = useState({
    key: null,
    direction: null // null untuk state default/unsorted
  });

  const sortedProducts = React.useMemo(() => {
    if (!sortConfig.key || !sortConfig.direction) return products;

    return [...products].sort((a, b) => {
      const getValue = (obj, path) => {
        return path.split('.').reduce((o, i) => (o ? o[i] : null), obj);
      };

      let aValue = getValue(a, sortConfig.key);
      let bValue = getValue(b, sortConfig.key);

      if (typeof aValue === 'string' && aValue.includes('Rp')) {
        aValue = parseFloat(aValue.replace('Rp', '').replace(/,/g, ''));
        bValue = parseFloat(bValue.replace('Rp', '').replace(/,/g, ''));
      }

      if (typeof aValue === 'string' && aValue.includes('%')) {
        aValue = parseFloat(aValue);
        bValue = parseFloat(bValue);
      }

      if (aValue < bValue) {
        return sortConfig.direction === 'asc' ? -1 : 1;
      }
      if (aValue > bValue) {
        return sortConfig.direction === 'asc' ? 1 : -1;
      }
      return 0;
    });
  }, [products, sortConfig]);

  const handleSort = (key) => {
    setSortConfig((prevConfig) => {
      if (prevConfig.key !== key) {
        return { key, direction: 'asc' };
      }
      
      const states = {
        'asc': 'desc',
        'desc': null,
        'null': 'asc'
      };
      
      return {
        key: states[prevConfig.direction] ? key : null,
        direction: states[prevConfig.direction]
      };
    });
  };

  const getSortIcon = (columnKey) => {
    if (sortConfig.key !== columnKey || !sortConfig.direction) {
      return "/kelolapesanan/icon-sort-inactive.svg";
    }
    return sortConfig.direction === 'asc'
      ? "/kelolapesanan/icon-sort-desc.svg"
      : "/kelolapesanan/icon-sort-asc.svg";
  };

  // Improvement fix wording pak Bryan
  const SkeletonRow = () => (
    <tr className="flex gap-[20px] border border-gray-200">
      <td className="w-[246px] px-4 py-4">
        <div className="flex items-start gap-4">
          <div className="w-16 h-16 bg-gray-200 rounded animate-pulse" />
          <div className="gap-[12px]">
            <div className="h-4 w-32 bg-gray-200 rounded animate-pulse mb-2" />
            <div className="h-3 w-24 bg-gray-200 rounded animate-pulse mb-1" />
            <div className="h-3 w-20 bg-gray-200 rounded animate-pulse" />
          </div>
        </div>
      </td>
      <td className="w-[170px] px-4 py-4">
        <div className="h-4 w-24 bg-gray-200 rounded animate-pulse" />
      </td>
      <td className="w-[64px] px-4 py-4">
        <div className="h-4 w-8 bg-gray-200 rounded animate-pulse" />
      </td>
      <td className="w-[74px] px-4 py-4">
        <div className="h-4 w-8 bg-gray-200 rounded animate-pulse" />
      </td>
      <td className="w-[76px] px-4 py-4">
        <div className="h-4 w-8 bg-gray-200 rounded animate-pulse" />
      </td>
      <td className="w-[82px] px-4 py-4">
        <div className="h-4 w-8 bg-gray-200 rounded animate-pulse" />
      </td>
      <td className="w-[64px] px-4 py-4">
        <div className="h-4 w-8 bg-gray-200 rounded animate-pulse" />
      </td>
      <td className="w-[150px] px-4 py-4">
        <div className="h-4 w-20 bg-gray-200 rounded animate-pulse" />
      </td>
      <td className="w-[50px] px-4 py-4">
        <div className="h-4 w-6 bg-gray-200 rounded animate-pulse" />
      </td>
      <td className="w-[66px] px-4 py-4">
        <div className="h-4 w-8 bg-gray-200 rounded animate-pulse" />
      </td>
      <td className="w-[76px] px-4 py-4">
        <div className="h-6 w-16 bg-gray-200 rounded animate-pulse" />
      </td>
    </tr>
  );

  return (
    <div className="rounded-md border border-gray-200 mt-[20px]">
      <div className="overflow-x-auto no-scrollbartablex overflow-y-auto no-scrollbartabley max-h-[344px]">
        <table className="w-full">
          <thead className="sticky top-0 bg-white">
            <tr className='flex gap-[20px] border border-gray-200'>
              <th onClick={() => handleSort('name')} className="w-[246px] flex gap-[8px] items-center px-4 py-3 text-left AvenirBold12px Color7B7B7B cursor-pointer">
                <div>
                  Nama Produk
                </div>
                <div>
                  <IconComponent src={getSortIcon('name')} classname={''} width={16} height={16} />
                </div>
              </th>
              <th onClick={() => handleSort('category')} className="w-[170px] flex gap-[8px] items-center px-4 py-3 text-left AvenirBold12px Color7B7B7B cursor-pointer">
                <div>
                  Kategori
                </div>
                <div>
                  <IconComponent src={getSortIcon('category')} classname={''} width={16} height={16} />
                </div>
              </th>
              <th onClick={() => handleSort('analytics.views')} className="w-[64px] flex gap-[8px] items-center px-4 py-3 text-left AvenirBold12px Color7B7B7B cursor-pointer">
                <div>
                Dilihat
                </div>
                <div>
                  <IconComponent src={getSortIcon('analytics.views')} classname={''} width={16} height={16} />
                </div>
              </th>
              <th onClick={() => handleSort('analytics.orders')} className="w-[74px] flex gap-[8px] items-center px-4 py-3 text-left AvenirBold12px Color7B7B7B cursor-pointer">
                <div>
                  Pesanan
                </div>
                <div>
                  <IconComponent src={getSortIcon('analytics.orders')} classname={''} width={16} height={16} />
                </div>
              </th>
              <th onClick={() => handleSort('analytics.conversionRate')} className="w-[76px] flex gap-[8px] items-center px-4 py-3 text-left AvenirBold12px Color7B7B7B cursor-pointer">
                <div>
                  Konversi
                </div>
                <div>
                  <IconComponent src={getSortIcon('analytics.conversionRate')} classname={''} width={16} height={16} />
                </div>
              </th>
              <th onClick={() => handleSort('analytics.complaint')} className="w-[82px] flex gap-[8px] items-center px-4 py-3 text-left AvenirBold12px Color7B7B7B cursor-pointer">
                <div>
                  Komplain
                </div>
                <div>
                  <IconComponent src={getSortIcon('analytics.complaint')} classname={''} width={16} height={16} />
                </div>
              </th>
              <th onClick={() => handleSort('analytics.unitsSold')} className="w-[64px] flex gap-[8px] items-center px-4 py-3 text-left AvenirBold12px Color7B7B7B cursor-pointer">
                <div>
                  Terjual
                </div>
                <div>
                  <IconComponent src={getSortIcon('analytics.unitsSold')} classname={''} width={16} height={16} />
                </div>
              </th>
              <th onClick={() => handleSort('analytics.revenue')} className="w-[150px] flex gap-[8px] items-center px-4 py-3 text-left AvenirBold12px Color7B7B7B cursor-pointer whitespace-nowrap">
                <div>
                  Total Pendapatan
                </div>
                <div>
                  <IconComponent src={getSortIcon('analytics.revenue')} classname={''} width={16} height={16} />
                </div>
              </th>
              <th onClick={() => handleSort('analytics.cartAdds')} className="w-[50px] flex gap-[8px] items-center px-4 py-3 text-left AvenirBold12px Color7B7B7B cursor-pointer">
                <div>
                  Troli
                </div>
                <div>
                  <IconComponent src={getSortIcon('analytics.cartAdds')} classname={''} width={16} height={16} />
                </div>
              </th>
              <th onClick={() => handleSort('analytics.favorites')} className="w-[66px] flex gap-[8px] items-center px-4 py-3 text-left AvenirBold12px Color7B7B7B cursor-pointer">
                <div>
                  Favorit
                </div>
                <div>
                  <IconComponent src={getSortIcon('analytics.favorites')} classname={''} width={16} height={16} />
                </div>
              </th>
              <th onClick={() => handleSort('status')} className="w-[76px] flex gap-[8px] items-center px-4 py-3 text-left AvenirBold12px Color7B7B7B cursor-pointer">
                Status
              </th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <>
                <SkeletonRow />
                <SkeletonRow />
                <SkeletonRow />
                <SkeletonRow />
                <SkeletonRow />
              </>
            ) : (
              <>
                {sortedProducts.map((product) => (
                  <tr key={product.id} className="flex gap-[20px] border border-gray-200">
                    <td className="w-[246px] px-4 py-4">
                      <div className="flex items-start gap-4">
                        <img 
                          src={product.mainImage || "/placeholder-product.png"} 
                          alt={product.name} 
                          className="w-16 h-16 object-cover rounded" 
                        />
                        <div className="gap-[12px]">
                          <p className="AvenirBold12px Color000000">{product.name}</p>
                          <p className="AvenirNormal10px Color000000">SKU: {product.sku}</p>
                          <p className="AvenirNormal10px Color000000">Brand: {product.brand}</p>
                        </div>
                      </div>
                    </td>
                    <td className="w-[170px] px-4 py-4 AvenirNormal10px Color000000">{product.category}</td>
                    <td className="w-[64px] px-4 py-4 AvenirNormal10px Color000000">{product.analytics.views}</td>
                    <td className="w-[74px] px-4 py-4 AvenirNormal10px Color000000">{product.analytics.orders}</td>
                    <td className="w-[76px] px-4 py-4 AvenirNormal10px Color000000">{product.analytics.conversionRate}%</td>
                    <td className="w-[82px] px-4 py-4 AvenirNormal10px Color000000">{product.analytics.complaint}</td>
                    <td className="w-[64px] px-4 py-4 AvenirNormal10px Color000000">{product.analytics.unitsSold}</td>
                    <td className="w-[150px] px-4 py-4 AvenirNormal10px Color000000">Rp {product.analytics.revenue?.toLocaleString()}</td>
                    <td className="w-[50px] px-4 py-4 AvenirNormal10px Color000000">{product.analytics.cartAdds}</td>
                    <td className="w-[66px] px-4 py-4 AvenirNormal10px Color000000">
                      <div className="flex gap-[8px] items-center">
                        <IconComponent src={'/icons/Love.svg'} classname={''} width={16} height={16} />
                        {product.analytics.favorites}
                      </div>
                    </td>
                    <td className="w-[76px] px-4 py-4">
                      <span className="w-[76px] h-[24px] py-[4px] px-[8px] rounded-[6px] BgE3F5ED AvenirDemi12px Color0FBBB1">
                        {product.status}
                      </span>
                    </td>
                  </tr>
                ))}
                {sortedProducts.length === 0 && (
                  <tr>
                    <td colSpan="11" className="text-center py-4 AvenirNormal12px Color7B7B7B">
                      Tidak ada data
                    </td>
                  </tr>
                )}
              </>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};