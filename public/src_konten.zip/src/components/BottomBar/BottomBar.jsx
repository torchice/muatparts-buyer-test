import Card from "@/components/Card/Card";
import IconComponent from "@/components/IconComponent/IconComponent";
import * as Icon from "@/icons";
import { sideMenuResponsive } from "@/libs/linkServices";
import { useEffect, useMemo, useState } from "react";
import { useCustomRouter } from "@/libs/CustomRoute";
import ModalComponent from "../Modals/ModalComponent";
import ImageComponent from "../ImageComponent/ImageComponent";
import Button from "../Button/Button";
import { copyToClipboard } from "../KelolaPesananComponent/shared/utils";
import { useTranslation } from "@/context/TranslationProvider";

// LB - 0020 MP - 026
const BottomBar = () => {
  const { tOrEmpty } = useTranslation();
  const [open, setOpen] = useState([]);
  const router = useCustomRouter();

  const [modalAturMassal, setModalAturMassal] = useState(false);
  const [linkAturMassal, setLinkAturMassal] = useState("");
  const [showLinkAturMassal, setShowLinkAturMassal] = useState(false);

  // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0890, LB - 0891, LB - 0892, LB - 0893, LB - 0894
  const sideMenuTranslated = useMemo(() => {
    return sideMenuResponsive.map((item) => ({
      ...item,
      title: tOrEmpty(item.title),
      // just in case the child is not exist in future
      ...(item.child && {
        child: item.child.map((child) => ({
          ...child,
          title: tOrEmpty(child.title),
        }))
      })
    }));
  }, [tOrEmpty]);


  const resetToggle = () => {
    setOpen((prev) => {
      const resetOpen = prev.map((key) => ({
        ...key,
        open: true,
      }));
      return resetOpen;
    });
  };

  const toggleMenu = (key) => {
    setOpen((prev) => {
      const findIndex = open.findIndex((item) => item.title === key.title);

      return prev.map((key, index) => ({
        ...key,
        // just simply toggle the open state of the current key and do not change the other open state, its more predictable
        open: index === findIndex ? !key.open : key.open,
      }));
    });
  };

  useEffect(() => {
    // set menu after translation is done
    setOpen(sideMenuTranslated);
    resetToggle();
  }, [sideMenuTranslated]);

  return (
    <Card classname={"rounded-none border-none py-2 px-4 !shadow-none mb-24"}>
      {open.map((key, index) => {
        return (
          <div
            key={index}
            className="flex text-neutral-900 flex-col font-semibold text-xs select-none relative"
            tabIndex={0}
          >
            <div
              key={index}
              className="flex items-center justify-between cursor-pointer py-3 w-full"
              onClick={() => toggleMenu(key)}
            >
              <div className="flex gap-2 capitalize cursor-pointer items-center">
                <IconComponent src={key.icon} width={20} height={20} />
                <span className="pt-1">{key.title}</span>
              </div>
              {key.child && (
                <IconComponent
                  classname={`${key.open && "rotate-180"} cursor-pointer`}
                  src={Icon.ChevronDownIcon}
                />
              )}
            </div>

            {/* content menu inside jika menu sembunyikan aktif */}
            {key.child && key.open == true && (
              <div key={key.id} className="flex flex-col capitalize">
                {key?.child?.map((key, index) => {
                  return (
                    <div key={index} className="flex h-10 gap-[30px] pr-5">
                      <span
                        key={index}
                        className="w-full flex items-center cursor-pointer pl-[33px] pr-5"
                        onClick={(e) => {
                          // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0901
                          // Fix haruse modal itu cuman muncul di link aturprodukmassal
                          if(key.link.includes("aturprodukmassal")){
                            setModalAturMassal(true);
                            setLinkAturMassal(
                              process.env.NEXT_PUBLIC_ASSET_REVERSE + key.link
                            );
                          } else {
                            router.push(key.link);
                          }
                        }}
                      >
                        {key.title}
                      </span>
                    </div>
                  );
                })}
              </div>
            )}
            <div
              className={`w-full border-[0.9px] border-neutral-400 ${
                index == open.length - 1 && "hidden"
              }`}
            />
          </div>
        );
      })}

      {/* PRIO : 8 - 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - Prio 8 - LB - 0589 */}
      {/* LBM - EKA - Fix gambar konten marketing - 16 Mei 2025 */}
      <ModalComponent
        isOpen={modalAturMassal}
        setClose={() => {setModalAturMassal(false); setShowLinkAturMassal(false)}}
        full
        title={tOrEmpty("AppMuatpartsDashboardSellerFeatureNotAvailableInApp")}
        type="BottomSheet"
      >
        <div className="px-4 pb-6 space-y-4">
          <ImageComponent
            src="/img/akses-pc.png"
            width={200}
            height={200}
            className={"mx-auto"}
          />
          <div className="text-neutral-600 text-center font-semibold">
            {tOrEmpty("AppMuatpartsDashboardSellerCopyLinkBelow")}
          </div>
          <Button
            children={tOrEmpty("AppMuatpartsDashboardSellerSalinLink")}
            iconLeft={
              <ImageComponent
                src="/img/copy.png"
                width={12}
                className={"mb-1"}
              />
            }
            Class="!h-10 !min-w-full"
            onClick={() => {
              setShowLinkAturMassal(true);
              copyToClipboard(linkAturMassal);
            }}
          />
          {showLinkAturMassal && (
            <div className="text-neutral-600 text-center font-semibold">
              {linkAturMassal}
            </div>
          )}
        </div>
      </ModalComponent>
    </Card>
  );
};
// LB - 0020 MP - 026
export default BottomBar;
