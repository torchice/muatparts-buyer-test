"use client";

import { url } from "@/services/url";
import { usePathname } from 'next/navigation';
import IconComponent from "../IconComponent/IconComponent";
import { useCustomRouter } from '@/libs/CustomRoute';
import ImageComponent from '@/components/ImageComponent/ImageComponent';
import { authZustand } from "@/store/auth/authZustand";

const DashboardBottomNavbar = () => {
  const router = useCustomRouter();
  const pathname = usePathname();

  return (
    <div className="z-50 relative hidden sm:block">
      <ImageComponent src="/img/bottom_bar.svg"
        alt=""
        className="w-full fixed -bottom-9"
        width="12"
        height="12"
        onClick={() => router.replace(url.dashboard)
        }
      />
      {/* LB - 0236 25.03 */}
      <div
        className={`flex flex-col gap-0 items-center z-[51] fixed bottom-2 left-12 cursor-pointer ${
          pathname === url.pesananMasuk ? "text-blue-700" : "text-neutral-600"
        }`}
        onClick={() => {
          router.push(
            `${process.env.NEXT_PUBLIC_CHAT_URL}initiate?accessToken=${
              authZustand.getState().accessToken
            }&refreshToken=${
              authZustand.getState().refreshToken
            }&initiatorRole=buyer`
          )
        }}
      >
        <IconComponent
          width={35}
          height={35}
          src="/icons/chat.svg"
          classname="text-neutral-600"
        />
        <span className="capitalize font-medium text-xs">pesan</span>
      </div>

      <div
        className={`flex flex-col gap-0 items-center z-[51] fixed bottom-2 right-12 cursor-pointer  ${
          pathname === url.profile ? "text-blue-700" : "text-neutral-600"
        }`}
        onClick={() => router.replace(url.profile)}
      >
        <IconComponent
          width={35}
          height={35}
          src="/icons/profile.svg"
          classname="text-neutral-600"
        />
        <span className="capitalize font-medium text-xs nav-">profile</span>
      </div>

      <div
        className="fixed bottom-2"
        style={{
          left: "calc(100vw - (50vw + 18px))",
        }}
      >
        <span
          className={`capitalize font-medium text-xs cursor-pointer ${
            pathname === url.dashboard ? "text-blue-700" : "text-neutral-600"
          }`}
        >
          home
        </span>
      </div>
    </div>
  );
};

export default DashboardBottomNavbar;

