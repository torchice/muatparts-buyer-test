
'use client';
import Button from '../Button/Button';
import SwitchButtonMenu from '../SwitchButtonMenu/SwitchButtonMenu';
import ToogleButton from '../ToogleButton/ToogleButton';
import style from './ButtonBottomMobile.module.scss'
function ButtonBottomMobile({textLeft,textRight,onClickLeft,onClickRight,children,classname, leftColor,rightColor,toggleLabelActive,toggleLabelInactive,onToggle,defaultValueToggle,isFixed=true,isSingleButton,textSingleButton,onClickSingleButton,colorButton='primary'}) {
    return(
    <div className={`${style.main} bg-neutral-50 h-fit w-full shadow-2xl flex gap-3 z-50 bottom-0 left-0 rounded-t-[10px] ${isFixed?'fixed':''} ${isSingleButton?'py-3 px-4':''} ${classname}`}>
        {children?children:
        <>
            {isSingleButton?<Button Class='!max-w-full !w-full' onClick={onClickSingleButton} color={colorButton} >{textSingleButton}</Button>:
            <div className='flex flex-col gap-3 w-full'>
                {typeof onToggle==='function' &&<div className='flex px-4 mt-3 gap-2'>
                    <ToogleButton onClick={onToggle} textActive={toggleLabelActive} textInactive={toggleLabelInactive?toggleLabelInactive:toggleLabelActive} value={defaultValueToggle} />
                </div> }   
                <div className='w-full gap-2 py-3 px-4 flex shadow-2xl'>
                    <Button onClick={onClickLeft} Class='!w-full !max-w-full' color={leftColor?leftColor:'primary_secondary'} >{textLeft}</Button>
                    <Button onClick={onClickRight} Class='!w-full !max-w-full' color={rightColor?rightColor:'primary'} >{textRight}</Button>
                </div>
            </div>}
        </>
        }
    </div>
    )
}

export default ButtonBottomMobile;
  