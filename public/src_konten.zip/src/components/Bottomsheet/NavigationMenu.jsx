import React from "react";
import IconComponent from "../IconComponent/IconComponent";
import "../../app/globals.scss";
import "./Bottomsheet.scss";
import { useCustomRouter } from "@/libs/CustomRoute";
import toast from "@/store/zustand/toast";
import { authZustand } from "@/store/auth/authZustand";
import clsx from "clsx";
import { useTranslation } from "@/context/TranslationProvider";

const NavigationMenu = () => {
  const router = useCustomRouter();
  const { dataNavMenu } = toast();
  const { tOrEmpty } = useTranslation();

  // const isHidden = pathname.includes('buatvoucher') ||
  //                  /\/voucherseller\/[^\/]+$/.test(pathname);
  return (
    // <div className="hidden md:flex fixed bottom-0 left-0 right-0 bg-white shadow-lg justify-around items-center h-16 px-10 py-3 shadow-muat">
    // FIX BUG Pengecekan Ronda Muatparts LB-0064
    <div className={clsx("z-50 sm:z-10 relative sm:block", "hidden")}>
      <button
        className={`border-none bg-transparent fixed bottom-11 ${
          dataNavMenu.type === 1
            ? "left-[44%] w-16 h-16"
            : "left-[40%] w-20 h-20"
        } rounded-full z-[51]`}
        onClick={() =>
          dataNavMenu.onClick
            ? dataNavMenu.onClick()
            : router.push(dataNavMenu.action)
        }
      />
      <span className="capitalize text-primary-700 text-xs font-medium z-[51] fixed bottom-2 !w-full !m-auto !text-center !ml-[2px]">
        {dataNavMenu.title}
      </span>
      <div
        className="flex flex-col gap-0 items-center z-[51] fixed bottom-2 left-12 cursor-pointer"
        onClick={() =>
          router.push(
            `${process.env.NEXT_PUBLIC_CHAT_URL}initiate?accessToken=${
              authZustand.getState().accessToken
            }&refreshToken=${
              authZustand.getState().refreshToken
            }&initiatorRole=buyer`
          )
        }
      >
        <IconComponent
          width={35}
          height={35}
          color="gray"
          src="/icons/chat.svg"
        />
        <span className="capitalize font-medium text-neutral-600 text-xs">
          {tOrEmpty("labelPesanBuyer")}
        </span>
      </div>
      <div
        className="flex flex-col gap-0 items-center z-[51] fixed bottom-2 right-12 cursor-pointer"
        onClick={() => router.push("/profileseller")}
      >
        <IconComponent
          width={35}
          height={35}
          color="gray"
          src="/icons/profile.svg"
        />
        <span className="capitalize font-medium text-neutral-600 text-xs nav-">
          {/* 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0971 */}
          {tOrEmpty("HomeSellerIndexProfile")}
        </span>
      </div>
      {/* LBM, penambahan different home img */}
      {dataNavMenu.type === 1 ? (
        <img
          src={process.env.NEXT_PUBLIC_ASSET_REVERSE + "/img/navmenumobile.svg"}
          className="z-50 fixed w-[115%] -bottom-[35px] -left-[26px] max-w-[1000%] main-navmenu"
          alt="navmenu"
          srcSet=""
        />
      ) : (
        <img
          src={process.env.NEXT_PUBLIC_ASSET_REVERSE + "/img/bottom_bar.svg"}
          className="z-50 fixed w-[115%] -left-[26px] max-w-[1000%] !-bottom-[35px]"
          alt="navmenu"
          srcSet=""
        />
      )}
    </div>
  );
};

export default NavigationMenu;
