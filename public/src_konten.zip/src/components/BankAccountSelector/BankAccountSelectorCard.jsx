export function BankAccountSelectorCard({
  bankName,
  accountNumber,
  accountHolder,
  isMain,
  isSelected,
  onSelect,
}) {
  return (
    <div
      className={`flex gap-4 p-3 w-full border-b border-solid border-b-stone-300 ${
        isSelected ? "bg-sky-100" : ""
      }`}
    >
      <div className="flex flex-col flex-1 shrink self-start text-xs basis-0 min-w-0 sm:min-w-[240px]">
        <div className="flex gap-2 items-center w-full flex-wrap">
          <div className="self-stretch my-auto font-bold text-black">
            {bankName}
          </div>
          {isMain && (
            <div className="gap-1 self-stretch py-0.5 px-1 my-auto font-semibold text-white whitespace-nowrap bg-blue-600 rounded">
              Utama
            </div>
          )}
        </div>
        <div className="mt-1 text-sm font-bold text-black">{accountNumber}</div>
        <div className="mt-1 font-semibold text-black">a.n {accountHolder}</div>
      </div>
      <div className="flex flex-col justify-center items-center text-sm font-semibold whitespace-nowrap">
        <button
          onClick={onSelect}
          className={`gap-1 self-stretch px-4 sm:px-6 rounded-3xl border border-solid transition-colors ${
            isSelected
              ? "bg-zinc-100 border-neutral-400 text-neutral-500"
              : "bg-white border-blue-600 text-blue-600 hover:bg-blue-50"
          } min-h-[32px] min-w-[90px] sm:min-w-[112px]`}
          aria-pressed={isSelected}
        >
          {isSelected ? "Terpilih" : "Pilih"}
        </button>
      </div>
    </div>
  );
}
