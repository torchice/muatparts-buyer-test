export function BankAccountSelectorButton({
  children,
  variant = "solid",
  ...props
}) {
  return (
    <button
      className={`flex-1 shrink gap-1 self-stretch px-4 sm:px-6 py-1 rounded-3xl min-h-[32px] 
          transition-colors text-center justify-center items-center flex
          ${
            variant === "outline"
              ? "text-blue-600 bg-white border border-blue-600 border-solid hover:bg-blue-50"
              : "text-white bg-blue-600 hover:bg-blue-700"
          }`}
      {...props}
    >
      {children}
    </button>
  );
}
