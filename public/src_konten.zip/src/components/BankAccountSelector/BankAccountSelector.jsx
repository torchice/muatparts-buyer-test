import MockServer_BankAccount from "@/services/MockServer_BankAccounts";
import useLoadingStore from "@/store/zustand/loading";
import { Dialog, DialogPanel, useClose } from "@headlessui/react";
import { useEffect, useState } from "react";
import { BankAccountSelectorButton } from "./BankAccountSelectorButton";
import { BankAccountSelectorCard } from "./BankAccountSelectorCard";
import ImageComponent from '@/components/ImageComponent/ImageComponent';

export const BankAccountSelector = ({
  isOpen,
  setIsOpen,
  closeArea = true,
  fetchAccount,
}) => {
  const { updateShow } = useLoadingStore();
  const [accounts, setAccounts] = useState([]);
  const [selectedAccount, setSelectedAccount] = useState(null);

  let close = useClose();

  const closeModal = () => {
    close();
  };

  const handleAddAccount = () => {
    console.log("handleAddAccount");
  };

  const handleAccountSelect = async (id) => {
    setSelectedAccount(id);
  };

  const handleSaveAccount = async () => {
    try {
      updateShow(true);
      await MockServer_BankAccount.setMainAccount(selectedAccount);
      fetchAccount();
      setIsOpen(false);
    } catch (error) {
    } finally {
      updateShow(false);
    }
  };

  const fetchData = async () => {
    const res = (await MockServer_BankAccount.getBankAccounts()).Data;
    const selected = res.accounts.find((acc) => acc.isFund === true)?.id ?? "";

    setAccounts(res.accounts);
    setSelectedAccount(selected);
  };

  useEffect(() => {
    fetchData();
  }, [isOpen]);

  return (
    <Dialog
      open={isOpen}
      onClose={closeArea ? setIsOpen : () => {}}
      transition
      className="fixed inset-0 flex w-screen items-center justify-center bg-black/30 p-4 z-[51] transition duration-300 ease-out data-[closed]:opacity-0"
    >
      <div
        className="fixed inset-0 flex w-screen items-center justify-center p-4"
        onClick={closeModal}
      >
        <DialogPanel className={`relative w-full`}>
          <div className="flex overflow-hidden relative flex-col px-4 sm:px-6 py-6 sm:py-8 leading-tight bg-white rounded-xl w-[470px] max-w-[470px] mx-auto">
            <div className="flex z-0 flex-col w-full">
              <div className="text-base font-bold text-black">
                Pilih Rekening Pencairan
              </div>
              <div className="flex flex-col mt-4 w-full">
                <div className="flex overflow-hidden flex-col w-full">
                  {accounts.map((account) => (
                    <BankAccountSelectorCard
                      key={account.id}
                      {...account}
                      isSelected={selectedAccount === account.id}
                      onSelect={() => handleAccountSelect(account.id)}
                    />
                  ))}
                </div>
              </div>
              <div className="flex flex-row sm:flex-col gap-3 items-stretch sm:items-start mt-4 w-full text-sm font-semibold">
                <BankAccountSelectorButton
                  variant="outline"
                  onClick={handleAddAccount}
                >
                  Tambah Rekening
                </BankAccountSelectorButton>
                <BankAccountSelectorButton
                  variant="solid"
                  onClick={handleSaveAccount}
                >
                  Simpan
                </BankAccountSelectorButton>
              </div>
            </div>
            <button
              className="absolute top-2 right-1 z-0 w-5 h-5"
              onClick={() => console.log("Close selector")}
              aria-label="Close account selector"
            >
              <ImageComponent loading="lazy"
                src="/img/bluecross.svg"
                alt=""
                width={10}
                height={10}
                className="object-contain"
                onClick={() => setIsOpen(false)}
              />
            </button>
          </div>
        </DialogPanel>
      </div>
    </Dialog>
  );
};

