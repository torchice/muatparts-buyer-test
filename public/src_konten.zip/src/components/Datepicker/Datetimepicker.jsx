"use client";

import React, { useState } from "react";
import "./Datepicker.scss";
import propTypes from "prop-types";
import Button from "@/components/Button/Button";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import IconComponent from "../IconComponent/IconComponent";

// terdapat prop value untuk mengirim value dari komponen ke parent nantinya, pastikan prop ini di parent langsung di isi setter dari use state.
// pastikan prop value yang dikirim di convert dahulu dalam format date beserta time nya (new Date("2024-10-03T14:24:00")).
// Anda dapat menggunakan fungsi datetimeAPItoFE() yang terdapat pada services.js untuk merubah format sesuai yang dibutuhkan komponen ini (new Date(datetimeAPItoFE(<<value dari API>>)))
const Datetimepicker = ({ value, props }) => {
  const [openDate, setOpenDate] = useState(null);
  const [temp, setTemp] = useState();

  return (
    <div className="container-datetimepicker">
      <DatePicker
        // tabIndex={0}
        // tidak bisa input manual
        onKeyDown={(e) => e.preventDefault()}
        onBlur={() => setOpenDate(false)}
        onFocus={() => setOpenDate(true)}
        className={`!p-0 !px-2 !py-2 !text-xs rounded-md border border-neutral-200 w-44 font-semibold text-neutral-900`}
        showIcon
        icon={
          <IconComponent
            classname={"absolute top-1 right-2"}
            size={"medium"}
            src={"/icons/calendar.svg"}
          />
        }
        // tidak ter close ketika select
        shouldCloseOnSelect={false}
        open={openDate}
        // menampilkan jam
        showTimeSelect
        placeholderText="Tanggal Awal"
        // menutup tanggal ketika scroll
        closeOnScroll={true}
        popperPlacement="bottom"
        toggleCalendarOnIconClick
        disabledKeyboardNavigation
        timeFormat="HH:mm"
        dateFormat="dd MMM YYYY HH:mm"
        // set value yang terpilih
        selected={temp}
        onChange={(date) => setTemp(date)}
        {...props}
      >
        <div className="inline-flex gap-2 border-t border-t-neutral-300">
          <Button
            Class="rounded-sm"
            onClick={() => {
              value(temp);
              setTemp("");
              setOpenDate(false);
            }}
          >
            Batal
          </Button>
          <Button
            Class="rounded-sm"
            onClick={() => {
              value(temp);
              setOpenDate(false);
            }}
          >
            Terapkan
          </Button>
        </div>
      </DatePicker>
    </div>
  );
};

Datetimepicker.propTypes = {
  value: propTypes.any.isRequired,
};
export default Datetimepicker;
