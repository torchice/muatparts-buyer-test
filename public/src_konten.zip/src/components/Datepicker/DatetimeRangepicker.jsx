"use client";

import React, { useState } from "react";
import "./Datepicker.scss";
import Button from "@/components/Button/Button";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import IconComponent from "../IconComponent/IconComponent";
import propTypes from "prop-types";

// prop startDate berisi value tanggal mulai yang ditangkap pada komponen ini
// prop endDate berisi value tanggal akhir yang ditangkap pada komponen ini
// prop setStartDate untuk melakukan set data tanggal mulai untuk parent
// prop setEndDate untuk melakukan set data tanggal akhir untuk parent
// pastikan seluruh prop menghasilkan value (new Date("2024-10-03T14:24:00")).
// Anda dapat menggunakan fungsi datetimeAPItoFE() yang terdapat pada services.js untuk merubah format sesuai yang dibutuhkan komponen ini (new Date(datetimeAPItoFE(<<value dari API>>)))

const Datetimepicker = ({ startDate, endDate, setStartDate, setEndDate }) => {
  const [openStartDate, setOpenStartDate] = useState(false);
  const [openEndDate, setOpenEndDate] = useState(false);
  const [tempStart, setTempStart] = useState(startDate);
  const [tempEnd, setTempEnd] = useState(endDate);

  return (
    <div className="flex items-center gap-2 ">
      <div className="container-datetimepicker ">
        <DatePicker
          // tabIndex={0}
          // tidak bisa input manual
          onKeyDown={(e) => e.preventDefault()}
          onBlur={() => setOpenStartDate(false)}
          onFocus={() => {
            setOpenStartDate(true);
            setOpenEndDate(false);
          }}
          className={`!p-0 !px-2 !py-2 !text-xs rounded-md border w-44 font-semibold text-neutral-900 border-[#d8d8d8]`}
          showIcon
          icon={
            <IconComponent
              classname={"absolute top-1 right-2"}
              size={"medium"}
              src={"/icons/calendar.svg"}
            />
          }
          // tidak ter close ketika select
          shouldCloseOnSelect={false}
          open={openStartDate}
          // jam
          showTimeSelect
          placeholderText="Tanggal Awal"
          closeOnScroll={true}
          popperPlacement="bottom"
          // first pick date
          selectsStart
          toggleCalendarOnIconClick
          disabledKeyboardNavigation
          timeFormat="HH:mm"
          dateFormat="dd MMM YYYY HH:mm"
          // set value yang terpilih
          selected={tempStart}
          onChange={(date) => setTempStart(date)}
          startDate={tempStart}
          endDate={tempEnd}
        >
          <div className="inline-flex gap-2 border-t border-t-neutral-300">
            <Button
              Class="rounded-sm"
              onClick={() => {
                setTempStart(startDate);
                setOpenStartDate(false);
              }}
            >
              Batal
            </Button>
            <Button
              Class="rounded-sm"
              onClick={() => {
                setStartDate(tempStart);
                setOpenStartDate(false);
              }}
            >
              Terapkan
            </Button>
          </div>
        </DatePicker>
      </div>
      <span className="text-neutral-900 font-semibold text-xs">s/d</span>
      <div className="container-datetimepicker ">
        <DatePicker
          // tabIndex={0}
          // tidak bisa input manual
          onKeyDown={(e) => e.preventDefault()}
          onBlur={() => setOpenEndDate(false)}
          onFocus={() => {
            setOpenStartDate(false);
            setOpenEndDate(true);
          }}
          className={`!p-0 !px-2 !py-2 !text-xs rounded-md border w-44 font-semibold text-neutral-900 border-[#d8d8d8]`}
          showIcon
          icon={
            <IconComponent
              classname={"absolute top-1 right-2"}
              size={"medium"}
              src={"/icons/calendar.svg"}
            />
          }
          // tidak ter close ketika select
          shouldCloseOnSelect={false}
          open={openEndDate}
          // jam
          showTimeSelect
          placeholderText="Tanggal Akhir"
          closeOnScroll={true}
          popperPlacement="bottom"
          // last pick date
          selectsEnd
          toggleCalendarOnIconClick
          disabledKeyboardNavigation
          timeFormat="HH:mm"
          dateFormat="dd MMM YYYY HH:mm"
          // set value yang terpilih
          selected={tempEnd}
          onChange={(date) => setTempEnd(date)}
          startDate={tempStart}
          endDate={tempEnd}
          minDate={tempStart}
        >
          <div className="inline-flex gap-2 border-t border-t-neutral-300">
            <Button
              Class="rounded-sm"
              onClick={() => {
                setTempEnd(endDate);
                setOpenEndDate(false);
              }}
            >
              Batal
            </Button>
            <Button
              Class="rounded-sm"
              onClick={() => {
                setEndDate(tempEnd);
                setOpenEndDate(false);
              }}
            >
              Terapkan
            </Button>
          </div>
        </DatePicker>
      </div>
    </div>
  );
};

Datetimepicker.propTypes = {
  startDate: propTypes.any.isRequired,
  endDate: propTypes.any.isRequired,
  setStartDate: propTypes.any.isRequired,
  setEndDate: propTypes.any.isRequired,
};
export default Datetimepicker;
