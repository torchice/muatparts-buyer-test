function BankAccountCard({ account, isSelected, onSelect }) {
  return (
    <div className="flex flex-col pb-4 w-full border-b border-solid border-b-stone-300 mt-4 first:mt-0">
      <div className="flex gap-3 items-start w-full">
        <div className="flex gap-2 items-center w-4">
          <input
            type="radio"
            id={account.id}
            name="bankAccount"
            checked={isSelected}
            onChange={() => onSelect(account.id)}
            className="w-4 h-4 cursor-pointer accent-primary-600"
          />
        </div>
        <label
          htmlFor={account.id}
          className="flex flex-1 shrink gap-2 items-center pt-0.5 text-sm font-semibold leading-none text-black basis-0 min-w-[240px] cursor-pointer"
        >
          <div className="flex gap-2 items-center w-full">
            <div className="flex flex-col flex-1 shrink self-stretch my-auto w-full basis-0 min-w-[240px]">
              <div className="font-bold">{account.bankName}</div>
              <div className="mt-1">{account.accountNumber}</div>
              <div className="mt-1 text-xs leading-tight">
                a.n {account?.accountHolder.toUpperCase()}
              </div>
              {account.isMain && (
                <div className="gap-1 self-start px-2 py-1 mt-1 text-sky-100 whitespace-nowrap bg-blue-600 rounded-md min-h-[24px] text-sm">
                  Utama
                </div>
              )}
            </div>
          </div>
        </label>
      </div>
    </div>
  );
}

export default BankAccountCard;
