
'use client';
import IconComponent from '../IconComponent/IconComponent';
import style from './CardPesananSeller.module.scss'
import Button from '../Button/Button';
import ImageComponent from '../ImageComponent/ImageComponent';
import { useCustomRouter } from '@/libs/CustomRoute';
import { authZustand } from '@/store/auth/authZustand';
import { numberFormatMoney } from '@/libs/NumberFormat';
function CardPesananSeller({
    status_pesanan,
    id,
    invoice_number,
    order_date,
    cancellation_date,
    expired_at,
    user_id,
    status,
    payment_status,
    buyer_status,
    status_info,
    customer,
    shipping,
    products,
    total_amount,
    response_limit,
    handleActionButton,
    val:allData
}) {
    const router = useCustomRouter()
    const { accessToken, refreshToken } = authZustand();

    const handleContactBuyer = () => {
        const data = {
            recipientRole: "buyer",
            recipientId: 3755,
            initiatorRole: "seller",
            initiatorId: "",
            menuName: "Muatparts",
            subMenuName: "Muatparts",
            message: "Oi ga rilis2",
            accessToken,
            refreshToken
        }
        const queryString = new URLSearchParams(data).toString()
        window.location.href = `http://localhost:3009/initiate?${queryString}`;
        router.push(`http://localhost:3009/initiate?${queryString}`)
    }
    return (
        <div className={`${style.main} flex-col border border-neutral-400 rounded-[10px] w-full bg-neutral-50 text-neutral-900`}>
            <div className='pb-5 pt-[18px] px-8 flex flex-col gap-5'>
                <div className="flex justify-between">
                    <div className='flex gap-1 items-center'>
                        <span className="py-1 px-8 rounded-md bg-primary-50 text-primary-700 semi-xs">{invoice_number}</span>
                        {/* <div className="flex gap-1 select-none cursor-pointer">
                            <span className='medium-xs text-primary-700'>Cetak Invoice</span>
                            <IconComponent src={'/icons/document-blue.svg'}/>
                        </div> */}
                    </div>
                    {/* <div className='flex gap-3 items-center'>
                        <span className="medium-xs text-neutral-600">Pembayaran : <span className="text-neutral-900">28 Aug 2021 17.08 WIB</span></span>
                        <span className={`py-1 px-2 rounded-md bg-warning-100 text-warning-900 semi-xs`}>Perlu Respon 02:10:20</span>
                    </div> */}
                </div>
                <div className="flex flex-col gap-3">
                    {products?.map(val=><div key={val?.id} className="flex justify-between gap-6">
                        <div className='flex gap-5 items-start'>
                            {val?.image_url&&<ImageComponent width={56} height={56} src={process.env.NEXT_PUBLIC_ASSET_REVERSE+'/img/chopper.png'} alt='product' />}
                            <div className="flex flex-col gap-3 py-[2px]">
                                <span className="bold-xs">{val?.name}</span>
                                {/* <span className='font-medium text-[10px]'>Tipe : A</span> */}
                                {val?.sku&&<span className='font-medium text-[10px]'>SKU : {val?.sku}</span>}
                                {val?.catatan&&<span className='font-medium text-[10px] line-clamp-1'>Catatan : {val?.catatan}</span>}
                            </div>
                        </div>
                        <div className="flex gap-6 item-start">
                            <div className="flex flex-col gap-2 min-w-[114px]">
                                <div className="flex gap-2 item-center text-neutral-600">
                                    <IconComponent src={'/icons/troller.svg'} />
                                    <span className="medium-xs">Jumlah</span>
                                </div>
                                <span className='medium-xs'>{val?.quantity}</span>
                            </div>
                            <div className="flex flex-col gap-2 min-w-[200px]">
                                <div className="flex gap-2 item-center text-neutral-600">
                                    <IconComponent src={'/icons/tangan-budha.svg'} />
                                    <span className="medium-xs">Harga Penjualan</span>
                                </div>
                                {!!(val?.discount)&&<div className="flex flex-col gap-2">
                                    <strike className="medium-xs text-[10px]">{numberFormatMoney(val?.price)}</strike>
                                    <div className='flex gap-3 items-center'>
                                        <span className="text-error-400 bold-xs text-[10px]">{numberFormatMoney(val?.price_promo)}</span>
                                        <span className="py-1 px-2 rounded-md bg-success-50 text-success-400">{val?.discount} % OFF</span>
                                    </div>
                                </div>}
                                {!val.discount&&<span className="medium-xs text-[10px]">{numberFormatMoney(val?.price)}</span>}
                            </div>
                            <div className="flex flex-col gap-2 min-w-[140px]">
                                <div className="flex gap-2 item-center text-neutral-600">
                                    <IconComponent src={'/icons/user-truck.svg'} />
                                    <span className="medium-xs">Kurir</span>
                                </div>
                                <div className='flex flex-col gap-3'>
                                    <span className='medium-xs'>{shipping?.courier}</span>
                                    <span className='medium-xs'>{shipping?.method}</span>
                                </div>
                            </div>
                        </div>
                    </div>)}
                    {/* {products.length>1&&<div className="flex gap-2 item-center text-primary-700 mt-6 select-none cursor-pointer">
                        <span className="medium-xs">+ {products.length-1} Produk Lainnya</span>
                        <IconComponent src={'/icons/chevron-down.svg'} classname={'icon-blue'} />
                    </div>} */}
                </div>
            </div>
            <div className='pb-5 pt-[18px] px-8 flex justify-between items-center border-y border-neutral-400'>
                <span className="bold-sm">Total Pesanan</span>
                <span className="bold-sm">{numberFormatMoney(total_amount)}</span>
            </div>
            <div className='pb-5 pt-[18px] px-8 flex justify-between items-center'>
                <div className="flex gap-2 items-center">
                    {customer?.image_url&&<ImageComponent src={customer?.image_url} width={30} height={30} alt='photo' />}
                    <span className="semi-sm">{customer?.name}</span>
                </div>
                <div className="flex gap-3 item-center">
                    {
                        status_pesanan?.find(val=>val?.id==buyer_status)?.action_button_detail?.map(val=><Button Class='!h-8' onClick={()=>handleActionButton(val?.buttonText,allData)} color={val?.color} key={val?.buttonText}>{val?.buttonText}</Button>)
                    }
                    
                </div>
            </div>
        </div>
    );
}

export default CardPesananSeller;
  