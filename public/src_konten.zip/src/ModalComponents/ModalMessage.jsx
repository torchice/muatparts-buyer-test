import React, {useContext} from 'react'
import { StateContext } from "@/common/StateContext";

const ModalMessage = () => {
  const {props} = useContext(StateContext);
  return (
    <div className={'flex flex-col gap-[24px] items-center text-neutral-900 py-[36px] px-[24px]'}>
        <p className={`text-neutral-900 font-[500] text-[14px]`}>{props.message}</p>
    </div>
  )
}

export default ModalMessage
