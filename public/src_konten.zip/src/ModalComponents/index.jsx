import React, { useContext } from "react";
import style from "./index.module.scss";
import { StateContext } from "@/common/StateContext";
import ExampleModal, { listModalComponents } from "./serviceModal";
import HeaderModalWindow from "@/container/HeaderModalWindow/HeaderModalWindow";
function ModalComponentsIndex() {
  const { modalId, isLoading, withHeader, props } = useContext(StateContext);
  const { id, component: Modal } =
    listModalComponents.find((val) => val.id === modalId) || {};
  return (
    <div className={`${style.main} ${isLoading && style.bgLoading}`}>
      {id === modalId && <HeaderModalWindow />}
      <Modal {...props} />
    </div>
  );
}

export default ModalComponentsIndex;
