import React from 'react'
import style from './MetodeVerifikasi.module.scss'
import Button from '@/components/Button/Button'

const MetodeVerifikasi = () => {
  return (
    <div className={`py-[36px] px-[24px] flex flex-col gap-[24px] items-center justify-center h-auto`}>
      <h1 className={`font-[700] text-[16px] text-center leading-[16px]`}>Pilih Metode Verifikasi</h1>
      <span className={`font-[500] text-[14px] text-center leading-[16px] max-w-[300px]`}>Pilih salah satu metode dibawah ini untuk mendapatkan kode verifikasi</span>
      <div className='flex flex-col gap-[12px] w-full'>
        <div className='border-[1px] rounded-[6px] flex gap-[8px] py-[16px] px-[8px] w-full items-center'>
            <img src="/icons/wa-verifikasi.svg" className='w-[24px] h-[24px]' alt="" />
            <div className='flex flex-col'>
                <h1 className='font-[500] text-[12px] leading-[14px] text-neutral-900'>WhatsApp</h1>
                <span className='font-[500] text-[12px] leadding-[14px] text-neutral-600'>Nomor WA</span>
            </div>
        </div>
        <div className='border-[1px] rounded-[6px] flex gap-[8px] py-[16px] px-[8px] w-full items-center'>
          <img src="/icons/email-verifikasi.svg" className='w-[24px] h-[24px]' alt="" />
              <div className='flex flex-col'>
                  <h1 className='font-[500] text-[12px] leading-[14px] text-neutral-900'>Email</h1>
                  <span className='font-[500] text-[12px] leadding-[14px] text-neutral-600'>Email</span>
              </div>
          </div>
        </div>
        <Button color="primary" disabled={true}>Verifikasi</Button>
    </div>
  )
}

export default MetodeVerifikasi