import BreadCrumb from '@/components/BreadCrumb/BreadCrumb';
import Input from '@/components/Input/Input'
import React,{useContext, useEffect, useRef,useState} from 'react'
import style from './KategoriAddProduct.module.scss'
import { useForm } from 'react-hook-form';
import DataNotFound from '@/components/DataNotFound/DataNotFound';
import { highlightText } from '@/libs/TypographServices';
import debounce from "lodash/debounce";
import addProductState from "@/store/zustand/produk/tambahProduk";
import SWRHandler from "@/services/useSWRHook";
import { GenerateCategories } from '@/libs/services';
import { categoriesZustand } from '@/store/zustand/categories/categoriesZustand';
import IconComponent from '@/components/IconComponent/IconComponent';
import { set } from 'lodash';
import { StateContext } from '@/common/StateContext';



const data = ['Group Category','Category','Sub Category','Item']
const KategoriAddProduct = () => {
    const {closeModal}=useContext(StateContext)
    const { useSWRHook, useSWRMutateHook } = SWRHandler;
    const { informasiProduk, validation, setProducts, setValidation } =
    addProductState();
    const {categories:dataCategories,breadCrumbCategories,setBreadCrumbCategories}= categoriesZustand()
    const [category,setCategory]=useState()
    const [categories,setCategories]=useState([])
    const [getBreadcrumbs,setBreadcrumbs]=useState([])
    const [selectedCategory,setSelectedCateogry]=useState()
    const {
        data: search_category,
        error: search_category_error,
        // trigger: search_category_trigger,

        isMutating,
      } = useSWRHook(
        process.env.NEXT_PUBLIC_GLOBAL_API + `muatparts/product/search_category?keyword=${category}&product=${informasiProduk.ProductName}`);
console.log(search_category)
    const search = useRef();
    const changeSearch = () => {
        //(search.current.value)
    }
    function handleSubmitInput(){
        //(category)
    }
    function handleSelectedCategory(val){
        if(val?.children?.length) {
            setBreadcrumbs(prev=>([...prev,{id:val?.id,value:val?.value}]))
            setCategories(val?.children)
        }else{
            setProducts('informasiProduk','Categories',{
                GroupcategoryID: getBreadcrumbs?.[0]?.['id']?getBreadcrumbs?.[0]?.['id']:null,
                CategoryID: getBreadcrumbs?.[1]?.['id']?getBreadcrumbs?.[1]?.['id']:null,
                SubcategoryID: getBreadcrumbs?.[2]?.['id']?getBreadcrumbs?.[2]?.['id']:null,
                ItemID: getBreadcrumbs?.[3]?.['id']?getBreadcrumbs?.[3]?.['id']:null,
            })
            setProducts('informasiProduk','category',getBreadcrumbs)
            setBreadCrumbCategories(categories)
            setBreadcrumbs([])
            setCategories(dataCategories)
            closeModal()
        }
    }
    const onSearchValue = debounce((e) => {
        setCategory(e.target.value)
        // search_category_trigger({
        //     keyword: e.target.value,
        //     product: informasiProduk.ProductName
        // })
    },500)
    useEffect(()=>{
        if(dataCategories.length) setCategories(dataCategories)
    },[dataCategories])
    useEffect(()=>{
        if(informasiProduk?.Categories?.length&&informasiProduk?.category?.length) setBreadcrumbs(informasiProduk?.category)
        if(breadCrumbCategories?.length) setCategories(breadCrumbCategories)
    },[])
    return (
        <>
            <form onSubmit={(e)=>{
                e.preventDefault()
                handleSubmitInput()}} className={`flex flex-col py-[32px] px-[24px] w-[471px] max-h-[466px]`}>
                {
                    getBreadcrumbs?.length?
                    <div className='flex flex-col gap-4'>
                        <span className='font-bold text-base text-neutral-900 text-center'>{getBreadcrumbs.at(-1)?.['value']}</span>
                        <BreadCrumb maxWidth={'90px'} data={[{id:'home',value:'Semua Kategori'},...getBreadcrumbs]} onclick={val=>{
                            let tmp = getBreadcrumbs?.filter(a=>a?.id!==val?.id)
                            setBreadcrumbs(tmp)
                        }} />
                    </div>
                    :<>
                        <div className={`flex flex-col items-center gap-4`}>
                            <span className={`text-neutral-900 text-[16px] text-center font-[700]`}>Kategori</span>
                            <Input ref={search} placeholder="Cari Nama Kategori" 
                                width={{width: '100%'}} icon={{left: '/icons/search.svg'}} changeEvent={onSearchValue} value={category} />
                        </div>
                        <div className={`mt-4`}>
                            <span className={`text-neutral-900 text-[16px] font-[700]`}>{(search_category?.length&&category)?'Hasil Pencarian':'Semua Kategori'}</span> 
                        </div>
                    </>
                }
                {categories.length&&<ul className='list-none overflow-y-auto'>
                    {
                        categories.map(val=>{
                            return(<li key={val.id} className='py-3 border-b border-neutral-400 cursor-pointer w-full' onClick={()=>handleSelectedCategory(val)}>
                                <div className='w-full flex justify-between items-center'>
                                    <span className='text-neutral-900 text-xs font-semibold'>{val?.value}</span>
                                    {val?.children?.length?<IconComponent src='/icons/chevron-right.svg' width={20}  />:<></>}
                                </div>
                            </li>)
                        })
                    }
                </ul>}
                {(search_category?.length&&category)?<ul className='list-none overflow-y-auto'>

                    {/* <li className='py-3 border-b border-neutral-400 cursor-pointer'>
                        <BreadCrumb data={data?.map(val=> highlightText(category,val))} disableActive maxWidth={100} classname={style.BreadCrumb} />
                    </li>
                    <li className='py-3 border-b border-neutral-400 cursor-pointer'>
                        <BreadCrumb data={data} disableActive maxWidth={100} classname={style.BreadCrumb} />
                    </li>
                    <li className='py-3 border-b border-neutral-400 cursor-pointer'>
                        <BreadCrumb data={data} disableActive maxWidth={100} classname={style.BreadCrumb} />
                    </li>
                    <li className='py-3 border-b border-neutral-400 cursor-pointer'>
                        <BreadCrumb data={data} disableActive maxWidth={100} classname={style.BreadCrumb} />
                    </li> */}
                </ul>:(!search_category?.length&&category)?<DataNotFound title={'Keyword Tidak Ditemukan'} />:''}
                {(!search_category?.length&&category)?<><div className={`mt-4`}>
                    <span className={`text-neutral-900 text-[16px] font-[700]`}>Penjual Lain Juga Memasang {} di kategori</span> 
                </div>
                <ul className='list-none overflow-y-auto'>
                    <li className='py-3 border-b border-neutral-400 cursor-pointer'>
                        <BreadCrumb data={data?.map(val=> highlightText(category,val))} disableActive maxWidth={'100px'} classname={style.BreadCrumb} />
                    </li>
                    <li className='py-3 border-b border-neutral-400 cursor-pointer'>
                        <BreadCrumb data={data?.map(val=> highlightText(category,val))} disableActive maxWidth={'100px'} classname={style.BreadCrumb} />
                    </li>
                    <li className='py-3 border-b border-neutral-400 cursor-pointer'>
                        <BreadCrumb data={data} disableActive maxWidth={'100px'} classname={style.BreadCrumb} />
                    </li>
                    <li className='py-3 border-b border-neutral-400 cursor-pointer'>
                        <BreadCrumb data={data} disableActive maxWidth={'100px'} classname={style.BreadCrumb} />
                    </li>
                </ul></>:''}
            </form>
        </>
    )
}

export default KategoriAddProduct