import Button from '@/components/Button/Button'
import style from './AturMasalVariantModal.module.scss' 
import Input from '@/components/Input/Input'
import TableComponent from '@/components/TableComponent/TableComponent'
import addProductState from '@/store/zustand/produk/tambahProduk'
import Checkbox from '@/components/Checkbox/Checkbox'
import { useContext, useState } from 'react'
import { numberFormatMoney, ThousandSeparator } from '@/libs/NumberFormat'
import InputHandler from '@/libs/inputHandler'
import { StateContext } from '@/common/StateContext'
const AturMasalVariantModal = ()=>{ 
    const {closeModal}=useContext(StateContext)
    const {handleChangeInput} = new InputHandler()
    const [getVariantId,setVariantId]=useState([])
    const [getState,setState]=useState({
        Price:0,
        Stock:0,
        SKU:'',
        Weight:0
    })
    const [getValidation,setValidation]=useState([])
    const {informasiPenjualan:{varian,Variants},setProducts} = addProductState()
    function handleCheckVariant(val,checked) {
        if(checked) setVariantId(a=>([...a,val]))
        else setVariantId(getVariantId?.filter(a=>a!=val))
    }
    function handleTerapkan() {
        let newVariants = Variants?.map(val=>{
            if(getVariantId?.some(a=>a===val?.ID)){
                let SKU=getState?.SKU??val?.SKU
                return {
                    ...val,
                    Price:getState?.Price,
                    Stock:getState?.Stock,
                    SKU:SKU,
                    Weight:getState?.Weight
                }
            }
            return val
        })
        setProducts('informasiPenjualan','Variants',newVariants)
        closeModal()
    }
    return ( 
        <div className="flex flex-col gap-3 justify-center items-center p-6">
            <span className="text-[#1b1b1b] font-bold text-base">Atur Massal</span>
            <div className="border border-neutral-400 rounded-xl p-3 bg-neutral-50 flex flex-col gap-3">
                <div className="rounded-xl bg-primary-50 py-3 px-8 flex gap-4">
                    <div className="flex flex-col gap-2">
                        <span className="text-neutral-600 font-bold text-xs">Harga*</span>
                        <Input 
                        changeEvent={e=>{
                            handleChangeInput({
                                value:e.target.value,
                                errMsg:'',
                                key:'Price',
                                setValidation:setValidation,
                                validation:getValidation
                            })
                            setState(a=>({...a,Price:parseInt(e.target.value.replaceAll(/\./g, ""), 10)}))}
                        } 
                        value={getState?.Price?ThousandSeparator(getState?.Price):''} 
                        icon={{left:<span className='text-neutral-900'>Rp</span>}} 
                        placeholder='Contoh : 1.000.000' className={'bg-white'}  />
                    </div>
                    <div className="flex flex-col gap-2">
                        <span className="text-neutral-600 font-bold text-xs">Stok*</span>
                        <Input changeEvent={e=>{
                            handleChangeInput({
                                value:e.target.value,
                                errMsg:'',
                                key:'Stock',
                                setValidation:setValidation,
                                validation:getValidation
                            })
                            setState(a=>({...a,Stock:e.target.value}))}} value={getState?.Stock?getState?.Stock:''} placeholder='Contoh : 1' className={'bg-white'} />
                    </div>
                    <div className="flex flex-col gap-2">
                        <span className="text-neutral-600 font-bold text-xs">Kode SKU <span className='text-xs font-normal'>(Optional)</span></span>
                        <Input changeEvent={e=>{
                            handleChangeInput({
                                value:e.target.value,
                                errMsg:'',
                                key:'Weight',
                                setValidation:setValidation,
                                validation:getValidation
                            })
                            setState(a=>({...a,SKU:e.target.value}))}} value={getState?.SKU?getState?.SKU:''} placeholder='Contoh : SKU' className={'bg-white'} />
                    </div>
                    <div className="flex flex-col gap-2">
                        <span className="text-neutral-600 font-bold text-xs">Berat*</span>
                        <Input changeEvent={e=>setState(a=>({...a,Weight:e.target.value}))} value={getState?.Weight?getState?.Weight:''} placeholder='Contoh : 1' className={'bg-white'} />
                    </div>
                </div>
                {/* <TableComponent classname={style.tableHeader} colums={varian?.map(a=>a?.ID)} checkboxField={[varian?.[0]?.['ID']?.trim()]} onChangeChecke d={(e)=>console.log(e)} > */}
                <div className={`${style.main} ${style.tableHeader}`}>
                <table className='w-full'>
                    <thead>
                            <tr>
                            {

                                varian?.map((val,i)=><th key={val?.ID} className={`${style.th} ${i==0?'flex items-center gap-5':''}`}>
                                    {i==0?<Checkbox onChange={(e)=>{
                                        if(e?.checked) setVariantId(Variants?.map(a=>a?.ID))
                                        else setVariantId([])
                                    }} label='' />:''}
                                    <span>{val?.ID}</span>
                                </th>)
                            }
                            </tr>
                    </thead>
                    <tbody>
                        {
                            Variants?.map((val,index)=>{
                                return(
                                    <tr key={`variant-row-${index}`} className='py-3 h-10 border-b border-neutral-400 last:border-b-0'>
                                        <td className='py-3' key={`first-${index}`}>
                                            <div className='flex items-center gap-5'>
                                                <Checkbox checked={getVariantId?.some(a=>a===val?.ID)} onChange={a=>handleCheckVariant(val?.ID,a?.checked)} label='' />
                                                <span>{val?.VariantFirstOpsi}</span>
                                            </div>
                                        </td>
                                        <td className='py-3' key={`second-${index}`}>{val?.VariantSecondOpsi}</td>
                                    </tr>
                                )
                            })
                        }
                    </tbody>
                </table>
                </div>
                {/* </TableComponent> */}
            </div>
            <div className='flex w-full justify-between items-center'>
                <span className="text-[#1b1b1b] font-bold text-base">Atur Massal : {getVariantId.length}/{Variants?.length}</span>
                <Button disabled={!getVariantId.length} onClick={handleTerapkan}>Terapkan</Button>
            </div>
        </div> 
    ) 
}
export default AturMasalVariantModal