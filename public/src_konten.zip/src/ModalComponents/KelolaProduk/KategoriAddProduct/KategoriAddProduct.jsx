import BreadCrumb from "@/components/BreadCrumb/BreadCrumb";
import Input from "@/components/Input/Input";
import React, {
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
} from "react";
import style from "./KategoriAddProduct.module.scss";
import { useForm } from "react-hook-form";
import DataNotFound from "@/components/DataNotFound/DataNotFound";
import { highlightText } from "@/libs/TypographServices";
// import debounce from "lodash/debounce";
import addProductState from "@/store/zustand/produk/tambahProduk";
import SWRHandler from "@/services/useSWRHook";
import { GenerateCategories } from "@/libs/services";
import CategoriesHandler from "@/libs/CategoriesHandler";
import debounce from "@/libs/debounce";
import { StateContext } from "@/common/StateContext";
import IconComponent from "@/components/IconComponent/IconComponent";
import selectedCategories from "@/store/zustand/produk/categories";

const data = ["Group Category", "Category", "Sub Category", "Item"];
const KategoriAddProduct = ({ categories, closeModal, setCategories, t }) => {
  const { useSWRHook, useSWRMutateHook } = SWRHandler;
  const { informasiProduk, validation, setProducts, setValidation } =
    addProductState();

  const [category, setCategory] = useState();
  const [getAllCategories, setAllCategories] = useState([]);
  const [getSelectedCategories, setSelectedCategories] = useState([]);
  const [categorySearch, setCategorySearch] = useState();
  const { generateCategoriesToList } = CategoriesHandler;
  const {
    data: search_category,
    error: search_category_error,
    mutate,
    isLoading,
    // trigger: search_category_trigger,
    // isMutating,
  } = useSWRHook(
    categorySearch
      ? process.env.NEXT_PUBLIC_GLOBAL_API +
          `v1/muatparts/product/search_category?keyword=${categorySearch}${
            informasiProduk.ProductName
              ? `&product=${informasiProduk?.ProductName}`
              : ""
          }`
      : null
  );

  const search = useRef();
  const changeSearch = () => {
    //(search.current.value)
  };
  function handleSubmitInput() {
    //(category)
  }
  function handleChooseCategoryNested(val) {
    let index = getSelectedCategories?.length;
    let field = ["GroupcategoryID", "CategoryID", "SubcategoryID", "ItemID"];
    setProducts("informasiProduk", "category", [
      ...getSelectedCategories?.map((val) => val?.value),
      val?.value,
    ]);
    setProducts("informasiProduk", "Categories", {
      ...informasiProduk?.Categories,
      [field[index]]: val?.id,
    });
    setSelectedCategories((a) => [...a, { id: val?.id, value: val?.value }]);
    setAllCategories(val?.children);
    if (!val?.children?.length) {
      setSelectedCategories([]);
      setCategories({
        category: [
          ...getSelectedCategories?.map((val) => val?.value),
          val?.value,
        ],
        Categories: {
          ...informasiProduk?.Categories,
          [field[index]]: val?.id,
        },
      });
      closeModal();
    }
  }
  function handleBreadCrumb(val) {
    let tmp = getSelectedCategories;
    let getIndex = tmp.findIndex((a) => a.id === val?.id);
    if (getIndex === -1) return setSelectedCategories(tmp);
    let newTmp = tmp.slice(0, getIndex + 1);
    if (getIndex == 0)
      setAllCategories(categories.find((a) => a?.id == val?.id)?.["children"]);
    if (getIndex == 1) {
      let lvl1 = categories.find(
        (a) => a?.id === getSelectedCategories?.[0]?.["id"]
      )?.["children"];
      setAllCategories(lvl1.find((a) => a.id === val.id)?.["children"]);
    }
    if (getIndex == 2) {
      let lvl1 = categories.find(
        (a) => a?.id === getSelectedCategories?.[0]?.["id"]
      )?.["children"];
      let lvl2 = lvl1.find(
        (a) => a?.id === getSelectedCategories?.[1]?.["id"]
      )?.["children"];
      setAllCategories(lvl2.find((a) => a.id === val.id)?.["children"]);
    }
    // yasha
    // setAllCategories(tmp[getIndex+1]['children'])
    setSelectedCategories(newTmp);
  }
  const onSearchValue = useCallback(
    debounce((e) => {
      setCategorySearch(e);
    }, 700),
    []
  );
  useEffect(() => {
    if (categories?.length) setAllCategories(categories);
  }, [categories]);
  return (
    <>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSubmitInput();
        }}
        className={`flex flex-col gap-4 py-[32px] px-[24px] w-[471px] max-h-[466px]`}
      >
        <div className={`flex flex-col items-center gap-4`}>
          <span
            className={`text-neutral-900 text-[16px] text-center font-[700]`}
          >
            {/* LB - 0652, LB - 0653, LB - 0654 - 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 */}
            {getSelectedCategories?.length
              ? getSelectedCategories?.[getSelectedCategories?.length - 1]
                  ?.value
              : t("columnCategory")}
          </span>
          {getSelectedCategories.length ? (
            ""
          ) : (
            <Input
              ref={search}
              placeholder={t("labelPlaceholderCariKategori")}
              width={{ width: "100%" }}
              icon={{ left: "/icons/search.svg" }}
              changeEvent={(e) => {
                setCategory(e.target.value);
                onSearchValue(e?.target?.value);
              }}
              value={category}
            />
          )}
        </div>
        {category ? (
          <div className={``}>
            <span className={`text-neutral-900 text-[16px] font-[700]`}>
              {t("labelSearchResult")}
            </span>
          </div>
        ) : (
          ""
        )}
        {search_category?.Data?.search?.length ? (
          <ul className="list-none overflow-y-auto">
            {search_category?.Data?.search?.map((val, i) => {
              return (
                <li
                  key={i}
                  className="py-3 border-b border-neutral-400 cursor-pointer"
                  onClick={() => {
                    setProducts("informasiProduk", "category", val?.value);
                    setProducts("informasiProduk", "Categories", {
                      GroupcategoryID: val?.id?.[0],
                      CategoryID: val?.id?.[1],
                      // optional
                      SubcategoryID: val?.id?.[2],
                      // optional
                      ItemID: val?.id?.[3],
                    });
                    if (!val?.children?.length) {
                      setCategories({
                        category: informasiProduk?.category,
                        Categories: informasiProduk?.Categories,
                      });
                      closeModal();
                    }
                  }}
                >
                  <BreadCrumb
                    data={val?.value}
                    disableActive
                    maxWidth={100}
                    classname={style.BreadCrumb}
                  />
                </li>
              );
            })}
          </ul>
        ) : (
          ""
        )}
        {!category ? (
          <>
            {getSelectedCategories.length ? (
              <BreadCrumb
                data={getSelectedCategories}
                onclick={handleBreadCrumb}
              />
            ) : (
              <div className={``}>
                <span className={`text-neutral-900 text-[16px] font-[700]`}>
                  {t("dropdownSemuaKategori")}
                </span>
              </div>
            )}
            <ul className="list-none overflow-y-auto">
              {getAllCategories?.map((val) => {
                return (
                  <li
                    key={val?.id}
                    className="py-3 border-b border-neutral-400 cursor-pointer flex w-full justify-between"
                    onClick={() => handleChooseCategoryNested(val)}
                  >
                    <span className="semi-xs text-neutral-900">
                      {val?.value}
                    </span>
                    {val?.children?.length ? (
                      <span className="w-5 h-5">
                        <IconComponent src={"/icons/chevron-right.svg"} />
                      </span>
                    ) : (
                      ""
                    )}
                  </li>
                );
              })}
            </ul>
          </>
        ) : (
          ""
        )}
        {(search_category_error?.status == 404 ||
          !search_category?.Data?.search?.length) &&
        category &&
        !isLoading ? (
          <DataNotFound
            title={t("DetailPesananIklanIndexKeywordTidakDitemukan")}
            classname={""}
            width={71}
            height={61}
          />
        ) : (
          ""
        )}

        {(search_category_error?.status == 404 ||
          !search_category?.Data?.search?.length) &&
        category &&
        !isLoading ? (
          <>
            <div className={`mt-4`}>
              <span className={`text-neutral-900 text-[16px] font-[700]`}>
                Penjual lain juga memasang {categorySearch} di kategori
              </span>
            </div>
            <ul className="list-none overflow-y-auto">
              {generateCategoriesToList(categories)?.map((val) => {
                return (
                  <li
                    key={val?.id}
                    className="py-3 border-b border-neutral-400 cursor-pointer"
                    onClick={() => {
                      setProducts(
                        "informasiProduk",
                        "category",
                        val?.map((val) => val?.value)
                      );
                      setProducts("informasiProduk", "Categories", {
                        GroupcategoryID: val?.[0]?.id,
                        CategoryID: val?.[1]?.id,
                        // optional
                        SubcategoryID: val?.[2]?.id,
                        // optional
                        ItemID: val?.[3]?.id,
                      });
                      if (!val?.children?.length) {
                        setCategories({
                          category: informasiProduk?.category,
                          Categories: informasiProduk?.Categories,
                        });
                        closeModal();
                      }
                    }}
                  >
                    <BreadCrumb
                      data={val}
                      disableActive
                      maxWidth={100}
                      classname={style.BreadCrumb}
                    />
                  </li>
                );
              })}
            </ul>
          </>
        ) : (
          ""
        )}
      </form>
    </>
  );
};

export default KategoriAddProduct;
