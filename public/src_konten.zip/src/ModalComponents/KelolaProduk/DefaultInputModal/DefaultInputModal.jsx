import Input from "@/components/Input/Input";
import { useState, useContext } from "react";
import Button from "@/components/Button/Button";
import { StateContext } from "@/common/StateContext";
import style from "./DefaultInputModal.module.scss";
import { useTranslation } from "@/context/TranslationProvider";

const DefaultInputModal = ({ handleSimpanTambahBonus }) => {
  // LB - 0652, LB - 0653, LB - 0654 - 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2
  const { t } = useTranslation();
  const { closeModal } = useContext(StateContext);
  const [val, setVal] = useState("");
  // 24. THP 2 - MOD001 - MP - 005 - QC Plan - Web - MuatParts - Paket 011 A - Seller - Daftar Produk - LB - 0176
  const [validation, setValidation] = useState("");

  return (
    <div className="py-8 px-6 bg-white flex flex-col gap-6 justify-center items-center">
      <span className="text-neutral-900 text-base font-bold">
        {t("labelMasukkanBonusKamu")}
      </span>
      <Input
        classname={`${style.input} ${validation ? "input-error" : ""}`}
        value={val}
        changeEvent={(e) => {
          if (e.target.value.length <= 50) {
            setValidation("");
            setVal(e.target.value);
          }
        }}
        placeholder={t("AppKelolaProdukMuatpartsExampleGuarantee")}
        supportiveText={{ title: validation || "", desc: `${val.length}/50` }}
      />
      <div className="flex gap-2">
        <Button
          color="primary_secondary"
          onClick={() => {
            closeModal();
            setVal("");
          }}
        >
          {t("labelBatalButton")}
        </Button>
        <Button
          onClick={() => {
            if (!val) {
              return setValidation(
                t("AppKelolaProdukMuatpartsBonusNameMandatory")
              );
            }
            handleSimpanTambahBonus(val);
            closeModal();
          }}
        >
          {t("labelSimpanButton")}
        </Button>
      </div>
    </div>
  );
};
export default DefaultInputModal;
