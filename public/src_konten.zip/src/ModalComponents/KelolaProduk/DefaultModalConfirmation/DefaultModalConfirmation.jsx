import Button from '@/components/Button/Button'
import style from './DefaultModalConfirmation.module.scss' 
 const DefaultModalConfirmation = ({
    children,
    text,
    buttonNoText,
    buttonYesText,
    buttonNoClick,
    buttonYesClick,
    buttonNoColor,
    buttonYesColor,
 })=>{
 return ( 
 <div className={style.main}>
    {children?children:<>
        <span className="text-sm font-medium text-center">{text}</span>
        <div className="flex gap-2 items-center">
            <Button Class='h-8' onClick={buttonNoClick} color={buttonNoColor?buttonNoColor:'primary_secondary'}>{buttonNoText?buttonNoText:'Batal'}</Button>
            <Button Class='h-8' onClick={buttonYesClick} color={buttonYesColor?buttonYesColor:'primary'}>{buttonYesText?buttonYesText:'Ya'}</Button>
        </div>
    </>}
 </div> 
 ) 
 }
 export default DefaultModalConfirmation