import { useContext, useCallback, useEffect, useState } from "react";
import style from "./TambahVarianModal.module.scss";
import Input from "@/components/Input/Input";
import Button from "@/components/Button/Button";
import { StateContext } from "@/common/StateContext";
import addProductState from "@/store/zustand/produk/tambahProduk";
import viewport from "@/store/zustand/common";
import toast from "@/store/zustand/toast";
import useScreen from "@/store/zustand/screens";
import { useTranslation } from "@/context/TranslationProvider";

const TambahVarianModal = ({
  isEdit,
  handleShowVariant = () => {},
  handleSimpanVarian,
}) => {
  // LB - 0652, LB - 0653, LB - 0654 - 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2
  const { t } = useTranslation();
  const { isMobile } = viewport();
  const { setShowBottomsheet, showBottomsheet } = toast();
  const { informasiPenjualan, setProducts } = addProductState();
  const [validation, setValidation] = useState("");
  const { closeModal } = useContext(StateContext);
  const { currentScreen, setScreen, popScreen } = useScreen();
  const handleInput = (e) => {
    if (e.target.value.length <= 20) {
      if (e.target.value) setValidation("");
      else setValidation(t("messageTipeVarianRequired"));
      setProducts("informasiPenjualan", "inputVarian", e.target.value);
    }
  };
  const handleSetProduct = useCallback(() => {
    let val = informasiPenjualan["varian"] || [];
    if (!informasiPenjualan["inputVarian"]) {
      setValidation(t("messageTipeVarianRequired"));
      return;
    }
    if (
      informasiPenjualan["varian"].length &&
      informasiPenjualan["varian"]?.some(
        (a) =>
          a?.ID.toLowerCase() ===
          informasiPenjualan["inputVarian"].toLowerCase()
      )
    )
      return setValidation("Tipe varian tidak boleh sama");
    if (typeof isEdit === "object")
      val[isEdit.index]["ID"] = informasiPenjualan["inputVarian"];
    else {
      val.push({
        ID: informasiPenjualan["inputVarian"],
        Opsi: [""],
      });
    }
    setProducts("informasiPenjualan", "varian", val);
    setProducts("informasiPenjualan", "inputVarian", "");
    // setScreen('variant')
    isMobile ? handleSimpanVarian?.() : closeModal();
    // setScreen({screen:'variant',title:'Varian'})
  }, [informasiPenjualan]);
  useEffect(() => {
    if (isEdit?.val)
      setProducts("informasiPenjualan", "inputVarian", isEdit?.val);
  }, [isEdit]);
  useEffect(() => {
    if (!showBottomsheet) setProducts("informasiPenjualan", "inputVarian", "");
  }, [showBottomsheet]);

  if (isMobile) {
    return (
      <div className={style.mainRespoonsive + " flex flex-col gap-9"}>
        <div className="relative w-full">
          <Input
            autoFocus
            placeholder={t("labelPlaceholderTipeVarian")}
            classname={`${style.inputVarian} ${validation ? style.error : ""}`}
            value={informasiPenjualan["inputVarian"]}
            changeEvent={handleInput}
          />
          {validation ? (
            <span
              className={`text-[12px] font-medium absolute left-0 -bottom-5 text-error-400`}
            >
              {validation}
            </span>
          ) : (
            ""
          )}
          <span
            className={`text-neutral-600 text-[12px] font-medium absolute right-0 -bottom-5 ${
              validation ? style.errorText : ""
            }`}
          >
            {informasiPenjualan["inputVarian"]?.length || 0}/20
          </span>
        </div>
        <Button onClick={handleSetProduct} Class={style.saveResponsive}>
          Simpan
        </Button>
      </div>
    );
  }
  return (
    <div className={`${style.main}`}>
      <span className="text-neutral-900 text-base font-bold">
        {t("labelTambahTipeVarian")}
      </span>
      <div className="relative w-full">
        <Input
          autoFocus
          placeholder={t("labelPlaceholderTipeVarian")}
          classname={`${style.inputVarian} ${validation ? style.error : ""}`}
          value={informasiPenjualan["inputVarian"]}
          changeEvent={handleInput}
        />
        {validation ? (
          <span
            className={`text-[12px] font-medium absolute left-0 -bottom-5 text-error-400`}
          >
            {validation}
          </span>
        ) : (
          ""
        )}
        <span
          className={`text-neutral-600 text-[12px] font-medium absolute right-0 -bottom-5 ${
            validation ? style.errorText : ""
          }`}
        >
          {informasiPenjualan["inputVarian"]?.length || 0}/20
        </span>
      </div>
      <div className="mt-1 flex gap-2">
        <Button color="primary_secondary" onClick={() => closeModal()}>
          {t("labelBatalButton")}
        </Button>
        <Button onClick={handleSetProduct}>{t("labelSimpanButton")}</Button>
      </div>
    </div>
  );
};

export default TambahVarianModal;
