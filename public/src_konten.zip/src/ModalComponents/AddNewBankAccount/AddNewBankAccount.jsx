"use client"
import React, { useState } from 'react'
import style from './AddNewBankAccount.module.scss'
import Dropdown from '@/components/Dropdown/Dropdown'
import Input from '@/components/Input/Input'
import IconComponent from '@/components/IconComponent/IconComponent'
import Checkbox from '@/components/Checkbox/Checkbox'
import Button from '@/components/Button/Button'
function AddNewBankAccount() {
    const [getSearch,setSearch]=useState('')
    const [getSelected,setSelected]=useState([])
    const [getValidation,setValidation]=useState({
        error:false,
        text:''
    })
    const data=[]
  return (
    <div className={style.main}>
      <span className='font-bold text-base text-neutral-900 text-center'>Input Rekening Pencarian</span>
      <div className='flex justify-between items-center'>
        <span className='text-neutral-600 text-xs font-medium'>Nomor Bank*</span>
        <Dropdown classname="!w-[274px]" options={[]} onSearchValue={a=>setSearch(a)} onSelected={a=>setSelected(a)} placeholder="Pilih Bank" />
      </div>
      <div className='flex justify-between items-center'>
        <span className='text-neutral-600 text-xs font-medium'>Nomor Rekening*</span>
        <div className='flex flex-col gap-2'>
            <Input classname={`${getValidation.error?'input-error':''} w-[274px]`} placeholder="Masukkan Nomor Rekening" icon={{right:<span className='text-xs font-medium text-neutral-500 hover:text-primary-800 cursor-pointer'>Periksa</span>}} />
            {
                getValidation.error&&<span className='text-xs font-medium text-error-400'>{getValidation.text}</span>
            }
        </div>
      </div>
      {
        !!data.length&&<div className='flex justify-between items-center'>
        <span className='text-neutral-600 text-xs font-medium'>Nomor Bank*</span>
        <div className='flex flex-col gap-4'>
            <span className='text-xs font-medium text-neutral-900'>Nama dari norek</span>
            <Checkbox label='Jadikan sebagai rekening utama' checked={true} onChange={a=>console.log(a)} disabled={true} />
        </div>
      </div>
      }
      <div className='w-full flex py-4 px-6 rounded-md bg-secondary-100'>
        {/* <IconComponent/> */}
        <span className='text-xs font-medium text-neutral-900'>Rekening Bank akan digunakan sebagai rekening tujuan pencairan dana kamu</span>
      </div>
      {!!data.length&&<div className='flex gap-2'>
        <Button Class='h-8' color='primary_secondary'>Batal</Button>
        <Button Class='h-8'>Simpan</Button>
        </div>}
    </div>
  )
}

export default AddNewBankAccount
