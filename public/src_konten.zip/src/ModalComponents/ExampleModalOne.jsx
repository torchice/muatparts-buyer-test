import React from "react";

function ExampleModalOne() {
  return (
    <div className={`shadow-xl`} onClick={(e) => e.stopPropagation()}>
      <div className="rounded-b-[12px] w-full py-4 px-2 gap-8">
        <p className="text-3xl capitalize">content here</p>
      </div>
    </div>
  );
}

export default ExampleModalOne;

export const BubbleFilterModal = () => {
  return (
    <div className={`shadow-xl`} onClick={(e) => e.stopPropagation()}>
      <div className="rounded-b-[12px] w-full py-4 px-2 gap-8">
        <p className="text-3xl capitalize">content here DI BUBBLE FILTER</p>
      </div>
    </div>
  );
};
