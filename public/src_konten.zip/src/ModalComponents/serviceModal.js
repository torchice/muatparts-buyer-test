import { FillModal } from "@/libs/versionBrowser";
import {
  ConfirmationClosed,
  ModalTambahBrand,
  ModalTambahRekening
} from "@/app/kelolaproduk/tambahproduk/TambahProdukPage";
import {
  AktifkanProdukModal,
  KonfirmasiProdukModal,
} from "@/app/kelolaproduk/daftarproduk/(partials)/AktifkanProduk";
import { ConfirmationFormAddModal } from "@/app/kelolaproduk/tambahproduk/TambahProdukPageResponsive";
import {
  EditStockModal,
  EditHargaModal,
  EditStockVariantModal,
  EditHargaVariantModal,
} from "@/app/kelolaproduk/daftarproduk/(partials)/ListDataProduk";
import KategoriAddProduct from "./KelolaProduk/KategoriAddProduct/KategoriAddProduct";
import ModalMessage from "./ModalMessage";
import TambahVarianModal from "@/ModalComponents/KelolaProduk/TambahVarianModal/TambahVarianModal";
import AturMasalVariantModal from "@/ModalComponents/KelolaProduk/AturMasalVariantModal/AturMasalVariantModal";
import DefaultInputModal from "@/ModalComponents/KelolaProduk/DefaultInputModal/DefaultInputModal";
import DefaultModalConfirmation from "@/ModalComponents/KelolaProduk/DefaultModalConfirmation/DefaultModalConfirmation";
import ManajemenLokasiModal from "@/components/ManajemenLokasi/ManajemenLokasi";
import { KonfirmasiCloseModal } from "../container/FormContainer/TambahProdukContainer/InformasiPenjualan/HargaGrosirResponsive";
import { ModalVariant } from "@/container/FormContainer/TambahProdukContainer/InformasiPenjualan/InformasiPenjualan";
import MetodeVerifikasi from './MetodeVerifikasi/MetodeVerifikasi'
import AddNewBankAccount from "./AddNewBankAccount/AddNewBankAccount";
import DoneRegisterModal from "@/container/Register/DoneRegisterModal";
import { ModalKonfirmasiHapusRekening, ModalRekeningBank, modalVerifikasiOTPRekening } from "@/container/RekeningPencairanContainer/RekeningPencairanWeb";
import { ModalOnboardingProdukMasal } from "@/container/AturProdukMassalContainer/ModalOnboardingProdukMasal";


export const listModalComponents = [
  {
    id: "browserversion",
    component: FillModal,
  },
  {
    id: "aktifkanproduk",
    component: AktifkanProdukModal,
  },
  {
    id: "ConfirmationFormAdd",
    component: ConfirmationFormAddModal,
  },
  {
    id: "ConfirmationFormAddWeb",
    component: ConfirmationClosed,
  },
  {
    id: "manajemenlokasi",
    component: ManajemenLokasiModal,
  },
  {
    id: "konfirmasiproduk",
    component: KonfirmasiProdukModal,
  },
  {
    id: "konfirmsukeluarresp",
    component: KonfirmasiCloseModal,
  },
  {
    id: "tambah_varian",
    component: TambahVarianModal,
  },
  {
    id: "kategori",
    component: KategoriAddProduct,
  },
  {
    id: "edit_stock",
    component: EditStockModal,
  },
  {
    id: "edit_stock_variant",
    component: EditStockVariantModal,
  },
  {
    id: "edit_harga",
    component: EditHargaModal,
  },
  {
    id: "edit_harga_variant",
    component: EditHargaVariantModal,
  },
  {
    id: "tambah_brand",
    component: ModalTambahBrand,
  },
  {
    id: "modal_message",
    component: ModalMessage,
  },
  {
    id: "atur_massal_varian",
    component: AturMasalVariantModal,
  },
  {
    id: "tambah_bonus_modal",
    component: DefaultInputModal,
  },
  {
    id: "default_modal_confirm",
    component: DefaultModalConfirmation,
  },
  {
    id: "modal_variant",
    component: ModalVariant,
  },
  {
    id: "tambah_rekening_baru",
    component: ModalRekeningBank
  },
  {
    id: "metode_verifikasi",
    component: MetodeVerifikasi
  },
  {
    id: "hapus_rekening",
    component: ModalKonfirmasiHapusRekening,
  },
  {
    id: "done_register",
    component: DoneRegisterModal,
  },
  {
    id: "modal_verifikasi_otp",
    component: modalVerifikasiOTPRekening
  },
  {
    id: "modal_tambah_rekening",
    component: ModalTambahRekening
  },
  {
    // Improvement Konten Marketing by Ce Nola
    id: "modal_onboarding_produk_masal",
    component: ModalOnboardingProdukMasal
  }
];
