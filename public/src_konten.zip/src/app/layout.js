import localFont from "next/font/local";
import "./globals.scss";
import Loading from "@/components/Loading/Loading";
import "rsuite/dist/rsuite.min.css";
import "rsuite/dist/rsuite.min.css";
import MainApp from "@/common/MainApp";
import { Suspense } from "react";
// import "react-datepicker/dist/react-datepicker.module.css"

export const metadata = {
  title: "muatparts Seller",
  description: "Jalan Mudah Bersama",
  // LBM - EKA - PERUBAHAN ICON DISAMAKAN DENGAN TAHAP 1 MENGGUNAKAN FAVICON GENERATOR - 12 Mei 2025
  icons: {
    icon: [
      { url: '/favicon-32x32.png', sizes: '32x32', type: 'image/png' },
      { url: '/favicon-16x16.png', sizes: '16x16', type: 'image/png' }
    ],
    apple: [
      { url: '/apple-touch-icon.png', sizes: '180x180', type: 'image/png' }
    ]
  },
  manifest: '/site.webmanifest'
};

const Avenir = localFont({
  src: [
    {
      path: "../fonts/AvenirNextLTPro-Bold.otf",
      weight: "700",
      style: "bolder",
    },
    {
      path: "../fonts/AvenirNextLTPro-Demi.otf",
      weight: "600",
      style: "bold",
    },
    {
      path: "../fonts/AvenirNextLTPro-Medium.otf",
      weight: "500",
      style: "normal",
    },
    {
      path: "../fonts/AvenirNextLTPro-Regular.otf",
      weight: "400",
      style: "lighter",
    },
  ],
});

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className={Avenir.className + " bg-[#ffff]"}>
        <Suspense fallback={<Loading />}>
          <div className="relative flex">
            <div
              className={`sm:px-0 sm:overflow-hidden bg-neutral-100 w-full h-full min-h-dvh max-h-dvh sm:h-lvh`}
            >
              <MainApp>{children}</MainApp>
            </div>
          </div>
        </Suspense>
      </body>
    </html>
  );
}
