"use client";

import { useEffect } from "react";
import Kenapa from "@/container/LandingContainer/Kenapa";
import Hero from "@/container/LandingContainer/Hero";
import Kenali from "@/container/LandingContainer/Kenali";
import Transaksi from "@/container/LandingContainer/Transaksi";
import Step from "@/container/LandingContainer/Step";
import Penjual from "@/container/LandingContainer/Penjual";
import Faq from "@/container/LandingContainer/Faq";
import Join from "@/container/LandingContainer/Join";
import Footer from "@/container/LandingContainer/Footer";
import toast from "@/store/zustand/toast";
import headerZustand from "@/store/zustand/header";
import { useMatrixCheck } from "@/container/LandingContainer/useMatrixCheck";
import Modal from "@/components/AI/Modal";
import { userZustand } from "@/store/auth/userZustand";
import { useHeader } from "@/common/ResponsiveContext";

export default function LandingMuatParts() {
  const { setShowNavMenu } = toast();
  const { setHeader, setBackIcon, setDataMatrix, dataMatrix } = headerZustand();
  const { dataUser } = userZustand();
  const { checkMatrixVerification } = useMatrixCheck();
  const { clearScreen, setScreen, screen } = useHeader();

  // LB - 0803 - 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2
  useEffect(() => {
    setScreen("landing");
  }, []);

  useEffect(() => {
    if (screen === "landing") {
      clearScreen();
    }
  }, [screen]);

  // Reset state saat unmount
  // useEffect(() => {
  //   return () => {
  //     setDataLogin(null);
  //     setDataMatrixLS(null);
  //     apiCallRef.current = false;
  //   };
  // }, []);

  useEffect(() => {
    setShowNavMenu(false);
    setHeader("");
    setBackIcon(false);
  }, []);

  const handleCheckMatrix = () => {
    checkMatrixVerification(dataMatrix);
  };

  return (
    <div className="flex flex-col rounded-none w-full sm:w-auto m-[-25px_auto_-20px_auto] sm:!-mt-[56px] bg-white sm:pt-0">
      <Modal />
      <Hero />
      <Kenapa dataLogin={dataUser} handleAuthLanding={handleCheckMatrix} />
      {window.innerWidth < 550 ? (
        <Kenali />
      ) : (
        <div className="mx-auto bg-slate-50 w-[1280px] flex justify-center">
          <Kenali />
        </div>
      )}
      <Transaksi />
      <Step dataLogin={dataUser} handleAuthLanding={handleCheckMatrix} />
      <Penjual />
      {window.innerWidth < 550 ? (
        <Faq />
      ) : (
        <div className="mx-auto bg-slate-50 w-full flex justify-center">
          <Faq />
        </div>
      )}
      <Join dataLogin={dataUser} handleAuthLanding={handleCheckMatrix} />
      <Footer />
    </div>
  );
}
