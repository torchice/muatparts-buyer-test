// app/tambahetalase/susunproduk/page.jsx
'use client';

import React, { useState, useEffect } from 'react';
import { useCustomRouter } from '@/libs/CustomRoute';
import { ChevronLeft, GripVertical, Info } from 'lucide-react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import useSusunProdukStore from '@/store/susunProdukStore';
import { MockServer_TambahEtalase } from '@/services/MockServer_TambahEtalase';
import Toast from '@/components/Toast/Toast';
import { useLanguage } from '@/providers/LanguageProvider';
import toast from "@/store/zustand/toast";
import ImageComponent from '@/components/ImageComponent/ImageComponent';
import Button from "@/components/Button/Button";

export default function SusunProdukPage() {
  const router = useCustomRouter();
  const { t, currentLocale, changeLanguage, loading: langLoading } = useLanguage();
  const { products, setProducts, reorderProducts } = useSusunProdukStore();
  const [loading, setLoading] = useState(false);
  const [showInfoTooltip, setShowInfoTooltip] = useState(false);
  const { showToast, setShowToast, setDataToast } = toast();

  // Separate products into available and out of stock
  const availableProducts = products.filter(p => p.stock > 0);
  const outOfStockProducts = products.filter(p => p.stock === 0);

  const handleDragEnd = (result) => {
    if (!result.destination) return;

    const items = Array.from(availableProducts);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);

    // Combine with out of stock products
    const newOrder = [...items, ...outOfStockProducts];
    reorderProducts(newOrder);
  };

  const handleSave = async () => {
    try {
      setLoading(true);
      await MockServer_TambahEtalase.reOrderPositionProduct({
        products: products.map((product, index) => ({
          productId: product.id,
          position: index + 1
        }))
      });

      setDataToast({
        type: 'success',
        message: t('Berhasilmenyusunurutanproduk')
      });
      setShowToast(true);

      // Navigate back after success toast
      setTimeout(() => {
        router.back();
      }, 1500);
    } catch (error) {
      setDataToast({
        type: 'error',
        message: t('Gagalmenyusunurutanproduk')
      });
      setShowToast(true);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen   w-full">
      <h1 className="text-xl font-bold">{t('susunProduk')}</h1>
      
      <div className="text-sm text-[#7b7b7b]">
        {t('susunUrutanProduk')}
      </div>

      <div className="sticky top-0 z-10 bg-white border-b border-gray-200">
        <div className =" py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <button onClick={() => router.back()}>
                <ChevronLeft className="w-6 h-6 text-[#176CF7]" />
              </button>
              <h1 className="text-xl font-bold">{t('SusunProduk')}</h1>
              <button 
                className="ml-2"
                onMouseEnter={() => setShowInfoTooltip(true)}
                onMouseLeave={() => setShowInfoTooltip(false)}
              >
                <Info className="w-5 h-5 text-gray-400" />
              </button>
              {showInfoTooltip && (
                <div className="absolute mt-8 p-3 bg-black text-white text-sm rounded-lg max-w-xs">
                  {t('Susunurutanprodukkamudengantekanpanahpadasalahsatuprodukdangeserkeatasataukebawah')}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className =" py-4">
        <DragDropContext onDragEnd={handleDragEnd}>
          <Droppable droppableId="products">
            {(provided) => (
              <div
                {...provided.droppableProps}
                ref={provided.innerRef}
                className="bg-white rounded-xl shadow-lg divide-y"
              >
                {/* Available Products */}
                {availableProducts.map((product, index) => (
                  <Draggable
                    key={product.id}
                    draggableId={product.id}
                    index={index}
                  >
                    {(provided, snapshot) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        className={`p-4 ${
                          snapshot.isDragging ? 'bg-blue-50' : ''
                        } hover:bg-gray-50`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4">
                            <ImageComponent
                              src={product.image}
                              alt={product.name}
                              width={56}
                              height={56}
                              className="w-14 h-14 rounded object-cover"
                            />
                            <div>
                              <div className="font-medium">{product.name}</div>
                              <div className="text-sm text-[#7b7b7b]">
                              {t('SKU')}: {product.sku}
                              </div>
                              <div className="text-sm text-[#7b7b7b]">
                              {t('Brand')}: {product.brand}
                              </div>
                            </div>
                          </div>
                          <div {...provided.dragHandleProps}>
                            <GripVertical className="w-6 h-6 text-gray-400 hover:text-[#176CF7]" />
                          </div>
                        </div>
                      </div>
                    )}
                  </Draggable>
                ))}

                {/* Out of Stock Products */}
                {outOfStockProducts.map((product) => (
                  <div
                    key={product.id}
                    className="p-4 opacity-50"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <ImageComponent
                          src={product.image}
                          alt={product.name}
                          width={56}
                          height={56}
                          className="w-14 h-14 rounded object-cover"
                        />
                        <div>
                          <div className="font-medium">{product.name}</div>
                          <div className="text-sm text-[#7b7b7b]">
                          {t('SKU')}: {product.sku}
                          </div>
                          <div className="text-sm text-[#7b7b7b]">
                          {t('Brand')}: {product.brand}
                          </div>
                          <div className="text-sm text-red-500">
                          {t('StokHabis')}
                          </div>
                        </div>
                      </div>
                      <GripVertical className="w-6 h-6 text-gray-300" />
                    </div>
                  </div>
                ))}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        </DragDropContext>
      </div>

      {/* Fixed Bottom Action Buttons */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4 flex justify-end gap-3">
        <button
          onClick={() => router.back()}
          className ="px-6 py-2 border border-gray-300 text-gray-700 rounded-full hover:bg-gray-50"
        >
          {t('labelBatal')}
        </button>
        <Button
          onClick={handleSave}
          disabled={loading}
          color="primary"
Class ="px-6 py-2 bg-blue-600 text-white rounded-full hover:bg-blue-700 
                   disabled:bg-gray-300 disabled:cursor-not-allowed"
        >
          {loading ? t('labelMenyimpan') : t('labelSimpan')}
        </Button>
      </div>

      {/* Toast Notifications */}
      <Toast />
    </div>
  );
}