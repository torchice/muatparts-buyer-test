// app/tambahetalase/page.jsx
'use client';

import React, { useState, useEffect } from 'react';
import { useCustomRouter } from '@/libs/CustomRoute';
import { ChevronLeft } from 'lucide-react';
import { MockServer_TambahEtalase } from '@/services/MockServer_TambahEtalase';
import Toast from '@/components/Toast/Toast';
import BreadCrumb from '../components/BreadCrumb';
import ProductTable from '../components/ProductTable';
import SearchFilter from '../components/SearchFilter';
import ProductSelectionPopup from '../popup/ProductSelectionPopup';
import DeleteMassalPopup from '../popup/DeleteMassalPopup';
import DeleteConfirmationPopup from '../popup/ConfirmationPopup';
import useSusunProdukStore from '@/store/susunProdukStore';
import toast from "@/store/zustand/toast"; // Add this import
import Button from "@/components/Button/Button";

const mockSelectedProducts = [
  {
    id: "1",
    name: "Peralatan Angkutan Test",
    sku: "SKU123456",
    brand: "UD Truck",
    image: "https://cdn.builder.io/api/v1/image/assets/60cdcdaf919148d9b5b739827a6f5b2a/d0fda75fb24c25a96d87fe40765be8e2487514f2e43a2794febe0f0a576c5662?apiKey=60cdcdaf919148d9b5b739827a6f5b2a&",
    categories: ["Produk Lainnya", "Tools Diagnosa"],
    stock: 300,
    price: "Rp 1.350.000",
    sold: "40 Terjual"
  },
  {
    id: "2",
    name: "Angkutan Peralatan Two",
    sku: "SKU789012",
    brand: "UD Truck",
    image: "https://cdn.builder.io/api/v1/image/assets/60cdcdaf919148d9b5b739827a6f5b2a/d0fda75fb24c25a96d87fe40765be8e2487514f2e43a2794febe0f0a576c5662?apiKey=60cdcdaf919148d9b5b739827a6f5b2a&",
    categories: ["Produk Lainnya", "Sparepart"],
    stock: 0,
    price: "Rp 2.500.000",
    sold: "25 Terjual"
  }
];

export default function TambahEtalasePage() {
  const router = useCustomRouter();
  const { products, setProducts } = useSusunProdukStore();
  const { showToast, setShowToast, setDataToast } = toast(); // Add this
  
  const [showDeleteMassal, setShowDeleteMassal] = useState(false);
  const [showDeleteConfirmation, setShowDeleteConfirmation] = useState(false);
  const [itemsToDelete, setItemsToDelete] = useState([]);
  const [name, setName] = useState('');
  const [image, setImage] = useState(null);
  const [selectedProducts, setSelectedProducts] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(false);
  const [showProductPopup, setShowProductPopup] = useState(false);
  // Remove the toast state:
  // const [toast, setToast] = useState({ show: false, status: 'success', text: '' });

  // Effect to sync store products with local state
  useEffect(() => {
    if (products.length > 0) {
      setSelectedProducts(products);
    }
  }, [products]);

  const breadcrumbItems = [
    { text: 'Dashboard', path: '/dashboard' },
    { text: 'Daftar Etalase', path: '/daftaretalase' },
    { text: 'Tambah Etalase' }
  ];

  const handleImageUpload = async (file) => {
    if (file.size > 10 * 1024 * 1024) {
      setDataToast({
        type: 'error',
        message: 'Ukuran file maksimal 10MB!'
      });
      setShowToast(true);
      return;
    }
    
    if (!['image/jpeg', 'image/png'].includes(file.type)) {
      setDataToast({
        type: 'error',
        message: 'Format file tidak sesuai ketentuan!'
      });
      setShowToast(true);
      return;
    }
    
    setImage(file);
  };

  const handleProductSelection = (newProducts) => {
    // Sort based on stock status
    const inStockProducts = newProducts.filter(p => p.stock > 0);
    const outOfStockProducts = newProducts.filter(p => p.stock === 0);

    const orderedProducts = [...inStockProducts, ...outOfStockProducts];
    // Update both local state and store
    setSelectedProducts(orderedProducts);
    setProducts(orderedProducts);
  };

  const handleDeleteProducts = async (productIds) => {
    try {
      setLoading(true);
      const ids = Array.isArray(productIds) ? productIds : [productIds];
    
      // Update frontend state and store
      const updatedProducts = selectedProducts.filter(p => !ids.includes(p.id));
      setSelectedProducts(updatedProducts);
      setProducts(updatedProducts);

      setDataToast({
        type: 'success',
        message: ids.length > 1 ? 
          `Berhasil menghapus ${ids.length} produk` : 
          'Berhasil menghapus produk'
      });
      setShowToast(true);
    } catch (error) {
      setDataToast({
        type: 'error',
        message: 'Gagal menghapus produk'
      });
      setShowToast(true);
    } finally {
      setLoading(false);
    }
  };

  const handleMassDelete = (productIds) => {
    setItemsToDelete(productIds);
    setShowDeleteConfirmation(true);
    setShowDeleteMassal(false);
  };
  
  const handleConfirmDelete = async () => {
    try {
      setLoading(true);
      
      // Update frontend state and store
      const updatedProducts = selectedProducts.filter(p => !itemsToDelete.includes(p.id));
      setSelectedProducts(updatedProducts);
      setProducts(updatedProducts);
      
      setDataToast({
        type: 'success',
        message: `Berhasil menghapus ${itemsToDelete.length} produk`
      });
      setShowToast(true);
    } catch (error) {
      setDataToast({
        type: 'error',
        message: 'Gagal menghapus produk'
      });
      setShowToast(true);
    } finally {
      setLoading(false);
      setShowDeleteConfirmation(false);
      setItemsToDelete([]);
    }
  };

  // const handleToggleReorder = () => {
  //   // Save current products to store before navigation
  //   setProducts(selectedProducts);
  //   router.push('/daftaretalase/susunproduk');
  // };

  const handleSearch = (value) => {
    setSearchTerm(value);
  };

  const filteredProducts = selectedProducts.filter(product => 
    product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    product.sku?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    product.brand.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSave = async () => {
    if (!name.trim()) {
      setDataToast({
        type: 'error',
        message: 'Nama etalase wajib diisi'
      });
      setShowToast(true);
      return;
    }

    try {
      setLoading(true);
      const data = {
        name: name.trim(),
        image: image,
        products: selectedProducts.map((product, index) => ({
          productId: product.id,
          position: index + 1
        }))
      };

      await MockServer_TambahEtalase.createEtalase(data);
      
      setDataToast({
        type: 'success',
        message: 'Berhasil menambah etalase baru!'
      });
      setShowToast(true);

      setTimeout(() => {
        router.push('/daftar-etalase');
      }, 1500);
    } catch (error) {
      let errorMessage = 'Gagal menambah etalase';
      
      if (error.response?.data?.message === 'NAME_EXISTS') {
        errorMessage = 'Nama etalase telah digunakan';
      }
      
      setDataToast({
        type: 'error',
        message: errorMessage
      });
      setShowToast(true);
    } finally {
      setLoading(false);
    }
  };

  const [isReorderMode, setIsReorderMode] = useState(false);

  const handleToggleReorder = () => {
    if (isReorderMode) {
      handleProductOrder(selectedProducts);
    }
    setIsReorderMode(!isReorderMode);
  };

  const handleProductOrder = async (reorderedProducts) => {
    try {
      setLoading(true);
      await MockServer_TambahEtalase.reOrderPositionProduct({
        products: reorderedProducts.map((product, index) => ({
          productId: product.id,
          position: index + 1
        }))
      });
      
      setSelectedProducts(reorderedProducts);
      setProducts(reorderedProducts);
      setDataToast({
        type: 'success',
        message: 'Berhasil mengubah urutan produk'
      });
      setShowToast(true);
    } catch (error) {
      setDataToast({
        type: 'error',
        message: 'Gagal mengubah urutan produk'
      });
      setShowToast(true);
      // Revert to previous order if there's an error
      setSelectedProducts(prevProducts => [...prevProducts]);
    } finally {
      setLoading(false);
      setIsReorderMode(false);
    }
  };

  return (
    <div className="min-h-screen   w-full">
      {/* Breadcrumb and Header */}
      <div className =" py-4">
        <BreadCrumb items={breadcrumbItems} />
        <div className="flex items-center mt-4">
          <div className="flex items-center gap-2">
            <ChevronLeft className="w-6 h-6 text-[#176CF7]" />
            <h1 className="text-xl font-bold">Tambah Etalase</h1>
          </div>
        </div>
      </div>

      {/* Form Section */}
      <div className =" py-4">
        <div className="bg-white rounded-xl p-6 shadow-lg">
          <div className="mb-6">
            <div className="grid grid-cols-[100px,1fr] gap-6 items-start">
              <label className="pt-3 text-sm text-[#7b7b7b]">Nama Etalase*</label>
              <div>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => {
                    if (e.target.value.length <= 80) {
                      setName(e.target.value);
                    }
                  }}
                  placeholder="Masukkan nama Etalase"
                  className="w-full px-4 py-2 border border-gray-300 rounded-md hover:border-blue-500 focus:outline-none focus:border-blue-600 focus:ring-blue-500"
                  maxLength={80}
                />
                <div className="text-right mt-1 text-sm text-[#7b7b7b]">
                  {name.length}/80
                </div>
              </div>
            </div>
          </div>

          {/* Image Upload */}
          <div className="grid grid-cols-[100px,1fr] gap-6 items-start">
            <label className="text-sm text-[#7b7b7b]">
              Gambar
              <span className="block text-sm italic text-[#7b7b7b]">(Opsional)</span>
            </label>
            <div>
              <input
                type="file"
                accept="image/jpeg,image/png"
                onChange={(e) => handleImageUpload(e.target.files[0])}
                className="hidden"
                id="image-upload"
              />
              <label
                htmlFor="image-upload"
                className ="px-6 py-2 bg-blue-600 text-white rounded-full cursor-pointer inline-block hover:bg-blue-700"
              >
                {image ? 'Ubah' : 'Unggah'}
              </label>
              <span className="ml-4 text-sm text-[#7b7b7b]">
                Format file jpg/png max. 10MB
              </span>
              {image && (
                <div className="mt-2 flex items-center gap-2">
                  <img
                    src={URL.createObjectURL(image)}
                    alt="Preview"
                    className="w-16 h-16 object-cover rounded"
                  />
                  <Button
                    onClick={() => setImage(null)}
                    className="text-red-600 text-sm hover:text-red-700"
                  >
                    Hapus
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Product List Section */}
        {selectedProducts.length === 0 ? (
          <div className="mt-4 bg-white rounded-xl p-8 shadow-lg text-center">
            <div className="flex flex-col items-center max-w-full text-base text-center w-full">
              <img
                loading="lazy"
                src="/icons/import.png"
                alt="Empty state"
                className="object-contain w-[93px] mb-4"
              />
              <h3 className="text-base font-semibold mb-2">Isi Etalasemu</h3>
              <p className="text-sm text-[#7b7b7b] mb-4">
                Pilih produk yang sesuai dengan nama etalasemu
              </p>
              <Button 
                onClick={() => setShowProductPopup(true)}
                className ="px-6 py-2 bg-blue-600 text-white rounded-full hover:bg-blue-700"
              >
                Pilih Produk
              </Button>
            </div>
          </div>
        ) : (
          <div className="mt-4 bg-white rounded-xl p-6 shadow-lg">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-lg font-semibold">Daftar Produk</h2>
              <div className="flex items-center justify-between w-full">
                <SearchFilter onSearch={handleSearch} showFilterButton={false}/>
                {/* Button section in the page component */}
                <div className="flex items-center gap-3">
                  {isReorderMode ? (
                    <>
                      <Button
                        onClick={() => setIsReorderMode(false)}
                        className ="px-6 py-2 text-gray-600 border border-gray-300 rounded-full hover:bg-gray-50"
                      >
                        Batal
                      </Button>
                      <Button
                        onClick={handleToggleReorder}
                        className ="px-6 py-2 bg-blue-600 text-white rounded-full hover:bg-blue-700"
                      >
                        Simpan
                      </Button>
                    </>
                  ) : (
                    <>
                      <Button
                        onClick={() => setShowDeleteMassal(true)}
                        className ="px-6 py-2 text-red-500 border border-red-500 rounded-full hover:bg-red-50"
                      >
                        Hapus Massal
                      </Button>
                      <Button
                        onClick={() => setIsReorderMode(true)}
                        className ="px-6 py-2 text-[#176CF7] border border-blue-600 rounded-full hover:bg-blue-50"
                      >
                        Susun Produk
                      </Button>
                      <Button
                        onClick={() => setShowProductPopup(true)}
                        className ="px-6 py-2 bg-blue-600 text-white rounded-full hover:bg-blue-700"
                      >
                        Tambah
                      </Button>
                    </>
                  )}
                </div>
              </div>
            </div>

            <ProductTable 
              products={filteredProducts}
              onDelete={handleDeleteProducts}
              onReorder={handleProductOrder}
              isReorderMode={isReorderMode}
            />

            <div className="mt-4 text-sm text-gray-600">
              Total Produk: {filteredProducts.length}
            </div>
          </div>
        )}
      </div>

      {/* Fixed Bottom Save Button */}
      
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4 flex justify-end">
        <Button 
          onClick={handleSave}
          disabled={loading}
          className ="px-6 py-2 bg-blue-600 text-white rounded-full disabled:bg-gray-300 hover:enabled:bg-blue-700"
        >
          {loading ? 'Menyimpan...' : 'Simpan'}
        </Button>
      </div>

      {/* Product Selection Popup */}
      {showProductPopup && (
        <ProductSelectionPopup
          onClose={() => setShowProductPopup(false)}
          onSelect={handleProductSelection}
          selectedProducts={selectedProducts}
          maxSelections={30}
        />
      )}

      {/* Toast Notifications */}
      <Toast />
      
      {/* Delete Massal Popup */}
      {showDeleteMassal && (
        <DeleteMassalPopup
          products={selectedProducts}
          onClose={() => setShowDeleteMassal(false)}
          onConfirmDelete={handleMassDelete}
        />
      )}

      {/* Delete Confirmation Popup */}
      {showDeleteConfirmation && (
        <DeleteConfirmationPopup
          count={itemsToDelete.length}
          onConfirm={handleConfirmDelete}
          onCancel={() => setShowDeleteConfirmation(false)}
        />
      )}
    </div>
  );
}