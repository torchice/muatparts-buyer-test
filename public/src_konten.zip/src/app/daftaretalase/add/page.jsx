// app/tambahetalase/page.jsx

/* 
THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase 
- LB - 0018 
- LB - 0112
- LB - 0136
- LB - 0143
- LB - 0117
- Lb - 0123
*/
'use client';

import React, { useState, useEffect } from 'react';
import { useCustomRouter } from '@/libs/CustomRoute';
import { ChevronLeft } from 'lucide-react';
import { MockServer_TambahEtalase } from '@/services/MockServer_TambahEtalase';
import Toast from '@/components/Toast/Toast';
import BreadCrumb from '../components/BreadCrumb';
import ProductTable from '../components/ProductTable';
import SearchFilter from '../components/SearchFilter';
import ProductSelectionPopup from '../popup/ProductSelectionPopup';
import DeleteMassalPopup from '../popup/DeleteMassalPopup';
import DeleteConfirmationPopup from '../popup/ConfirmationPopup';
import useSusunProdukStore from '@/store/susunProdukStore';
import ImageUploader from '@/components/ImageUploader/ImageUploader';
import UnifiedProductPopup from '../components/UnifiedProductPopup';
import { useLanguage } from '@/providers/LanguageProvider';
import Image from 'next/image';
import IconBack from '@/icons/iconBack.svg';
import toast from "@/store/zustand/toast"; // Add this import at the top
import ImageComponent from '@/components/ImageComponent/ImageComponent';
import CustomLink from '@/components/CustomLink';
import { el } from 'date-fns/locale';
import Button from "@/components/Button/Button";

const mockSelectedProducts = [
  {
    id: "1",
    name: "Peralatan Angkutan Test",
    sku: "SKU123456",
    brand: "UD Truck",
    image: "https://cdn.builder.io/api/v1/image/assets/60cdcdaf919148d9b5b739827a6f5b2a/d0fda75fb24c25a96d87fe40765be8e2487514f2e43a2794febe0f0a576c5662?apiKey=60cdcdaf919148d9b5b739827a6f5b2a&",
    categories: ["Produk Lainnya", "Tools Diagnosa"],
    stock: 300,
    price: "Rp 1.350.000",
    sold: "40 Terjual"
  },
  {
    id: "2",
    name: "Angkutan Peralatan Two",
    sku: "SKU789012",
    brand: "UD Truck",
    image: "https://cdn.builder.io/api/v1/image/assets/60cdcdaf919148d9b5b739827a6f5b2a/d0fda75fb24c25a96d87fe40765be8e2487514f2e43a2794febe0f0a576c5662?apiKey=60cdcdaf919148d9b5b739827a6f5b2a&",
    categories: ["Produk Lainnya", "Sparepart"],
    stock: 0,
    price: "Rp 2.500.000",
    sold: "25 Terjual"
  }
];

export default function TambahEtalasePage() {
  // Add this state for exit confirmation
  const [showExitConfirm, setShowExitConfirm] = useState(false);
  const { t, currentLocale, changeLanguage, loading: langLoading } = useLanguage();
  const router = useCustomRouter();
  const { products, setProducts } = useSusunProdukStore();
  const { showToast, setShowToast, setDataToast } = toast(); // Add this

  const [showDeleteMassal, setShowDeleteMassal] = useState(false);
  const [showDeleteConfirmation, setShowDeleteConfirmation] = useState(false);
  const [itemsToDelete, setItemsToDelete] = useState([]);
  const [name, setName] = useState('');
  const [image, setImage] = useState(null);
  const [selectedProducts, setSelectedProducts] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(false);
  const [showProductPopup, setShowProductPopup] = useState(false);
  const [imageError, setImageError] = useState(false);
  const [nameError, setNameError] = useState(false);
  const [tempProducts, setTempProducts] = useState([]); // Add this state for temporary order
  const [activeFilters, setActiveFilters] = useState({ categories: [], brands: [] });
  const [displayProducts, setDisplayProducts] = useState([]);

  // Add this state at the top with other state declarations
  const [deleteSource, setDeleteSource] = useState('');
  const [bottomPadding, setBottomPadding] = useState('ml-[192px] pl-[50px]');

  // Add this state near other state declarations
  const [massDeleteSelectedItems, setMassDeleteSelectedItems] = useState(new Set());

  // Add this useEffect to monitor main-container changes
  //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0030
  useEffect(() => {
    const checkMainContainer = () => {
      const mainContainer = document.querySelector('nav.shadow-muat');
      if (mainContainer && mainContainer.classList.contains('w-fit') ) {
        setBottomPadding('ml-[32px] pl-[32px]');
      } else {
        //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0030
        setBottomPadding('ml-[192px] pl-[50px]');
      }
    };

    // Initial check
    checkMainContainer();

    // Create observer
    const observer = new MutationObserver(checkMainContainer);

    // Start observing
    const mainContainer = document.querySelector('.main-container');
    if (mainContainer) {
      observer.observe(mainContainer, {
        attributes: true,
        attributeFilter: ['class']
      });
    }

    // Cleanup
    return () => observer.disconnect();
  }, []);

  // Effect to sync store products with local state
  useEffect(() => {
    if (products.length > 0) {
      setSelectedProducts(products);
    }
  }, [products]);
  useEffect(() => {
    setSelectedProducts([]);
  }, []);
  function resetZindex(){}

  // Tambahkan useEffect setelah deklarasi state
  useEffect(() => {
    if(showProductPopup){
        // Fungsi untuk menghapus class z-index yang tinggi
        const removeHighZIndex = () => {
          const toastElements = document.querySelectorAll('[class*="z-[9999999999]"]');
          toastElements.forEach(element => {
            element.classList.remove('z-[9999999999]');
            // Optionally set a lower z-index if needed
            element.classList.add('z-[5]');
          });
        };

        // Observer untuk memantau perubahan DOM
        const observer = new MutationObserver(removeHighZIndex);

        // Mulai observing
        observer.observe(document.body, {
          childList: true,
          subtree: true
        });

        // Cleanup observer
        return () => observer.disconnect();
    }
    
  }, [showProductPopup]);

  const breadcrumbItems = [
    { text: t('labelDashboard'), path: '/dashboard' },
    { text: t('daftarEtalase'), path: '/daftaretalase' },
    { text: t('tambahEtalase') }
  ];

  const handleImageUpload = (base64Image) => {
    console.log(base64Image, 'base64Image.url')
    base64Image ? setImage(base64Image.url) : setImage('');
  };

  const handleImageError = (error) => {
    console.log(error, 'error')
    setImageError(error);
    if (error) {
      setDataToast({
        type: 'error',
        message: error.includes('size') ? t('ukuranFileMaksimal10MB') : t('formatFileTidakSesuai')
      });
      setShowToast(true);
    }
  };

  const handleProductSelection = (newProducts) => {
    console.log('Received new products:', newProducts);

    // Check if there are any new products
    const hasNewProducts = newProducts.some(p => !selectedProducts.some(sp => sp.id === p.id));

    // If no new products added, maintain current order
    if (!hasNewProducts) {
      console.log('No new products, maintaining current order');
      return setSelectedProducts(newProducts);
    }

    // Split into existing and new
    const existingProducts = newProducts.filter(p =>
      selectedProducts.some(sp => sp.id === p.id)
    );
    const newProducts2 = newProducts.filter(p =>
      !selectedProducts.some(sp => sp.id === p.id)
    );

    // Sort by created date (newest first)
    const compareByDate = (a, b) => new Date(b.created) - new Date(a.created);

    // Group and sort products
    const existingInStock = existingProducts
      .filter(p => p.stock > 0)
      .sort(compareByDate);

    const existingOutOfStock = existingProducts
      .filter(p => p.stock <= 0)
      .sort(compareByDate);

    const newInStock = newProducts2
      .filter(p => p.stock > 0)
      .sort(compareByDate);

    const newOutOfStock = newProducts2
      .filter(p => p.stock <= 0)
      .sort(compareByDate);

    // Combine in correct order:
    // 1. Produk LAMA dengan stok > 0
    // 2. Produk BARU dengan stok > 0
    // 3. Produk BARU dengan stok 0
    // 4. Produk LAMA dengan stok 0
    const finalProducts = [
      ...existingInStock,    // 1. Produk lama dengan stok
      ...newInStock,         // 2. Produk baru dengan stok
      ...newOutOfStock,      // 3. Produk baru tanpa stok
      ...existingOutOfStock  // 4. Produk lama tanpa stok
    ];

    console.log('Product grouping:', {
      existing: {
        inStock: existingInStock.length,
        outOfStock: existingOutOfStock.length
      },
      new: {
        inStock: newInStock.length,
        outOfStock: newOutOfStock.length
      }
    });

    setSelectedProducts(finalProducts);

    // Update displayProducts if no search active
    if (!searchTerm) {
      setDisplayProducts(finalProducts);
    }
  };

  const handleDeleteProducts = async (productIds) => {
    const newProducts = selectedProducts.filter(p => !productIds.includes(p.id));
    setSelectedProducts(newProducts);
    setShowDeleteConfirmation(false);
    setShowDeleteMassal(false); // Make sure this is also closed

    // Show toast only if deletion is from confirmation popup
    if (deleteSource === 'confirmation') {
      setDataToast({
        type: 'success',
        message: t('berhasilMenghapusProduk').replace('{count}', productIds.length)
      });
      setShowToast(true);
    }
    setDeleteSource(''); // Reset source after deletion
  };

  // Modifikasi handler untuk menyimpan state seleksi
  const handleMassDelete = (productIds) => {
    setItemsToDelete(productIds);
    setMassDeleteSelectedItems(new Set(productIds)); // Simpan state seleksi
    handleShowDeleteConfirmation();
    setShowDeleteMassal(false);
    setDeleteSource('confirmation');
  };

  const handleSingleDelete = (id) => {
    setDeleteSource('table');
    handleDeleteProducts([id]);
  };

  const handleSearch = (value) => {
    setSearchTerm(value);
    const searchLower = value.toLowerCase();

    if (!searchLower) {
      setDisplayProducts(selectedProducts);
      return;
    }

    // Separate matches into categories
    const nameMatches = [];
    const skuMatches = [];
    const brandMatches = [];

    selectedProducts.forEach(product => {
      const productName = (product.name || '').toLowerCase();
      const productSku = (product.sku || '').toLowerCase();
      const productBrand = (product.brand || '').toLowerCase();

      if (productName.includes(searchLower)) {
        nameMatches.push(product);
      } else if (productSku.includes(searchLower)) {
        skuMatches.push(product);
      } else if (productBrand.includes(searchLower)) {
        brandMatches.push(product);
      }
    });

    // Sort each category alphabetically
    nameMatches.sort((a, b) => (a.name || '').localeCompare(b.name || ''));
    skuMatches.sort((a, b) => (a.sku || '').localeCompare(b.sku || ''));
    brandMatches.sort((a, b) => (a.brand || '').localeCompare(b.brand || ''));

    // Combine all matches in the specified order
    setDisplayProducts([...nameMatches, ...skuMatches, ...brandMatches]);
  };

  // Add effect to sync displayProducts with selectedProducts
  useEffect(() => {
    if (!searchTerm) {
      setDisplayProducts(selectedProducts);
    }
  }, [selectedProducts]);

  const validateForm = () => {
    if (!name.trim()) {
      setNameError(true);
      setDataToast({
        type: 'error',
        message: 'Terdapat field yang kosong'
      });
      setShowToast(true);
      return false;
    }
    setNameError(false);
    return true;
  };

  const handleSave = async () => {
    if (!name.trim()) {
      setNameError(true); // Set nameError ke true
      setDataToast({
        type: 'error',
        message: t('terdapatFieldYangKosong')
      });
      setShowToast(true);
      return;
    }

    if (!name.trim()) {
      setNameError(true)
      setDataToast({
        type: 'error',
        message: t('namaEtalaseWajibDiisi')
      });
      setShowToast(true);
      return;
    }

    try {
      setLoading(true);
      const data = {
        name: name.trim(),
        image: image,
        products: selectedProducts.map((product, index) => ({
          productId: product.id,
          position: index + 1
        }))
      };

      await MockServer_TambahEtalase.createEtalase(data);
      router.push('/daftaretalase');

      // Set toast setelah redirect
      localStorage.setItem('showToast', 'true');
      localStorage.setItem('toastMessage', t('berhasilMenambahEtalase'));
      localStorage.setItem('toastType', 'success');
      // setTimeout(() => {
      //   setDataToast({
      //     type: 'success',
      //     message: t('berhasilMenambahEtalase')
      //   });
      //   setShowToast(true);
      // }, 100);

    } catch (error) {
      if(error.messageKey === 'namaEtalaseTelahaDigunakan') {
        setNameError(true)
      }
      setDataToast({
        type: 'error',
        message: error.messageKey ? t(error.messageKey) : error.message // Use messageKey for translation if available
      });
      setShowToast(true);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (formData) => {
    try {
      setLoading(true);
      await MockServer_TambahEtalase.createEtalase(formData);
      setDataToast({
        type: 'success',
        message: t('berhasilMenambahEtalase')
      });
      setShowToast(true);
      router.push('/daftaretalase');
    } catch (error) {
      setDataToast({
        type: 'error',
        message: error.message || t('gagalMenambahkanEtalase')
      });
      setShowToast(true);
    } finally {
      setLoading(false);
    }
  };

  const [isReorderMode, setIsReorderMode] = useState(false);

  const handleToggleReorder = () => {
    if (isReorderMode) {
      // Save changes when clicking save
      handleProductOrder(tempProducts);
    } else {
      // When entering reorder mode, initialize tempProducts with current products
      setTempProducts(selectedProducts);
    }
    setIsReorderMode(!isReorderMode);
  };

  const handleProductOrder = async (reorderedProducts) => {
    try {
      setLoading(true);

      if (reorderedProducts) {
        // Langsung gunakan urutan dari reorderedProducts tanpa pengurutan ulang
        setSelectedProducts(reorderedProducts);
      }

      setDataToast({
        type: 'success',
        message: t('berhasilMenyusunUrutanProduk')
      });
      setShowToast(true);
    } catch (error) {
      setDataToast({
        type: 'error',
        message: t('gagalMenyusunUrutanProduk')
      });
      setShowToast(true);
    } finally {
      setLoading(false);
      setIsReorderMode(false);
    }
  };

  // Add this effect to sync tempProducts with selectedProducts
  useEffect(() => {
    if (!isReorderMode) {
      setTempProducts(selectedProducts);
    }
  }, [selectedProducts, isReorderMode]);

  // Add this handler for cancel button
  const handleCancelReorder = () => {
    setIsReorderMode(false);
    setTempProducts([]); // Clear temporary order
  };

  // Update the cancel handler to reopen delete massal popup
  const handleDeleteConfirmationCancel = () => {
    setShowDeleteConfirmation(false);
    setShowDeleteMassal(true);
  };

  // Add handler for back button
  const handleBack = () => {
    setShowExitConfirm(true);
  };

  // Add handler for exit confirmation
  const handleExitConfirm = () => {
    router.push('/daftaretalase');
  };

  // Add handler for exit cancellation
  const handleExitCancel = () => {
    setShowExitConfirm(false);
  };

  /**
 * Fungsi untuk menambahkan max-width pada message konfirmasi delete
 * Digunakan untuk mengatur lebar maksimal pesan konfirmasi agar tidak terlalu panjang
 * Target: element span dengan class "font-[500] text-[14px] leading-[16.8px] text-[#000000] text-center"
 * Note: 
 * - Fungsi ini perlu disesuaikan jika ada perubahan pada class di Modal component
 * - Class yang ditarget harus sesuai dengan class di Modal component
 */
// LB - 0122 - etalase
const handleShowDeleteConfirmation = () => {
  setShowDeleteConfirmation(true);
  console.log('Show delete confirmation');
  // Beri waktu untuk Modal muncul di DOM
  setTimeout(() => {
    // Perbaiki selector dengan menggunakan kombinasi class yang lebih aman
    const messageElement = document.querySelector('span[class*="font-[500]"][class*="text-[14px]"][class*="leading-[16.8px]"][class*="text-[#000000]"][class*="text-center"]');
    if (messageElement) {
      messageElement.style.maxWidth = '72%';
      messageElement.style.display = 'block';
      messageElement.style.margin = '0 auto';
    }
  }, 100);
};

  return (
    <div className="min-h-screen  w-full relative pb-20">
      {/* Breadcrumb and Header */}
      {/*24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0001 */}
      <div className=" pb-4">
        <BreadCrumb items={breadcrumbItems} />
        <div className="flex items-center mt-4">
          <div className="flex items-center gap-2">
            <ImageComponent
              src={"/icons/etalase/iconBack.svg"}
              width={24}
              height={24}
              alt={t('labelKembali')}
              className="cursor-pointer"
              onClick={handleBack}
            />
            <h1 className="text-xl font-bold">{t('tambahEtalase')}</h1>
          </div>
        </div>
      </div>

      {/* Form Section */}
      <div className=" py-4">
        <div className="bg-white rounded-xl p-6 shadow-lg">
          <div className="mb-6">
            <div className="grid grid-cols-[100px,1fr] gap-6 items-start">
              <label className="pt-2 text-sm text-[#7b7b7b] font-[500]">{t('namaEtalase')}*</label>
              <div>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => {
                    setNameError(false);
                    if (e.target.value.length <= 80) {
                      setName(e.target.value);
                    }
                  }}
                  placeholder={t('masukanNamaEtalase')}
                  className={`w-full px-4 py-2 border rounded-md  
                    ${nameError
                      ? 'border-[#EE4343] focus:border-[#EE4343] focus:ring-[#EE4343]'
                      : 'border-gray-300 focus:border-blue-600 focus:ring-blue-500 hover:border-blue-500'
                    } focus:outline-none`}
                  maxLength={80}
                />
                <div className="text-right mt-1 text-sm text-[#7b7b7b]">
                  {name.length}/80
                </div>
              </div>
            </div>
          </div>

          {/* Image Upload Section */}
          <div className="flex flex-wrap gap-6 mt-3 w-full">
            <label className="gap-2.5 self-stretch h-full text-sm text-[#7b7b7b] leading-4  w-[100px] font-[500]">
              {t('labelGambar')} <span className="italic font-[400]">{t('labelOpsional')}</span>
            </label>
            <div className="flex flex-col flex-wrap flex-1 shrink gap-2 items-start my-auto leading-tight basis-0 min-w-[240px]">
              <ImageUploader
                getImage={handleImageUpload}
                isBig={false}
                // onUpload={(value) => {
                //   setImage(value);
                //   setImageError(false);
                // }}
                isNull={imageError}
                // isMain={true}
                maxSize={10}
                error={imageError}
                onError={handleImageError}
                uploadText={t('labelUnggah')}
                isCircle={true}
                className={"!size-[72px]"}
                value={image}
                previewTitle={t('uploadGambar')}
              />
              <div className="flex-1 shrink gap-4 self-stretch my-auto text-xs font-medium min-w-[240px] text-neutral-500">
                {t('formatFile')}
              </div>
            </div>
          </div>

        </div>

        {/* Product List Section */}
        {selectedProducts.length === 0 ? (
          <div className="mt-4 bg-white rounded-xl p-8 shadow-lg">
            <div className="flex flex-col items-center justify-center text-center">
              <ImageComponent
                src="/icons/import.png"
                width={93}
                height={93}
                alt={t('isiEtalasemu')}
                className="mb-4"
              />
              <h3 className="text-base font-semibold mb-2 text-[#7b7b7b]">{t('isiEtalasemu')}</h3>
              <p className="text-sm text-[#7b7b7b] mb-4">
                {t('pilihProdukYangSesuai')}
              </p>
              <Button
              color="primary"
                onClick={() => setShowProductPopup(true)}
                Class="px-6 py-2 bg-blue-600 text-white rounded-full hover:bg-blue-700"
              >
                {t('pilihProduk')}
              </Button>
            </div>
          </div>
        ) : (
          <div className="mt-4 bg-white rounded-xl py-6 shadow-lg">
            <div className="flex justify-between items-center mb-6 gap-4 px-6">
              <h2 className="text-lg font-semibold text-black  whitespace-nowrap">{t('daftarProduk')}</h2>
              <div className={isReorderMode ? "flex items-center w-full justify-end" : "flex items-center w-full justify-between"}>
                {!isReorderMode && (
                  <SearchFilter
                    onSearch={handleSearch}
                    showFilterButton={false}
                    disabled={loading || (displayProducts.length === 0 && searchTerm)}
                  />
                )}
                <div className="flex items-center gap-3">
                  {isReorderMode ? (
                    <>
                      <Button
                        onClick={handleCancelReorder}
                        color='primary_secondary'
                        Class="px-6 py-2 text-blue-600 border border-blue-600 rounded-full hover:bg-blue-50"
                      >
                        {t('labelBatal')}
                      </Button>
                      <Button
                        onClick={handleToggleReorder}
                        color='primary'
                        Class="px-6 py-2 bg-blue-600 text-white rounded-full hover:bg-blue-700"
                      >
                        {t('labelSimpan')}
                      </Button>
                    </>
                  ) : (
                    <>
                      <Button
                        onClick={() => setShowDeleteMassal(true)}
                        color='error_secondary'
                        Class="px-6 py-2 text-red-500 border border-red-500 rounded-full hover:bg-red-50"
                      >
                        {t('hapusMassal')}
                      </Button>
                      <Button
                        onClick={() => setIsReorderMode(true)}
                        color='primary_secondary'
                        Class="px-6 py-2 text-[#176CF7] border border-blue-600 rounded-full hover:bg-blue-50"
                      >
                        {t('susunProduk')}
                      </Button>
                      <Button
                      color='primary'
                        onClick={() => setShowProductPopup(true)}
                        Class="px-6 py-2 bg-blue-600 text-white rounded-full hover:bg-blue-700"
                      >
                        {t('labelTambah')}
                      </Button>
                    </>
                  )}
                </div>
              </div>
            </div>

            <ProductTable
              products={isReorderMode ? tempProducts : (searchTerm ? displayProducts : selectedProducts)}
              onDelete={handleDeleteProducts}
              onReorder={setTempProducts}
              isReorderMode={isReorderMode}
              showActions={true}
              searchTerm={searchTerm} // Tambahkan prop ini
              activeFilters={activeFilters} // Tambahkan prop ini juga
            />
          </div>
        )}
      </div>

      {/* Fixed Bottom Save Button */}
      <div className={isReorderMode ? "hidden" : "fixed bottom-0 left-0 right-0 z-0"}>
        <div className={`${bottomPadding} pr-[48px] bg-white border-t border-gray-200 p-4`}>
          <div className="flex justify-between items-center">
            <div className="text-sm font-bold text-black">
              {t('totalProduk')} : {selectedProducts.length}
            </div>
            <Button
              onClick={handleSave}
              disabled={loading}
              Class="px-6 py-2 text-sm font-semibold bg-blue-600 text-white rounded-3xl disabled:bg-gray-300 hover:enabled:bg-blue-700 min-h-[32px]"
            >
              {t('labelSimpan')}
            </Button>
          </div>
        </div>
      </div>

      {/* Popups */}
      {showProductPopup && (
        <UnifiedProductPopup
          mode="select"
          selectedProducts={selectedProducts}
          initialSelectedItems={new Set(selectedProducts.map(p => p.id))} // Add this prop
          onClose={() => setShowProductPopup(false)}
          onConfirm={handleProductSelection}
        />
      )}

      <Toast />

      {showDeleteMassal && (
        <UnifiedProductPopup
          mode="delete"
          selectedProducts={selectedProducts}
          onClose={() => setShowDeleteMassal(false)}
          onDelete={handleMassDelete}
          initialSelectedItems={massDeleteSelectedItems} // Pass saved selections
        />
      )}

      {showDeleteConfirmation && (
        <DeleteConfirmationPopup
          title={''}
          message={t('konfirmasiHapusSekaligus').replace('{count}', itemsToDelete.length)}
          onConfirm={() => handleDeleteProducts(itemsToDelete)}
          onCancel={handleDeleteConfirmationCancel}
          confirmLabel={t('labelYaHapus')}
        />
      )}

      {/* Add Exit Confirmation Popup */}
      {showExitConfirm && (
        <DeleteConfirmationPopup
          title={t('titleExitPage')}
          message={t('konfirmasiKeluarHalaman')}
          onConfirm={handleExitConfirm}
          onCancel={handleExitCancel}
          confirmLabel={t('labelYaKeluar')}
          cancelLabel={t('labelBatal')}
          variant="warning"
        />
      )}
    </div>
  );
}