// app/daftaretalase/detail/[id]/layout.jsx
// app/daftaretalase/edit/[id]/layout.jsx
// app/daftaretalase/susunproduk/layout.jsx

'use client';
import { LanguageProvider } from "@/providers/LanguageProvider";

export default function Layout({ children }) {
  return (
    <>
      {children}
    </>
  );
}