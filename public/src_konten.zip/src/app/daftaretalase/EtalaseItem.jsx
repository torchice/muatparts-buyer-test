import * as React from "react";
import { useLanguage } from "@/providers/LanguageProvider";
import ImageComponent from '@/components/ImageComponent/ImageComponent';
import Button from "@/components/Button/Button";

export function EtalaseItem({ image, name, productCount, soldCount, isAllProducts }) {
  const { t } = useLanguage();

  return (
    <div className="flex flex-wrap gap-6 items-center px-6 py-5 w-full text-xs font-bold leading-tight text-black bg-white border-b border-solid border-b-stone-300 max-md:px-5 max-md:max-w-full">
      <ImageComponent
        src={image}
        alt={`${name} thumbnail`}
        width={48}
        height={48}
        className="object-contain shrink-0 self-stretch my-auto rounded aspect-square"
      />
      <div className="self-stretch my-auto w-[200px]">{name}</div>
      <div className="flex-1 shrink self-stretch my-auto basis-0">{productCount}</div>
      <div className="flex-1 shrink self-stretch my-auto basis-0">{soldCount}</div>
      <div className="flex gap-3 items-center self-stretch my-auto min-w-[240px]">
        {!isAllProducts && (
          <>
            <Button color="primary_secondary" Class="flex gap-1 justify-center items-center self-stretch px-3 py-2 my-auto w-10 bg-white rounded-3xl border border-blue-600 border-solid min-h-[32px]">
              <ImageComponent
                src="https://cdn.builder.io/api/v1/image/assets/60cdcdaf919148d9b5b739827a6f5b2a/43ec747140c183f22a7c8f920a78dba31cac4bf9fa44f20c937b515843444e20"
                alt="Edit Icon"
                width={16}
                height={16}
                className="object-contain self-stretch my-auto aspect-square"
              />
            </Button>
            <Button color="error_secondary" Class="gap-1 self-stretch px-6 py-3 my-auto text-sm font-semibold leading-tight text-red-500 whitespace-nowrap bg-white rounded-3xl border border-red-500 border-solid min-h-[32px] min-w-[112px] max-md:px-5">
              {t('labelHapus')}
            </Button>
            <Button color="primary_secondary" Class="gap-1 self-stretch px-6 py-3 my-auto text-sm font-semibold leading-tight text-[#176CF7] whitespace-nowrap bg-white rounded-3xl border border-blue-600 border-solid min-h-[32px] min-w-[112px] max-md:px-5">
              {t('labelUbah')}
            </Button>
          </>
        )}
        <Button color="primary_secondary" Class="gap-1 self-stretch px-6 py-3 my-auto text-sm font-semibold leading-tight text-white whitespace-nowrap bg-blue-600 rounded-3xl min-h-[32px] min-w-[112px] max-md:px-5">
          {t('labelDetail')}
        </Button>
      </div>
    </div>
  );
}