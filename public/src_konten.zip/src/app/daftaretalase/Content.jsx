import * as React from "react";
import { EtalaseItem } from "./EtalaseItem";
import { useLanguage } from "@/providers/LanguageProvider";
import Button from "@/components/Button/Button";

const etalaseData = [
  {
    image: "https://cdn.builder.io/api/v1/image/assets/60cdcdaf919148d9b5b739827a6f5b2a/c51e22ebb55bb9f13283508d3d9401020eb9d300c806befa4f1beb6c09b1a378?apiKey=60cdcdaf919148d9b5b739827a6f5b2a&",
    name: "Semua Produk",
    productCount: "20.000",
    soldCount: "20.000",
    isAllProducts: true
  },
  {
    image: "https://cdn.builder.io/api/v1/image/assets/60cdcdaf919148d9b5b739827a6f5b2a/b3c362d9d21247300bc15ac921790b334c9dd0040c54e994c48af37e20116ab2?apiKey=60cdcdaf919148d9b5b739827a6f5b2a&",
    name: "Peralatan Angkutan",
    productCount: "7",
    soldCount: "0",
    isAllProducts: false
  }
];

export function Content() {
  const { t } = useLanguage();

  return (
    <div className="flex flex-col grow shrink-0 self-start p-6 basis-0 w-fit max-md:px-5 max-md:max-w-full">
      <div className="flex gap-1.5 items-center w-full text-xs font-medium leading-tight min-h-[16px] text-neutral-500 max-md:max-w-full">
        <div className="flex flex-wrap gap-1.5 items-center self-stretch my-auto min-w-[240px] w-[662px]">
          <div className="self-stretch my-auto">{t('labelDashboard')}</div>
          <img
            loading="lazy"
            src="https://cdn.builder.io/api/v1/image/assets/60cdcdaf919148d9b5b739827a6f5b2a/aa96d47395c849d89aef11b76aadbd1487b01b986404063ae4c17a86d291a247?apiKey=60cdcdaf919148d9b5b739827a6f5b2a&"
            alt="Navigation Arrow"
            className="object-contain shrink-0 self-stretch my-auto w-4 aspect-square"
          />
          <div className="self-stretch my-auto">{t('daftarEtalase')}</div>
          <img
            loading="lazy"
            src="https://cdn.builder.io/api/v1/image/assets/60cdcdaf919148d9b5b739827a6f5b2a/aa96d47395c849d89aef11b76aadbd1487b01b986404063ae4c17a86d291a247?apiKey=60cdcdaf919148d9b5b739827a6f5b2a&"
            alt="Navigation Arrow"
            className="object-contain shrink-0 self-stretch my-auto w-4 aspect-square"
          />
          <div className="self-stretch my-auto font-semibold text-[#176CF7]">
            {t('tambahEtalase')}
          </div>
        </div>
      </div>
      <div className="flex flex-wrap gap-10 justify-between items-center mt-4 w-full leading-tight max-md:max-w-full">
        <div className="flex flex-wrap gap-3 items-center self-stretch my-auto text-xl font-bold text-black min-w-[240px] w-[515px] max-md:max-w-full">
          <img
            loading="lazy"
            src="https://cdn.builder.io/api/v1/image/assets/60cdcdaf919148d9b5b739827a6f5b2a/3748eae9d1da22c74c2909b41b26f252a8a8d356e82524d16ad42e586f29f80d?apiKey=60cdcdaf919148d9b5b739827a6f5b2a&"
            alt="Etalase Icon"
            className="object-contain shrink-0 self-stretch my-auto w-6 aspect-square"
          />
          <div className="self-stretch my-auto">{t('tambahEtalase')}</div>
        </div>
        <Button color="primary" Class="flex gap-1 justify-center items-center self-stretch px-6 py-2 my-auto text-sm font-semibold text-white bg-blue-600 rounded-3xl min-w-[112px] max-md:px-5">
          <img
            loading="lazy"
            src="https://cdn.builder.io/api/v1/image/assets/60cdcdaf919148d9b5b739827a6f5b2a/d837688464dee19f645c2cb075496029294193bf8683c56ac813ac3727e032b7?apiKey=60cdcdaf919148d9b5b739827a6f5b2a&"
            alt="Add Icon"
            className="object-contain shrink-0 self-stretch my-auto w-4 aspect-square"
          />
          <div className="self-stretch my-auto">{t('tambahEtalase')}</div>
        </Button>
      </div>
      <div className="flex flex-col mt-4 w-full max-md:max-w-full">
        <div className="flex overflow-hidden flex-col pt-5 w-full bg-white rounded-xl shadow-lg max-md:max-w-full">
          <div className="flex flex-col items-start px-6 pb-5 w-full text-xs font-medium leading-tight border-b border-solid border-b-stone-300 text-neutral-500 max-md:px-5 max-md:max-w-full">
            <div className="flex gap-2 items-center px-3 py-2 max-w-full bg-white rounded-md border border-solid border-neutral-500 min-h-[32px] w-[262px]">
              <img
                loading="lazy"
                src="https://cdn.builder.io/api/v1/image/assets/60cdcdaf919148d9b5b739827a6f5b2a/aee01b40870236a437d866ff2aa09f2dbd358503c3458f3d7e5b1b2ee392bd9a?apiKey=60cdcdaf919148d9b5b739827a6f5b2a&"
                alt="Search Icon"
                className="object-contain shrink-0 self-stretch my-auto w-4 aspect-square"
              />
              <input
                type="text"
                placeholder={t('cariNamaEtalase')}
                aria-label="Search etalase"
                className="flex-1 shrink self-stretch my-auto basis-0 bg-transparent border-none outline-none"
              />
            </div>
          </div>
          <div className="flex flex-wrap gap-6 items-center px-6 py-5 w-full text-xs font-bold leading-tight bg-white border-b border-solid border-b-stone-300 text-neutral-500 max-md:px-5 max-md:max-w-full">
            <div className="self-stretch my-auto w-[272px]">{t('namaEtalase')}</div>
            <div className="flex-1 shrink self-stretch my-auto basis-0">
              {t('jumlahProduk')}
            </div>
            <div className="flex-1 shrink self-stretch my-auto basis-0">
              {t('totalTerjual')}
            </div>
            <div className="self-stretch my-auto w-[420px]">{t('totalTerjual')}</div>
          </div>
          {etalaseData.map((item, index) => (
            <EtalaseItem key={index} {...item} />
          ))}
        </div>
        <div className="flex flex-wrap gap-10 justify-between items-start mt-4 w-full text-xs font-medium leading-tight text-neutral-500 max-md:max-w-full">
          <div className="w-[238px]">{t('totalEtalase')} : 2</div>
          <div className="text-right w-[238px]">({t('etalaseMaks')})</div>
        </div>
      </div>
    </div>
  );
}