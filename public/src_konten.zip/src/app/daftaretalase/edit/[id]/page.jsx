// THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase
// LB - 0069
// LB - 0124
// LB - 0125
//LB - 0171
'use client';
import React, { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { ChevronLeft } from 'lucide-react';
import { MockServer_TambahEtalase } from '@/services/MockServer_TambahEtalase';
import Toast from '@/components/Toast/Toast';
import BreadCrumb from '../../components/BreadCrumb';
import ProductTable from '../../components/ProductTable';
import SearchFilter from '../../components/SearchFilter';
import UnifiedProductPopup from '../../components/UnifiedProductPopup';
import DeleteConfirmationPopup from '../../popup/ConfirmationPopup';
import FilterDropdown from '../../components/FilterDropdown';
import ConfirmLeavePopup from '../../popup/ConfirmLeavePopup';
import LoadingSkeleton from '../../components/LoadingSkeleton';
import { useLanguage} from "@/providers/LanguageProvider";
import ImageComponent from '@/components/ImageComponent/ImageComponent';
// import IconBack from '/public/icons/back.svg';
import ImageUploader from '@/components/ImageUploader/ImageUploader';
import toast from "@/store/zustand/toast"; // Add this import
import CustomLink from '@/components/CustomLink';
import { useCustomRouter } from '@/libs/CustomRoute';
import Button from "@/components/Button/Button";

const UpdateEtalasePage = () => {
  const { t, currentLocale, changeLanguage, loading: langLoading } = useLanguage();
  const router = useCustomRouter();
  const params = useParams();
  const { showToast, setShowToast, setDataToast } = toast(); // Add this
  // Remove old toast state
  // const [toast, setToast] = useState({ show: false, status: 'success', text: '' });

  // Form state
  const [name, setName] = useState('');
  const [image, setImage] = useState(null);
  const [initialImage, setInitialImage] = useState(null);
  const [selectedProducts, setSelectedProducts] = useState([]);
  const [initialProducts, setInitialProducts] = useState([]);
  const [imageError, setImageError] = useState(null);
  const [nameError, setNameError] = useState(false);

  // UI state
  const [loading, setLoading] = useState(true);
  const [isReorderMode, setIsReorderMode] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filters, setFilters] = useState({
    categories: [],
    brands: []
  });
  const [displayProducts, setDisplayProducts] = useState([]);

  // Modal state
  const [showProductPopup, setShowProductPopup] = useState(false);
  const [showDeleteMassal, setShowDeleteMassal] = useState(false);
  const [showDeleteConfirmation, setShowDeleteConfirmation] = useState(false);
  const [showLeaveConfirmation, setShowLeaveConfirmation] = useState(false);
  const [itemsToDelete, setItemsToDelete] = useState([]);
  const [deleteSource, setDeleteSource] = useState(''); // Add this state

  // Tambahkan state untuk menyimpan item yang tercentang
  const [massDeleteSelectedItems, setMassDeleteSelectedItems] = useState(new Set());

  // Add bottomPadding state
  const [bottomPadding, setBottomPadding] = useState('ml-[192px] pl-[50px]');

  // Add this function
  const handleSearch = (value) => {
    setSearchTerm(value);
    const searchLower = value.toLowerCase();
  
    if (!searchLower) {
      setDisplayProducts(selectedProducts);
      return;
    }
  
    // Separate matches into categories
    const nameMatches = [];
    const skuMatches = [];
    const brandMatches = [];
  
    selectedProducts.forEach(product => {
      const productName = (product.name || '').toLowerCase();
      const productSku = (product.sku || '').toLowerCase();
      const productBrand = (product.brand || '').toLowerCase();
  
      if (productName.includes(searchLower)) {
        nameMatches.push(product);
      } else if (productSku.includes(searchLower)) {
        skuMatches.push(product);
      } else if (productBrand.includes(searchLower)) {
        brandMatches.push(product);
      }
    });
  
    // Sort each category alphabetically
    nameMatches.sort((a, b) => (a.name || '').localeCompare(b.name || ''));
    skuMatches.sort((a, b) => (a.sku || '').localeCompare(b.sku || ''));
    brandMatches.sort((a, b) => (a.brand || '').localeCompare(b.brand || ''));
  
    // Combine all matches in the specified order
    setDisplayProducts([...nameMatches, ...skuMatches, ...brandMatches]);
  };

  // Also need to add tempProducts state and handlers for reorder mode
  const [tempProducts, setTempProducts] = useState([]);
  
  const handleCancelReorder = () => {
    setIsReorderMode(false);
    setTempProducts([]); // Clear temporary order
  };

  const handleToggleReorder = () => {
    if (isReorderMode) {
      handleProductOrder(tempProducts);
    } else {
      setTempProducts(selectedProducts);
    }
    setIsReorderMode(!isReorderMode);
  };

  const handleProductOrder = async (reorderedProducts) => {
    try {
      setLoading(true);
      
      if (reorderedProducts) {
        // Sort by stock status and created date
        const outOfStock = reorderedProducts
          .filter(p => p.stock <= 0)
          .sort((a, b) => new Date(b.created) - new Date(a.created));
        
        const available = reorderedProducts
          .filter(p => p.stock > 0)
          .sort((a, b) => new Date(b.created) - new Date(a.created));

        setSelectedProducts([...outOfStock, ...available]);
      }
      
      setDataToast({
        type: 'success',
        message: t('berhasilMenyusunUrutanProduk')
      });
      setShowToast(true);
    } catch (error) {
      setDataToast({
        type: 'error',
        message: t('gagalMenyusunUrutanProduk')
      });
      setShowToast(true);
    } finally {
      setLoading(false);
      setIsReorderMode(false);
    }
  };

  // Add this effect to sync tempProducts with selectedProducts
  useEffect(() => {
    if (!isReorderMode) {
      setTempProducts(selectedProducts);
    }
  }, [selectedProducts, isReorderMode]);

  useEffect(() => {
    loadEtalaseData();
  }, [params.id]);

  useEffect(() => {
    if (!searchTerm) {
      setDisplayProducts(selectedProducts);
    }
  }, [selectedProducts]);

  // Add useEffect for monitoring main-container
  useEffect(() => {
    const checkMainContainer = () => {
      const mainContainer = document.querySelector('nav.shadow-muat');
      if (mainContainer && mainContainer.classList.contains('w-fit') ) {
        setBottomPadding('ml-[32px] pl-[32px]');
      } else {
        //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0030
        setBottomPadding('ml-[192px] pl-[50px]');
      }
    };

    // Initial check
    checkMainContainer();

    // Create observer
    const observer = new MutationObserver(checkMainContainer);

    // Start observing
    const mainContainer = document.querySelector('.main-container');
    if (mainContainer) {
      observer.observe(mainContainer, {
        attributes: true,
        attributeFilter: ['class']
      });
    }

    // Cleanup
    return () => observer.disconnect();
  }, []);

  const loadEtalaseData = async () => {
    try {
      setLoading(true);
      const response = await MockServer_TambahEtalase.getEtalaseDetail(params.id);

      if (response.data.isDefault) {
        setDataToast({
          type: 'error',
          message: t('etalaseDefaultTidakBisaDiubah')
        });
        setShowToast(true);
        router.push('/daftaretalase');
        return;
      }

      setName(response.data.name);
      setImage(response.data.imageUrl);
      setInitialImage(response.data.imageUrl);

      // Gunakan data langsung dari API tanpa sorting
      setSelectedProducts(response.data.products);
      setInitialProducts(response.data.products);
    } catch (error) {
      setDataToast({
        type: 'error',
        message: 'Gagal memuat data etalase'
      });
      setShowToast(true);
    } finally {
      setLoading(false);
    }
  };

  const handleImageUpload = (base64Image) => {
    console.log(base64Image,'base64Image.url')
    base64Image?setImage(base64Image.url):setImage('');
    setImageError(false);
  };

  const handleImageDelete = (e) => {
    e.preventDefault();
    e.stopPropagation();
    
    try {
      // Reset states
      setImage(null);
      setInitialImage(null);
      setImageError(null);
      
      // Clear input file
      const input = document.getElementById('image-upload');
      if (input) {
        input.value = '';
      }
  
    } catch (error) {
      console.error('Error deleting image:', error);
      setDataToast({
        type: 'error',
        message: t('GagalmenghapusGambar')
      });
      setShowToast(true);
    }
  };

  const handleImageError = (error) => {
    setImageError(error);
    if (error) {
      setDataToast({
        type: 'error',
        message: 'Format file tidak sesuai ketentuan!'
      });
      setShowToast(true);
    }
  };

  const validateForm = () => {
    if (!name.trim()) {
      setNameError(true);
      setDataToast({
        type: 'error',
        message: 'Terdapat field yang kosong'
      });
      setShowToast(true);
      return false;
    }
    setNameError(false);
    return true;
  };

  const handleSave = async () => {
    if (!name.trim()) {
      setNameError(true); // Set nameError ke true
      setDataToast({
        type: 'error',
        message: t('terdapatFieldYangKosong')
      });
      setShowToast(true);
      return;
    }

    try {
      setLoading(true);

      if (!name.trim()) {
        setDataToast({
          type: 'error',
          message: t('terdapatFieldYangKosong')
        });
        setShowToast(true);
        return;
      }

      const data = {
        name: name.trim(),
        image: image,
        products: selectedProducts.map((product, index) => ({
          productId: product.id,
          position: index + 1
        }))
      };

      await MockServer_TambahEtalase.updateEtalase(params.id, data);
      router.push('/daftaretalase');
      
      // Set toast setelah redirect
      localStorage.setItem('showToast', 'true');
      localStorage.setItem('toastMessage', t('etalasemuBerhasilDiubah'));
      localStorage.setItem('toastType', 'success');
      // setTimeout(() => {
      //   setDataToast({
      //     type: 'success',
      //     message: t('etalasemuBerhasilDiubah')
      //   });
      //   setShowToast(true);
      // }, 100);

    } catch (error) {
      if(error.messageKey === 'namaEtalaseTelahaDigunakan') {
        setNameError(true)
      }
      setDataToast({
        type: 'error',
        message: error.messageKey ? t(error.messageKey) : error.message // Use messageKey for translation if available
      });
      setShowToast(true);
    } finally {
      setLoading(false);
    }
  };

  const handleBack = () => {
    setShowLeaveConfirmation(true);
  };

  const handleProductSelection = (newSelectedProducts) => {
    // Check if there are any new products
    const existingProductIds = new Set(selectedProducts.map(p => p.id));
    const hasNewProducts = newSelectedProducts.some(p => !existingProductIds.has(p.id));
  
    // If no new products, keep the existing order
    if (!hasNewProducts) {
      setSelectedProducts(newSelectedProducts);
      return;
    }
  
    // If there are new products, apply sorting rules
    const existingProducts = new Map(selectedProducts.map(p => [p.id, p]));
    
    // Separate new and existing products
    const newProducts = newSelectedProducts.filter(p => !existingProducts.has(p.id));
    const existingSelected = newSelectedProducts.filter(p => existingProducts.has(p.id));
  
    // Sort new products
    const newOutOfStock = newProducts
      .filter(p => p.stock <= 0)
      .sort((a, b) => new Date(b.created) - new Date(a.created));
      
    const newAvailable = newProducts
      .filter(p => p.stock > 0)
      .sort((a, b) => new Date(b.created) - new Date(a.created));
  
    // Keep existing products in their current order
    const existingOutOfStock = existingSelected
      .filter(p => p.stock <= 0);
      
    const existingAvailable = existingSelected
      .filter(p => p.stock > 0);
  
    setSelectedProducts([
      ...newOutOfStock,
      ...existingOutOfStock,
      ...existingAvailable,
      ...newAvailable
    ]);
  };

  const handleDeleteConfirmationCancel = () => {
    setShowDeleteConfirmation(false);
    setShowDeleteMassal(true); // Reopen delete massal popup
    // Tidak perlu mengosongkan itemsToDelete agar tetap terpilih saat kembali
  };

  const handleMassDelete = (productIds) => {
    setItemsToDelete(productIds);
    setMassDeleteSelectedItems(new Set(productIds)); // Simpan state seleksi
    handleShowDeleteConfirmation();
    setShowDeleteMassal(false);
    setDeleteSource('confirmation'); // Set source as confirmation popup
  };

  const handleDeleteProducts = async (productIds) => {
    const newProducts = selectedProducts.filter(p => !productIds.includes(p.id));
    setSelectedProducts(newProducts);
    setShowDeleteConfirmation(false);
    setShowDeleteMassal(false); // Make sure this is also closed
    setItemsToDelete([]);

    // Show toast only if deletion is from confirmation popup
    if (deleteSource === 'confirmation') {
      setDataToast({
        type: 'success',
        message: t('berhasilMenghapusProduk').replace('{count}', productIds.length)
      });
      setShowToast(true);
    }
    setDeleteSource(''); // Reset source after deletion
  };

  const handleFilterSelect = (type, item) => {
    setFilters(prev => {
      const key = type === 'category' ? 'categories' : 'brands';
      const exists = prev[key].find(f => f.id === item.id);

      if (exists) {
        return {
          ...prev,
          [key]: prev[key].filter(f => f.id !== item.id)
        };
      } else {
        return {
          ...prev,
          [key]: [...prev[key], item]
        };
      }
    });
  };

  /**
 * Fungsi untuk menambahkan max-width pada message konfirmasi delete
 * Digunakan untuk mengatur lebar maksimal pesan konfirmasi agar tidak terlalu panjang
 * Target: element span dengan class "font-[500] text-[14px] leading-[16.8px] text-[#000000] text-center"
 * Note: 
 * - Fungsi ini perlu disesuaikan jika ada perubahan pada class di Modal component
 * - Class yang ditarget harus sesuai dengan class di Modal component
 */
// LB - 0122 - etalase
const handleShowDeleteConfirmation = () => {
  setShowDeleteConfirmation(true);
  
  // Beri waktu untuk Modal muncul di DOM
  setTimeout(() => {
    // Perbaiki selector dengan menggunakan kombinasi class yang lebih aman
    const messageElement = document.querySelector('span[class*="font-[500]"][class*="text-[14px]"][class*="leading-[16.8px]"][class*="text-[#000000]"][class*="text-center"]');
    if (messageElement) {
      messageElement.style.maxWidth = '72%';
      messageElement.style.display = 'block';
      messageElement.style.margin = '0 auto';
    }
  }, 100);
};

  const filteredProducts = selectedProducts.filter(product => {
    const searchTermLower = searchTerm.toLowerCase();
    const productName = (product.name || '').toLowerCase();
    const productSku = (product.sku || '').toLowerCase();
    const productBrand = (product.brand || '').toLowerCase();

    const matchesSearch = 
      productName.includes(searchTermLower) ||
      productSku.includes(searchTermLower) ||
      productBrand.includes(searchTermLower);

    const matchesCategories =
      filters.categories.length === 0 ||
      filters.categories.some(c => (product.category?.path || '').includes(c.name));

    const matchesBrands =
      filters.brands.length === 0 ||
      filters.brands.some(b => productBrand.includes(b.name));

    return matchesSearch && matchesCategories && matchesBrands;
  });

  const breadcrumbItems = [
    { text: t('labelDashboard'), path: '/dashboard' },
    { text: t('daftarEtalase'), path: '/daftaretalase' },
    { text: t('ubahEtalase') }
  ];

  if (loading && !name) {
    return <LoadingSkeleton />;
  }

  return (
    <div className="flex flex-col min-h-screen pb-20  w-full relative pb-10">
      {/* Breadcrumb and Header Section */}
      {/*24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0001 */}
      <div className =" pb-4">
        <BreadCrumb items={breadcrumbItems} />
        <div className="flex flex-wrap gap-10 justify-between items-center mt-4 w-full leading-tight">
          <div className="gap-3 self-stretch my-auto text-xl font-bold text-black min-w-[240px] w-[515px]">
            <div className="flex items-center gap-2">
              <ImageComponent
                src="/icons/etalase/iconBack.svg"
                alt={t('labelKembali')}
                width={24}
                height={24}
                className="w-6 h-6 cursor-pointer"
                onClick={() => handleBack()}
              />
              <span>{t('ubahEtalase')}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Form Section */}
      <div className =" pb-4">
        <div className="bg-white rounded-xl p-8  w-full shadow-lg">
          {/* Nama Etalase Section */}
          <div className="flex flex-wrap gap-6 w-full text-xs font-medium leading-tight">
            <label className="gap-2.5 pt-2 h-full text-neutral-500 w-[100px] font-medium font-[500]">
              {t('namaEtalase')}*
            </label>
            <div className="flex flex-col flex-1 shrink my-auto basis-0 min-w-[240px]">
              <input
                type="text"
                value={name}
                onChange={(e) => {
                  setNameError(false);
                  const value = e.target.value;
                  setName(value.slice(0, 80));
                }}
                placeholder={t('masukanNamaEtalase')}
                className={`w-full px-4 py-2 border rounded-md  
                  ${nameError 
                    ? 'border-[#EE4343] focus:border-[#EE4343] focus:ring-[#EE4343]' 
                    : 'border-gray-300 focus:border-blue-600 focus:ring-blue-500 hover:border-blue-500'
                  } focus:outline-none`}
              />
              <div className="flex flex-wrap gap-3 items-start mt-2 w-full whitespace-nowrap h-[7px] text-neutral-500">
                <div className="flex-1 shrink basis-0"></div>
                <div className="text-right">{name.length}/80</div>
              </div>
            </div>
          </div>

          {/* Gambar Section */}
          <div className="flex flex-wrap gap-6 mt-3 w-full">
            <label className="gap-2.5 self-stretch h-full text-xs italic font-medium leading-4 text-neutral-500 w-[100px] font-[500]">
              {t('labelGambar')} <span className="italic font-[400]">{t('labelOpsional')}</span>
            </label>
            <div className="flex flex-col  flex-wrap flex-1 shrink gap-2 items-start my-auto leading-tight basis-0 min-w-[240px]">
            <ImageUploader
                  getImage={handleImageUpload}
                  error={imageError}
                  onError={handleImageError}
                  maxSize={10} // 10MB dalam kilobytes
                  value={image}
                  isBig={false}
                  // uploadText="Unggah Foto"
                  // errorText="Ulangi"
                  // className="!w-[120px] !h-[120px]" // Menyesuaikan ukuran container
                  // onUpload={(value) => {
                  //   setImage(value);
                  //   setImageError(false);
                  // }}
                 
                uploadText={t('labelGambar')}
                isCircle={true}
                className={"!size-[72px]"}
                previewTitle={t('uploadGambar')}
                  />
              <div className="flex-1 shrink gap-4 self-stretch my-auto text-xs font-medium  min-w-[240px] text-neutral-500">
                Format file jpg/png max. 10MB
              </div>
            </div>
          </div>

          {/* Hidden Image Upload Input */}
          {/* <div className="hidden">
            <ImageUploader
              id="image-upload"
              getImage={handleImageUpload}
              error={imageError}
              onError={handleImageError}
              maxSize={10000}
              value={image}
            />
          </div> */}
        </div>

        {/* Product List Section */}
        {selectedProducts.length === 0 ? (
          <div className="mt-4 flex flex-col justify-center items-center px-6 py-5 font-semibold leading-tight bg-white rounded-xl shadow-lg text-neutral-500 w-full">
              <div className="flex flex-col items-center max-w-full text-base text-center w-[117px]">
                <div className="flex min-h-[74px] w-[93px]">
                  {/*24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase - LB - 0222 */}
                  <ImageComponent
                    loading="lazy"
                    src="/icons/import.png"
                    alt="Empty state"
                    className="object-contain w-[93px] min-h-[74px]"
                  />
                </div>
                <div className="mt-3 font-semibold">
                  {t('isiEtalasemu')}
                </div>
              </div>
              <div className="mt-3 text-xs font-medium text-center max-w-full">
                {t('pilihProdukYangSesuai')}
              </div>
              <Button
                onClick={() => setShowProductPopup(true)}
                color="primary"
                Class="gap-1  px-6 py-3 mt-3 text-sm font-semibold text-white bg-blue-600 rounded-3xl min-h-[32px] min-w-[112px] hover:bg-blue-700"
              >
                {t('pilihProduk')}
              </Button>
            </div>
        ) : (
          <div className="mt-4 bg-white rounded-xl pt-6 shadow-lg">
          <div className="flex justify-between items-center mb-6 gap-4 px-6">
            <div className="text-lg font-semibold text-black whitespace-nowrap">{"Produk Terpilih"}</div>
            <div className={isReorderMode ? "flex items-center w-full justify-end" : "flex items-center w-full justify-between"}>
              {!isReorderMode && <SearchFilter onSearch={handleSearch} />}
              <div className="flex items-center gap-3">
                {isReorderMode ? (
                  <>
                    <Button
                      onClick={handleCancelReorder}
                      color='primary_secondary'
                      Class ="px-6 py-2 text-sm font-semibold text-blue-600 border border-blue-600 rounded-3xl hover:bg-blue-50"
                    >
                      {t('labelBatal')}
                    </Button>
                    <Button
                      onClick={handleToggleReorder}
                      color='primary'
                      Class ="px-6 py-2 text-sm font-semibold bg-blue-600 text-white rounded-3xl hover:bg-blue-700"
                    >
                      {t('labelSimpan')}
                    </Button>
                  </>
                ) : (
                  <>
                    <Button
                      onClick={() => setShowDeleteMassal(true)}
                      color='error_secondary'
                      className ="px-6 py-2 text-sm font-semibold text-red-500 border border-red-500 rounded-3xl hover:bg-red-50"
                    >
                      {t('hapusMassal')}
                    </Button>
                    <Button
                      onClick={() => setIsReorderMode(true)}
                      color='primary_secondary'
                      Class ="px-6 py-2 text-sm font-semibold text-blue-600 border border-blue-600 rounded-3xl hover:bg-blue-50"
                    >
                      {t('susunProduk')}
                    </Button>
                    <Button
                      onClick={() => setShowProductPopup(true)}
                      color='primary'
                      Class ="px-6 py-2 text-sm font-semibold bg-blue-600 text-white rounded-3xl hover:bg-blue-700"
                    >
                      {t('labelTambah')}
                    </Button>
                  </>
                )}
              </div>
            </div>
          </div>

          <ProductTable 
            products={isReorderMode ? tempProducts : (searchTerm ? displayProducts : selectedProducts)}
            onDelete={(id) => {
              setDeleteSource('table');
              handleDeleteProducts([id]);
            }}
            onReorder={setTempProducts}
            isReorderMode={isReorderMode}
            showActions={true}
          />
        </div>
        )}
      </div>

      {/* Fixed Bottom Save Button */}
      <div className={isReorderMode?"hidden":"fixed bottom-0 left-0 right-0 z-0"}>
        <div className={`${bottomPadding} pr-[48px] bg-white border-t border-gray-200 p-4`}>
          <div className="flex justify-between items-center">
            <div className="text-sm font-bold text-black">
            {t('totalProduk')} : {selectedProducts.length}
            </div>
            <Button 
              onClick={handleSave}
              disabled={loading}
              color='primary'
              Class ="px-6 py-2 text-sm font-semibold bg-blue-600 text-white rounded-3xl disabled:bg-gray-300 hover:enabled:bg-blue-700 min-h-[32px]"
            >
              {t('labelSimpan')}
            </Button>
          </div>
        </div>
      </div>

      {/* Popups */}
      {showProductPopup && (
        <UnifiedProductPopup
          mode="select"
          selectedProducts={selectedProducts}
          onClose={() => setShowProductPopup(false)}
          onConfirm={handleProductSelection}
          etalaseId={params.id}
        />
      )}

      <Toast />
      
      {showDeleteMassal && (
        <UnifiedProductPopup
          mode="delete"
          selectedProducts={selectedProducts}
          onClose={() => setShowDeleteMassal(false)}
          onDelete={handleMassDelete}
          initialSelectedItems={massDeleteSelectedItems} // Tambahkan prop ini
          onSelectedItemsChange={setMassDeleteSelectedItems} // Tambahkan prop ini
        />
      )}

      {showDeleteConfirmation && (
        <DeleteConfirmationPopup
          title={''}
          message={t('konfirmasiHapusSekaligus').replace('{count}', itemsToDelete.length)}
          onConfirm={() => handleDeleteProducts(itemsToDelete)}
          onCancel={handleDeleteConfirmationCancel}
          confirmLabel={t('labelYaHapus')}
        />
      )}

      {showLeaveConfirmation && (
        <ConfirmLeavePopup
          onConfirm={() => router.back()}
          onCancel={() => setShowLeaveConfirmation(false)}
          variant = 'primary'
        />
      )}
    </div>
  );
};

export default UpdateEtalasePage;