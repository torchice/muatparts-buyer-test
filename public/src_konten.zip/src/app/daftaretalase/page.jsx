// 24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase
//LB - 0066
'use client';
import React, { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Search, Plus, X } from 'lucide-react'; // Add X import
import { MockServer_TambahEtalase } from '@/services/MockServer_TambahEtalase';
import Toast from '@/components/Toast/Toast';
import ConfirmationPopup from './popup/ConfirmationPopup';
import Image from 'next/image';
import IconBack from '@/icons/iconBack.svg';
import { DragDropContext, Draggable, Droppable } from '@hello-pangea/dnd';
import DaftarEtalaseSvg from '@/icons/Daftar Etalase.svg';
import toast from "@/store/zustand/toast"; // Add this import
import ImageComponent from '@/components/ImageComponent/ImageComponent';
import CustomLink from '@/components/CustomLink';
import { useCustomRouter } from '@/libs/CustomRoute';
import useFilterStore from '@/store/zustand/filterstore'; // Add this import at the top with other imports
import useSusunProdukStore from '@/store/susunProdukStore';
import Button from "@/components/Button/Button";
import { useTranslation } from '@/context/TranslationProvider';
import TranslationSkeleton from '@/components/Skeleton/TranslationSkeleton';



const DaftarEtalasePage = () => {
  const router = useCustomRouter();
  const searchParams = useSearchParams();
  // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0866
  const { tOrEmpty } = useTranslation();
  const { showToast, setShowToast, setDataToast } = toast(); // Add this

  const [loading, setLoading] = useState(true);
  const [etalases, setEtalases] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [deleteConfirm, setDeleteConfirm] = useState({ show: false, id: null });
  const [stats, setStats] = useState({ total: 0, max: 10 });
  const resetFilters = useFilterStore((state) => state.resetFilters); // Add this line
  const { products, setProducts, clearProducts } = useSusunProdukStore();

  const success = searchParams.get('success');
  // fixing 17/03/2025
  const tableRef = React.useRef(null);

  //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0150, LB - 0156
  useEffect(() => {
    const toastBol = localStorage.getItem('showToast');
    const toastMessage = localStorage.getItem('toastMessage');
    const toastType = localStorage.getItem('toastType');
    if(toastBol){
      setDataToast({
        type: toastType,
        message: toastMessage
      });
      setShowToast(true);
      localStorage.removeItem('showToast');
      localStorage.removeItem('toastMessage');
      localStorage.removeItem('toastType');
    }
  })
  
  useEffect(() => {
    // Show success toast based on query param
    if (success === 'create') {
      setDataToast({
        type: 'success',
        message: tOrEmpty('berhasilMenambahEtalase')
      });
      setShowToast(true);
    } else if (success === 'update') {
      setDataToast({
        type: 'success',
        message: tOrEmpty('etalasemuBerhasilDiubah') 
      });
      setShowToast(true);
    }
  }, [success]);

  // Initialize language from URL
  // useEffect(() => {
  //   const urlLang = searchParams.get('lang');
  //   if (urlLang && urlLang !== currentLocale) {
  //     changeLanguage(urlLang);
  //   }
  // }, [searchParams, currentLocale, changeLanguage]);


  useEffect(() => {
    loadEtalases();
    localStorage.removeItem('etalaseSourceRoute')
  }, [searchTerm]);
  

  const loadEtalases = async () => {
    try {
      setLoading(true);
      resetFilters()
      const response = await MockServer_TambahEtalase.getEtalaseList(searchTerm);
      console.log(response,'response')
      setEtalases(response.data.etalase);
      setStats({
        total: response.data.totalEtalase,
        max: response.data.maxEtalase
      });
    } catch (error) {
      setDataToast({
        type: 'error',
        message: error.message || tOrEmpty('gagalMemuatDaftarEtalase')
      });
      setShowToast(true);
    } finally {
      setLoading(false);
    }
  };

  const handleAddClick = async () => {
    
    clearProducts()
    localStorage.removeItem('susun-produk-storage'); // Add this line
    if (stats.total >= stats.max) {
      setDataToast({
        type: 'error',
        message: tOrEmpty('etalaseSellerMaks').replace('{count}', formatNumber(stats.max))
      });
      setShowToast(true);
      return;
    }
    router.push('/daftaretalase/add');
  };

  const handleDeleteClick = async () => {
    if (!deleteConfirm.id) return;

    try {
      setLoading(true);
      await MockServer_TambahEtalase.deleteEtalase(deleteConfirm.id);
      setDataToast({
        type: 'success',
        message: tOrEmpty('berhasilMenghapusEtalase')
      });
      setShowToast(true);
      loadEtalases();
    } catch (error) {
      setDataToast({
        type: 'error',
        message: tOrEmpty('gagalMenghapusEtalase')
      });
      setShowToast(true);
    } finally {
      setLoading(false);
      setDeleteConfirm({ show: false, id: null });
    }
  };

  const formatNumber = (num) => {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  };

  const onDragEnd = async (result) => {
    if (!result.destination) return;

    // Get dragged item and destination item
    const draggedItem = etalases[result.source.index];
    const destinationItem = etalases[result.destination.index];
    
    // Prevent dragging default etalase or dragging items to position before/after default etalase
    if (draggedItem.isDefault || destinationItem?.isDefault) {
      return;
    }

    // Get all default etalase indices
    const defaultEtalaseIndices = etalases
      .map((etalase, index) => etalase.isDefault ? index : -1)
      .filter(index => index !== -1);

    // Check if trying to drag across default etalase
    const isDraggingAcrossDefault = defaultEtalaseIndices.some(defaultIndex => {
      return (result.source.index < defaultIndex && result.destination.index > defaultIndex) ||
             (result.source.index > defaultIndex && result.destination.index < defaultIndex);
    });

    if (isDraggingAcrossDefault) {
      return;
    }

    const items = Array.from(etalases);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);

    // Update UI immediately
    setEtalases(items);

    try {
      // Filter out default etalase when preparing positions
      const positions = items
        .filter(etalase => !etalase.isDefault)
        .map((etalase, index) => ({
          etalaseId: etalase.id,
          position: index + 1
        }));

      await MockServer_TambahEtalase.updateEtalaseOrder(positions);

    } catch (error) {
      loadEtalases();
      setDataToast({
        type: 'error',
        message: tOrEmpty('gagalMenyusunUrutanEtalase')
      });
      setShowToast(true);
    }
  };

  const handleSearchSubmit = (e) => {
    if (e.key === 'Enter') {
      setSearchTerm(searchQuery);
    }
  };

  const clearSearch = () => {
    setSearchQuery('');
    setSearchTerm('');
  };

  return (
  //  {/*24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0001 */}
    <div className="min-h-screen  pb-6 w-full">
      {/* Updated Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          {/* <Image 
            src={IconBack} 
            alt="Back"
            className="w-6 h-6 cursor-pointer hover:opacity-80 transition-opacity"
            onClick={() => router.back()}
          /> */}
          <TranslationSkeleton 
            label="daftarEtalase"
            className="text-xl font-bold text-zinc-900"
            skeletonClassName="w-[200px] h-5"
          />
        </div>
        <Button
        color='primary'
          onClick={handleAddClick}
          Class="inline-flex items-center justify-center gap-2 px-6 py-2 bg-blue-600 text-white text-sm font-semibold rounded-full hover:bg-blue-700 transition-colors  min-w-[112px]"
        >
          <Plus className="w-5 h-5" />
          <span>{tOrEmpty('tambahEtalase')}</span>
        </Button>
      </div>

      {/* Updated Main Content */}
      <div className="bg-white rounded-xl shadow-lg">
        {/* Refined Search Bar */}
        <div className="p-4 border-b border-stone-300">
          <div className="relative w-64">
            <input
              type="text"
              placeholder={tOrEmpty('cariNamaEtalase')}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyPress={handleSearchSubmit}
              className="w-full pl-10 pr-10 py-2 border rounded-md transition-all
                hover:border-blue-600 focus:border-blue-600 focus:outline-none focus:border-blue-600 focus:ring-blue-100
                text-sm font-medium"
            />
            <Search className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500" />
            {searchQuery && (
              <button
                onClick={clearSearch}
                Class="absolute right-3 top-1/2 -translate-y-1/2 hover:bg-gray-100 p-1 rounded-full transition-colors"
              >
                <X className="w-4 h-4 text-neutral-500" />
              </button>
            )}
          </div>
        </div>

        {/* Updated Table Header */}
        {/* // fixing 17/03/2025 */}
        <table ref={tableRef} className="w-full table-fixed">
          <thead>
            <tr className="text-xs font-bold text-neutral-500 border-b border-stone-300">
              <th className="text-left p-4 font-bold w-[30%]">{tOrEmpty('namaEtalase')}</th>
              <th className="text-left p-4 font-bold w-[15%]">{tOrEmpty('jumlahProduk')}</th>
              <th className="text-left p-4 font-bold w-[15%]">{tOrEmpty('totalTerjual')}</th>
              <th className="text-right p-4 font-bold w-[40%]"></th>
            </tr>
          </thead>

          <DragDropContext onDragEnd={onDragEnd}>
            <Droppable droppableId="etalase-list" type="ETALASE">
              {(provided) => (
                <tbody 
                  {...provided.droppableProps}
                  ref={provided.innerRef}
                  className="text-sm"
                >
                  {loading ? (
                    <LoadingSkeleton />
                  ) : etalases.length === 0 ? (
                    <tr>
                      <td colSpan={4} className="text-center py-8">
                        <div className="flex flex-col items-center gap-3">
                          {/*24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0066 */}
                          <ImageComponent 
                            src="/icons/etalase/search-not-found.png"
                            alt="Search Not Found"
                            className="w-36 h-36 object-contain"
                          />
                          <span className="text-neutral-500 font-medium">
                            {tOrEmpty('keywordTidakDitemukan')}
                          </span>
                        </div>
                      </td>
                    </tr>
                  ) : (
                    etalases.map((etalase, index) => (
                      <Draggable 
                        key={etalase.id} 
                        draggableId={etalase.id.toString()} 
                        index={index}
                        isDragDisabled={etalase.isDefault}
                      >
                        {(provided, snapshot) => {
                          // Add custom dragging styles
                          // fixing 17/03/2025
                          if (snapshot.isDragging) {
                            provided.draggableProps.style = {
                              ...provided.draggableProps.style,
                              display: 'inline-table',
                              tableLayout: 'fixed',
                              width: tableRef.current?.offsetWidth || '100%'
                            }
                          }
                          
                          return (
                            <tr
                              ref={provided.innerRef}
                              {...provided.draggableProps}
                              className={`border-b transition-colors
                                ${snapshot.isDragging ? 'bg-blue-50' : 'hover:bg-gray-50'}
                                ${etalase.isDefault ? '' : ''}`}
                            >
                              {/* // fixing 17/03/2025 */}
                              <td className="p-4 w-[29.5%]">
                                <div className="flex items-center gap-3">
                                  {etalase.isDefault ? (
                                    <ImageComponent
                                      src="/icons/etalase/semua_produk.png"
                                      alt={etalase.name}
                                      width={48}
                                      height={48}
                                    />
                                  ) : etalase.imageUrl ? (
                                    //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0198
                                    <ImageComponent
                                      src={etalase.imageUrl}
                                      alt={etalase.name}
                                      width={48}
                                      height={48}
                                      className="w-[56px] h-[56px] object-cover"
                                      style={{borderRadius: '4px'}}
                                    />
                                  ) : (
                                    <ImageComponent
                                      src={"/icons/etalase/Daftar Etalase.svg"}
                                      alt={etalase.name}
                                      width={48}
                                      height={48}
                                    />
                                  )}
                                  <span className="font-bold line-clamp-2">
                                    {etalase.name}
                                  </span>
                                </div>
                              </td>
                              {/* // fixing 17/03/2025 */}
                              <td className="p-4 font-bold w-[15.8%]">
                                {etalase.totalProducts>0? formatNumber(etalase.totalProducts):'0'}
                              </td>
                              <td className="p-4 font-bold">
                                {etalase.totalSold>0?formatNumber(etalase.totalSold):'0'}
                              </td>
                              <td className="p-4">
                                <div className="flex justify-end gap-3 ">
                                  {!etalase.isDefault && (
                                    <>
                                      <div
                                        {...provided.dragHandleProps}
                                        className={`flex gap-1 justify-center items-center self-stretch px-3 py-2  rounded-full border min-h-[32px] w-10
                                          ${etalase.isDefault 
                                            ? 'cursor-not-allowed opacity-50 border-gray-300'
                                            : 'min-w-fit cursor-grab active:cursor-grabbing border-blue-600 hover:bg-[#E2F2FF] transition-colors'
                                          }`}
                                      >
                                         <ImageComponent
                                          src="/icons/etalase/drag-item.svg"
                                          alt="Drag Handle"
                                          width={16}
                                          height={16}
                                          className={`object-contain self-stretch my-auto transition-opacity ${
                                            etalase.isDefault 
                                              ? 'opacity-50' 
                                              : 'opacity-70 group-hover:opacity-100'
                                          }`}
                                        />
                                      </div>
                                      <Button 
                                      color="error_secondary"
                                        onClick={() => setDeleteConfirm({ show: true, id: etalase.id })}
                                        Class ="py-2 my-auto px-[35px] text-red-500 border border-red-500 rounded-full hover:bg-red-50 transition-colors text-sm font-semibold whitespace-nowrap"
                                      >
                                        {tOrEmpty('labelHapus')}
                                      </Button>
                                      <Button
                                      color="primary_secondary"
                                        onClick={() => router.push(`/daftaretalase/edit/${etalase.id}`)}
                                        Class ="py-2 my-auto px-[35px] text-blue-600 border border-blue-600 rounded-full hover:bg-blue-50 transition-colors text-sm font-semibold whitespace-nowrap"
                                      >
                                        {tOrEmpty('labelUbah')}
                                      </Button>
                                    </>
                                  )}
                                  <CustomLink
                                    href={`/daftaretalase/detail/${etalase.id}`}
                                    className ="py-2 my-auto px-[35px] bg-blue-600 text-white rounded-full hover:bg-blue-800 hover:text-white hover:no-underline transition-colors text-sm font-semibold whitespace-nowrap focus:text-white hover:no-underline"
                                  >
                                    {tOrEmpty('labelDetail')}
                                  </CustomLink>
                                </div>
                              </td>
                            </tr>
                          )}}
                      </Draggable>
                    ))
                  )}
                  {provided.placeholder}
                </tbody>
              )}
            </Droppable>
          </DragDropContext>
        </table>
      </div>

      {/* Updated Footer Stats */}
      <div className="flex justify-between mt-4 px-1">
        <div className="text-sm text-neutral-500 font-medium">
          {tOrEmpty('totalEtalase')} : {stats.total}
        </div>
        <div className="text-sm text-neutral-500 font-medium">
          ({tOrEmpty('etalaseMaks').replace('{count}', formatNumber(stats.max))})
        </div>
      </div>

      {/* Confirmation Modal with Updated Design */}
      {deleteConfirm.show && (
        <ConfirmationPopup
          title={tOrEmpty('')}
          message={tOrEmpty('konfirmasiHapusEtalase')}
          onConfirm={handleDeleteClick}
          onCancel={() => setDeleteConfirm({ show: false, id: null })}
          confirmLabel={tOrEmpty('labelYaHapus')}
          cancelLabel={tOrEmpty('labelBatal')}
          variant=""
        />
      )}

      <Toast />
    </div>
  );
}

const LoadingSkeleton = () => (
  <>
    {[...Array(3)].map((_, i) => (
      <tr key={i} className="animate-pulse border-b">
        <td className="p-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gray-200 rounded" />
            <div className="h-4 bg-gray-200 rounded w-32" />
          </div>
        </td>
        <td className="p-4">
          <div className="h-4 bg-gray-200 rounded w-16" />
        </td>
        <td className="p-4">
          <div className="h-4 bg-gray-200 rounded w-16" />
        </td>
        <td className="p-4">
          <div className="flex justify-end gap-3">
            <div className="w-24 h-8 bg-gray-200 rounded-full" />
            <div className="w-24 h-8 bg-gray-200 rounded-full" />
          </div>
        </td>
      </tr>
    ))}
  </>
);

export default DaftarEtalasePage;