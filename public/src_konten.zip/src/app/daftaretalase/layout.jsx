'use client';
import "./etalase.scss"
import React, { useEffect } from 'react';
import { usePathname } from 'next/navigation';
import TopBar from "@/components/headersellercomponents/TopBar";
import SidebarWithDropdown from "@/components/headersellercomponents/SidebarWithDropdown";
import ResponsiveHandler from '@/providers/ResponsiveHandler/ResponsiveHandler';
import { LanguageProvider } from '@/providers/LanguageProvider';
import MainApp from '@/common/MainApp';
import headerZustand from "@/store/zustand/header";
import toast from "@/store/zustand/toast";


 

const Layout = ({children}) => {
    const pathname = usePathname();
    const isMobilePath = pathname.includes('/mobile');
    const isMobile = window.innerWidth <= 480;
    const { setShowNavMenu } = toast()
    const { setHeader,header } = headerZustand()
    useEffect(() => {
        if(!isMobile && header){
            setShowNavMenu(false)
            setHeader(false)
        }
       
    }, [header])

    return (
        <ResponsiveHandler>
            <LanguageProvider>
            <div className="flex flex-col min-h-screen ">
                {/* Top Bar */}
                {/* {!isMobilePath && <TopBar />} */}
                
                {/* Main Content */}
                <div className={`flex w-full ${!isMobilePath ? 'pt-[0px]' : ''} max-md:max-w-full`}>
                    {/* Sidebar */}
                    {/* {!isMobilePath && <SidebarWithDropdown />} */}
                    
                    {/* Page Content - Add left margin to account for sidebar */}
                    <main className={`flex-1 w-full ${!isMobilePath ? 'ml-[0px]' : ''}`}>
                    {/* {!isMobilePath ? <MainApp>{children}</MainApp>:<>{children}</>} */}
                    {children}
                    </main>
                </div>
            </div>     
            </LanguageProvider>
        </ResponsiveHandler>
    );
};

export default Layout;