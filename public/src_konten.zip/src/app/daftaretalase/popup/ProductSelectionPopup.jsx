import React, { useState, useEffect } from 'react';
import { X, ChevronDown, Search } from 'lucide-react';
import { MockServer_TambahEtalase } from '@/services/MockServer_TambahEtalase';
import _ from 'lodash';
import { useLanguage } from "@/providers/LanguageProvider";
import ImageComponent from '@/components/ImageComponent/ImageComponent';
import Button from "@/components/Button/Button";

const mockProducts = [
  {
    id: "1",
    name: "Peralatan Angkutan Test",
    sku: "SKU123456",
    brand: "UD Truck",
    imageUrl: "https://cdn.builder.io/api/v1/image/assets/60cdcdaf919148d9b5b739827a6f5b2a/d0fda75fb24c25a96d87fe40765be8e2487514f2e43a2794febe0f0a576c5662?apiKey=60cdcdaf919148d9b5b739827a6f5b2a&",
    category: {
      id: "cat1",
      name: "Produk Lainnya"
    },
    price: {
      min: 1350000,
      max: 1500000
    },
    stock: 300,
    status: "ACTIVE"
  },
  {
    id: "2",
    name: "Angkutan Peralatan Two",
    sku: "SKU789012",
    brand: "Hino",
    imageUrl: "https://cdn.builder.io/api/v1/image/assets/60cdcdaf919148d9b5b739827a6f5b2a/d0fda75fb24c25a96d87fe40765be8e2487514f2e43a2794febe0f0a576c5662?apiKey=60cdcdaf919148d9b5b739827a6f5b2a&",
    category: {
      id: "cat2",
      name: "Sparepart" 
    },
    price: {
      min: 2500000,
      max: 3000000
    },
    stock: 150,
    status: "ACTIVE"
  }
];

const mockCategories = [
  { id: "cat1", name: "Produk Lainnya" },
  { id: "cat2", name: "Sparepart" },
  { id: "cat3", name: "Tools" }
];

const mockBrands = [
  { id: "b1", name: "UD Truck" },
  { id: "b2", name: "Hino" },
  { id: "b3", name: "Mitsubishi" }
];


export default function ProductSelectionPopup({ onClose, onSelect, selectedProducts = [] }) {
  const { t } = useLanguage();
  // States for popup data and UI
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedItems, setSelectedItems] = useState(
    new Set(selectedProducts.map(p => p.id))
  );
  
  // Search and filter states
  const [search, setSearch] = useState('');
  const [searchDebounced, setSearchDebounced] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [activeFilters, setActiveFilters] = useState({
    categories: [],
    brands: []
  });
  
  // Sort states
  const [sortConfig, setSortConfig] = useState({
    field: '',
    direction: 'asc'  // 'asc' or 'desc'
  });
  
  // Filter dropdown states
  const [filterType, setFilterType] = useState(null); // 'category' or 'brand'
  const [filterSearch, setFilterSearch] = useState('');
  const [filterOptions, setFilterOptions] = useState({
    categories: [],
    brands: []
  });

  // Debounced search handler
  useEffect(() => {
    const handler = setTimeout(() => {
      setSearchDebounced(search);
    }, 300);

    return () => clearTimeout(handler);
  }, [search]);

  // Load products
  useEffect(() => {
    const loadProducts = async () => {
      setLoading(true);
      try {
        const params = {
          search: searchDebounced,
          categoryIds: activeFilters.categories.map(c => c.id),
          brandIds: activeFilters.brands.map(b => b.id),
          sort: sortConfig.field,
          order: sortConfig.direction
        };
        
        const response = await MockServer_TambahEtalase.getProductList(params);
        setProducts(response.data.products);
      } catch (error) {
        console.error('Failed to load products:', error);
      } finally {
        setLoading(false);
      }
    };

    loadProducts();
  }, [searchDebounced, activeFilters, sortConfig]);

  // Load filter options
  useEffect(() => {
    const loadFilterOptions = async () => {
      try {
        if (filterType === 'category') {
          const response = await MockServer_TambahEtalase.getCategoryFilter(filterSearch);
          setFilterOptions(prev => ({
            ...prev,
            categories: response.data.categories
          }));
        } else if (filterType === 'brand') {
          const response = await MockServer_TambahEtalase.getBrandFilter(filterSearch);
          setFilterOptions(prev => ({
            ...prev,
            brands: response.data.brands
          }));
        }
      } catch (error) {
        console.error('Failed to load filter options:', error);
      }
    };

    if (filterType) {
      loadFilterOptions();
    }
  }, [filterType, filterSearch]);

  const handleSearchInput = (e) => {
    if (e.key === 'Enter' || e.type === 'change') {
      setSearch(e.target.value);
    }
  };

  const handleSort = (field) => {
    setSortConfig(prev => ({
      field,
      direction: prev.field === field && prev.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  const handleFilterSelect = (type, item) => {
    setActiveFilters(prev => {
      const key = type === 'category' ? 'categories' : 'brands';
      const exists = prev[key].find(f => f.id === item.id);
      
      if (exists) {
        return {
          ...prev,
          [key]: prev[key].filter(f => f.id !== item.id)
        };
      } else {
        return {
          ...prev,
          [key]: [...prev[key], item]
        };
      }
    });
  };

  const handleSelectAll = () => {
    if (selectedItems.size === products.length) {
      setSelectedItems(new Set());
    } else {
      setSelectedItems(new Set(products.map(p => p.id)));
    }
  };

  const handleItemSelect = (productId) => {
    const newSelected = new Set(selectedItems);
    if (newSelected.has(productId)) {
      newSelected.delete(productId);
    } else {
      newSelected.add(productId);
    }
    setSelectedItems(newSelected);
  };

  const handleSave = () => {
    const selectedProductsList = products.filter(p => selectedItems.has(p.id));
    console.log('Selected Products:', selectedProductsList);
  // const selectedProductsList = [
  //     {
  //       id: "1",
  //       name: "Peralatan Angkutan Test",
  //       sku: "SKU123456",
  //       brand: "UD Truck",
  //       image: "",
  //       categories: ["Produk Lainnya", "Tools Diagnosa"],
  //       stock: 300,
  //       price: "Rp 1.350.000",
  //       sold: "40 Terjual"
  //     },
  //     {
  //       id: "2",
  //       name: "Angkutan Peralatan Two",
  //       sku: "SKU789012",
  //       brand: "UD Truck",
  //       image: "https://cdn.builder.io/api/v1/image/assets/60cdcdaf919148d9b5b739827a6f5b2a/d0fda75fb24c25a96d87fe40765be8e2487514f2e43a2794febe0f0a576c5662?apiKey=60cdcdaf919148d9b5b739827a6f5b2a&",
  //       categories: ["Produk Lainnya", "Sparepart"],
  //       stock: 2,
  //       price: "Rp 2.500.000",
  //       sold: "25 Terjual"
  //     }
  //   ];
    onSelect(selectedProductsList);
    onClose();
  };

  // Table component with sorting, loading states etc.
  const ProductTable = () => (
    <table className="w-full">
      <thead className="bg-white sticky top-0 z-10 border-b">
        <tr>
          <th className="p-4">
            <input
              type="checkbox"
              checked={selectedItems.size === products.length && products.length > 0}
              onChange={handleSelectAll}
              className="rounded border-gray-300"
            />
          </th>
          <th 
            className="p-4 text-left cursor-pointer"
            onClick={() => handleSort('name')}
          >
            Nama Produk
            {sortConfig.field === 'name' && (
              <span>{sortConfig.direction === 'asc' ? ' ↑' : ' ↓'}</span>
            )}
          </th>
          <th 
            className="p-4 text-left cursor-pointer"
            onClick={() => handleSort('category')}
          >
            Kategori
            {sortConfig.field === 'category' && (
              <span>{sortConfig.direction === 'asc' ? ' ↑' : ' ↓'}</span>
            )}
          </th>
          <th 
            className="p-4 text-left cursor-pointer"
            onClick={() => handleSort('price')}
          >
            Harga Jual
            {sortConfig.field === 'price' && (
              <span>{sortConfig.direction === 'asc' ? ' ↑' : ' ↓'}</span>
            )}
          </th>
        </tr>
      </thead>
      <tbody className="relative">
        {loading ? (
          <LoadingSkeleton />
        ) : products.length === 0 ? (
          <tr>
            <td colSpan={4} className="p-8 text-center">
              <div className="flex flex-col items-center gap-2">
                <ImageComponent 
                  src="/icons/etalase/search-not-found.png"
                  alt="Search Not Found"
                  width={144}
                  height={144}
                  className="object-contain"
                />
                <span className="text-[#7b7b7b]">Keyword Tidak Ditemukan</span>
              </div>
            </td>
          </tr>
        ) : (
          products.map(product => (
            <tr key={product.id} className="border-b hover:bg-gray-50">
              <td className="p-4">
                <input
                  type="checkbox"
                  checked={selectedItems.has(product.id)}
                  onChange={() => handleItemSelect(product.id)}
                  className="rounded border-gray-300"
                />
              </td>
              <td className="p-4">
                <div className="flex gap-3">
                  <ImageComponent
                    src={product.imageUrl}
                    alt={product.name}
                    width={56}
                    height={56}
                    className="object-cover rounded"
                  />
                  <div>
                    <div className="font-medium">{product.name}</div>
                    <div className="text-sm text-[#7b7b7b]">
                      SKU: {product.sku || '-'}
                      <br />
                      Brand: {product.brand}
                    </div>
                  </div>
                </div>
              </td>
              <td className="p-4">{product.category.path}</td>
              <td className="p-4">
                {product.price.min === product.price.max ? 
                  `Rp${product.price.min.toLocaleString()}` :
                  `Rp${product.price.min.toLocaleString()} - Rp${product.price.max.toLocaleString()}`
                }
              </td>
            </tr>
          ))
        )}
      </tbody>
    </table>
  );

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl w-[800px] max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex justify-between items-center p-4 border-b">
          <h2 className="text-lg font-semibold">{t('pilihProduk')}</h2>
          <button onClick={onClose}>
            <X className="w-5 h-5 text-[#7b7b7b]" />
          </button>
        </div>

        {/* Search and Filters */}
        <div className="p-4 border-b">
          <div className="flex gap-3">
            <div className="flex-1 relative">
              <input
                type="text"
                placeholder={t('cariNamaProduk')}
                value={search}
                onChange={handleSearchInput}
                onKeyDown={(e) => e.key === 'Enter' && handleSearchInput(e)}
                className="w-full pl-10 pr-4 py-2 border rounded-md"
              />
              <Search className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            </div>
            <FilterDropdown
              activeFilters={activeFilters}
              onFilterSelect={handleFilterSelect}
              filterOptions={filterOptions}
              filterType={filterType}
              setFilterType={setFilterType}
              filterSearch={filterSearch}
              setFilterSearch={setFilterSearch}
            />
          </div>

          {/* Active Filters */}
          {(activeFilters.categories.length > 0 || activeFilters.brands.length > 0) && (
            <div className="mt-3 flex flex-wrap gap-2 items-center">
              {[...activeFilters.categories, ...activeFilters.brands].map(filter => (
                <span 
                  key={filter.id}
                  className="px-3 py-1 bg-blue-50 text-[#176CF7] rounded-full text-sm flex items-center gap-1"
                >
                  {filter.name}
                  <X 
                    className="w-4 h-4 cursor-pointer"
                    onClick={() => handleFilterSelect(
                      activeFilters.categories.includes(filter) ? 'category' : 'brand',
                      filter
                    )}
                  />
                </span>
              ))}
              <button
                onClick={() => setActiveFilters({ categories: [], brands: [] })}
                className="text-[#176CF7] text-sm"
              >
                Hapus Semua Filter
              </button>
            </div>
          )}
        </div>

        {/* Products Table */}
        <div className="flex-1 overflow-auto">
          <ProductTable />
        </div>

        {/* Footer */}
        <div className="border-t p-4 flex justify-between items-center">
          <div className="text-sm text-[#7b7b7b]">
            {t('labelTerpilih')}: {selectedItems.size} {t('labelProduk')}
          </div>
          <Button
            onClick={handleSave}
            disabled={selectedItems.size === 0}
            className="px-6 py-2 rounded-full bg-blue-600 text-white disabled:bg-gray-300 disabled:cursor-not-allowed relative group"
          >
            {t('labelSimpan')}
            {selectedItems.size === 0 && (
              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 whitespace-nowrap bg-gray-900 text-white text-sm px-3 py-1.5 rounded opacity-0 group-hover:opacity-100 transition-opacity">
                {t('pilihMinimal1Produk')}
              </div>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}

const LoadingSkeleton = () => (
  <>
    {[...Array(5)].map((_, i) => (
      <tr key={i} className="animate-pulse">
        <td className="p-4">
          <div className="w-4 h-4 bg-gray-200 rounded" />
        </td>
        <td className="p-4">
          <div className="flex gap-3">
            <div className="w-12 h-12 bg-gray-200 rounded" />
            <div className="flex-1">
              <div className="h-4 bg-gray-200 rounded w-48 mb-2" />
              <div className="h-3 bg-gray-200 rounded w-32" />
            </div>
          </div>
        </td>
        <td className="p-4">
          <div className="h-4 bg-gray-200 rounded w-32" />
        </td>
        <td className="p-4">
          <div className="h-4 bg-gray-200 rounded w-24" />
        </td>
      </tr>
    ))}
  </>
);

const FilterDropdown = ({
  activeFilters,
  onFilterSelect,
  filterOptions,
  filterType,
  setFilterType,
  filterSearch,
  setFilterSearch
}) => {
  return (
    <div className="relative">
      <Button 
        onClick={() => setFilterType(filterType ? null : 'category')}
        className="px-4 py-2 border rounded-md flex items-center gap-2"
      >
        Filter
        <ChevronDown className="w-4 h-4" />
      </Button>

      {filterType && (
        <div className="absolute right-0 top-full mt-2 w-64 bg-white rounded-md shadow-lg border z-20">
          <div className="p-3">
            <input
              type="text"
              placeholder={`Cari ${filterType === 'category' ? 'kategori' : 'brand'}...`}
              value={filterSearch}
              onChange={(e) => setFilterSearch(e.target.value)}
              className="w-full px-3 py-2 border rounded-md"
            />
          </div>
          
          <div className="max-h-60 overflow-y-auto">
            {filterType === 'category' ?
              filterOptions.categories.map(category => (
                <div
                  key={category.id}
                  className="px-4 py-2 hover:bg-gray-50 cursor-pointer flex items-center"
                  onClick={() => onFilterSelect('category', category)}
                >
                  <input
                    type="checkbox"
                    checked={activeFilters.categories.some(f => f.id === category.id)}
                    onChange={() => {}}
                    className="mr-2"
                  />
                  <span className="truncate">{category.name}</span>
                </div>
              ))
              :
              filterOptions.brands.map(brand => (
                <div
                  key={brand.id}
                  className="px-4 py-2 hover:bg-gray-50 cursor-pointer flex items-center"
                  onClick={() => onFilterSelect('brand', brand)}
                >
                  <input
                    type="checkbox"
                    checked={activeFilters.brands.some(f => f.id === brand.id)}
                    onChange={() => {}}
                    className="mr-2"
                  />
                  <span className="truncate">{brand.name}</span>
                </div>
              ))
            }
            {((filterType === 'category' && filterOptions.categories.length === 0) ||
              (filterType === 'brand' && filterOptions.brands.length === 0)) && (
              <div className="px-4 py-2 text-sm text-[#7b7b7b]">
                Data Tidak Ditemukan
              </div>
            )}
          </div>
        </div>
      )}

      {filterType === null && (
        <div className="absolute right-0 top-full mt-2 w-48 bg-white rounded-md shadow-lg border z-20">
          <div 
            className="px-4 py-2 hover:bg-gray-50 cursor-pointer flex justify-between items-center group"
            onClick={() => setFilterType('category')}
          >
            <span>Kategori</span>
            <ChevronDown className="w-4 h-4 invisible group-hover:visible" />
          </div>
          <div 
            className="px-4 py-2 hover:bg-gray-50 cursor-pointer flex justify-between items-center group"
            onClick={() => setFilterType('brand')}
          >
            <span>Brand</span>
            <ChevronDown className="w-4 h-4 invisible group-hover:visible" />
          </div>
        </div>
      )}
    </div>
  );
};