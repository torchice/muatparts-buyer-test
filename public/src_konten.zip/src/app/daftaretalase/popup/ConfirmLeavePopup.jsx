import React from 'react';
import Modal from '@/components/Modals/modal';
import { useLanguage } from "@/providers/LanguageProvider";

export default function ConfirmLeavePopup({ onConfirm, onCancel }) {
  const { t } = useLanguage();
  
  return (
    <Modal
      isOpen={true}
      setIsOpen={onCancel}
      title={t('keluarHalamanIni')}
      desc={t('konfirmasiKeluarHalaman')}
      action1={{
        text: t('labelBatal'),
        style: "outline",
        color: "#176CF7",
        action: onCancel
      }}
      action2={{
        text: t('labelYaKeluar'),
        style: "full",
        color: "#176CF7",
        action: onConfirm
      }}
      headerColor="red"
    />
  );
}