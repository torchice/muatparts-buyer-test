'use client';
import React from 'react';
import Modal from '@/components/Modals/modal';

const ConfirmationPopup = ({ 
  title = 'Hapus Etalase',
  message, 
  onConfirm, 
  onCancel,
  confirmLabel = 'Hapus',
  cancelLabel = 'Batal',
  variant = ''
}) => {
  return (
    <Modal
      isOpen={true}
      setIsOpen={onCancel}
      closeArea={true}
      closeBtn={true}
      title={title}
      desc={message}
      headerColor={variant === 'danger' ? 'red' : 'red'}
      action1={{
        action: onCancel,
        text: cancelLabel,
        style: "outline",
        color: "#176CF7",
        customStyle:{minWidth:'111px'}
      }}
      action2={{
        action: onConfirm,
        text: confirmLabel,
        style: "full",
        color: variant === 'danger' ? "#EF4444" : "#176CF7",
        customStyle:{minWidth:'111px'}
      }}
    />
  );
};

export default ConfirmationPopup;