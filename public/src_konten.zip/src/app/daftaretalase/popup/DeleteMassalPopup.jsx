'use client';
import React, { useState } from 'react';
import Modal from '@/components/Modals/modal';
import { X, ChevronDown, Search } from 'lucide-react';
import { useLanguage } from "@/providers/LanguageProvider";
import ImageComponent from '@/components/ImageComponent/ImageComponent';
import Button from "@/components/Button/Button";

export default function DeleteMassalPopup({ 
  products, 
  onClose, 
  onDelete,
  onConfirmDelete 
}) {
  const [selectedItems, setSelectedItems] = useState(new Set());
  const [search, setSearch] = useState('');
  const [sortConfig, setSortConfig] = useState({
    field: '',
    direction: 'asc'
  });

  const { t } = useLanguage();

  const handleSort = (field) => {
    setSortConfig(prev => ({
      field,
      direction: prev.field === field && prev.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  const handleSelectAll = () => {
    if (selectedItems.size === products.length) {
      setSelectedItems(new Set());
    } else {
      setSelectedItems(new Set(products.map(p => p.id)));
    }
  };

  const handleItemSelect = (productId) => {
    const newSelected = new Set(selectedItems);
    if (newSelected.has(productId)) {
      newSelected.delete(productId);
    } else {
      newSelected.add(productId);
    }
    setSelectedItems(newSelected);
  };

  const handleConfirmDelete = () => {
    onConfirmDelete([...selectedItems]);
  };

  const filteredProducts = products.filter(product =>
    product.name.toLowerCase().includes(search.toLowerCase()) ||
    product.sku?.toLowerCase().includes(search.toLowerCase()) ||
    product.brand.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <Modal
      isOpen={true}
      setIsOpen={onClose}
      isBig={true}
      title={t('hapusMassal')}
      headerColor="red"
    >
      {/* Search */}
      <div className="p-4 border-b">
        <div className="flex-1 relative">
          <input
            type="text"
            placeholder={t('cariNamaProduk')}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border rounded-md"
          />
          <Search className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
        </div>
      </div>

      {/* Table */}
      <div className="flex-1 overflow-auto max-h-[50vh]">
        <table className="w-full">
          <thead className="bg-white sticky top-0 z-10 border-b">
            <tr>
              <th className="p-4">
                <input
                  type="checkbox"
                  checked={selectedItems.size === filteredProducts.length && filteredProducts.length > 0}
                  onChange={handleSelectAll}
                  className="rounded border-gray-300"
                />
              </th>
              <th 
                className="p-4 text-left cursor-pointer"
                onClick={() => handleSort('name')}
              >
                Nama Produk
                {sortConfig.field === 'name' && (
                  <span>{sortConfig.direction === 'asc' ? ' ↑' : ' ↓'}</span>
                )}
              </th>
              <th 
                className="p-4 text-left cursor-pointer"
                onClick={() => handleSort('category')}
              >
                Kategori
                {sortConfig.field === 'category' && (
                  <span>{sortConfig.direction === 'asc' ? ' ↑' : ' ↓'}</span>
                )}
              </th>
              <th 
                className="p-4 text-left cursor-pointer"
                onClick={() => handleSort('price')}
              >
                Harga Jual
                {sortConfig.field === 'price' && (
                  <span>{sortConfig.direction === 'asc' ? ' ↑' : ' ↓'}</span>
                )}
              </th>
            </tr>
          </thead>
          <tbody>
            {filteredProducts.map(product => (
              <tr key={product.id} className="border-b hover:bg-gray-50">
                <td className="p-4">
                  <input
                    type="checkbox"
                    checked={selectedItems.has(product.id)}
                    onChange={() => handleItemSelect(product.id)}
                    className="rounded border-gray-300"
                  />
                </td>
                <td className="p-4">
                  <div className="flex gap-3">
                    <ImageComponent
                      src={product.image}
                      alt={product.name}
                      width={48}
                      height={48}
                      className="object-cover rounded"
                    />
                    <div>
                      <div className="font-medium">{product.name}</div>
                      <div className="text-sm text-[#7b7b7b]">
                        SKU: {product.sku || '-'}
                        <br />
                        Brand: {product.brand}
                      </div>
                    </div>
                  </div>
                </td>
                <td className="p-4">{product.categories.join(' > ')}</td>
                <td className="p-4">{product.price}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Footer */}
      <div className="border-t p-4 flex justify-between items-center">
        <div className="text-sm text-[#7b7b7b]">
          {t('labelTerpilih')}: {selectedItems.size} {t('labelProduk')}
        </div>
        <Button
          onClick={handleConfirmDelete}
          disabled={selectedItems.size === 0}
          color="error"
Class="px-6 py-2 rounded-full bg-red-500 text-white disabled:bg-gray-300 disabled:cursor-not-allowed hover:bg-red-600"
        >
          {t('hapusMassal')}
        </Button>
      </div>
    </Modal>
  );
}