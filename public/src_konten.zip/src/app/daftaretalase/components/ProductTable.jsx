// components/ProductTable.jsx
// 24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase
// LB - 0117
// LB - 0118
// LB - 0119
'use client';

import React, { useState, useEffect } from 'react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import ImageComponent from '@/components/ImageComponent/ImageComponent';
import CustomLink from '@/components/CustomLink';
import Button from "@/components/Button/Button";
// 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0867
import { useTranslation } from '@/context/TranslationProvider';

const formatPrice = (price) => {
  if (!price) return '-';

  const formatter = new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  });

  const formatNumber = (num) =>
    formatter.format(num).replace('Rp', '').trim().replace(/\./g, ',').replace(/,/g, '.');

  if (price.min === price.max) {
    return `Rp${formatNumber(price.min)}`;
  }

  return `Rp${formatNumber(price.min)} - Rp${formatNumber(price.max)}`;
};

const formatNumber = (number) => {
  return number?.toLocaleString('id-ID').replace(/,/g, '.') || '0';
};

const CategoryPathSeparator = () => (
  <ImageComponent
    src="/icons/etalase/chevron-right.svg"
    width={16}
    height={16}
    className="object-contain shrink-0 self-stretch my-auto w-4 aspect-[1.6]"
  />
);

//24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase - LB - 0047 & LB - 0093
const ProductRow = ({ product, onDelete, isDraggable, dragHandleProps, snapshot='', showActions,index }) => {
  const { t } = useTranslation();
  const isOutOfStock = product.stock <= 0;

  return (
    <>
      <td className={`p-4 align-top w-[35%] pl-6`}>
        <div className="flex gap-3">
          <ImageComponent
            src={product.imageUrl}
            alt={product.name}
            width={56}
            height={56}
            className="object-contain shrink-0 rounded aspect-square w-[56px] h-[56px]"
          />
          <div>
            <div className="text-xs font-bold leading-4 line-clamp-2">{product.name}</div>
            <div className="mt-3 text-[10px] font-medium line-clamp-1">SKU : {product.sku || '-'}</div>
            <div className="mt-3 text-[10px] font-medium line-clamp-1">Brand : {product.brand || '-'}</div>
          </div>
        </div>
      </td>
      <td className="p-4 align-top max-w-[200px] w-[200px]">
        <div className="flex flex-wrap  items-center text-xs max-w-[200px]">
          {product.category.path.split('>').map((part, index, array) => (
            <React.Fragment key={index}>
              {/* LB - 0045 - daftar etalase */}
              <span className='flex flex-no-wrap items-center'>
                  <span className="truncate max-w-[144px] text-[10px] font-medium" title={part.trim()}>
                    {part.trim()}
                  </span>
                  {index < array.length - 1 && <CategoryPathSeparator />}
              </span>
              
            </React.Fragment>
          ))}
        </div>
      </td>
      {/* //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase - LB - 0047 & LB - 0093 */}
      <td className={`p-4 text-[10px] font-medium align-top ${isOutOfStock ? 'text-red-500' : ''} ${
                              snapshot.isDragging ? 'w-[10%]' : ''
                            }`}>
        {isOutOfStock ? t('stokHabis') : formatNumber(product.stock)}
      </td>
      {/* //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase - LB - 0047 & LB - 0093 */}
      <td className={`p-4 text-left break-all text-[10px] font-medium align-top ${
                              snapshot.isDragging ? 'w-[18%]' : ''
                            }`}>
        {formatPrice(product.price)}
      </td>
      {/* //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase - LB - 0047 & LB - 0093 */}
      <td className={`p-4 pr-6 text-[10px] font-medium align-top ${
        snapshot.isDragging ? 'w-[8%]' : ''
      }`}>
        {formatNumber(product.totalSold)}
      </td>
      <td className="p-4 pr-6 align-top">
        {showActions ?
          (!isDraggable ? (
            <Button
              onClick={() => onDelete(product.id)}
              color='error_secondary'
              Class="gap-1 self-stretch px-6 py-3 my-auto text-sm font-semibold text-red-500 bg-white rounded-3xl border border-red-500 border-solid  min-w-[112px]"
            >
              {t('labelHapus')}
            </Button>
          ) : (
            <div
              {...dragHandleProps}
              className={`flex gap-1 justify-center items-center my-auto rounded-3xl border border-solid min-h-[32px] w-[40px] ${
                isOutOfStock
                  ? 'bg-zinc-100 border-neutral-400 cursor-not-allowed opacity-50'
                  : 'bg-white border-blue-600 cursor-grab active:cursor-grabbing hover:bg-[#E2F2FF]'
              }`}
            >
              <ImageComponent
                src="/icons/etalase/drag-item.svg"
                alt="Drag Handle"
                width={16}
                height={16}
                className={`object-contain self-stretch my-auto w-4 aspect-square transition-opacity ${
                  isOutOfStock
                    ? 'opacity-50'
                    : 'opacity-70 group-hover:opacity-100'
                }`}
              />
            </div>
          )) : null
        }
      </td>
    </>
  );
};

const KeywordNotFoundMessage = ({ isFilter }) => {
  const { t } = useTranslation();
  return (
    <div className="flex flex-col items-center justify-center py-12 w-full border-b border-gray-200">
      <ImageComponent
        src={isFilter ? "/icons/etalase/search-not-found.png" : "/icons/etalase/search-not-found.png"}
        alt={isFilter ? "Filter Not Found" : "Search Not Found"}
        width={142}
        height={122}
        className="mb-4"
      />
      <p className="text-[#7B7B7B] text-center font-semibold whitespace-pre-line">
        {isFilter
          ? `${t('dataTidakDitemukan')}\n${t('mohonCobaHapusBeberapaFilter')}`
          : t('keywordTidakDitemukan')}
      </p>
    </div>
  );
};

const ProductTable = ({ products, onDelete, onReorder, isReorderMode, showActions, searchTerm, activeFilters, disableStockSort = false }) => {
  const { tOrEmpty } = useTranslation();
  //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase - LB - 0047 & LB - 0093
  const tableRef = React.useRef(null); // Add this line

  // Tambahkan state untuk tracking aktivitas terakhir
  const [lastActivity, setLastActivity] = useState(null); // 'search' atau 'filter'

  // Update useEffect untuk memantau searchTerm
  useEffect(() => {
    if(searchTerm) {
      setLastActivity('search');
    }
  }, [searchTerm]);

  // Update useEffect untuk memantau filter
  useEffect(() => {
    if(activeFilters?.categories?.length > 0 || activeFilters?.brands?.length > 0) {
      setLastActivity('filter');
    }
  }, [activeFilters]);

  // Modifikasi logic pemisahan produk
  const { availableProducts, outOfStockProducts } = React.useMemo(() => {
    // Jika disableStockSort true, kembalikan semua produk dalam availableProducts
    if (disableStockSort) {
      return {
        availableProducts: products,
        outOfStockProducts: []
      };
    }

    // Jika tidak, gunakan pemisahan stok seperti biasa
    const available = products.filter(p => p.stock > 0);
    const outOfStock = products.filter(p => p.stock <= 0);
    return { 
      availableProducts: available, 
      outOfStockProducts: outOfStock 
    };
  }, [products, disableStockSort]);

  const handleDragEnd = (result) => {
    if (!result.destination) return;

    const items = Array.from(availableProducts);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);

    // Just update the temporary order without saving
    const newOrder = [...items, ...outOfStockProducts];
    onReorder(newOrder);
  };

  const hasActiveFilters = activeFilters?.categories?.length > 0 || activeFilters?.brands?.length > 0;
  const showFilterNotFound = products.length === 0 && hasActiveFilters;
  const showSearchNotFound = products.length === 0 && searchTerm && !hasActiveFilters;

  return (
    <div className="overflow-x-auto rounded-b-xl">
      <DragDropContext onDragEnd={handleDragEnd}>
        {/* //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase - LB - 0047 & LB - 0093 */}
        <table ref={tableRef} className="w-full"> {/* Add ref here */}
          <thead className="bg-white">
            <tr className="text-xs font-bold text-neutral-500 border-y border-solid border-y-stone-300">
              <th className="p-4 pl-6 text-left">{tOrEmpty('namaProduk')}</th>
              <th className="p-4 text-left max-w-[200px] w-[200px]">{tOrEmpty('labelKategori')}</th>
              <th className="p-4 text-left">{tOrEmpty('labelStok')}</th>
              <th className="p-4 text-left">{tOrEmpty('hargaJual')}</th>
              <th className="p-4 text-left">{tOrEmpty('labelTerjual')}</th>
              <th className="p-4 pr-6 w-28"></th>
            </tr>
          </thead>
          {products.length === 0 ? (
            <tbody>
              <tr>
                <td colSpan="6">
                  {lastActivity === 'search' ? (
                    // Jika aktivitas terakhir search, tampilkan pesan search not found
                    <KeywordNotFoundMessage isFilter={false} />
                  ) : lastActivity === 'filter' ? (
                    // Jika aktivitas terakhir filter, tampilkan pesan filter not found  
                    <KeywordNotFoundMessage isFilter={true} />
                  ) : (
                    // Jika tidak ada aktivitas, tampilkan pesan default
                    <div className="flex flex-col items-center justify-center py-12">
                      <ImageComponent
                        src="/icons/etalase/data-not-found.png" 
                        width={93}
                        height={93}
                        alt={tOrEmpty('noData')}
                        className="mb-4"
                      />
                      <p className="mt-4 text-[#7b7b7b] text-base font-semibold">
                        {tOrEmpty('tidakAdaData')}
                      </p>
                    </div>
                  )}
                </td>
              </tr>
            </tbody>
          ) : (
            <Droppable droppableId="products">
              {(provided) => (
                <tbody {...provided.droppableProps} ref={provided.innerRef}>
                  {availableProducts.map((product, index) => (
                    <Draggable
                      key={product.id}
                      draggableId={product.id}
                      index={index}
                      isDragDisabled={!isReorderMode || product.stock <= 0}
                    >
                      {(provided, snapshot) => {
                        // Add custom dragging styles
                        //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase - LB - 0047 & LB - 0093
                        if (snapshot.isDragging) {
                          provided.draggableProps.style = {
                            ...provided.draggableProps.style,
                            display: 'inline-table',
                            tableLayout: 'fixed',
                            width: tableRef.current?.offsetWidth || '100%'
                          }
                        }
                        
                        return (
                          <tr
                            ref={provided.innerRef}
                            {...provided.draggableProps}
                            className={`border-b border-solid border-b-stone-300 ${
                              snapshot.isDragging ? 'bg-blue-50' : 'bg-white'
                            } hover:bg-gray-50 cursor-pointer`}
                          >
                            {/* //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase - LB - 0047 & LB - 0093 LB - 0065*/}
                            <ProductRow
                              product={product}
                              onDelete={onDelete}
                              isDraggable={isReorderMode}
                              dragHandleProps={provided.dragHandleProps}
                              snapshot={snapshot}
                              showActions={showActions}
                              index={index}
                            />
                          </tr>
                        );
                      }}
                    </Draggable>
                  ))}
                  {!disableStockSort && outOfStockProducts.map((product,index) => (
                    <tr
                      key={product.id}
                      className="border-b border-solid border-b-stone-300 bg-white hover:bg-gray-50 cursor-pointer"
                    >
                      <ProductRow
                        product={product}
                        onDelete={onDelete}
                        isDraggable={isReorderMode}
                        showActions={showActions}
                        index={index}

                      />
                    </tr>
                  ))}
                  {provided.placeholder}
                </tbody>
              )}
            </Droppable>
          )}
        </table>
      </DragDropContext>
      {!showActions && (
        <div className="text-sm font-bold text-black py-5 px-6">
          {tOrEmpty('totalProduk')}: {products.length}
        </div>
      )}
    </div>
  );
};

export default ProductTable;