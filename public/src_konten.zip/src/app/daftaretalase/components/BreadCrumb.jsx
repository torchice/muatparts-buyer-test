// components/BreadCrumb.jsx
import React from 'react';
import CustomLink from '@/components/CustomLink';
import ImageComponent from '@/components/ImageComponent/ImageComponent';
import { useLanguage } from "@/providers/LanguageProvider";

const BreadcrumbChevron = () => (
  <ImageComponent
    src="/icons/etalase/chevron-right.svg"
    width={16}
    height={16}
    alt="chevron"
    className="object-contain shrink-0 self-stretch my-auto aspect-square"
  />
);

const BreadCrumb = ({ items }) => {
  const { t } = useLanguage();

  return (
    <nav 
      aria-label="breadcrumb" 
      className="flex gap-1.5 items-center w-full text-xs font-medium leading-tight min-h-[16px] text-neutral-500"
    >
      <div className="flex flex-wrap gap-1.5 items-center self-stretch my-auto min-w-[240px] w-[662px]">
        {items.map((item, index) => (
          <React.Fragment key={index}>
            {index === items.length - 1 ? (
              // Last item - not clickable, different color
              <div className="self-stretch my-auto text-blue-600 font-semibold">
                {t(item.text)}
              </div>
            ) : (
              // Clickable items
              <>
                <CustomLink
                  href={item.path}
                  className="self-stretch my-auto text-[#7b7b7b] hover:text-blue-600 hover:no-underline  transition-colors no-underline"
                >
                  {t(item.text)}
                </CustomLink>
                <BreadcrumbChevron />
              </>
            )}
          </React.Fragment>
        ))}
      </div>
    </nav>
  );
};

export default BreadCrumb;