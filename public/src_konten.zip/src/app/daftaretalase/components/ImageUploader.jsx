import React, { useState, useRef } from 'react';
import Modal from '@/components/Modals/modal';
import { useLanguage } from "@/providers/LanguageProvider";
import ImageComponent from '@/components/ImageComponent/ImageComponent';
import Button from "@/components/Button/Button";

const ImageUploader = ({
  onUpload,
  onError,
  maxSize = 10, // MB
  allowedFormats = ['image/jpeg', 'image/png']
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [error, setError] = useState('');
  const [dragActive, setDragActive] = useState(false);
  const inputRef = useRef(null);
  const { t } = useLanguage();
  
  const validateFile = (file) => {
    if (!file) return false;
    
    // Check file size (10MB max)
    if (file.size > maxSize * 1024 * 1024) {
      setError('Ukuran file maksimal 10MB!');
      return false;
    }

    // Check file format
    if (!allowedFormats.includes(file.type)) {
      setError('Format file tidak sesuai ketentuan!');
      return false;
    }

    return true;
  };

  const handleFile = (file) => {
    if (validateFile(file)) {
      // Proceed with upload
      onUpload(file);
      setIsModalOpen(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    setDragActive(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    setDragActive(false);
  };

  const handleChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  return (
    <Modal
      isOpen={isModalOpen}
      setIsOpen={setIsModalOpen}
      title={t('unggahGambar')}
    >
      <div className="p-6">
        {/* Drop Zone Area */}
        <div className={`border-2 border-dashed rounded-lg p-8 text-center
          ${dragActive ? 'border-blue-500 bg-blue-50' : 'border-gray-300'}
          ${error ? 'border-red-500 bg-red-50' : ''}`}
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
        >
          <div className="flex flex-col items-center gap-4">
            <span className="text-sm text-[#7b7b7b]">
              {t('formatFile')}
            </span>
            
            <Button
              onClick={() => inputRef.current?.click()}
              color='primary'
              Class="px-4 py-2 text-[#176CF7] hover:bg-blue-50 rounded-full border border-blue-600"
            >
              {t('labelUnggah')}
            </Button>

            <input
              ref={inputRef}
              type="file"
              className="hidden"
              accept="image/jpeg,image/png"
              onChange={handleChange}
            />
          </div>
        </div>

        {/* Error Message */}
        {error && (
          <div className="mt-4 px-4 py-2 bg-red-100 border border-red-200 rounded-lg flex items-center gap-2 text-red-600">
            <span className="text-sm">{t(error)}</span>
            <button 
              onClick={() => setError('')}
              className="ml-auto text-red-600 hover:text-red-700"
            >
              ×
            </button>
          </div>
        )}
      </div>
    </Modal>
  );
};

export default ImageUploader;