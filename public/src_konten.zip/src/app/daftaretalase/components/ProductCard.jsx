import React from 'react';
import ImageComponent from '@/components/ImageComponent/ImageComponent';
import { useLanguage } from "@/providers/LanguageProvider";
import Button from "@/components/Button/Button";

const ProductCard = ({ product, onDelete, showDeleteButton = true }) => {
  const { t } = useLanguage();
  
  return (
    <div className="flex flex-wrap flex-1 shrink gap-5 items-start justify-between py-5 basis-0 min-w-[240px] size-full">
      <ImageComponent
        src={product.image}
        alt={product.name}
        width={56}
        height={56}
        className="object-contain shrink-0 w-14 rounded aspect-square"
      />
      <div className="flex flex-col justify-center py-1 w-[200px]">
        <div className="text-xs font-bold leading-4">{product.name}</div>
        <div className="mt-3">{t('labelSKU')} : {product.sku}</div>
        <div className="mt-3">{t('labelBrand')} : {product.brand}</div>
      </div>
      <div className="flex flex-wrap gap-2 items-center py-0.5 w-[170px]">
        {product.categories.map((category, index) => (
          <React.Fragment key={index}>
            <div className="self-stretch my-auto">{category}</div>
            {index < product.categories.length - 1 && (
              <ImageComponent
                src="/icons/etalase/chevron-right.svg"
                alt="separator"
                width={16}
                height={16}
                className="object-contain shrink-0 self-stretch my-auto w-4 aspect-[1.6]"
              />
            )}
          </React.Fragment>
        ))}
      </div>
      <div className={`gap-1 self-stretch py-1 w-16 ${product.stock === 0 ? 'text-red-500' : ''}`}>
        {product.stock === 0 ? t('stokHabis') : product.stock}
      </div>
      <div className="flex gap-2.5 items-start py-1 w-[168px]">
        <div className="gap-1 self-stretch w-[168px]">{product.price}</div>
      </div>
      <div className="gap-2.5 py-1 w-16 whitespace-nowrap">{product.sold}</div>
      {showDeleteButton && (
        <div className="flex gap-3 items-center text-sm font-semibold leading-tight text-red-500 whitespace-nowrap">
          <Button 
            onClick={() => onDelete(product.id)}
            color='error_secondary'
              Class="gap-1 self-stretch px-6 py-3 my-auto bg-white rounded-3xl border border-red-500 border-solid  min-w-[112px]"
          >
            {t('labelHapus')}
          </Button>
        </div>
      )}
    </div>
  );
};

export default ProductCard;