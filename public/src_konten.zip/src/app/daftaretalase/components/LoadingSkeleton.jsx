import React from 'react';

const PageHeaderSkeleton = () => (
  <div className="mb-6">
    <div className="h-4 w-96 bg-gray-200 rounded animate-pulse mb-6"/>
    <div className="h-6 w-48 bg-gray-200 rounded animate-pulse"/>
  </div>
);

const TableRowSkeleton = ({ columns, hasActions }) => {
  return (
    <tr className="border-b">
      {Array.from({ length: columns }).map((_, i) => (
        <td key={i} className="py-4 px-4">
          <div className="h-4 bg-gray-200 rounded animate-pulse"/>
          {i === 0 && (
            <div className="h-3 w-24 bg-gray-200 rounded animate-pulse mt-2"/>
          )}
        </td>
      ))}
      {hasActions && (
        <td className="py-4 pr-4">
          <div className="h-8 w-20 bg-gray-200 rounded-full animate-pulse"/>
        </td>
      )}
    </tr>
  );
};

const TableSkeleton = ({ rows = 5, columns = 6, hasActions = true }) => (
  <div className="overflow-x-auto">
    <table className="w-full">
      <thead>
        <tr>
          {Array.from({ length: columns }).map((_, i) => (
            <th key={i} className="py-3 px-4 text-left">
              <div className="h-4 w-24 bg-gray-200 rounded animate-pulse"/>
            </th>
          ))}
          {hasActions && <th className="py-3 pr-4 w-[112px]"/>}
        </tr>
      </thead>
      <tbody>
        {Array.from({ length: rows }).map((_, i) => (
          <TableRowSkeleton 
            key={i} 
            columns={columns} 
            hasActions={hasActions}
          />
        ))}
      </tbody>
    </table>
  </div>
);

export const LoadingSkeleton = () => {
  return (
    <div className="min-h-screen bg-slate-50 p-6 w-full">
      <PageHeaderSkeleton />
      
      <div className="bg-white rounded-xl p-6 shadow-lg mb-6">
        <div className="grid grid-cols-[120px,1fr] gap-6 items-start mb-6">
          <div className="h-4 w-24 bg-gray-200 rounded animate-pulse"/>
          <div className="h-10 bg-gray-200 rounded animate-pulse"/>
        </div>
        
        <div className="grid grid-cols-[120px,1fr] gap-6 items-start">
          <div className="h-4 w-24 bg-gray-200 rounded animate-pulse"/>
          <div className="h-10 bg-gray-200 rounded animate-pulse"/>
        </div>
      </div>
      
      <div className="bg-white rounded-xl shadow-lg">
        <div className="p-4 border-b flex justify-between items-center">
          <div className="h-6 w-32 bg-gray-200 rounded animate-pulse"/>
          <div className="flex gap-3">
            <div className="h-8 w-24 bg-gray-200 rounded-full animate-pulse"/>
            <div className="h-8 w-24 bg-gray-200 rounded-full animate-pulse"/>
          </div>
        </div>
        
        <div className="p-4 border-b flex justify-between items-center">
          <div className="h-10 w-64 bg-gray-200 rounded animate-pulse"/>
          <div className="h-10 w-32 bg-gray-200 rounded animate-pulse"/>
        </div>
        
        <TableSkeleton rows={5} columns={6} hasActions={true}/>
        
        <div className="p-4 border-t">
          <div className="h-4 w-32 bg-gray-200 rounded animate-pulse"/>
        </div>
      </div>
      
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4 flex justify-end">
        <div className="h-10 w-24 bg-gray-200 rounded-full animate-pulse"/>
      </div>
    </div>
  );
};

export default LoadingSkeleton;