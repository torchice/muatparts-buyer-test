import React, { useState, useEffect } from 'react';
import { Header } from '@/components/daftaretalase/Header';
import { Sidebar } from '@/components/daftaretalase/Sidebar';

// Custom hook untuk mendeteksi viewport width
const useViewport = () => {
  const [width, setWidth] = useState(undefined);

  useEffect(() => {
    // Handler untuk update state
    const handleWindowResize = () => setWidth(window.innerWidth);
    
    // Set width awal
    handleWindowResize();
    
    // Subscribe ke window resize events
    window.addEventListener("resize", handleWindowResize);
    
    // Cleanup
    return () => window.removeEventListener("resize", handleWindowResize);
  }, []);

  // Return viewport width
  return width;
};

const ResponsiveLayout = ({ children, MobileComponent }) => {
  const viewportWidth = useViewport();
  
  // Breakpoint untuk mobile (sesuaikan dengan kebutuhan)
  const breakpoint = 768;
  
  // Render mobile view
  if (viewportWidth < breakpoint) {
    return <MobileComponent />;
  }
  
  // Render desktop view
  return (
    <div className="flex flex-col bg-[#F8F8FB]">
      <Header />
      <div className="flex w-full max-md:max-w-full">
        <Sidebar />
        {children}
      </div>
    </div>
  );
};

export default ResponsiveLayout;