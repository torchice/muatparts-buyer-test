// components/SearchFilter.jsx
import React, { useState } from 'react';
import { useLanguage } from '@/providers/LanguageProvider';
import ImageComponent from '@/components/ImageComponent/ImageComponent';
import Button from "@/components/Button/Button";

const SearchFilter = ({ onSearch }) => {
  const { t } = useLanguage();
  const [keyword, setKeyword] = useState('');
  const [isFocused, setIsFocused] = useState(false);
  
  const handleSearch = (value) => {
    setKeyword(value);
    // onSearch(value);
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      handleSearch(keyword);
      onSearch(e.target.value);
    }
  };

  return (
    <div className={`flex gap-2 items-center px-3 py-2 min-w-[240px] w-[262px] text-xs font-medium bg-white rounded-md border border-solid ${isFocused ? 'border-blue-600' : 'border-neutral-500'} min-h-[32px] `}>
      <ImageComponent
        src="/icons/etalase/search.svg"
        alt="search"
        width={16}
        height={16}
        className="object-contain shrink-0 self-stretch my-auto w-4 aspect-square"
      />
      <input
        type="text"
        value={keyword}
        placeholder={t('cariNamaProduk')+'/'+t('labelSKU')}
        onChange={(e) => handleSearch(e.target.value)}
        onKeyPress={handleKeyPress}
        onFocus={() => setIsFocused(true)}
        onBlur={() => setIsFocused(false)}
        className="flex-1 shrink bg-transparent border-none outline-none text-black placeholder-neutral-500 focus:outline-none"
      />
      {keyword && (
        <button
          onClick={() => {handleSearch(''); onSearch('')}}
          className="hover:bg-gray-100 rounded-full"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="h-4 w-4 text-[#7b7b7b]"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M6 18L18 6M6 6l12 12"
            />
          </svg>
        </button>
      )}
    </div>
  );
};

export default SearchFilter;