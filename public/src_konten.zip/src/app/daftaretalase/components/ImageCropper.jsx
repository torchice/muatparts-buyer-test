import React, { useState } from 'react';
import Modal from '../Modals/modal';
import Cropper from 'react-easy-crop';
import { useLanguage } from "@/providers/LanguageProvider";
import Button from "@/components/Button/Button";

const CropperModal = ({
  isOpen,
  setIsOpen,
  imageSource,
  onComplete,
  aspectRatio = 1
}) => {
  const { t } = useLanguage();
  const [crop, setCrop] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const [rotation, setRotation] = useState(0);

  const handleRotate = (direction) => {
    setRotation(prev => direction === 'left' ? prev - 90 : prev + 90);
  };

  const handleSave = async () => {
    if (!imageSource) return;
    
    // Implement crop logic here
    // This would typically create a cropped version of the image
    // and maintain aspect ratio with white background as specified
    
    onComplete(imageSource); // Replace with actual cropped image
    setIsOpen(false);
  };

  return (
    <Modal
      isOpen={isOpen}
      setIsOpen={setIsOpen}
      title={t('sesuaikanGambar')}
      action1={{
        text: t('labelBatal'),
        style: 'outline',
        color: '#6B7280',
        action: () => setIsOpen(false)
      }}
      action2={{
        text: t('labelSimpan'),
        style: 'full',
        color: '#2563EB',
        action: handleSave
      }}
    >
      <div className="p-6">
        <div className="relative h-80 bg-gray-100 rounded-lg overflow-hidden">
          {imageSource && (
            <Cropper
              image={imageSource}
              crop={crop}
              zoom={zoom}
              rotation={rotation}
              aspect={aspectRatio}
              onCropChange={setCrop}
              onZoomChange={setZoom}
              objectFit="contain"
              showGrid={false}
            />
          )}
        </div>

        {/* Controls */}
        <div className="mt-4 flex justify-between items-center">
          <div className="flex gap-2">
            <button 
              onClick={() => handleRotate('left')}
              className="p-2 hover:bg-gray-100 rounded"
            >
              ↺
            </button>
            <button 
              onClick={() => handleRotate('right')}
              className="p-2 hover:bg-gray-100 rounded"
            >
              ↻
            </button>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-sm text-[#7b7b7b]">Zoom</span>
            <input
              type="range"
              value={zoom}
              min={1}
              max={3}
              step={0.1}
              onChange={(e) => setZoom(Number(e.target.value))}
              className="w-24"
            />
          </div>
        </div>
      </div>
    </Modal>
  );
};

export default CropperModal;