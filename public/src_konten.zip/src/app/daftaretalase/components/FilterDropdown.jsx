import React, { useState, useEffect, useRef } from 'react';
import { Search, ChevronRight, X } from 'lucide-react';
import { MockServer_TambahEtalase } from '@/services/MockServer_TambahEtalase';
import { useLanguage } from "@/providers/LanguageProvider";
import ImageComponent from '@/components/ImageComponent/ImageComponent';
import Button from "@/components/Button/Button";
import { useTranslation } from '@/context/TranslationProvider';

const FilterDropdown = ({ activeFilters, onFilterSelect, onResetFilters, etalaseId, disabled }) => {
  const [filterType, setFilterType] = useState(null);
  const [filterSearch, setFilterSearch] = useState('');
  const [categories, setCategories] = useState([]);
  const [brands, setBrands] = useState([]);
  const [showFilterMenu, setShowFilterMenu] = useState(false);
  const [hoverTimeout, setHoverTimeout] = useState(null);
  // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0867
  const { tOrEmpty } = useTranslation();
  const filterRef = useRef(null);
  const [submenuPosition, setSubmenuPosition] = useState({ top: 0, left: 0 });

  // Check if any filters are active
  const hasActiveFilters = activeFilters.categories.length > 0 || activeFilters.brands.length > 0;

  // Load filter options
  useEffect(() => {
    const loadFilters = async () => {
      try {
        if (filterType === 'category') {
          const response = await MockServer_TambahEtalase.getCategoryFilter(filterSearch, etalaseId);
          setCategories(response.data.categories);
        } else if (filterType === 'brand') {
          const response = await MockServer_TambahEtalase.getBrandFilter(filterSearch, etalaseId);
          setBrands(response.data.brands);
        }
      } catch (error) {
        console.error('Failed to load filters:', error);
      }
    };

    if (filterType) {
      const debounceTimer = setTimeout(loadFilters, 300);
      return () => clearTimeout(debounceTimer);
    }
  }, [filterType, filterSearch, etalaseId]);

  useEffect(() => {
    if (showFilterMenu || filterType == null) {
      setFilterType(null);
    }
  }, [showFilterMenu]);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (filterRef.current && !filterRef.current.contains(event.target)) {
        setShowFilterMenu(false);
        setFilterType(null);
        setFilterSearch('');
      }
    };

    if (showFilterMenu) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showFilterMenu]);

  const calculateSubmenuPosition = (parentElement) => {
    if (!parentElement) return;
    
    const rect = parentElement.getBoundingClientRect();
    const spaceRight = window.innerWidth - rect.right;
    
    // Position the submenu to the right of the parent by default
    let left = rect.right;
    
    // If there's not enough space on the right, position to the left
    if (spaceRight < 256) { // 256px is the width of submenu (w-64)
      left = rect.left - 256;
    }
    
    setSubmenuPosition({
      top: rect.top,
      left: left
    });
  };

  const handleMouseEnter = (type, event) => {
    clearTimeout(hoverTimeout);
    // Reset filter search when changing filter type
    if (filterType !== type) {
      setFilterSearch('');
    }
    setFilterType(type);
    calculateSubmenuPosition(event.currentTarget);
  };

  const handleMouseLeave = () => {
    const timeout = setTimeout(() => {
      const dropdown = document.querySelector('.filter-dropdown');
      const submenu = document.querySelector('.filter-submenu');
      if (dropdown && submenu) {
        const dropdownRect = dropdown.getBoundingClientRect();
        const submenuRect = submenu.getBoundingClientRect();
        
        const mouseX = event.clientX;
        const mouseY = event.clientY;

        const isOverDropdown = (
          mouseX >= dropdownRect.left &&
          mouseX <= dropdownRect.right &&
          mouseY >= dropdownRect.top &&
          mouseY <= dropdownRect.bottom
        );

        const isOverSubmenu = (
          mouseX >= submenuRect.left &&
          mouseX <= submenuRect.right &&
          mouseY >= submenuRect.top &&
          mouseY <= submenuRect.bottom
        );

        if (!isOverDropdown && !isOverSubmenu) {
          setFilterType(null);
          setFilterSearch(''); // Reset filter search when closing submenu
        }
      }
    }, 100);
    setHoverTimeout(timeout);
  };

  // Add new effect to reset filter search when filter type changes
  useEffect(() => {
    if (!filterType) {
      setFilterSearch('');
    }
  }, [filterType]);
  // THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase 
// LB - 0121 - etalase
// LB - 0018
  return (
    <div className="relative" ref={filterRef}>
      <button 
        onClick={() => !disabled && setShowFilterMenu(!showFilterMenu)}
        color=''
        Class={`px-4 py-2 border  rounded-md flex items-center justify-between w-[108px] h-full transition-colors
          ${disabled 
            ? 'bg-gray-100 cursor-not-allowed text-gray-400 ' 
            : hasActiveFilters 
              ? 'border-[#176CF7] text-[#176CF7]' 
              : 'border-[#7b7b7b] text-[#7B7B7B] hover:border-[#176CF7]'}`}
        disabled={disabled}
      >
        {tOrEmpty('labelFilter')}
        <svg 
          width="16" 
          height="16" 
          viewBox="0 0 16 16" 
          fill="none" 
          xmlns="http://www.w3.org/2000/svg"
          className={disabled ? 'opacity-50' : ''}
        >
          <g clipPath="url(#clip0_132_6752)">
            <path 
              d="M9.48089 4.2965C10.299 4.2965 10.9623 3.63326 10.9623 2.81512C10.9623 1.99698 10.299 1.33374 9.48089 1.33374C8.66275 1.33374 7.99951 1.99698 7.99951 2.81512C7.99951 3.63326 8.66275 4.2965 9.48089 4.2965Z" 
              stroke={hasActiveFilters && !disabled ? "#176CF7" : "#555555"} 
              strokeWidth="1.5" 
              strokeLinecap="round" 
              strokeLinejoin="round"
            />
            <path 
              d="M10.2221 14.6662C11.0402 14.6662 11.7035 14.003 11.7035 13.1849C11.7035 12.3667 11.0402 11.7035 10.2221 11.7035C9.40396 11.7035 8.74072 12.3667 8.74072 13.1849C8.74072 14.003 9.40396 14.6662 10.2221 14.6662Z" 
              stroke={hasActiveFilters && !disabled ? "#176CF7" : "#555555"} 
              strokeWidth="1.5" 
              strokeLinecap="round" 
              strokeLinejoin="round"
            />
            <path 
              d="M5.03704 9.48131C5.85519 9.48131 6.51842 8.81808 6.51842 7.99993C6.51842 7.18179 5.85519 6.51855 5.03704 6.51855C4.2189 6.51855 3.55566 7.18179 3.55566 7.99993C3.55566 8.81808 4.2189 9.48131 5.03704 9.48131Z" 
              stroke={hasActiveFilters && !disabled ? "#176CF7" : "#555555"} 
              strokeWidth="1.5" 
              strokeLinecap="round" 
              strokeLinejoin="round"
            />
            <path 
              d="M1.3335 2.81519H7.9997" 
              stroke={hasActiveFilters && !disabled ? "#176CF7" : "#555555"} 
              strokeWidth="1.5" 
              strokeLinecap="round" 
              strokeLinejoin="round"
            />
            <path 
              d="M10.9629 2.81519H14.6663" 
              stroke={hasActiveFilters && !disabled ? "#176CF7" : "#555555"} 
              strokeWidth="1.5" 
              strokeLinecap="round" 
              strokeLinejoin="round"
            />
            <path 
              d="M1.3335 8H3.55556" 
              stroke={hasActiveFilters && !disabled ? "#176CF7" : "#555555"} 
              strokeWidth="1.5" 
              strokeLinecap="round" 
              strokeLinejoin="round"
            />
            <path 
              d="M6.51904 8H14.6666" 
              stroke={hasActiveFilters && !disabled ? "#176CF7" : "#555555"} 
              strokeWidth="1.5" 
              strokeLinecap="round" 
              strokeLinejoin="round"
            />
            <path 
              d="M1.3335 13.1847H8.74039" 
              stroke={hasActiveFilters && !disabled ? "#176CF7" : "#555555"} 
              strokeWidth="1.5" 
              strokeLinecap="round" 
              strokeLinejoin="round"
            />
            <path 
              d="M11.7026 13.1847H14.6654" 
              stroke={hasActiveFilters && !disabled ? "#176CF7" : "#555555"} 
              strokeWidth="1.5" 
              strokeLinecap="round" 
              strokeLinejoin="round"
            />
          </g>
          <defs>
            <clipPath id="clip0_132_6752">
              <rect width="16" height="16" fill="white"/>
            </clipPath>
          </defs>
        </svg>
      </button>

      {showFilterMenu && !disabled && (
        <div 
          className="filter-dropdown absolute left-0 top-full mt-2 w-48 bg-white rounded-md shadow-lg border z-20"
          onMouseLeave={handleMouseLeave}
        >
          <div 
            className="px-4 py-2 hover:bg-gray-50 cursor-pointer flex justify-between items-center group relative"
            onMouseEnter={(e) => handleMouseEnter('category', e)}
          >
            <span>{tOrEmpty('labelKategori')}</span>
            <ChevronRight className="w-4 h-4" />

            {filterType === 'category' && (
              <div 
                className="filter-submenu fixed w-64 bg-white rounded-md shadow-lg border z-50"
                onMouseEnter={() => setFilterType('category')}
                style={{
                  top: `${submenuPosition.top}px`,
                  left: `${submenuPosition.left}px`
                }}
              >
                <div className="p-3">
                  <div className="relative">
                    <input
                      type="text"
                      placeholder={tOrEmpty('cariKategori')}
                      value={filterSearch}
                      onChange={(e) => setFilterSearch(e.target.value)}
                      className="w-full pl-10 pr-8 py-2 border rounded-md text-xs font-medium focus:outline-none focus:border-blue-600 focus:ring-[#176CF7] focus:border-[#176CF7] hover:border-[#176CF7] placeholder-[#7b7b7b]"
                    />
                    <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#7b7b7b]" />
                    {filterSearch && (
                      <button
                        onClick={() => setFilterSearch('')}
                        Class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
                <div className="max-h-[220px] overflow-y-auto divide-y"> {/* Height for 5 items (44px each) */}
                  {categories.map(category => (
                    <div
                      key={category.id}
                      className="px-4 py-2 hover:bg-gray-50 cursor-pointer flex items-center h-[44px]"
                      onClick={() => onFilterSelect('category', category)}
                    >
                      <input
                        type="checkbox"
                        checked={activeFilters.categories.some(f => f.id === category.id)}
                        readOnly
                        className="mr-2 rounded"
                      />
                      <div>
                        {/*24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase  LB - 0215 , LB - 0216*/}
                        <div className="line-clamp-2 break-all text-sm">{category.name}</div>
                        {/* <div className="text-sm text-[#7b7b7b]">{category.totalProducts} Produk</div> */}
                      </div>
                    </div>
                  ))}
                  {categories.length === 0 && (
                    <div className="px-4 py-2 text-sm text-[#7b7b7b] text-center">
                      {tOrEmpty('dataTidakDitemukan')}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          <div 
            className="px-4 py-2 hover:bg-gray-50 cursor-pointer flex justify-between items-center group relative"
            onMouseEnter={(e) => handleMouseEnter('brand', e)}
          >
            <span>{tOrEmpty('labelBrand')}</span>
            <ChevronRight className="w-4 h-4" />

            {filterType === 'brand' && (
              <div 
                className="filter-submenu fixed w-64 bg-white rounded-md shadow-lg border z-50"
                onMouseEnter={() => setFilterType('brand')}
                style={{
                  top: `${submenuPosition.top}px`,
                  left: `${submenuPosition.left}px`
                }}
              >
                <div className="p-3">
                  <div className="relative">
                    <input
                      type="text"
                      placeholder={tOrEmpty('cariBrand')}
                      value={filterSearch}
                      onChange={(e) => setFilterSearch(e.target.value)}
                      className="w-full pl-10 pr-8 py-2 border rounded-md text-xs font-medium focus:outline-none focus:border-blue-600 focus:ring-[#176CF7] focus:border-[#176CF7] hover:border-[#176CF7] placeholder-[#7b7b7b]"
                    />
                    <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#7b7b7b]" />
                    {filterSearch && (
                      <button
                        onClick={() => setFilterSearch('')}
                        Class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
                <div className="max-h-[220px] overflow-y-auto divide-y"> {/* Height for 5 items (44px each) */}
                  {brands.map(brand => (
                    <div
                      key={brand.id}
                      className="px-4 py-2 hover:bg-gray-50 cursor-pointer flex items-center h-[44px]"
                      onClick={() => onFilterSelect('brand', brand)}
                    >
                      <input
                        type="checkbox"
                        checked={activeFilters.brands.some(f => f.id === brand.id)}
                        readOnly
                        className="mr-2 rounded"
                      />
                      <div>
                        {/*24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase  LB - 0215 , LB - 0216*/}
                        <div className="line-clamp-2 break-all text-sm">{brand.name}</div>
                        {/* <div className="text-sm text-[#7b7b7b]">{brand.totalProducts} Produk</div> */}
                      </div>
                    </div>
                  ))}
                  {brands.length === 0 && (
                    <div className="px-4 py-2 text-sm text-[#7b7b7b] text-center">
                      {tOrEmpty('dataTidakDitemukan')}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default FilterDropdown;