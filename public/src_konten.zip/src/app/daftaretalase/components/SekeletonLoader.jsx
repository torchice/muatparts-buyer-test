import React from 'react';

// Base skeleton for various shapes
const Skeleton = ({ className = '', ...props }) => (
  <div 
    className={`animate-pulse bg-gray-200 rounded ${className}`} 
    {...props} 
  />
);

// Text skeleton with configurable width and height
export const TextSkeleton = ({ width = 'w-full', height = 'h-4', className = '' }) => (
  <Skeleton className={`${width} ${height} ${className}`} />
);

// Avatar/Image skeleton with configurable size
export const ImageSkeleton = ({ size = 'w-12 h-12', className = '' }) => (
  <Skeleton className={`${size} rounded-lg ${className}`} />
);

// Table row skeleton
export const TableRowSkeleton = ({ columns = 4, hasActions = true }) => (
  <tr className="border-b">
    {[...Array(columns)].map((_, i) => (
      <td key={i} className="p-4">
        {i === 0 ? (
          <div className="flex items-center gap-3">
            <ImageSkeleton />
            <TextSkeleton width="w-32" />
          </div>
        ) : hasActions && i === columns - 1 ? (
          <div className="flex justify-end gap-3">
            <Skeleton className="w-24 h-8 rounded-full" />
            <Skeleton className="w-24 h-8 rounded-full" />
          </div>
        ) : (
          <TextSkeleton width="w-16" />
        )}
      </td>
    ))}
  </tr>
);

// Table skeleton with configurable rows and columns
export const TableSkeleton = ({ rows = 5, columns = 4, hasActions = true }) => (
  <table className="w-full">
    {[...Array(rows)].map((_, i) => (
      <TableRowSkeleton key={i} columns={columns} hasActions={hasActions} />
    ))}
  </table>
);

// Card skeleton for etalase details
export const EtalaseCardSkeleton = () => (
  <div className="bg-white rounded-xl p-6 shadow-lg mb-6">
    <div className="flex items-start gap-6">
      <ImageSkeleton size="w-24 h-24" />
      <div className="flex-1">
        <TextSkeleton width="w-48" height="h-6" className="mb-4" />
        <TextSkeleton width="w-32" className="mb-2" />
        <TextSkeleton width="w-32" />
      </div>
    </div>
  </div>
);

// Form field skeleton
export const FormFieldSkeleton = () => (
  <div className="grid grid-cols-[120px,1fr] gap-6 items-start mb-6">
    <TextSkeleton width="w-20" />
    <div>
      <TextSkeleton height="h-10" />
      <TextSkeleton width="w-16" className="mt-1 ml-auto" />
    </div>
  </div>
);

// Page header skeleton
export const PageHeaderSkeleton = ({ showActions = true }) => (
  <div className="mb-6">
    <TextSkeleton width="w-64" height="h-8" className="mb-6" />
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-2">
        <Skeleton className="w-6 h-6 rounded-full" />
        <TextSkeleton width="w-48" height="h-6" />
      </div>
      {showActions && (
        <div className="flex gap-3">
          <Skeleton className="w-28 h-10 rounded-full" />
          <Skeleton className="w-28 h-10 rounded-full" />
        </div>
      )}
    </div>
  </div>
);

// Full page skeletons for different page types
export const DetailPageSkeleton = () => (
  <div className="min-h-screen bg-slate-50 p-6">
    <PageHeaderSkeleton />
    <EtalaseCardSkeleton />
    <div className="bg-white rounded-xl shadow-lg p-6">
      <TableSkeleton rows={5} />
    </div>
  </div>
);

export const FormPageSkeleton = () => (
  <div className="min-h-screen bg-slate-50 p-6">
    <PageHeaderSkeleton showActions={false} />
    <div className="bg-white rounded-xl p-6 shadow-lg mb-6">
      <FormFieldSkeleton />
      <FormFieldSkeleton />
    </div>
    <div className="bg-white rounded-xl shadow-lg p-6">
      <TableSkeleton rows={3} />
    </div>
  </div>
);

export const ListPageSkeleton = () => (
  <div className="min-h-screen bg-slate-50 p-6">
    <PageHeaderSkeleton />
    <div className="bg-white rounded-xl shadow-lg">
      <div className="p-4 border-b">
        <TextSkeleton width="w-64" height="h-10" />
      </div>
      <TableSkeleton rows={5} />
    </div>
  </div>
);

export default {
  Text: TextSkeleton,
  Image: ImageSkeleton,
  TableRow: TableRowSkeleton,
  Table: TableSkeleton,
  EtalaseCard: EtalaseCardSkeleton,
  FormField: FormFieldSkeleton,
  PageHeader: PageHeaderSkeleton,
  DetailPage: DetailPageSkeleton,
  FormPage: FormPageSkeleton,
  ListPage: ListPageSkeleton
};