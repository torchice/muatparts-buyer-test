// 24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase
// LB - 0136
// LB - 0044
// LB - 0059
// LB - 0116
// LB - 0120

import React, { useState, useEffect, useRef } from 'react';
import { X, Search, ChevronLeft, ChevronRight } from 'lucide-react';
import { MockServer_TambahEtalase } from '@/services/MockServer_TambahEtalase';
import FilterDropdown from './FilterDropdown';
import { useLanguage } from "@/providers/LanguageProvider";
import ImageComponent from '@/components/ImageComponent/ImageComponent';
import Button from "@/components/Button/Button";
import Checkbox from '@/components/Checkbox/Checkbox';

const CategoryPathSeparator = () => (
  <svg 
    width="6" 
    height="10" 
    viewBox="0 0 6 10" 
    fill="none" 
    xmlns="http://www.w3.org/2000/svg"
    className="mx-1 inline-block flex-shrink-0"
  >
    <path 
      d="M1 9L4.73569 5.54622C4.90498 5.38877 5 5.17579 5 4.95378C5 4.73178 4.90498 4.51879 4.73569 4.36134L1.09998 1" 
      stroke="#555555" 
      strokeWidth="1.5" 
      strokeLinecap="round" 
      strokeLinejoin="bevel"
    />
  </svg>
);

const formatPrice = (price) => {
  if (!price) return '-';

  const formatter = new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  });

  // Remove 'Rp' prefix and replace comma with dot
  const formatNumber = (num) => 
    formatter.format(num).replace('Rp', '').trim().replace(/\./g, ',').replace(/,/g, '.');

  if (price.min === price.max) {
    return `Rp${formatNumber(price.min)}`;
  }

  return `Rp${formatNumber(price.min)} - Rp${formatNumber(price.max)}`;
};

// Tambahkan reference ke produk yang sudah dipilih sebelumnya
export const UnifiedProductPopup = ({ 
  mode = 'select',
  selectedProducts = [],
  onClose,
  onConfirm,
  onDelete,
  etalaseId = null, // Make etalaseId optional with default value null
  initialSelectedItems = new Set(), // Tambahkan prop ini
  onSelectedItemsChange = () => {}, // Tambahkan prop ini
}) => {
  const { t } = useLanguage();
  const popupRef = useRef(null);
  // Data states
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [brands, setBrands] = useState([]);
  const [originalProducts, setOriginalProducts] = useState([]); // Add this state
  
  // Initialize selectedItems with initialSelectedItems
  const [selectedItems, setSelectedItems] = useState(initialSelectedItems);
  const [search, setSearch] = useState('');
  const [sortConfig, setSortConfig] = useState({ field: '', direction: null });
  const [activeFilters, setActiveFilters] = useState({ categories: [], brands: [] });
  const [filterType, setFilterType] = useState(null);
  const [filterSearch, setFilterSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [hoverTimeout, setHoverTimeout] = useState(null);
  const [searchQuery, setSearchQuery] = useState(''); // Add this new state
  const [showTooltip, setShowTooltip] = useState(false); // Add this new state
  const [isHovering, setIsHovering] = useState(false);
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const containerRef = useRef(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(false);
  const [isSearchDisabled, setIsSearchDisabled] = useState(false);
  const [displayProducts, setDisplayProducts] = useState([]); // Add this new state
  const [allSelectedProductsData, setAllSelectedProductsData] = useState({});
  const [isAllSelected, setIsAllSelected] = useState(false); // Add this new state
  const [headerCheckedStatus, setHeaderCheckedStatus] = useState(false); // Add this new state
  const [lastAction, setLastAction] = useState(null); // 'search' atau 'filter'

  // Load products with search, sort, and filters
  useEffect(() => {
    const loadProducts = async () => {
      try {
        setLoading(true);
        console.log('Loading Products:', {
          mode,
          selectedProductsLength: selectedProducts.length,
        });
        
        if (mode === 'delete') {
          console.log('Delete Mode: Setting products from selectedProducts');
          setProducts(selectedProducts);
          // Only set originalProducts if it's empty
          if (originalProducts.length === 0) {
            setOriginalProducts(selectedProducts);
          }
          setLoading(false);
          return;
        }

        const params = {
          search: search,
          categoryId: activeFilters.categories.map(c => c.id),
          brandId: activeFilters.brands.map(b => b.id),
          sort: sortConfig.field || 'created', // Default sort by created date
          order: sortConfig.direction || 'desc', // Default order desc
        };

        // Only add etalaseId to params if it exists
        if (etalaseId) {
          params.etalaseId = etalaseId;
        }

        const response = await MockServer_TambahEtalase.getProductList(params);
        setProducts(response.data.products);
        // Only set originalProducts on initial load or if it's empty
        if (originalProducts.length === 0) {
          setOriginalProducts(response.data.products);
        }
      } catch (error) {
        console.error('Failed to load products:', error);
      } finally {
        setLoading(false);
      }
    };

    loadProducts();
  }, [search, activeFilters, sortConfig, etalaseId, mode, selectedProducts]);

  // Load filter options
  useEffect(() => {
    const loadFilters = async () => {
      try {
        if (filterType === 'category') {
          const response = await MockServer_TambahEtalase.getCategoryFilter(filterSearch, etalaseId);
          setCategories(response.data.categories);
        } else if (filterType === 'brand') {
          const response = await MockServer_TambahEtalase.getBrandFilter(filterSearch, etalaseId);
          setBrands(response.data.brands);
        }
      } catch (error) {
        console.error('Failed to load filters:', error);
      }
    };

    if (filterType) {
      const debounceTimer = setTimeout(loadFilters, 300);
      return () => clearTimeout(debounceTimer);
    }
  }, [filterType, filterSearch, etalaseId]); // Add etalaseId to dependencies

  // Add click outside handler
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (popupRef.current && !popupRef.current.contains(event.target)) {
        onClose();
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [onClose]);

const handleSort = (field) => {
  setSortConfig(prev => {
    if (prev.field === field) {
      if (prev.direction === 'asc') {
        return { field, direction: 'desc' };
      }
      if (prev.direction === 'desc') {
        return { field: '', direction: null };
      }
    }
    return { field, direction: 'asc' };
  });
};
//24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase -  LB - 0220
  const handleFilterSelect = (type, item) => {
    
    setActiveFilters(prev => {
      const key = type === 'category' ? 'categories' : 'brands';
      const exists = prev[key].find(f => f.id === item.id);
     
      if (exists) {
        
        return {
          ...prev,
          [key]: prev[key].filter(f => f.id !== item.id)
        };
      } else {
        
        return {
          ...prev,
          [key]: [...prev[key], item]
        };
      }
      
    });
  };
//24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase -  LB - 0220
const handleResetFilters = () => {
  if(search){
    setLastAction('search');
  }else{
    setLastAction('filter');
  }
  console.log('test')
  setActiveFilters({ categories: [], brands: [] });
  setIsSearchDisabled(false);
  setIsAllSelected(false); // Reset isAllSelected
  setHeaderCheckedStatus(false); // Reset header checkbox
  
  // Pertahankan produk yang sudah dipilih sebelumnya
  const currentSelected = new Set(selectedItems);
  setSelectedItems(currentSelected);
};

const handleSelectAll = () => {
  const visibleProductIds = displayProducts.map(p => p.id);
  const newSelected = new Set(selectedItems);
  const newProductsData = { ...allSelectedProductsData };
  
  const areAllVisibleSelected = visibleProductIds.every(id => selectedItems.has(id));
  
  if (!areAllVisibleSelected) {
    // Hanya pilih produk yang terlihat
    visibleProductIds.forEach(id => {
      const product = displayProducts.find(p => p.id === id);
      if (product) {
        newSelected.add(id);
        newProductsData[id] = product;
      }
    });
  } else {
    // Hapus hanya produk yang terlihat
    visibleProductIds.forEach(id => {
      newSelected.delete(id);
      delete newProductsData[id];
    });
  }
  
  setSelectedItems(newSelected);
  setAllSelectedProductsData(newProductsData);
  setHeaderCheckedStatus(!areAllVisibleSelected);
};

const handleItemSelect = (productId) => {
  const newSelected = new Set(selectedItems);
  const newProductsData = { ...allSelectedProductsData };
  // Cari produk dari berbagai sumber
  const product = products.find(p => p.id === productId) || 
                 selectedProducts.find(p => p.id === productId);

  if (newSelected.has(productId)) {
    // Hapus dari seleksi
    newSelected.delete(productId);
    delete newProductsData[productId];
  } else if (product) {
    // Tambah ke seleksi
    newSelected.add(product.id);
    newProductsData[product.id] = product;
  }
  
  setSelectedItems(newSelected);
  setAllSelectedProductsData(newProductsData);
  console.log('Selected Products Data:', newProductsData); // Debug log
};

const handleConfirm = () => {
  if (mode === 'delete') {
    if (selectedItems.size > 0) {
      onDelete(Array.from(selectedItems));
      onClose();
    }
    return;
  }

  // Get selected products data
  const selectedProductsList = Array.from(selectedItems)
    .map(id => {
      return allSelectedProductsData[id] || 
             products.find(p => p.id === id) ||
             selectedProducts.find(p => p.id === id);
    })
    .filter(Boolean);

  // Check if there are any changes in selection
  const currentSelectedIds = new Set(selectedItems);
  const previousSelectedIds = new Set(selectedProducts.map(p => p.id));
  
  // If no changes in selection, maintain current order by returning existing products
  if (areSelectionsEqual(currentSelectedIds, previousSelectedIds)) {
    console.log('No changes in selection, maintaining current order');
    onConfirm(selectedProducts);
    onClose();
    return;
  }

  // If there are changes, proceed with sorting
  console.log('Selection changed, reordering products');

  const existingProducts = selectedProductsList.filter(p => 
    selectedProducts.find(sp => sp.id === p.id)
  );
  const newProducts = selectedProductsList.filter(p => 
    !selectedProducts.find(sp => sp.id === p.id)
  );

  // Sort by created date (newest first)
  const compareByDate = (a, b) => new Date(b.created) - new Date(a.created);

  // Group and sort products
  const existingInStock = existingProducts
    .filter(p => p.stock > 0)
    .sort(compareByDate);

  const newInStock = newProducts
    .filter(p => p.stock > 0)
    .sort(compareByDate);

  const newOutOfStock = newProducts
    .filter(p => p.stock <= 0)
    .sort(compareByDate);

  const existingOutOfStock = existingProducts
    .filter(p => p.stock <= 0)
    .sort(compareByDate);

  const finalProducts = [
    ...existingInStock,    // 1. Produk lama dengan stok
    ...newInStock,         // 2. Produk baru dengan stok
    ...newOutOfStock,      // 3. Produk baru tanpa stok
    ...existingOutOfStock  // 4. Produk lama tanpa stok
  ];

  onConfirm(finalProducts);
  onClose();
};

  // Helper function to compare selections
  const areSelectionsEqual = (setA, setB) => {
    if (setA.size !== setB.size) return false;
    for (const item of setA) {
      if (!setB.has(item)) return false;
    }
    return true;
  };

  // Add these new functions
  const handleSearchSubmit = (e) => {
    if (e.key === 'Enter') {
      setLastAction('search');
      setSearch(searchQuery);
    }
  };

const handleSearchReset = () => {
  setSearchQuery('');
  setSearch('');
  if (mode === 'select') {
    setHeaderCheckedStatus(false);
    setIsAllSelected(false); // Reset isAllSelected state
  }
};

  // Modifikasi handler mouse events
  const handleMouseEnter = () => {
    if (selectedItems.size === 0) {
      setIsHovering(true);
      const button = document.querySelector('[data-save-button]');
      if (button) {
        const rect = button.getBoundingClientRect();
        const buttonCenter = rect.left + (rect.width / 2);
        document.documentElement.style.setProperty('--button-center', `${buttonCenter}px`);
      }
    }
  };

  const handleMouseLeave = () => {
    setIsHovering(false); // Perbaiki dari setShowTooltip ke setIsHovering
  };

  // Simplify displayProductsMemo to only handle stock status grouping
  const displayProductsMemo = React.useMemo(() => {
    if (mode === 'delete') {
      return products;
    }
    return products;
  }, [products, mode]);

  // Group products by stock status for delete mode only
  const { availableProducts, outOfStockProducts } = React.useMemo(() => {
    if (mode !== 'delete') {
      return { availableProducts: displayProductsMemo, outOfStockProducts: [] };
    }
    
    const outOfStock = displayProductsMemo.filter(p => p.stock <= 0);
    const available = displayProductsMemo.filter(p => p.stock > 0);
    
    return {
      availableProducts: available,
      outOfStockProducts: outOfStock
    };
  }, [displayProductsMemo, mode]);

  // Loading skeleton component
  const LoadingSkeleton = () => (
    <>
      {[...Array(5)].map((_, i) => (
        <tr key={i} className="animate-pulse">
          <td className="p-4">
            <div className="w-4 h-4 bg-gray-200 rounded" />
          </td>
          <td className="p-4">
            <div className="flex gap-3">
              <div className="w-12 h-12 bg-gray-200 rounded" />
              <div className="flex-1">
                <div className="h-4 bg-gray-200 rounded w-48 mb-2" />
                <div className="h-3 bg-gray-200 rounded w-32" />
              </div>
            </div>
          </td>
          <td className="p-4">
            <div className="h-4 bg-gray-200 rounded w-32" />
          </td>
          <td className="p-4">
            <div className="h-4 bg-gray-200 rounded w-24" />
          </td>
        </tr>
      ))}
    </>
  );

  // Modifikasi fungsi checkScrollable untuk mengecek kemampuan scroll ke kiri dan kanan
  const checkScrollable = () => {
    if (containerRef.current) {
      const { scrollWidth, clientWidth, scrollLeft } = containerRef.current;
      setShowScrollButtons(scrollWidth > clientWidth);
      
      // Cek kemampuan scroll ke kiri
      setCanScrollLeft(scrollLeft > 0);
      
      // Cek kemampuan scroll ke kanan
      setCanScrollRight(scrollLeft < (scrollWidth - clientWidth));
    }
  };

  // Tambahkan useEffect untuk mengecek saat konten berubah dan scroll
  useEffect(() => {
    const container = containerRef.current;
    //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase -  LB - 0220, LB - 0221
    if((activeFilters.categories.length > 0 || activeFilters.brands.length > 0)){
      setLastAction('filter');
    }else{
      setLastAction('search');
    }
    console.log('cek',activeFilters)
    if (container) {
      // Initial check
      checkScrollable();
      
      // Add event listeners
      container.addEventListener('scroll', checkScrollable);
      window.addEventListener('resize', checkScrollable);
      
      // Cleanup
      return () => {
        container.removeEventListener('scroll', checkScrollable);
        window.removeEventListener('resize', checkScrollable);
      };
    }
    
  }, [activeFilters]); // Jalankan ulang saat filter berubah

  // Modifikasi fungsi scroll
  const scrollFilters = (direction) => {
    const container = containerRef.current;
    const scrollAmount = 200;
    
    if (container) {
      if (direction === 'left') {
        container.scrollLeft -= scrollAmount;
      } else {
        container.scrollLeft += scrollAmount;
      }
    }
  };

  // Tambahkan useEffect untuk mengatur overflow pada body
  useEffect(() => {
    // Nonaktifkan scroll pada body ketika popup muncul
    document.body.style.overflow = 'hidden';
    
    // Kembalikan scroll pada body ketika popup ditutup
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, []);

  const tooltipText = mode === 'delete' 
  ? t('pilihMinimal1Produk')
  : t('pilihMinimalProdukUntukmenambahProduk');

  // Update useEffect to check search and filter results
  useEffect(() => {
    // Sync displayProducts with filtered products
    let filteredProducts;
    
    if (mode === 'delete') {
      filteredProducts = selectedProducts;
    } else {
      filteredProducts = products;
    }
    
    // Apply filters first
    if (activeFilters.categories.length > 0) {
      filteredProducts = filteredProducts.filter(product =>
        activeFilters.categories.some(category => 
          product.category.path.includes(category.name)
        )
      );
    }

    if (activeFilters.brands.length > 0) {
      filteredProducts = filteredProducts.filter(product =>
        activeFilters.brands.some(brand => 
          product.brand === brand.id || product.brand === brand.name // Check both ID and name
        )
      );
    }

    // Then apply search
    if (search) {
      const searchLower = search.toLowerCase();
      filteredProducts = filteredProducts.filter(product => 
        product.name.toLowerCase().includes(searchLower) ||
        (product.sku && product.sku.toLowerCase().includes(searchLower)) ||
        (product.brand && product.brand.toLowerCase().includes(searchLower)) // Tambahkan pencarian berdasarkan brand
      );
    }

    setDisplayProducts(filteredProducts);

    console.log('Search and Filter State:', {
      search,
      displayProductsLength: filteredProducts.length,
      hasActiveFilters: activeFilters.categories.length > 0 || activeFilters.brands.length > 0,
      shouldDisableFilter: search && filteredProducts.length === 0 && !activeFilters.categories.length && !activeFilters.brands.length
    });
    // 24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0201, LB - 0202
    // Only disable search when there are active filters and no results
    setIsSearchDisabled(
      (activeFilters.categories.length > 0 || activeFilters.brands.length > 0) &&
      filteredProducts.length === 0 && searchQuery === ''
    );

    // If all was selected, select all filtered products
    if (isAllSelected) {
      const newSelected = new Set(selectedItems);
      const newProductsData = { ...allSelectedProductsData };
      
      filteredProducts.forEach(product => {
        newSelected.add(product.id);
        newProductsData[product.id] = product;
      });
      
      setSelectedItems(newSelected);
      setAllSelectedProductsData(newProductsData);
    }
  }, [search, activeFilters, mode, products, selectedProducts, isAllSelected]);

  // Update FilterDropdown styles to ensure checkbox visibility
  // You'll need to add these styles to the FilterDropdown component's checkbox items
  const checkboxBaseStyles = `
    .checkbox-item:hover .checkbox,
    .checkbox-item .checkbox {
      opacity: 1;
      visibility: visible;
    }
  `;

  // Add the styles to the document head
  useEffect(() => {
    const styleElement = document.createElement('style');
    styleElement.textContent = checkboxBaseStyles;
    document.head.appendChild(styleElement);

    return () => {
      document.head.removeChild(styleElement);
    };
  }, []);

  // Add debug console logs
  useEffect(() => {
    console.log('Debug Filter Button State:', {
      loading,
      mode,
      selectedProductsLength: selectedProducts.length,
      originalProductsLength: originalProducts.length,
      displayProductsLength: displayProducts.length,
      hasActiveFilters: activeFilters.categories.length > 0 || activeFilters.brands.length > 0,
      searchTerm: search,
    });
  }, [loading, mode, selectedProducts, originalProducts, displayProducts, activeFilters, search]);

  // Update useEffect untuk menangani search, sort, dan filter
useEffect(() => {
  let filteredProducts = [...products];
  
  // Khusus untuk mode delete
  if (mode === 'delete') {
    // Terapkan pencarian dengan pengurutan khusus
    if (search) {
      const searchLower = search.toLowerCase();
      
      // Kelompokkan hasil pencarian berdasarkan match type
      const nameMatches = [];
      const skuMatches = [];
      const brandMatches = [];
      
      filteredProducts.forEach(product => {
        if (product.name.toLowerCase().includes(searchLower)) {
          nameMatches.push(product);
        } else if (product.sku && product.sku.toLowerCase().includes(searchLower)) {
          skuMatches.push(product);
        } else if (product.brand && product.brand.toLowerCase().includes(searchLower)) {
          brandMatches.push(product);
        }
      });

      // Urutkan masing-masing kelompok berdasarkan abjad
      nameMatches.sort((a, b) => a.name.localeCompare(b.name));
      skuMatches.sort((a, b) => (a.sku || '').localeCompare(b.sku || ''));
      brandMatches.sort((a, b) => (a.brand || '').localeCompare(b.brand || ''));

      // Gabungkan hasil
      filteredProducts = [...nameMatches, ...skuMatches, ...brandMatches];
    }
    
    // Terapkan filter
    if (activeFilters.categories.length > 0) {
      filteredProducts = filteredProducts.filter(product =>
        activeFilters.categories.some(category => 
          product.category.path.includes(category.name)
        )
      );
    }

    if (activeFilters.brands.length > 0) {
      filteredProducts = filteredProducts.filter(product =>
        activeFilters.brands.some(brand => 
          product.brand === brand.id || product.brand === brand.name
        )
      );
    }

    // Terapkan sorting (override urutan pencarian)
    if (sortConfig.field) {
      filteredProducts.sort((a, b) => {
        let compareA, compareB;
        
        switch (sortConfig.field) {
          case 'name':
            compareA = a.name;
            compareB = b.name;
            break;
          case 'category':
            // Ambil kategori level terakhir dari path
            compareA = a.category.path.split('>').pop().trim();
            compareB = b.category.path.split('>').pop().trim();
            break;
          case 'price':
            compareA = a.price.min;
            compareB = b.price.min;
            break;
          default:
            return 0;
        }

        if (sortConfig.direction === 'asc') {
          return compareA > compareB ? 1 : -1;
        } else {
          return compareA < compareB ? 1 : -1;
        }
      });
    }
  } else {
    // Mode non-delete: gunakan logika filtering biasa
    if (search) {
      const searchLower = search.toLowerCase();
      filteredProducts = filteredProducts.filter(product => 
        product.name.toLowerCase().includes(searchLower) ||
        (product.sku && product.sku.toLowerCase().includes(searchLower)) ||
        (product.brand && product.brand.toLowerCase().includes(searchLower))
      );
    }

    // Terapkan filter untuk mode non-delete
    if (activeFilters.categories.length > 0) {
      filteredProducts = filteredProducts.filter(product =>
        activeFilters.categories.some(category => 
          product.category.path.includes(category.name)
        )
      );
    }

    if (activeFilters.brands.length > 0) {
      filteredProducts = filteredProducts.filter(product =>
        activeFilters.brands.some(brand => 
          product.brand === brand.id || product.brand === brand.name
        )
      );
    }
  }

  setDisplayProducts(filteredProducts);

  // Remove the automatic selection of all products
  // Just update header checked status based on visible products
  const areAllDisplayedSelected = filteredProducts.length > 0 && 
    filteredProducts.every(product => selectedItems.has(product.id));
  setHeaderCheckedStatus(areAllDisplayedSelected);

}, [search, activeFilters, sortConfig, products, mode, selectedProducts, lastAction]); // Tambahkan mode ke dependencies

  // Modify to initialize allSelectedProductsData
  useEffect(() => {
    const initialData = {};
    selectedProducts.forEach(product => {
      if (initialSelectedItems.has(product.id)) {
        initialData[product.id] = product;
      }
    });
    setAllSelectedProductsData(initialData);
    setSelectedItems(initialSelectedItems);
  }, [selectedProducts]); // Run when selectedProducts changes

  // Initialize with products that are currently selected
  useEffect(() => {
    // Mode select tetap menggunakan logika yang sama
    if (mode === 'select') {
      const newSelectedItems = new Set();
      const newProductsData = {};
      
      selectedProducts.forEach(product => {
        newSelectedItems.add(product.id);
        newProductsData[product.id] = product;
      });
      
      setSelectedItems(newSelectedItems);
      setAllSelectedProductsData(newProductsData);
    }
  }, []); // Run only on mount

  // Modifikasi useEffect untuk mengupdate status header checkbox
  useEffect(() => {
    const areAllDisplayedSelected = displayProducts.length > 0 && 
      displayProducts.every(product => selectedItems.has(product.id));
    setHeaderCheckedStatus(areAllDisplayedSelected);
  }, [displayProducts, selectedItems]); // tambahkan dependency ini

  // Modifikasi useEffect untuk mengatur initial state isSearchDisabled
  useEffect(() => {
    // Set search disabled jika tidak ada data saat pertama kali buka
    setIsSearchDisabled(products.length === 0 && searchQuery === '');
  }, [products]); // Dependency hanya pada products

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[24] p-6 mt-14">
      <div ref={popupRef} className="bg-white rounded-lg w-[800px] flex flex-col h-[100%]">
        {/* Header */}
        <div className="flex-none px-6 pt-4 relative">
          <div className="flex-1" /> {/* Spacer kiri */}
          <h2 className="text-base font-bold text-[#1B1B1B] flex-1 text-center">
            {mode === 'delete' ? t('hapusMassal') : t('pilihProduk')}
          </h2>
          <div className="flex-1 flex justify-end absolute top-[10px] right-[10px]" style={{top:'10px'}}> {/* Spacer kanan dengan button */}
            <button onClick={onClose}>
              <X className="w-5 h-5 text-[#176CF7]" />
            </button>
          </div>
        </div>

        {/* Main Content Container */}
        <div className="flex-1 px-6 py-[12px] overflow-hidden min-h-0">
          <div className="border rounded-lg h-full flex flex-col">
            {/* Search and Filters - Fixed */}
            <div className="flex-none p-4">
              {/* Search and filter inputs */}
              <div className="flex gap-3 h-[32px]">
                {/* LB - 0121 - etalase */}
                {/* // 24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0199
                // 24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0200*/}
                <div className="flex relative w-[262px] h-[32px]">
                  <input
                    type="text"
                    placeholder={t('cariNamaProduk')+'/'+t('labelSKU')}
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    onKeyPress={handleSearchSubmit}
                    disabled={isSearchDisabled || (lastAction==='filter' && displayProducts.length === 0 && search==='')}
                    className={`w-full pl-10 pr-8 py-2 border border-[#7B7B7B] rounded-md text-xs font-medium
                      focus:outline-none focus:border-[#176CF7] focus:ring-[#176CF7]
                      placeholder-[#7B7B7B] disabled:bg-gray-100 disabled:cursor-not-allowed text-[#000]
                      ${isSearchDisabled || (lastAction==='filter' && displayProducts.length === 0  && search==='') ? 'opacity-50' : 'hover:border-[#176CF7]'}`}
                  />
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#7B7B7B]" />
                  {searchQuery && !(isSearchDisabled || (lastAction==='filter' && displayProducts.length === 0) && search==='') && (
                    <button
                      onClick={handleSearchReset}
                      className="absolute right-3 top-1/2 -translate-y-1/2"
                    >
                      <X className="w-4 h-4 text-[#555555]" />
                    </button>
                  )}
                </div>
                {/* // 24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0199
// 24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0200 */}
                <FilterDropdown 
                  activeFilters={activeFilters}
                  onFilterSelect={handleFilterSelect}
                  onResetFilters={handleResetFilters}
                  etalaseId={etalaseId}
                  disabled={loading || (
                    // Disable when:
                    // 1. No products in initial state OR
                    // 2. Search with no results and no active filters
                    (mode === 'delete' 
                      ? originalProducts.length === 0 
                      : originalProducts.length === 0) ||
                    (search && displayProducts.length === 0 && lastAction==='search' && !(activeFilters.categories.length > 0 || activeFilters.brands.length > 0))
                  )}
                />
              </div>

              {/* Active Filters */}
              {(activeFilters.categories.length > 0 || activeFilters.brands.length > 0) && (
                <div className="mt-3 flex items-center gap-2 relative">
                  <button
                    onClick={handleResetFilters}
                    className="text-[#176CF7] text-sm font-semibold whitespace-nowrap"
                  >
                    {t('hapusSemuaFilter')}
                  </button>
                  
                  {/* Tombol scroll kiri */}
                  {showScrollButtons && (
                    <div 
                      onClick={() => scrollFilters('left')}
                      className={`flex-none flex items-center justify-center w-6 h-6 rounded-full border border-[#D8D8D8] bg-white hover:bg-gray-50 ${!canScrollLeft ? 'cursor-not-allowed' : 'cursor-pointer'}`}
                    >
                      <svg width="8" height="12" viewBox="0 0 8 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M6.87988 0.40967C7.07756 0.607353 7.09553 0.916694 6.93379 1.13468L6.87988 1.19713L2.07689 6.00037L6.87988 10.8036C7.07756 11.0013 7.09553 11.3106 6.93379 11.5286L6.87988 11.5911C6.6822 11.7888 6.37286 11.8067 6.15487 11.645L6.09242 11.5911L0.89545 6.3941C0.697767 6.19642 0.679796 5.88708 0.841537 5.66909L0.89545 5.60664L6.09242 0.40967C6.30987 0.192219 6.66243 0.192219 6.87988 0.40967Z" 
                          fill={canScrollLeft ? "black" : "#9D9D9D"}
                        />
                      </svg>
                    </div>
                  )}
                  
                  {/* Container untuk filter tags yang bisa di-scroll */}
                  <div 
                    ref={containerRef}
                    id="active-filters-container"
                    className="flex-1 overflow-x-auto flex gap-2 items-center scrollbar-hide"
                    style={{ scrollBehavior: 'smooth', overflowX: 'hidden' }}
                  >
                    {[...activeFilters.categories, ...activeFilters.brands].reverse().map(filter => (
                      <span 
                        key={filter.id}
                        className="flex-none px-3 py-1 bg-white text-[#176CF7] rounded-full border border-[#176CF7] text-sm flex items-center gap-1"
                      >
                        {filter.name}
                        <div className='cursor-pointer'
                          onClick={() => handleFilterSelect(
                            activeFilters.categories.includes(filter) ? 'category' : 'brand',
                            filter
                          )}
                        >
                          <X className="w-4 h-4" />
                        </div>
                      </span>
                    ))}
                  </div>
                  
                  {/* Tombol scroll kanan */}
                  {showScrollButtons && (
                    <div 
                      onClick={() => scrollFilters('right')}
                      className={`flex-none flex items-center justify-center w-6 h-6 rounded-full border border-[#D8D8D8] bg-white hover:bg-gray-50 ${!canScrollRight ? 'cursor-not-allowed' : 'cursor-pointer'}`}
                    >
                      <svg width="8" height="12" viewBox="0 0 8 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1.12012 0.40967C0.922437 0.607353 0.904466 0.916694 1.06621 1.13468L1.12012 1.19713L5.92311 6.00037L1.12012 10.8036C0.922437 11.0013 0.904466 11.3106 1.06621 11.5286L1.12012 11.5911C1.3178 11.7888 1.62714 11.8067 1.84513 11.645L1.90758 11.5911L7.10455 6.3941C7.30223 6.19642 7.3202 5.88708 7.15846 5.66909L7.10455 5.60664L1.90758 0.40967C1.69013 0.192219 1.33757 0.192219 1.12012 0.40967Z" 
                          fill={canScrollRight ? "black" : "#9D9D9D"}
                        />
                      </svg>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Table Section */}
            <div className="flex-1 border-t min-h-0 flex flex-col">
              {/* Fixed Header */}
              <div className="flex-none">
                <table className="w-full border-collapse table-fixed"> {/* Tambahkan table-fixed */}
                  <thead className="bg-white text-[#555555] text-xs font-medium">
                    <tr className="border-b">
                      <th className="px-4 py-3 w-[56px]"> {/* Tambahkan width tetap */}
                        <Checkbox
                          type="checkbox"
                          label=""
                          checked={mode === 'delete' 
                            ? headerCheckedStatus 
                            : (displayProducts.length > 0 && displayProducts.every(p => selectedItems.has(p.id)))
                          }
                          onChange={handleSelectAll}
                          //LB - 0037, LB - 0053, LB - 0085 - etalase
                          className="appearance-none w-4 h-4 rounded bg-white cursor-pointer 
                            checked:bg-[#176CF7] checked:border-[#176CF7]
                            border border-[#7B7B7B] 
                            hover:border-[#176CF7] hover:border
                            transition-colors duration-200
                            relative
                            "
                        />
                      </th>
                      {/*24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0195 */}
                      <th className="px-4 py-3 text-left bg-white w-[231.77px] max-w-[231.77px] min-w-[231.77px]"> {/* Tambahkan width percentage */}
                        <div className="flex items-center gap-1 cursor-pointer text-[#7b7b7b]" onClick={() => handleSort('name')}>
                          {t('namaProduk')}
                          <span className={sortConfig.field === 'name' ? 'text-[#176CF7]' : 'text-[#7b7b7b]'}>
                            {sortConfig.field === 'name'
                              ? (sortConfig.direction === 'asc' ? '↑' : '↓')
                              : '↑↓'
                            }
                          </span>
                        </div>
                      </th>
                      {/* 24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase - LB - 0195 */}
                      <th className="px-4 py-3 text-left bg-white w-[231px] min-w-[231px] max-w-[231px]" > {/* Tambahkan min-width */}
                        <div className="flex items-center gap-1 cursor-pointer text-[#7b7b7b]" onClick={() => handleSort('category')}>
                          {t('labelKategori')}
                          <span className={sortConfig.field === 'category' ? 'text-[#176CF7]' : 'text-[#7b7b7b]'}>
                            {sortConfig.field === 'category'
                              ? (sortConfig.direction === 'asc' ? '↑' : '↓')
                              : '↑↓'
                            }
                          </span>
                        </div>
                      </th>
                      {/* 24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase - LB - 0195 */}
                      <th className="px-4 py-3 text-left bg-white" style={{width: 'calc((100% - 287.77px) / 2)'}}> {/* Tambahkan min-width */}
                        <div className="flex items-center gap-1 cursor-pointer text-[#7b7b7b]" onClick={() => handleSort('price')}>
                          {t('hargaJual')}
                          <span className={sortConfig.field === 'price' ? 'text-[#176CF7]' : 'text-[#7b7b7b]'}>
                            {sortConfig.field === 'price'
                              ? (sortConfig.direction === 'asc' ? '↑' : '↓')
                              : '↑↓'
                            }
                          </span>
                        </div>
                      </th>
                    </tr>
                  </thead>
                </table>
              </div>

              {/* Scrollable Body */}
                      <div className="flex-1 overflow-y-auto min-h-0">
                      <table className="w-full "> {/* Tambahkan table-fixed */}
                        <tbody>
                        {loading ? (
                          <LoadingSkeleton />
                        ) : displayProducts.length === 0 ? (
                          <tr>
                          <td colSpan={4} className="p-8 text-center">
                            {/* Hanya tampilkan pesan error jika sudah ada search atau filter aktif */}
                            {(search || activeFilters.categories.length > 0 || activeFilters.brands.length > 0) && (
                              <div className="flex self-stretch justify-center items-center flex-row">
                                <div className="flex flex-1 justify-start items-center flex-col gap-5 py-3">
                                  <div 
                                    className="flex justify-start items-center flex-col gap-5"
                                    style={{ width: '289px' }}
                                  >
                                    <ImageComponent 
                                      src="/icons/etalase/search-not-found.png"
                                      alt="Search Not Found"
                                      width={142}
                                      height={122}
                                    />
                                    {/*24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase - LB - 0217, LB - 0218 */}
                                    <p className="self-stretch text-[#7B7B7B] text-sm text-center font-semibold whitespace-pre-line">
                                      {(activeFilters.categories.length > 0 || activeFilters.brands.length > 0) && lastAction==='filter'
                                        ? `${t('dataTidakDitemukan')}\n${t('mohonCobaHapusBeberapaFilter')}`
                                        : t('keywordTidakDitemukan')}
                                    </p>
                                  </div>
                                </div>
                              </div>
                            )}
                          </td>
                          </tr>
                        ) : (
                          <>
                          {/* Available Products */}
                        {displayProducts.length > 0 && (
                          <>
                            {displayProducts.map(product => (
                              <tr key={product.id} className="border-b hover:bg-gray-50">
                                <td className="px-4 py-3 w-[56px]"> {/* Match header width */}
                                  <Checkbox
                                    type="checkbox"
                                    label=""
                                    checked={selectedItems.has(product.id)}
                                    onChange={() => handleItemSelect(product.id)}
                                    //LB - 0037, LB - 0053, LB - 0085 - etalase
                                    className="appearance-none w-4 h-4 rounded bg-white cursor-pointer 
                                      checked:bg-[#176CF7] checked:border-[#176CF7]
                                      border border-[#7B7B7B] 
                                      hover:border-[#176CF7] hover:border
                                      transition-colors duration-200
                                      relative
                                      "
                                  />
                                </td>
                                {/*24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0195 */}
                                <td className="px-4 py-3 w-[231.77px] max-w-[231.77px] min-w-[231.77px]"> {/* Match header width */}
                                  <div className="flex gap-3">
                                    <ImageComponent
                                      src={product.imageUrl}
                                      alt={product.name}
                                      width={56}
                                      height={56}
                                      className="w-[56px] h-[56px] object-cover rounded-lg"
                                    />
                                    {/* UAT - 24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase - LB - 0213 */}
                                    <div className="flex flex-col justify-center  text-xs font-medium leading-tight text-black">
                                      <div className="text-xs font-bold leading-4 line-clamp-2">{product.name}</div>
                                      <div className="mt-3 text-[10px] font-medium line-clamp-1 break-all">SKU : {product.sku || '-'}</div>
                                      <div className="mt-3 text-[10px] font-medium line-clamp-1 break-all">Brand : {product.brand || '-'}</div>
                                    </div>
                                    {/* <div className="text-sm">
                                      <div className="font-medium line-clamp-2">{product.name}</div>
                                      <div className="text-[#7b7b7b]">
                                        SKU: {product.sku || '-'}
                                        <br />
                                        Brand: {product.brand || '-'}
                                      </div>
                                    </div> */}
                                  </div>
                                </td>
                                 {/* 24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase - LB - 0195 */}
                                <td className="px-4 py-3 w-[231px] min-w-[231px] max-w-[231px]" > {/* Match header width */}
                                  <div className="flex flex-wrap items-center text-sm">
                                    {product.category.path.split('>').map((part, index, array) => (
                                      // LB - 0045 - etalase
                                      <React.Fragment key={index}>
                                        <span className="flex items-center flex-nowrap">
                                        <span className="truncate max-w-[195px] inline-block text-[10px] font-medium" title={part.trim()}>{part.trim()}</span>{index < array.length - 1 && <CategoryPathSeparator />}
                                        </span>
                                        </React.Fragment>
                                    ))}
                                  </div>
                                </td>
                                 {/* 24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase - LB - 0195 */}
                                <td className="px-4 py-3 text-[10px]" style={{width: 'calc((100% - 287.77px) / 2)'}}> {/* Match header width */}
                                  {formatPrice(product.price)}
                                </td>
                              </tr>
                            ))}
                          </>
                        )}
                      </>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex-none px-6 pb-4 border-t">
          <div className="flex justify-between items-center bg-white relative overflow-visible mt-4">
            <div className="text-sm text-[#1B1B1B] font-bold">
              {t('labelTerpilih')} : {selectedItems.size} 
            </div>
            <div className="relative overflow-visible">
              <div 
                onMouseEnter={handleMouseEnter}
                onMouseLeave={handleMouseLeave}
              >
                <Button
                  data-save-button
                  onClick={handleConfirm}
                  disabled={selectedItems.size === 0}
                  color={mode === 'delete' ? 'error' : 'primary'}
                  Class={`
                    px-6 py-2 rounded-full text-sm font-medium
                    disabled:bg-[#F1F1F1] disabled:text-[#7B7B7B] cursor-pointer disabled:cursor-pointer
                    ${mode === 'delete' 
                      ? 'bg-[#D92D20] hover:bg-[#B42318] text-white' 
                      : 'bg-[#176CF7] hover:bg-[#1452BD] text-white'
                    }
                  `}
                >
                  {mode === 'delete' ? t('hapusMassal') : t('labelSimpan')}
                </Button>
              </div>
              {isHovering && selectedItems.size === 0 && (
                <div 
                  className="absolute px-4 py-2 bg-white text-sm rounded-lg shadow-lg border whitespace-nowrap"
                  style={{
                    filter: 'drop-shadow(0px 1px 2px rgba(16, 24, 40, 0.05))',
                    left: '50%',
                    transform: 'translateX(-50%)',
                    bottom: 'calc(100% + 15px)', // Posisikan di atas button
                    zIndex: 999,
                  }}
                >
                  {tooltipText}
                  <svg
                  style={{position: 'absolute',
                    bottom: '-27%',
                    left: '50%'}}
                    width="16"
                    height="11"
                    viewBox="0 0 16 11"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg">
                    <path
                      fill-rule="evenodd"
                      clip-rule="evenodd"
                      d="M15.4841 9.42498e-07H0.515869C0.550438 0.0842895 0.591322 0.167779 0.638793 0.250001L6.26796 10C7.03776 11.3333 8.96226 11.3333 9.73206 10L15.3612 0.250003C15.4087 0.16778 15.4496 0.0842895 15.4841 9.42498e-07Z"
                      fill="white" />
                  </svg>
                  {/* <div 
                    className="absolute w-4 h-4 bg-white rotate-45 border-b border-r"
                    style={{
                      bottom: '-7px',
                      left: '50%',
                      transform: 'translateX(-50%)',
                      boxShadow: '2px 2px 2px rgba(16, 24, 40, 0.05)',
                      zIndex: -1,
                    }}
                  /> */}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UnifiedProductPopup;