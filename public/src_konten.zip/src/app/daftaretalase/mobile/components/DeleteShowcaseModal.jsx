import React from 'react';
import { useLanguage } from "@/providers/LanguageProvider";
import CustomModal from '@/components/Modal/CustomModal';

const DeleteShowcaseModal = ({ isOpen, onClose, onConfirm }) => {
  const { t } = useLanguage();

  return (
    <CustomModal 
      isOpen={isOpen}
      onClose={onClose}
      onConfirm={onConfirm}
      title={t('hapusEtalase')}
      message={`${t('konfirmasiHapusEtalase')}`}
      confirmText={t('labelYaHapus')}
      cancelText={t('labelBatal')}
    />
  );
};

export default DeleteShowcaseModal;