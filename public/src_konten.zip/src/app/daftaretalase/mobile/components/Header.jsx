import React from "react";
import { useCustomRouter } from '@/libs/CustomRoute';
import ImageComponent from "@/components/ImageComponent/ImageComponent";
import { useLanguage } from "@/providers/LanguageProvider";
import Button from "@/components/Button/Button";

export function Header({ title, showArrangeIcon = false, onArrangeClick, onBack }) {
  const router = useCustomRouter();
  const { t } = useLanguage();

  const handleBack = () => {
    if (onBack) {
      onBack();
    } else {
      router.back();
    }
  };

  return (
    <div className="flex overflow-hidden relative gap-2.5 items-start px-4 py-4 pb-3 w-full text-base font-bold text-white bg-red-700 shadow-lg min-h-[62px] fixed top-0">
      <div className="flex z-10 flex-1 shrink gap-2 items-center w-full basis-0 min-h-[34px] min-w-[240px]">
        <button 
          onClick={handleBack}
          className="border-none bg-transparent cursor-pointer p-0"
          aria-label="Back"
        >
          <ImageComponent
            src="/icons/etalase/mobile/back-arrow.svg"
            alt={t('labelKembali')}
            width={24}
            height={24}
            className="object-contain shrink-0 self-stretch my-auto aspect-square hover:opacity-80 active:opacity-60"
          />
        </button>
        <div className="flex gap-4 items-center self-stretch my-auto min-w-[240px] w-full justify-between">
          <div className="self-stretch my-auto text-base font-bold w-[243px]" style={{lineHeight: 'normal'}}>
            {title}
          </div>
          {showArrangeIcon && (
            <button
              onClick={onArrangeClick}
              className="flex flex-col items-center self-stretch my-auto text-xs font-semibold leading-none text-center whitespace-nowrap w-[38px]"
              aria-label={t('labelSusun')}
            >
              <ImageComponent
                src="/icons/etalase/mobile/arrange.svg"
                alt={t('labelSusun')}
                width={24}
                height={24}
                className="object-contain aspect-square"
              />
              <div>{t('labelSusun')}</div>
            </button>
          )}
        </div>
      </div>
      <ImageComponent
        src="/icons/etalase/mobile/header-pattern.png"
        alt=""
        width={153}
        height={62}
        className="z-0 object-contain absolute right-0 bottom-0 shrink-0 aspect-[2.47]"
      />
    </div>
  );
}
