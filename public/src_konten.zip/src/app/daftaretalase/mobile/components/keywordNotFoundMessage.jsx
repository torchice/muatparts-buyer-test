import React from "react";
import { useLanguage } from "@/providers/LanguageProvider";
import ImageComponent from "@/components/ImageComponent/ImageComponent";

export const KeywordNotFoundMessage = ({customParentClass='justify-center items-center', customClass=''}) => {
  const { t } = useLanguage();
  
  return (
    <div className={`flex flex-col flex-1 ${customParentClass}  min-h-[calc(100vh-200px)] w-full bg-[#F8F8FB]`}>
      <div className={`flex flex-col items-center max-w-full w-[111px] ${customClass}`}>
        <ImageComponent
          src="/icons/etalase/search-not-found.png"
          alt={t('keywordTidakDitemukan')}
          width={142} 
          height={122}
          className="mb-4"
        />
        <p className="text-[#7B7B7B] text-center font-semibold whitespace-pre-line">
        {t('keywordTidakDitemukan').split(' ').map((word, index, array) => (
    <React.Fragment key={index}>
      {word}
      {index === 0 && <br />}
      {index !== array.length - 1 && index !== 0 && ' '}
    </React.Fragment>
  ))}
        </p>
      </div>
    </div>
  );
};