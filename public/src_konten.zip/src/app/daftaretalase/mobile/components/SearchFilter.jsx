"use client";
import React from 'react';
import { useCustomRouter } from '@/libs/CustomRoute';
import { useLanguage } from "@/providers/LanguageProvider";
import ImageComponent from "@/components/ImageComponent/ImageComponent";

export const SearchFilter = ({ 
  searchValue, 
  onSearch, 
  showFilterButton = true,
  activeFilterCount = 0,
  onClearFilter,
  etalaseId  // Add this prop
}) => {
  const router = useCustomRouter();
  const { t } = useLanguage();

  const handleFilterClick = () => {
    const filterUrl = etalaseId 
      ? `/daftaretalase/mobile/filter?etalaseId=${etalaseId}`
      : '/daftaretalase/mobile/filter';
    router.push(filterUrl);
  };

  // ...rest of the component code...
};
