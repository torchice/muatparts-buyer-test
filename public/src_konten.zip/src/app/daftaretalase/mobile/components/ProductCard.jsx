import React from "react";
import ImageComponent from "@/components/ImageComponent/ImageComponent";
import { useLanguage } from "@/providers/LanguageProvider";
import Button from "@/components/Button/Button";

export function ProductCard({ product, onDelete, showDeleteButton = false }) {
  const { t } = useLanguage();
  
  return (
    <div className="flex overflow-hidden gap-2.5 items-start px-4 py-3 w-full text-xs leading-none bg-white">
      <div className="flex flex-col flex-1 shrink w-full basis-0 min-w-[240px]">
        <div className="flex gap-3 items-start w-full font-medium text-black">
          <ImageComponent
            src={product.image || '/images/placeholder.png'}
            alt={product.name}
            width={68}
            height={68}
            className="object-contain shrink-0 rounded aspect-square"
          />
          <div className="flex flex-col flex-1 shrink basis-0 min-w-[240px]">
            <div className="text-sm font-bold leading-4 whitespace-nowrap text-ellipsis">
              {product.name}
            </div>
            <div className="mt-3 text-sm font-semibold">
              Rp{product.price.toLocaleString()}
            </div>
            <div className="mt-3 text-ellipsis">SKU : {product.sku}</div>
            <div className="mt-3 text-ellipsis">{t('labelBrand')} : {product.brand}</div>
            <div className="mt-3 text-ellipsis">
              {t('labelKategori')} : {product.category}
            </div>
          </div>
        </div>
        {showDeleteButton && (
          <Button
            onClick={() => onDelete(product.id)}
            color="error_secondary"
Class="gap-1 self-stretch px-6 py-2.5 mt-4 w-full font-semibold text-red-500 whitespace-nowrap bg-white rounded-3xl border border-red-500 border-solid min-h-[28px] min-w-[112px]"
          >
            {t('labelHapus')}
          </Button>
        )}
      </div>
    </div>
  );
}
