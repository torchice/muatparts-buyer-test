import React from "react";
import { useTranslation } from "@/context/TranslationProvider";

export function SearchBar({ onSearch }) {
  // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0867
  const { tOrEmpty } = useTranslation();
  
  return (
    <div className="flex gap-2 items-center px-3 py-2 w-full text-sm font-semibold bg-white rounded-md border border-solid border-neutral-500 min-h-[32px] text-neutral-500">
      <div className="object-contain shrink-0 self-stretch my-auto w-4 aspect-square">
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path fillRule="evenodd" clipRule="evenodd" d="M7.29411 11.8596C4.37025 11.8596 2 9.50324 2 6.59649C2 3.68973 4.37025 1.33334 7.29411 1.33334C10.218 1.33334 12.5882 3.68973 12.5882 6.59649C12.5882 7.98629 12.0464 9.25028 11.1612 10.191L13.8453 13.5265C14.0888 13.8292 14.0395 14.2708 13.7351 14.5129C13.4306 14.755 12.9864 14.7059 12.7429 14.4033L10.0685 11.0799C9.26177 11.5744 8.31145 11.8596 7.29411 11.8596ZM7.29411 10.4561C9.43827 10.4561 11.1765 8.72811 11.1765 6.59649C11.1765 4.46487 9.43827 2.73684 7.29411 2.73684C5.14995 2.73684 3.41176 4.46487 3.41176 6.59649C3.41176 8.72811 5.14995 10.4561 7.29411 10.4561Z" fill="#555555"/>
        </svg>
      </div>
      <input
        type="text"
        onChange={(e) => onSearch(e.target.value)}
        placeholder={tOrEmpty('cariNamaProdukSKU')}
        className="flex-1 shrink self-stretch my-auto basis-0 bg-transparent border-none outline-none"
        aria-label={tOrEmpty('cariNamaProdukSKU')}
      />
    </div>
  );
}
