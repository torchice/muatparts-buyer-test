// src/app/daftaretalase/mobile/add/cropper/cropfoto/page.jsx
"use client";
import React, { useState, useEffect } from 'react';
import { useCustomRouter } from '@/libs/CustomRoute';
import Cropper from 'react-cropper';
import 'cropperjs/dist/cropper.css';
import { useLanguage } from "@/providers/LanguageProvider";
import { useImageStore } from '@/store/zustand/etalase/imagestore';
import ImageComponent from "@/components/ImageComponent/ImageComponent";
import Button from "@/components/Button/Button";

const CropperPage = () => {
  const router = useCustomRouter();
  const [cropper, setCropper] = useState(null);
  const [aspectRatio, setAspectRatio] = useState(1);
  const [imageUrl, setImageUrl] = useState(null);
  const { t } = useLanguage();
  const [selectedRatio, setSelectedRatio] = useState('ORIGINAL');

  useEffect(() => {
    // Get stored image from localStorage
    const storedImageUrl = localStorage.getItem('selectedImage');
    if (storedImageUrl) {
      setImageUrl(storedImageUrl);
    }
  }, []);

  const aspectRatios = [
    { label: "1:1", width: "22px", value: 1 },
    { label: "3:2", width: "22px", value: 1.5 },
    { label: "ORIGINAL", width: "92px", value: null },
    { label: "4:3", width: "22px", value: 1.33 },
    { label: "16:9", width: "22px", value: 1.78 }
  ];

  const tools = [
    {
      icon: "https://cdn.builder.io/api/v1/image/assets/60cdcdaf919148d9b5b739827a6f5b2a/32a31214d4852c0af707547f7a2333be15d42e5f99a38e0b2db5335554c481d5?apiKey=60cdcdaf919148d9b5b739827a6f5b2a&",
      label: "Crop",
    },
    {
      icon: "https://cdn.builder.io/api/v1/image/assets/60cdcdaf919148d9b5b739827a6f5b2a/c7fc69547c74c67c874e428b4ec949f746cb39b21d052847cfc8450585b53a72?apiKey=60cdcdaf919148d9b5b739827a6f5b2a&",
      label: "",
    },
    {
      icon: "https://cdn.builder.io/api/v1/image/assets/60cdcdaf919148d9b5b739827a6f5b2a/9f3d4fa4fa5cabbe05700fe0dbfd5f751004db0c81c946384e170f905d140ac1?apiKey=60cdcdaf919148d9b5b739827a6f5b2a&",
      label: "",
    },
  ];

  const handleShowPreview = () => {
    if (!cropper) return;

    cropper.getCroppedCanvas({
      width: 800,
      height: 800,
      imageSmoothingQuality: 'high'
    }).toBlob((blob) => {
      const croppedImageUrl = URL.createObjectURL(blob);
      localStorage.setItem('croppedImage', croppedImageUrl);
      router.push('/daftaretalase/mobile/cropper/aftercrop');
    }, 'image/jpeg');
  };

  const handleAspectRatioChange = (ratio) => {
    setSelectedRatio(ratio.label);
    setCropper((current) => {
      if (current) {
        current.setAspectRatio(ratio.value || NaN); // NaN for original/free aspect ratio
        return current;
      }
    });
  };

  if (!imageUrl) {
    return <div>Loading...</div>;
  }

  return (
    <div className="flex flex-col h-screen bg-zinc-800">
      {/* Status Bar */}
      <div className="flex gap-10 justify-between items-center px-6 pt-3 pb-2">
        <div className="flex gap-1 items-center text-xs font-medium text-white">
          <div>9:22</div>
          <ImageComponent
            src="/icons/signal.svg"
            alt=""
            width={14}
            height={14}
            className="w-3.5 h-3.5"
          />
        </div>
        <div className="flex gap-1">
          <ImageComponent
            src="/icons/wifi.svg"
            alt=""
            width={14}
            height={14}
            className="w-3.5 h-3.5"
          />
          <ImageComponent
            src="/icons/battery.svg"
            alt=""
            width={14}
            height={14}
            className="w-3.5 h-3.5"
          />
        </div>
      </div>

      {/* Header */}
      <div className="flex px-4 pt-3 pb-4 text-base font-medium text-white">
        <div className="flex gap-10 justify-between items-center w-full">
          <div className="flex gap-3 items-center">
            <button onClick={() => router.back()} className="p-2">
              <ImageComponent
                src="/icons/back-white.svg"
                alt={t('labelKembali')}
                width={24}
                height={24}
              />
            </button>
            <span>{t('labelCrop')}</span>
          </div>
          <button onClick={handleShowPreview} className="focus:outline-none p-2">
            <ImageComponent
              src="/icons/menu.svg"
              alt={t('labelMenu')}
              width={24}
              height={24}
            />
          </button>
        </div>
      </div>

      {/* Cropper Area */}
      <div className="flex-1 flex justify-center items-center px-4">
        <Cropper
          src={imageUrl}
          style={{ width: '100%', height: '80%' }}
          aspectRatio={aspectRatio}
          guides={true}
          background={false}
          onInitialized={instance => setCropper(instance)}
          className="bg-stone-300"
          viewMode={1}
          dragMode="move"
          cropBoxMovable={true}
          cropBoxResizable={true}
          toggleDragModeOnDblclick={false}
        />
      </div>

      {/* Aspect Ratio Selector */}
      <div className="flex flex-col p-4 text-xs font-semibold text-center bg-white rounded-t-xl">
        <div className="flex gap-9 justify-between items-start w-full">
          {aspectRatios.map((ratio) => (
            <button
              key={ratio.label}
              style={{ width: ratio.width }}
              className={`${
                selectedRatio === ratio.label ? 'text-orange-600' : 'text-black'
              } transition-colors duration-200 hover:text-orange-500`}
              onClick={() => handleAspectRatioChange(ratio)}
            >
              {ratio.label}
            </button>
          ))}
        </div>
      </div>

      {/* Tool Bar */}
      <div className="flex overflow-hidden flex-col justify-center px-11 py-4 bg-zinc-800">
        <div className="flex gap-6">
          {tools.map((tool, index) => (
            <button
              key={index}
              className="flex flex-col flex-1 justify-between items-center text-xs font-medium text-center text-white"
            >
              <ImageComponent
                src={tool.icon}
                alt={tool.label || t('labelTool')}
                width={24}
                height={24}
                className="object-contain"
              />
              {tool.label && <div className="mt-1">{tool.label}</div>}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// AfterCropPage component
const AfterCropPage = () => {
  const router = useCustomRouter();
  const { t } = useLanguage();
  const setCropperImage = useImageStore(state => state.setCropperImage);
  const croppedImageUrl = localStorage.getItem('croppedImage');

  const handleSave = () => {
    setCropperImage(croppedImageUrl);
    
    const event = new CustomEvent('imageCropped', {
      detail: { imageUrl: croppedImageUrl }
    });
    window.dispatchEvent(event);

    // Get source path
    const sourcePath = localStorage.getItem('cropperSource');
    
    // Clean up localStorage
    localStorage.removeItem('cropperSource');
    localStorage.removeItem('croppedImage');
    localStorage.removeItem('selectedImage');
    localStorage.removeItem('selectedImageName');
    localStorage.removeItem('selectedImageType');
    
    // Redirect to source path or default to add page
    router.push(sourcePath || '/daftaretalase/mobile/add');
  };

  const handleRetake = () => {
    localStorage.removeItem('croppedImage');
    router.back();
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="relative bg-red-700 px-4 py-3.5 min-h-[62px]">
        <div className="flex items-center gap-2 z-10 relative">
          <Button onClick={() => router.back()} className="w-6 h-6 bg-white rounded-xl" />
          <div className="text-base font-bold text-white">
            {t('unggahGambar')}
          </div>
        </div>
        <ImageComponent
          src="/icons/etalase/mobile/header-pattern.png"
          alt=""
          width={153}
          height={62}
          className="absolute right-0 bottom-0 h-[62px]"
        />
      </div>

      {/* Preview */}
      <div className="flex justify-center items-center p-4 bg-stone-300 h-[400px]">
        <div className="bg-white rounded-full p-16">
          <ImageComponent
            src={croppedImageUrl}
            alt={t('labelPratinjau')}
            width={173}
            height={173}
            className="object-contain"
          />
        </div>
      </div>

      {/* Controls */}
      <div className="flex flex-col items-center mt-6">
        <Button
          onClick={handleRetake}
          color="primary_secondary"
Class="px-6 py-2 text-base font-semibold text-blue-600 border border-blue-600 rounded-2xl w-[134px]"
        >
          {t('ubahFoto')}
        </Button>
        <div className="mt-3 text-sm font-medium text-stone-500">
          {t('maksUkuranFoto')}
        </div>
      </div>

      {/* Save Button */}
      <div className="fixed bottom-0 left-0 right-0">
        <div className="p-4 bg-white shadow-[0px_-3px_55px_rgba(0,0,0,0.161)]">
          <Button
            onClick={handleSave}
            color="primary"
Class="w-full py-2.5 px-6 text-sm font-semibold text-white bg-blue-600 rounded-3xl"
          >
            {t('simpanFoto')}
          </Button>
        </div>
      </div>
    </div>
  );
};

export { CropperPage, AfterCropPage };