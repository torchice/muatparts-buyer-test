"use client";
import React from "react";
import { useLanguage } from "@/providers/LanguageProvider";
import ImageUploader from "@/components/ImageUploader/ImageUploader";
import { useImageStore } from '@/store/zustand/etalase/imagestore';
import Bottomsheet from "@/components/Bottomsheet/Bottomsheet";
import toast from "@/store/zustand/toast";

export const MediaUploadOptions = ({ onImageUpload, imageUrl, image }) => {
  const {
    showToast,
    dataToast,
    setShowToast,
    setDataToast,
    setShowBottomsheet,
    dataBottomsheet,
  } = toast();
  const { t } = useLanguage();
  const cropperImage = useImageStore(state => state.cropperImage);

  const getImage = (imageData) => {
    imageData?onImageUpload(imageData.url):onImageUpload('');
    
  };
  // 24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase 
  // LB - 0131
  return (
    // <ImageUploader
    //   getImage={getImage}
    //   value={imageUrl || cropperImage}
    //   uploadText={imageUrl ? t('ubah') : t('unggah')}
    //   maxSize={10000}
    // />
    <><Bottomsheet>{dataBottomsheet}</Bottomsheet>
    {/*24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0206 */}
    <ImageUploader
            getImage={getImage}
            // isNull={ProductPhotosValidation}
            maxSize={10}
            // uploadText={imageUrl ? t('ubah') : t('unggah')}
            isCircle={true}
            className={`!size-[72px]`}
            value={image || cropperImage || imageUrl}
            previewTitle="Upload Foto Produk"
          /></>
    
  );
};