"use client";
import React, { useState } from "react";
import { MediaUploadOptions } from "./MediaUploadOptions";

const MediaUploadLayout = () => {
  const [imageUrl, setImageUrl] = useState(null);

  const handleImageUpload = (url) => {
    setImageUrl(url);
  };

  return (
    <div className="flex flex-col mx-auto w-full max-w-[480px]">
      <div className="flex overflow-hidden flex-col bg-white">
        <div className="flex flex-col w-full bg-black bg-opacity-50 pt-[578px]">
          <div className="flex flex-col w-full">
            <MediaUploadOptions 
              imageUrl={imageUrl}
              onImageUpload={handleImageUpload}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export { MediaUploadLayout };
export default MediaUploadLayout;
