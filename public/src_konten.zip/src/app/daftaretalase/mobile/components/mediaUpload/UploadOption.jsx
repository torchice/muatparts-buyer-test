import React from "react";
import ImageComponent from "@/components/ImageComponent/ImageComponent";

const UploadOption = ({ icon, label, onClick }) => {
  return (
    <div
      className="flex flex-col items-center self-stretch my-auto"
      role="button"
      tabIndex={0}
      onClick={onClick}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          onClick();
        }
      }}
    >
      <ImageComponent
        src={icon}
        alt={label}
        width={64}
        height={64}
        className="object-contain aspect-square"
      />
      <div className="mt-4">{label}</div>
    </div>
  );
};

export { UploadOption };
export default UploadOption;