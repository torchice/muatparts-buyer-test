// components/BottomSheet/BottomSheet.jsx
"use client";
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

export const Bottomsheet = ({ children, onClose }) => {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  
  const height = typeof window !== 'undefined' ? window.innerHeight : 0;
  const maxDrag = height * 0.7;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 bg-black bg-opacity-50 flex items-end"
        onClick={onClose}
      >
        <motion.div
          drag="y"
          dragConstraints={{ top: -maxDrag, bottom: 50 }}
          dragElastic={0.2}
          onDragStart={() => setIsDragging(true)}
          onDragEnd={(_, info) => {
            setIsDragging(false);
            if (info.offset.y > 200) {
              onClose();
            } else if (info.offset.y < -100) {
              setIsFullscreen(true);
            } else {
              setIsFullscreen(false);
            }
          }}
          className={`w-full bg-white rounded-t-3xl transition-all duration-300 ease-out
            ${isFullscreen ? 'min-h-screen' : 'min-h-[30%]'}`}
          onClick={(e) => e.stopPropagation()}
        >
          {/* Handle untuk drag */}
          <div className="flex justify-center p-2 cursor-grab active:cursor-grabbing">
            <div className="w-10 h-1 bg-gray-300 rounded-full" />
          </div>

          {/* Konten */}
          <div className={`overflow-auto ${isFullscreen ? 'h-screen' : ''}`}>
            {children}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};