// ...existing code...

const handleFileSelect = async (e) => {
  const file = e.target.files?.[0];
  if (!file) return;
  
  try {
    const fileUrl = URL.createObjectURL(file);
    
    // Store file information
    localStorage.setItem('selectedImage', fileUrl);
    localStorage.setItem('selectedImageName', file.name);
    localStorage.setItem('selectedImageType', file.type);
    
    // Store current path as source
    localStorage.setItem('cropperSource', window.location.pathname);
    
    setIsBottomsheetOpen(false);
    
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
    
    router.push('/daftaretalase/mobile/cropper/cropfoto');
  } catch (error) {
    console.error('Error handling file:', error);
    alert(t('errorUploadingFile'));
  }
};

// ...existing code...
