import * as React from "react";
import { useLanguage } from "@/providers/LanguageProvider";
import ImageComponent from "@/components/ImageComponent/ImageComponent";

export const ShowcaseHeader = () => {
  const { t } = useLanguage();
  
  return (
    <div className="flex overflow-hidden relative gap-2.5 items-start px-4 py-3.5 text-white bg-red-700 shadow-lg min-h-[62px]">
      <div className="flex z-0 flex-1 shrink gap-2 items-center w-full basis-0 min-w-[240px]">
        <ImageComponent
          src="/icons/back-arrow.png"
          alt="Back"
          width={24}
          height={24}
          className="object-contain shrink-0 self-stretch my-auto aspect-square"
        />
        <div className="flex gap-4 justify-between items-center self-stretch my-auto w-full">
          <div className="self-stretch my-auto text-base font-bold w-[243px]">
            {t('daftarEtalase')}
          </div>
          <div className="flex flex-col items-center self-stretch my-auto text-xs font-semibold leading-none text-center whitespace-nowrap w-[38px]">
            <ImageComponent
              src="/icons/sort.png" 
              alt={t('labelSusun')}
              width={24}
              height={24}
              className="object-contain aspect-square"
            />
            <div>{t('labelSusun')}</div>
          </div>
        </div>
      </div>
      <ImageComponent
        src="/icons/header-bg.png"
        alt=""
        width={153}
        height={62}
        className="object-contain absolute right-0 bottom-0 z-0 shrink-0 aspect-[2.47]"
      />
    </div>
  );
};
