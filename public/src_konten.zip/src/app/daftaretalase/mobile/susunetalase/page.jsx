// 24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase
// LB - 0147
// LB - 0155
'use client';

import React, { useState, useEffect } from 'react';
import { useCustomRouter } from '@/libs/CustomRoute';
import { ChevronLeft, Info } from 'lucide-react';
import dynamic from 'next/dynamic';
import CustomModal from '@/components/Modal/CustomModal';
import ImageComponent from "@/components/ImageComponent/ImageComponent";
import Button from "@/components/Button/Button";

// Dynamically import drag and drop components with SSR disabled
const DragDropContext = dynamic(
  () => import('react-beautiful-dnd').then(mod => mod.DragDropContext),
  { ssr: false }
);
const Droppable = dynamic(
  () => import('react-beautiful-dnd').then(mod => mod.Droppable),
  { ssr: false }
);
const Draggable = dynamic(
  () => import('react-beautiful-dnd').then(mod => mod.Draggable),
  { ssr: false }
);
import { MockServer_TambahEtalase } from '@/services/MockServer_TambahEtalase';
import useEtalaseStore from '@/store/zustand/etalasestore';
import Toast from '@/components/Toast/Toast';
import { useLanguage } from "@/providers/LanguageProvider";
import toast from "@/store/zustand/toast";
import DaftarEtalaseSvg from '@/icons/Daftar Etalase.svg';
import Bottomsheet from "@/components/Bottomsheet/Bottomsheet";
import to_ast  from "@/store/zustand/toast";

const SusunEtalasePage = () => {
  const { t } = useLanguage();
  const router = useCustomRouter();
  const [isLoading, setIsLoading] = useState(false);
  // const { showToast, setShowToast, setDataToast } = toast();
  const [showLeaveModal, setShowLeaveModal] = useState(false);
  const [originalOrder, setOriginalOrder] = useState([]);
  
  const { etalaseList, fetchEtalaseList } = useEtalaseStore();
  const [items, setItems] = useState([]);
  const {
    showToast,
    dataToast,
    setShowToast,
    setDataToast,
    setShowBottomsheet,
    dataBottomsheet,
  } = to_ast();

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      try {
        await fetchEtalaseList();
      } catch (error) {
        setDataToast({
          type: 'error',
          message: t('gagalMemuatData')
        });
        setShowToast(true);
      } finally {
        setIsLoading(false);
      }
    };
    fetchData();
  }, []);

  useEffect(() => {
    if (etalaseList.length > 0) {
      const reorderableItems = etalaseList
        .filter(item => !item.isDefault)
        .sort((a, b) => a.position - b.position);
      setOriginalOrder(reorderableItems);
      setItems(reorderableItems);
    }
  }, [etalaseList]);

  // Simplified reorder function
  const reorder = (list, startIndex, endIndex) => {
    const result = Array.from(list);
    const [removed] = result.splice(startIndex, 1);
    result.splice(endIndex, 0, removed);
    return result;
  };

  const onDragEnd = (result) => {
    // drop outside the list
    if (!result.destination) {
      return;
    }

    const reorderedItems = reorder(
      items,
      result.source.index,
      result.destination.index
    );

    setItems(reorderedItems.map((item, index) => ({
      ...item,
      position: index + 1
    })));
  };

  const handleSave = async () => {
    try {
      setIsLoading(true);
      const positions = items.map((item) => ({
        etalaseId: item.id,
        position: item.position
      }));
  
      await MockServer_TambahEtalase.updateEtalaseOrder(positions);
      await fetchEtalaseList();
      router.back()
      //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0156
      localStorage.setItem('showToast', 'true');
      localStorage.setItem('toastMessage', t('berhasilMenyusunUrutanEtalase'));
      localStorage.setItem('toastType', 'success');
      // setDataToast({
      //   type: 'success',
      //   message: t('berhasilMenyusunUrutanEtalase')
      // });
      // setShowToast(true);
  
     
      // setTimeout(() => router.back(), 1500);
    } catch (error) {
      setDataToast({
        type: 'error',
        message: error.message || t('gagalMenyusunUrutanEtalase')
      });
      setShowToast(true);
    } finally {
      setIsLoading(false);
    }
  };

  const handleBack = () => {
    const hasChanges = JSON.stringify(items) !== JSON.stringify(originalOrder);
    setShowLeaveModal(true);
  };

  return (
    <div className="flex flex-col h-screen w-full bg-slate-50 relative">
      {/* Header - Fixed at top */}
      <div className="flex overflow-hidden relative gap-2.5 items-start px-4 py-3.5 bg-red-700 shadow-lg min-h-[62px] fixed top-0 left-0 right-0 z-50">
        <div className="flex z-0 gap-2 items-center min-h-[34px] min-w-[240px] w-[328px]">
          <div className="flex flex-col self-stretch my-auto w-6">
            <div 
              onClick={handleBack}
              className="flex shrink-0 w-6 h-6 bg-white rounded-xl"
            >
              <ChevronLeft className="w-6 h-6 text-red-700" />
            </div>
          </div>
          <div className="gap-4 self-stretch my-auto text-base font-bold text-white">
            {t('susunEtalase')}
          </div>
          <div 
            className="flex shrink-0 self-stretch my-auto w-4 h-4"
            onClick={() => setShowBottomsheet(true)}
          >
            <Info className="w-4 h-4 text-white" />
          </div>
        </div>
        <ImageComponent
          src="/icons/etalase/mobile/header-pattern.png"
          alt=""
          width={153}
          height={62}
          className="object-contain absolute right-0 bottom-0 z-0 shrink-0 aspect-[2.47]"
        />
      </div>

      {/* Content - Scrollable area */}
      <div className="flex flex-col w-full overflow-y-auto bg-zinc-100  pb-[75px]">
        {isLoading ? (
          <div className="flex justify-center items-center h-40">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-red-700" />
          </div>
        ) : items.length > 0 ? (
          <DragDropContext onDragEnd={onDragEnd}>
            <Droppable droppableId="droppable" touchAction="manipulation">
              {(provided, snapshot) => (
                <div
                  {...provided.droppableProps}
                  ref={provided.innerRef}
                  className="flex flex-col w-full"
                >
                  {items.map((item, index) => (
                    <Draggable
                      key={item.id.toString()}
                      draggableId={item.id.toString()}
                      index={index}
                    >
                      {(provided, snapshot) => (
                        <div
                          ref={provided.innerRef}
                          {...provided.draggableProps}
                          className={`flex overflow-hidden z-0 gap-4 items-center px-4 py-3 w-full bg-white 
                            ${index > 0 ? "mt-2" : ""}
                            ${snapshot.isDragging ? "shadow-lg bg-blue-50" : ""}`}
                        >
                          <div className="flex-1 flex items-center gap-4">
                            <div className="w-14 h-14 rounded-md overflow-hidden">
                            {item.isDefault ? (
                              <ImageComponent
                                src='/icons/etalase/semua_produk.png'
                                alt={item.name}
                                className="object-cover shrink-0 self-start w-14 rounded-md aspect-square"
                              />
                            ) : item.imageUrl ? (
                              <ImageComponent
                                src={item.imageUrl}
                                alt={item.name}
                                width={56}
                                height={56}
                                className="object-cover shrink-0 self-start rounded-md aspect-square"
                              />
                            ) : (
                              <div className="flex overflow-hidden flex-col justify-center items-center self-start w-14 h-14 bg-white rounded-md">
                                <ImageComponent
                                  src='/icons/etalase/Daftar Etalase.svg'
                                  alt=""
                                  width={68}
                                  height={56}
                                  className="object-contain aspect-[1.21] w-[68px]"
                                  aria-hidden="true"
                                />
                              </div>
                            )}
                            </div>
                            <div className="flex-1">
                              <div className="text-base font-bold leading-4 line-clamp-2">{item.name}</div>
                            </div>
                          </div>
                          <div {...provided.dragHandleProps} className="w-6 cursor-move">
                            <ImageComponent
                              src="/icons/etalase/mobile/drag-item-grey.svg"
                              alt={t('labelGeser')}
                              width={24}
                              height={24}
                              className="object-contain shrink-0 self-stretch my-auto aspect-square"
                            />
                          </div>
                        </div>
                      )}
                    </Draggable>
                  ))}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          </DragDropContext>
        ) : (
          <div className="flex justify-center items-center h-40">
            <p>{t('belumAdaEtalase')}</p>
          </div>
        )}
      </div>

      {/* Footer - Fixed at bottom */}
      <div className="fixed bottom-0 left-0 right-0 flex flex-col w-full z-50 bg-white">
        <div className="flex gap-3 items-center px-4 py-3 w-full text-sm font-semibold leading-none text-white whitespace-nowrap bg-white rounded-t-xl shadow-2xl">
          <Button
            onClick={handleSave}
            disabled={isLoading}
            color="primary"
            Class="flex-1 shrink gap-1 self-stretch px-6 py-4 my-auto w-full bg-blue-600 rounded-3xl min-h-[40px] min-w-[160px] sm:max-w-full"
          >
            {t('labelSimpan')}
          </Button>
        </div>
      </div>

      <Bottomsheet label={t('susunEtalaseKamu')}>
        <div className="w-full text-start text-[14px] font-medium">
          {t('susunUrutanEtalase')}
        </div>
      </Bottomsheet>

      <CustomModal 
        isOpen={showLeaveModal}
        onClose={() => setShowLeaveModal(false)}
        onConfirm={() => router.back()}
        title={t('keluarHalamanIni')}
        message={t('konfirmasiKeluarHalaman')}
        confirmText={t('labelYaKeluar')}
        cancelText={t('labelBatal')}
      />

      <Toast />
    </div>
  );
};

export default SusunEtalasePage;