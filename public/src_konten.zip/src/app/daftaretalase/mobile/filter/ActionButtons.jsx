import * as React from "react";
import { useLanguage } from "@/providers/LanguageProvider";
import Button from "@/components/Button/Button";
export function ActionButtons() {
  const { t } = useLanguage();
  
  return (
    <div className="flex flex-col mt-80 w-full">
      <div className="flex gap-2 justify-center">
        <button className="gap-1 self-stretch px-6 py-4 text-[#176CF7]">
          {t('labelBatal')}
        </button>
        <button className="gap-1 self-stretch px-6 py-4 text-white">
          {t('labelSimpan')}
        </button>
      </div>
    </div>
  );
}
