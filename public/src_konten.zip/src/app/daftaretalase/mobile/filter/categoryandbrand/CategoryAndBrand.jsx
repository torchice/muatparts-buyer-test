import React, { useState, useEffect } from 'react';
import { useCustomRouter } from '@/libs/CustomRoute';
import { LoadingSkeleton } from './error-loading';
import { useLanguage } from "@/providers/LanguageProvider";
import ImageComponent from "@/components/ImageComponent/ImageComponent";
import Button from "@/components/Button/Button";

export const CategoryListView = ({ selectedIds = [], onApply }) => {
  const { t } = useLanguage();
  const router = useCustomRouter();
  const [searchQuery, setSearchQuery] = useState('');
  const [categories, setCategories] = useState([]);
  const [selected, setSelected] = useState(new Set(selectedIds));
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const response = await window.mockServer.getCategoryFilter(searchQuery);
        setCategories(response.data.categories);
      } catch (error) {
        console.error('Error fetching categories:', error);
      } finally {
        setLoading(false);
      }
    };

    const debounceTimer = setTimeout(fetchCategories, 300);
    return () => clearTimeout(debounceTimer);
  }, [searchQuery]);

  const handleSelect = (id) => {
    setSelected(prev => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  };

  const filteredCategories = searchQuery 
    ? categories.filter(cat => 
        cat.name.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : categories;

  return (
    <div className="flex flex-col min-h-screen bg-white">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white shadow-md">
        <div className="flex items-center p-4">
          <button 
            onClick={() => router.back()}
            className="p-2"
          >
            <ImageComponent
              src="/icons/arrow-left.svg"
              alt={t('labelKembali')}
              width={24}
              height={24}
            />
          </button>
          <h1 className="ml-4 text-lg font-semibold">{t('labelKategori')}</h1>
        </div>

        {/* Search Bar */}
        <div className="px-4 pb-4">
          <div className="flex items-center px-3 py-2 bg-white rounded-md border border-gray-300">
            <ImageComponent
              src="/icons/search.svg"
              alt=""
              width={20}
              height={20}
              className="text-gray-400"
            />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t('cariKategori')}
              className="flex-1 ml-2 outline-none bg-transparent"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="p-1"
              >
                <ImageComponent
                  src="/icons/close.svg"
                  alt={t('labelHapus')}
                  width={16}
                  height={16}
                />
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Category List */}
      <div className="flex-1 pb-20">
        {loading ? (
          <div className="p-4">
            <LoadingSkeleton.FilterSection />
          </div>
        ) : filteredCategories.length === 0 ? (
          <div className="flex flex-col items-center justify-center p-8">
            <ImageComponent
              src="/icons/not-found.svg"
              alt={t('dataTidakDitemukan')}
              width={64}
              height={64}
              className="mb-4"
            />
            <p className="text-[#7b7b7b]">{t('dataTidakDitemukan')}</p>
          </div>
        ) : (
          <div className="divide-y">
            {filteredCategories.map((category) => (
              <label
                key={category.id}
                className="flex items-center px-4 py-3 hover:bg-gray-50"
              >
                <input
                  type="checkbox"
                  checked={selected.has(category.id)}
                  onChange={() => handleSelect(category.id)}
                  className="w-5 h-5 rounded border-gray-300 text-[#176CF7] focus:ring-blue-500"
                />
                <span className="ml-3 flex-1">
                  <span className="block text-sm font-medium text-gray-900">
                    {category.name}
                  </span>
                  <span className="block text-xs text-[#7b7b7b]">
                    {category.totalProducts} Produk
                  </span>
                </span>
              </label>
            ))}
          </div>
        )}
      </div>

      {/* Action Buttons */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white border-t">
        <div className="flex gap-3">
          <Button
            onClick={() => setSelected(new Set())}
            color="primary_secondary"
Class="flex-1 py-3 text-[#176CF7] bg-white border border-blue-600 rounded-full font-semibold"
          >
            {t('labelReset')}
          </Button>
          <Button
            onClick={() => {
              onApply(Array.from(selected));
              router.back();
            }}
            color="primary"
Class="flex-1 py-3 text-white bg-blue-600 rounded-full font-semibold"
          >
            {t('labelTerapkan')}
          </Button>
        </div>
      </div>
    </div>
  );
};

// Brand list view is very similar, just with different API endpoint
export const BrandListView = ({ selectedIds = [], onApply }) => {
  const { t } = useLanguage();
  // Similar implementation as CategoryListView but with brand-specific API calls
  // and minor UI adjustments
  
  // Main difference is in the API call:
  useEffect(() => {
    const fetchBrands = async () => {
      try {
        const response = await window.mockServer.getBrandFilter(searchQuery);
        setBrands(response.data.brands);
      } catch (error) {
        console.error('Error fetching brands:', error);
      } finally {
        setLoading(false);
      }
    };

    const debounceTimer = setTimeout(fetchBrands, 300);
    return () => clearTimeout(debounceTimer);
  }, [searchQuery]);

  // Rest of the implementation follows the same pattern as CategoryListView
};