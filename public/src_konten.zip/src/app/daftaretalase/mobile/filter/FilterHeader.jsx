import React from "react";
import { useLanguage } from "@/providers/LanguageProvider";
import ImageComponent from "@/components/ImageComponent/ImageComponent";

export function FilterHeader() {
  const { t } = useLanguage();

  return (
    <div className="flex flex-col justify-center">
      <div className="flex gap-2 justify-between">
        <ImageComponent
          src="/icons/etalase/closes.svg"
          alt={t('labelKembali')}
          width={24}
          height={24}
          className="w-6 h-6"
        />
        <div className="text-center">
          {t('labelFilter')}
        </div>
        <div/>
      </div>
    </div>
  );
}
