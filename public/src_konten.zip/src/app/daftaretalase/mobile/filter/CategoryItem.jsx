import * as React from "react";
import { useLanguage } from "@/providers/LanguageProvider";

export function CategoryItem({ name }) {
  const { t } = useLanguage();
  
  return (
    <div className="flex overflow-hidden flex-col justify-center px-3 py-2 rounded-3xl border border-solid bg-zinc-100 border-zinc-100 max-w-[262px]">
      <div className="gap-2 self-stretch min-h-[14px] text-ellipsis">
        {name}
      </div>
    </div>
  );
}
