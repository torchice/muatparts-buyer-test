// THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase
// LB - 0135
"use client";
import React, { useState, useEffect } from 'react';
import { useCustomRouter } from '@/libs/CustomRoute';
import { MockServer_TambahEtalase } from '@/services/MockServer_TambahEtalase';
import { Loading } from '@/components/Loading/Loading';
import useFilterStore from '@/store/zustand/filterstore';
import { useLanguage } from "@/providers/LanguageProvider";
import ImageComponent from "@/components/ImageComponent/ImageComponent";
import Button from "@/components/Button/Button";

const SkeletonLoader = () => (
  <div className="divide-y">
    {[...Array(10)].map((_, index) => (
      <div key={index} className="flex items-center px-4 py-3 animate-pulse">
        <div className="w-5 h-5 bg-gray-200 rounded mr-3"></div>
        <div className="h-4 bg-gray-200 rounded w-full"></div>
      </div>
    ))}
  </div>
);

export default function CategoryFilterPage() {
  const router = useCustomRouter();
  const { tempSelections, setCategoryFilters, setTempCategories } = useFilterStore();
  const { t } = useLanguage();
  
  const [categories, setCategories] = useState([]);
  const [selectedCategories, setSelectedCategories] = useState(
    tempSelections.categories || []
  );
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [etalaseId, setEtalaseId] = useState('');

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      fetchCategories();
    }
  };

  const fetchCategories = async () => {
    try {
      setIsLoading(true);
      let params = undefined;
      
      if (etalaseId) {
        params = etalaseId;
      }
      
      const response = await MockServer_TambahEtalase.getCategoryFilter(
        searchTerm, 
        params
      );
      setCategories(response.data.categories);
    } catch (error) {
      console.error('Error fetching categories:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const id = params.get('etalaseId');
    const selected = params.get('selected');
    
    if (id) setEtalaseId(id);
    
    // Set selected categories from URL param
    if (selected) {
      const selectedIds = selected.split(',').map(Number);
      setSelectedCategories(selectedIds);
    }
  }, []);

  useEffect(() => {
    const timeoutId = setTimeout(fetchCategories, 300);
    return () => clearTimeout(timeoutId);
  }, [searchTerm, etalaseId]);

  const handleSelect = (categoryId) => {
    setSelectedCategories(prev => 
      prev.includes(categoryId)
        ? prev.filter(id => id !== categoryId)
        : [...prev, categoryId]
    );
  };

  const handleReset = () => {
    setSelectedCategories([]); // Reset local selection only
  };

  const handleApply = () => {
    console.log('Category handleApply called');
    console.log('Before apply - Selected categories:', selectedCategories);
    //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0211, LB - 0138, LB - 0166
    setTempCategories(selectedCategories);
    localStorage.setItem('tempSaveCategories', true);
    console.log('After apply - tempSelections:', {
      categories: selectedCategories
    });
    
    router.back();
  };

  return (
    <div className="flex flex-col h-screen w-full bg-zinc-50"> {/* Changed to h-screen and flex-col */}
      {/* Search Header - remains fixed */}
      <div className="flex-none"> {/* Added flex-none to prevent shrinking */}
        <div className="flex gap-2 items-center px-4 py-3 w-full bg-white shadow-[0px_4px_15px_rgba(0,0,0,0.15)] z-[50]">
          <button 
            onClick={() => router.back()}
            className="flex flex-col self-stretch my-auto"
          >
            <div className="flex justify-center items-center w-6 h-6 bg-blue-600 rounded-xl">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M0 12C0 18.6274 5.37258 24 12 24C18.6274 24 24 18.6274 24 12C24 5.37258 18.6274 0 12 0C5.37258 0 0 5.37258 0 12Z" fill="#176CF7"/>
                <path d="M14 7L9.33039 11.3172C9.11878 11.514 9 11.7803 9 12.0578C9 12.3353 9.11878 12.6015 9.33039 12.7983L13.875 17" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="bevel"/>
              </svg>
            </div>
          </button>
          <div className="flex flex-1 items-center px-3 py-2 bg-white rounded-md border border-solid border-neutral-500 min-h-[32px] focus-within:border-[#176CF7] transition-colors">
            <ImageComponent
              src="/icons/etalase/search.svg"
              alt="Search"
              className="w-4 h-4 mr-2"
            />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={t('cariKategori')}
              className="flex-1 text-sm bg-transparent border-none outline-none placeholder-neutral-500"
            />
            {searchTerm && (
              <button 
                onClick={() => setSearchTerm('')}
                className="p-1"
              >
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 12L4 4" stroke="#555555" stroke-linecap="round" stroke-linejoin="bevel"/>
                  <path d="M12 4L4 12" stroke="#555555" stroke-linecap="round" stroke-linejoin="bevel"/>
                </svg>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Content Area - takes remaining space and scrolls */}
      <div className="flex-1 overflow-y-auto "> {/* Added mb-[100px] here */}
        {isLoading ? (
          <SkeletonLoader />
        ) : categories.length === 0 ? (
          <div className="flex flex-col justify-center items-center py-52 w-full text-sm font-semibold text-center text-neutral-500">
            <div className="flex flex-col w-[111px]">
              <ImageComponent
                src="/icons/etalase/search-not-found.png"
                alt="No results found"
                className="w-full aspect-[1.18] mb-3"
              />
              <div>
              {t('keywordTidakDitemukan').split(' ').map((word, index, array) => (
    <React.Fragment key={index}>
      {word}
      {index === 0 && <br />}
      {index !== array.length - 1 && index !== 0 && ' '}
    </React.Fragment>
  ))}
              </div>
            </div>
          </div>
        ) : (
          <div className="divide-y px-4">
            {categories.map((category, index) => (
              <label
                key={category.id}
                className={`flex items-center py-3 hover:bg-zinc-50 border-t-1 border-[#C4C4C4] ${index === (categories.length-1)?"mb-[100px]":''}`}
              >
                <input
                  type="checkbox"
                  checked={selectedCategories.includes(category.id)}
                  onChange={() => handleSelect(category.id)}
                  className="w-[16px] h-[16px] min-w-[16px] rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <span className="ml-3">
                  <span className="text-sm font-semibold text-[#000] line-clamp-2">
                    {category.name}
                  </span>
                </span>
              </label>
            ))}
          </div>
        )}
      </div>

      {/* Bottom Buttons - remains fixed */}
      <div className="flex-none"> {/* Added flex-none to prevent shrinking */}
        <div className="fixed bottom-0 left-0 right-0 flex flex-col justify-center px-4 py-3 bg-white rounded-t-xl shadow-[0px_-3px_55px_rgba(0,0,0,0.161)]">
          <div className="flex gap-2 justify-between w-full">
            <Button 
              onClick={handleReset}
              color="primary_secondary"
Class="flex-1 px-6 py-4 text-sm font-semibold text-blue-600 bg-white rounded-3xl border border-blue-600 sm:max-w-full"
            >
              {t('labelReset')}
            </Button>
            <Button
              onClick={handleApply}
              color="primary"
Class="flex-1 px-6 py-4 text-sm font-semibold text-white bg-blue-600 rounded-3xl sm:max-w-full"
            >
              {t('labelTerapkan')}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}