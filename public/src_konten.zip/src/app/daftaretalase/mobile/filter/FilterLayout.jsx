import * as React from "react";
import { useLanguage } from "@/providers/LanguageProvider";
import { CategorySection } from "./CategorySection";
import { FilterHeader } from "./FilterHeader";
import { ActionButtons } from "./ActionButtons";
import ImageComponent from "@/components/ImageComponent/ImageComponent";

const categories = [
  { name: "Axle" },
  { name: "Sistem Pengereman" },
  { name: "General" },
  { name: "Mesin" },
  { name: "Roda dan Ban" },
];

const brands = [
  { name: "Dunlop" },
  { name: "Sistem Pengereman" },
  { name: "General" },
  { name: "Mesin" },
  { name: "Roda dan Ban" },
];

export default function FilterLayout() {
  const { t } = useLanguage();

  return (
    <div className="flex overflow-hidden flex-col bg-zinc-50 max-w-[521px] shadow-[0px_4px_4px_rgba(0,0,0,0.25)]">
      <FilterHeader />
      <div className="flex flex-col self-center px-5 mt-5 w-full text-sm leading-none">
        <CategorySection title={t('labelKategori')} items={categories} />
        <ImageComponent
          src="/icons/divider.svg"
          alt=""
          width={480}
          height={1}
          className="object-contain self-stretch mt-5 w-full stroke-[1px] stroke-stone-300"
        />
        <CategorySection title={t('labelBrand')} items={brands} />
      </div>
      <ActionButtons />
    </div>
  );
}
