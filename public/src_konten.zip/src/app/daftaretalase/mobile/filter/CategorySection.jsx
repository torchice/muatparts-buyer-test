import * as React from "react";
import { useLanguage } from "@/providers/LanguageProvider";
import { CategoryItem } from "./CategoryItem";

export function CategorySection({ title, items }) {
  const { t } = useLanguage();

  return (
    <div className="flex flex-col w-full">
      <div className="flex gap-10 justify-between">
        <div className="text-black">{title}</div>
        <div className="text-[#176CF7]">{t('lihatSemua')}</div>
      </div>
      <div className="flex flex-row flex-wrap gap-2 mt-4 w-full font-medium text-black">
        {items.map((item, index) => (
          <CategoryItem key={index} name={item.name} />
        ))}
      </div>
    </div>
  );
}
