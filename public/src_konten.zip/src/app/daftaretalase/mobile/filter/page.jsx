"use client";
import React, { useState, useEffect } from 'react';
import { useCustomRouter } from '@/libs/CustomRoute';
import { MockServer_TambahEtalase } from '@/services/MockServer_TambahEtalase';
import { Loading } from '@/components/Loading/Loading';
import useFilterStore from '@/store/zustand/filterstore';
import { useLanguage } from "@/providers/LanguageProvider";
import ImageComponent from "@/components/ImageComponent/ImageComponent";
import Button from "@/components/Button/Button";

export default function FilterPage() {
  const { t } = useLanguage();
  const router = useCustomRouter();
  const { selectedFilters = {}, tempSelections = {}, setSelectedFilters, resetFilters, setTempSelections,lastActivity, setLastActivity } = useFilterStore();
  const [isLoading, setIsLoading] = useState(true);
  const [etalaseId, setEtalaseId] = useState('');

  const [categories, setCategories] = useState([]);
  const [brands, setBrands] = useState([]);
  //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0211, LB - 0138, LB - 0166
  const [tempSaveBrand,setTempSaveBrand] = useState(localStorage.getItem('tempSaveBrand'));
  const [tempSaveCategories,setTempSaveCategories] = useState(localStorage.getItem('tempSaveCategories'));

  // Local state for selections with null checks and default values
  //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0211, LB - 0138, LB - 0166, LB - 0229
  const [localCategoryIds, setLocalCategoryIds] = useState(
    tempSelections?.categories?.length > 0 || localStorage.getItem('tempSaveCategories') || (tempSelections?.categories?.length === 0 && localStorage.getItem('tempSaveBrand'))
      ? tempSelections.categories 
      : selectedFilters?.categories || []
  );

  const [localBrandIds, setLocalBrandIds] = useState(
    tempSelections?.brands?.length > 0 || localStorage.getItem('tempSaveBrand') || (tempSelections?.brands?.length === 0 && localStorage.getItem('tempSaveCategories'))
      ? tempSelections.brands 
      : selectedFilters?.brands || []
  );

  // Tambahkan state untuk menyimpan urutan
  const [filterOrder, setFilterOrder] = useState([]);

  // Tambahkan state untuk tracking urutan bubble
  const [selectedOrder, setSelectedOrder] = useState([]);

  // Add new states for bubble tracking
  const [activeBubbles, setActiveBubbles] = useState([]);
  const [selectedBubbles, setSelectedBubbles] = useState([]);

  // Add filterOptions at the top of the component
  const [filterOptions] = useState([
    'Kategori',
    'Brand'
  ]);

  // Tambahkan state untuk tracking filter yang aktif
  const [activeFilters, setActiveFilters] = useState({
    categories: selectedFilters?.categories || [],
    brands: selectedFilters?.brands || []
  });

  useEffect(() => {
    const fetchFilters = async () => {
      try {
        setIsLoading(true);
        // Get etalaseId from URL if present
        const urlParams = new URLSearchParams(window.location.search);
        const currentEtalaseId = urlParams.get('etalaseId');

        const [categoriesRes, brandsRes] = await Promise.all([
          MockServer_TambahEtalase.getCategoryFilter(
            '',  // search param
            currentEtalaseId // etalaseId param
          ),
          MockServer_TambahEtalase.getBrandFilter(
            '',  // search param
            currentEtalaseId // etalaseId param
          )
        ]);

        setCategories(categoriesRes.data.categories);
        setBrands(brandsRes.data.brands);
      } catch (error) {
        console.error('Error fetching filters:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchFilters();
  }, []);  // Remove etalaseId dependency since we're getting it from URL directly

  useEffect(() => {
    setTempSaveBrand(localStorage.getItem('tempSaveBrand'));
    setTempSaveCategories(localStorage.getItem('tempSaveCategories'));
    const params = new URLSearchParams(window.location.search);
    const id = params.get('etalaseId');
    if (id) setEtalaseId(id);
  }, []);

  // Load saved order on mount
  useEffect(() => {
    const savedOrder = localStorage.getItem('filterOrder');
    const savedFilters = localStorage.getItem('activeFilters');
    
    if (savedOrder && savedFilters) {
      setSelectedOrder(JSON.parse(savedOrder));
      setSelectedBubbles(JSON.parse(savedFilters));
      setActiveBubbles(JSON.parse(savedFilters));
    }
  }, []);

  useEffect(() => {
    console.log('Initial mount - Current states:', {
      selectedFilters,
      tempSelections,
      localCategoryIds,
      localBrandIds,
      activeFilters
    });
    console.log(tempSelections,'test bre')
    console.log('Initial localStorage:', {
      filterOrder: localStorage.getItem('filterOrder'),
      activeFilters: localStorage.getItem('activeFilters')
    });
  }, []);

  // Modifikasi handler untuk toggle kategori
  const toggleCategorySelection = (categoryId) => {
    setLocalCategoryIds(prev => {
      if (prev.includes(categoryId)) {
        // Jika sudah ada, hapus dari array
        return prev.filter(id => id !== categoryId);
      } else {
        // Jika belum ada, tambahkan di awal array
        return [categoryId, ...prev];
      }
    });
  };

  // Modifikasi handler untuk toggle brand 
  const toggleBrandSelection = (brandId) => {
    setLocalBrandIds(prev => {
      if (prev.includes(brandId)) {
        // Jika sudah ada, hapus dari array
        return prev.filter(id => id !== brandId);
      } else {
        // Jika belum ada, tambahkan di awal array
        return [brandId, ...prev];
      }
    });
  };

  // Modifikasi handler reset
  const handleReset = async () => {
    try {
      console.log(tempSelections,'tempSelections')
      console.log(selectedFilters,'selectedFilters')
      console.log(selectedFilters.brands.length,'selectedFilters')
      console.log(selectedFilters.categories.length,'selectedFilters')
      
      // Use Promise.all to handle multiple state updates concurrently
      await Promise.all([
        new Promise(resolve => {
            setTempSelections({
              categories: selectedFilters.categories,
              brands: selectedFilters.brands
            });
          resolve();
        }),
        new Promise(resolve => {
          if(selectedFilters.brands.length === 0) {
            setTempSelections({
              categories: selectedFilters.categories,
              brands: []
            });
          }
          resolve();
        }),
        new Promise(resolve => {
          if(selectedFilters.categories.length === 0) {
            setTempSelections({
              categories: [],
              brands: selectedFilters.brands
            });
          }
          resolve();
        }),
        new Promise(resolve => {
          if(selectedFilters.categories.length === 0 && selectedFilters.brands.length === 0) {
            setTempSelections({
              categories: [],
              brands: []
            });
          }
          resolve();
        }),
        //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0211, LB - 0138, LB - 0166
        new Promise(resolve => {
          setTempSaveBrand(false);
          setTempSaveCategories(false)
          localStorage.removeItem('tempSaveBrand', false);
          localStorage.removeItem('tempSaveCategories', false);
          resolve()
        })
      ]);
      console.log(tempSelections,'tempSelections after reset')
      console.log(selectedFilters,'selectedFilters after reset')
      // Navigate back after all state updates are complete
      router.back();
    } catch (error) {
      console.error('Error in handleReset:', error);
    }
  };

  // Modifikasi handler apply
  const handleApply = () => {
    const newFilters = {
      categories: localCategoryIds,
      brands: localBrandIds
    };
    setLastActivity('filter')
    //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0211, LB - 0138, LB - 0166
    setTempSaveBrand(false)
    setTempSaveCategories(false)
    localStorage.removeItem('tempSaveBrand', false);
    localStorage.removeItem('tempSaveCategories', false);
    
    // Set filters which will also update localStorage
    setSelectedFilters(newFilters);
    
    router.back();
  };

  const handleViewAllCategories = () => {
    setTempSelections({
      categories: localCategoryIds,
      brands: localBrandIds
    });
    
    const url = etalaseId 
      ? `/daftaretalase/mobile/filter/category?etalaseId=${etalaseId}`
      : '/daftaretalase/mobile/filter/category';
    router.push(url);
  };

  const handleViewAllBrands = () => {
    setTempSelections({
      categories: localCategoryIds,
      brands: localBrandIds
    });
    
    const url = etalaseId 
      ? `/daftaretalase/mobile/filter/brand?etalaseId=${etalaseId}`
      : '/daftaretalase/mobile/filter/brand';
    router.push(url);
  };

  // Helper function to get prioritized items
  const getPrioritizedItems = (items, selectedIds, limit = 5) => {
    const selectedItems = items.filter(item => selectedIds.includes(item.id));
    const unselectedItems = items.filter(item => !selectedIds.includes(item.id));
    
    if (selectedItems.length <= limit) {
      return [...selectedItems, ...unselectedItems].slice(0, limit);
    }
    
    // If more than limit items are selected, show only selected items up to limit
    return selectedItems.slice(0, limit);
  };

  const CategorySection = () => {
    // Ubah sortedCategories untuk menggunakan urutan dari localCategoryIds
    const sortedCategories = [...categories].sort((a, b) => {
      const aIndex = localCategoryIds.indexOf(a.id);
      const bIndex = localCategoryIds.indexOf(b.id);
      
      // Item yang tidak ada dalam localCategoryIds taruh di belakang
      if (aIndex === -1 && bIndex === -1) return 0;
      if (aIndex === -1) return 1;
      if (bIndex === -1) return -1;
      
      // Urutkan berdasarkan posisi di localCategoryIds
      return aIndex - bIndex;
    });

    const displayCategories = getPrioritizedItems(sortedCategories, localCategoryIds);
    const remainingSelectedCount = localCategoryIds.length > 5 ? localCategoryIds.length - 5 : 0;

    return (
      <>
        <div className="flex justify-between items-center px-5 py-3">
          <h2 className="text-sm font-semibold">Kategori</h2>
          <button 
            onClick={handleViewAllCategories}
            className="text-sm font-semibold text-[#176CF7]"
          >
            Lihat Semua
          </button>
        </div>
        <div className="flex flex-wrap gap-2 px-5">
          {displayCategories.map((category) => (
            <button
              key={category.id}
              onClick={() => toggleCategorySelection(category.id)}
              className={`
                px-3 py-2 text-sm font-medium rounded-3xl transition-colors 
                border border-solid max-w-full
                ${localCategoryIds.includes(category.id)
                  ? 'text-[#176CF7] bg-[#E2F2FF] border-[#176CF7]'
                  : 'text-gray-700 bg-[#F1F1F1] border-gray-200 hover:border-[#176CF7] hover:text-[#176CF7]'}
              `}
            >
              <span className="block text-left overflow-hidden overflow-ellipsis line-clamp-2 max-h-[40px]">{category.name}</span>
            </button>
          ))}
          {remainingSelectedCount > 0 && (
            <button
              onClick={handleViewAllCategories}
              className="px-3 py-2 text-sm font-medium rounded-3xl transition-colors border border-solid text-[#176CF7] bg-[#E2F2FF] border-[#176CF7]"
            >
              <span className="block truncate">+{remainingSelectedCount}</span>
            </button>
          )}
        </div>
      </>
    );
  };

  const BrandSection = () => {
    // Terapkan logika yang sama untuk brands
    const sortedBrands = [...brands].sort((a, b) => {
      const aIndex = localBrandIds.indexOf(a.id);
      const bIndex = localBrandIds.indexOf(b.id);
      
      if (aIndex === -1 && bIndex === -1) return 0;
      if (aIndex === -1) return 1;
      if (bIndex === -1) return -1;
      
      return aIndex - bIndex;
    });

    const displayBrands = getPrioritizedItems(sortedBrands, localBrandIds);
    const remainingSelectedCount = localBrandIds.length > 5 ? localBrandIds.length - 5 : 0;

    return (
      <>
        <div className="flex justify-between items-center px-5 py-3 mt-4">
          <h2 className="text-sm font-semibold">Brand</h2>
          <button 
            onClick={handleViewAllBrands}
            className="text-sm font-semibold text-[#176CF7]"
          >
            Lihat Semua
          </button>
        </div>
        <div className="flex flex-wrap gap-2 px-5">
          {displayBrands.map((brand) => (
            <button
              key={brand.id}
              onClick={() => toggleBrandSelection(brand.id)}
              className={`
                px-3 py-2 text-sm font-medium rounded-3xl transition-colors
                border border-solid max-w-full
                ${localBrandIds.includes(brand.id)
                  ? 'text-[#176CF7] bg-[#E2F2FF] border-[#176CF7]'
                  : 'text-gray-700 bg-[#F1F1F1] border-gray-200 hover:border-[#176CF7] hover:text-[#176CF7]'}
              `}
            >
              <span className="block text-left overflow-hidden overflow-ellipsis line-clamp-2 max-h-[40px]">{brand.name}</span>
            </button>
          ))}
          {remainingSelectedCount > 0 && (
            <button
              onClick={handleViewAllBrands}
              className="px-3 py-2 text-sm font-medium rounded-3xl transition-colors border border-solid text-[#176CF7] bg-[#E2F2FF] border-[#176CF7]"
            >
              <span className="block truncate">+{remainingSelectedCount}</span>
            </button>
          )}
        </div>
      </>
    );
  };

  const handleBubbleClick = (bubble) => {
    setSelectedBubbles(prev => {
      if (prev.includes(bubble)) {
        // Remove bubble if already selected
        const newSelected = prev.filter(b => b !== bubble);
        // Update order
        setSelectedOrder(curr => curr.filter(b => b !== bubble));
        return newSelected;
      } else {
        // Add to beginning of array if newly selected
        const newSelected = [bubble, ...prev];
        // Update order
        setSelectedOrder(curr => [bubble, ...curr]);
        return newSelected;
      }
    });
  };

  const renderOrderedBubbles = () => {
    return selectedOrder.map((bubble, index) => (
      <button
        key={index}
        onClick={() => handleBubbleClick(bubble)}
        className={`px-4 py-2 rounded-full border ${
          selectedBubbles.includes(bubble) 
            ? 'bg-blue-500 text-white' 
            : 'bg-white text-gray-700'
        }`}
      >
        {bubble}
      </button>
    ));
  };

  return (
    <div className="flex flex-col mx-auto bg-[#FCFCFC] w-full max-w-[480px] h-screen">
      <header className="fixed top-0 left-0 right-0 z-10 flex items-center p-4 bg-white shadow-md justify-between max-w-[480px] mx-auto">
        <button 
          // onClick={() => router.back()}
          onClick={handleReset}
          className="p-2"
        >
          <ImageComponent
            src="/icons/etalase/closes.svg"
            alt={t('labelKembali')}
            width={16}
            height={16}
            className="w-4 h-4"
          />
        </button>
        <h1 className="text-lg font-semibold">{t('labelFilter')}</h1>
        <button 
          className="p-2 opacity-0"
        >
          <ImageComponent
            src="/icons/etalase/closes.svg"
            alt={t('labelKembali')}
            width={16}
            height={16}
            className="w-4 h-4"
          />
        </button>
      </header>

      <div className="flex-1 overflow-y-auto pt-[72px] pb-24"> {/* Added padding-top to account for fixed header */}
        <CategorySection />
        <div className="h-px bg-gray-200 mx-5 my-4" />
        <BrandSection />
        {/* <div className="flex flex-wrap gap-2 p-4">
          {renderOrderedBubbles()}
          {filterOptions
            .filter(option => !selectedOrder.includes(option))
            .map((option) => (
              <Button
                key={option}
                onClick={() => handleBubbleClick(option)}
                className={`px-4 py-2 rounded-full border ${
                  selectedBubbles.includes(option) 
                    ? 'bg-blue-500 text-white' 
                    : 'bg-white text-gray-700'
                }`}
              >
                {option}
              </Button>
            ))}
        </div> */}
      </div>

      <div class="fixed bottom-0 left-0 right-0 p-4 bg-white border-t max-w-[480px] mx-auto">
        <div class="flex gap-3">
          <Button
            onClick={handleReset}
            // onClick={() => router.back()}
            color="primary_secondary"
            Class="flex-1 py-4 text-[#176CF7] bg-white border border-blue-600 rounded-full font-semibold sm:max-w-full"
          >
            {t('labelBatal')} {/* Keep as 'labelBatal' since it's now used to cancel/close */}
          </Button>
          <Button
            onClick={handleApply}
            color="primary"
            Class="flex-1 py-4 text-white bg-blue-600 rounded-full font-semibold sm:max-w-full"
          >
            {t('labelSimpan')}
          </Button>
        </div>
      </div>
    </div>
  );
}