import * as React from "react";
import { useLanguage } from "@/providers/LanguageProvider";
import ImageComponent from "@/components/ImageComponent/ImageComponent";

const CategoryItem = ({ icon, title, type }) => {
  const { t } = useLanguage();

  if (type === "checkbox") {
    return (
      <div className="flex gap-2 items-center pb-3 mt-3 w-full border-b border-solid border-b-stone-300">
        <div className="flex flex-col self-stretch my-auto w-4">
          <input
            type="checkbox"
            id={title}
            className="flex shrink-0 w-4 h-4 rounded border border-solid border-neutral-500"
            aria-label={t('labelPilihKategori')}
          />
        </div>
        <label
          htmlFor={title}
          className="self-stretch my-auto text-sm font-semibold leading-none text-black"
        >
          {t(title)}
        </label>
      </div>
    );
  }

  return (
    <div className="flex gap-2 items-center pb-3 w-full text-sm font-semibold leading-none text-black whitespace-nowrap border-b border-solid border-b-stone-300">
      <ImageComponent
        src={icon}
        alt={t('labelKategori')}
        width={16}
        height={16}
        className="object-contain shrink-0 self-stretch my-auto aspect-square"
      />
      <div className="self-stretch my-auto">{t(title)}</div>
    </div>
  );
};

export default CategoryItem;
