"use client";
import * as React from "react";
import { useLanguage } from "@/providers/LanguageProvider";
import SearchBar from "./SearchBar";
import CategoryItem from "./CategoryItem";
import ActionButtons from "./ActionButtons";

const CategoryFilter = () => {
  const { t } = useLanguage();

  const categories = [
    {
      id: 1,
      icon: "https://cdn.builder.io/api/v1/image/assets/60cdcdaf919148d9b5b739827a6f5b2a/a6712a94f394f062366747f78b2eddead853e57ba37f8171793b98ec1049a902?apiKey=60cdcdaf919148d9b5b739827a6f5b2a&",
      title: t('labelKategori'),
      type: "header",
    },
    {
      id: 2,
      title: "Sistem Pengereman",
      type: "checkbox",
    },
    {
      id: 3,
      title: "General",
      type: "checkbox",
    },
    {
      id: 4,
      icon: "https://cdn.builder.io/api/v1/image/assets/60cdcdaf919148d9b5b739827a6f5b2a/be5033906a28a577c3809c3809f6e26149a7f77be7b3cfb79b996afe7f5d5a59?apiKey=60cdcdaf919148d9b5b739827a6f5b2a&",
      title: "Mesin",
      type: "header",
    },
    {
      id: 5,
      icon: "https://cdn.builder.io/api/v1/image/assets/60cdcdaf919148d9b5b739827a6f5b2a/99e8744d35d57259c6e7c8682b8f69f7457082110609967fc3dd8d72fdcd2707?apiKey=60cdcdaf919148d9b5b739827a6f5b2a&",
      title: "Roda dan Ban",
      type: "header",
    },
  ];

  return (
    <div className="flex flex-col mx-auto w-full max-w-[480px]">
      <div className="flex overflow-hidden flex-col bg-zinc-50 shadow-[0px_4px_4px_rgba(0,0,0,0.25)]">
        <SearchBar />
        <div className="flex flex-col self-center px-5 mt-5 w-full">
          {categories.map((category) => (
            <CategoryItem key={category.id} {...category} />
          ))}
        </div>
        <ActionButtons />
      </div>
    </div>
  );
};

export default CategoryFilter;
