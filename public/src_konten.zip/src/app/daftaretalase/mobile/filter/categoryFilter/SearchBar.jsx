import * as React from "react";
import { useLanguage } from "@/providers/LanguageProvider";

const SearchBar = () => {
  const { t } = useLanguage();

  return (
    <div className="flex flex-col items-center">
      <div className="flex gap-2 items-center">
        <input
          type="search"
          placeholder={t('cariKategori')}
          aria-label={t('cariKategori')}
          className="self-stretch my-auto bg-transparent"
        />
      </div>
    </div>
  );
};

export default SearchBar;
