import * as React from "react";
import { useLanguage } from "@/providers/LanguageProvider";
import Button from "@/components/Button/Button";
const ActionButtons = () => {
  const { t } = useLanguage();

  return (
    <div className="flex flex-col mt-96 w-full">
      <div className="flex gap-2 justify-center">
        <button className="gap-1 self-stretch px-6 py-4 text-[#176CF7]">
          {t('labelReset')}
        </button>
        <button className="gap-1 self-stretch px-6 py-4 text-white">
          {t('labelTerapkan')}
        </button>
      </div>
    </div>
  );
};

export default ActionButtons;
