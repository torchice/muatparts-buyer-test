import * as React from "react";
import ImageComponent from "@/components/ImageComponent/ImageComponent";
import { useTranslation } from "@/context/TranslationProvider";

export const SearchBar = () => {
  // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0867
  const { tOrEmpty } = useTranslation();
  
  return (
    <div className="flex overflow-hidden flex-col p-4 w-full leading-none bg-white">
      <div className="flex gap-2 items-center px-3 py-2 w-full text-sm font-semibold bg-white rounded-md border border-solid border-neutral-500 min-h-[32px] text-neutral-500">
        <ImageComponent
          loading="lazy"
          src="https://cdn.builder.io/api/v1/image/assets/60cdcdaf919148d9b5b739827a6f5b2a/a5279daa22dacb6f25727c2884147c3ee2201ef302b416c8a74ce6acff27fc32?apiKey=60cdcdaf919148d9b5b739827a6f5b2a&"
          alt="Search icon"
          className="object-contain shrink-0 self-stretch my-auto w-4 aspect-square"
        />
        <label htmlFor="searchInput" className="sr-only">
          {tOrEmpty("cariNamaProdukSKU")}
        </label>
        <input
          id="searchInput"
          type="search"
          placeholder={tOrEmpty("cariNamaProdukSKU")}
          className="flex-1 shrink self-stretch my-auto basis-0 bg-transparent border-none outline-none"
        />
      </div>
    </div>
  );
};
