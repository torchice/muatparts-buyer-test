import * as React from "react";
import { useLanguage } from "@/providers/LanguageProvider";
import ImageComponent from "@/components/ImageComponent/ImageComponent";
import Button from "@/components/Button/Button";

export const ShowcaseItem = ({ title, image, products, sales, special }) => {
  const { t } = useLanguage();

  return (
    <div className="flex flex-col mt-2 w-full">
      <div className="flex overflow-hidden gap-4 px-4 py-3 w-full bg-white">
        {special ? (
          <ImageComponent
            src={image}
            alt={title}
            width={56}
            height={56}
            className="object-contain shrink-0 self-start rounded aspect-square"
          />
        ) : (
          <div className="flex overflow-hidden flex-col justify-center items-center self-start w-14 h-14 bg-blue-900 rounded-md">
            <ImageComponent
              src={image}
              alt={title}
              width={68}
              height={56}
              className="object-contain aspect-[1.21]"
            />
          </div>
        )}
        <div className="flex flex-col flex-1 shrink justify-center text-sm leading-none text-black basis-0 min-w-[240px]">
          <div className="font-bold">{title}</div>
          <div className="flex gap-2 items-start mt-3 font-medium">
            <div className="flex gap-1 items-center">
              <ImageComponent
                src="/icons/product.png"
                alt=""
                width={16}
                height={16}
                className="object-contain shrink-0 self-stretch my-auto aspect-square"
              />
              <div className="self-stretch my-auto">{t('labelProduk')} {products}</div>
            </div>
            <div className="flex gap-1 items-center">
              <ImageComponent
                src="/icons/sales.png"
                alt=""
                width={16} 
                height={16}
                className="object-contain shrink-0 self-stretch my-auto aspect-square"
              />
              <div className="self-stretch my-auto">{t('labelTerjual')} {sales}</div>
            </div>
          </div>
        </div>
      </div>
      <div className="flex flex-col justify-center px-4 pb-3 w-full text-xs font-semibold leading-none whitespace-nowrap bg-white">
        <div className="flex gap-2 items-start w-full">
          <Button 
          color="error_secondary"
          Class="flex-1 shrink gap-1 self-stretch px-6 py-2.5 text-red-500 bg-white rounded-3xl border border-red-500 border-solid min-h-[28px] min-w-[112px]">
            Hapus
          </Button>
          <Button 
          color="primary_secondary"
          Class="flex-1 shrink gap-1 self-stretch px-6 py-2.5 text-[#176CF7] bg-white rounded-3xl border border-blue-600 border-solid min-h-[28px] min-w-[112px]">
            Ubah
          </Button>
        </div>
      </div>
    </div>
  );
};
