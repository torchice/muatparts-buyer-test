"use client";
import { CropperPage } from '../../components/mediaUpload/image-cropper-flow';

export default function CropperPageContainer() {
  // Get stored image from localStorage
  const imageFile = new File(
    [localStorage.getItem('selectedImage')], 
    localStorage.getItem('selectedImageName')
  );
  
  return <CropperPage imageFile={imageFile} />;
}