"use client";
import { AfterCropPage } from '../../components/mediaUpload/image-cropper-flow';

export default function AfterCropContainer() {
  return <AfterCropPage />;
}