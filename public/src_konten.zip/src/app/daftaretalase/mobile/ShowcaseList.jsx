import { useEffect } from 'react';
import useEtalaseStore from '@/store/zustand/etalasestore';
import { Loading } from '@/components/Loading/Loading';
import ImageComponent from "@/components/ImageComponent/ImageComponent";

export const ShowcaseList = () => {
  const { etalaseList, isLoading, error, fetchEtalaseList } = useEtalaseStore();
  
  useEffect(() => {
    fetchEtalaseList();
  }, []);

  // if (isLoading) return <Loading />;
  if (error) return <div className="p-4 text-red-500">{error}</div>;
  
  return (
    <div className="flex flex-col gap-4 p-4">
      {etalaseList.map((etalase) => (
        <div 
          key={etalase.id}
          className="flex items-center justify-between p-4 bg-white rounded-lg shadow"
        >
          <div className="flex items-center gap-4">
            <ImageComponent 
              src={etalase.imageUrl || '/placeholder.png'} 
              alt={etalase.name}
              className="w-16 h-16 rounded-lg object-cover"
            />
            <div>
              <h3 className="font-semibold">{etalase.name}</h3>
              <p className="text-sm text-[#7b7b7b]">
                {etalase.totalProducts} Produk
              </p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};
