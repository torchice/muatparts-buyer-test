// THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase 
// LB - 0157
// LB - 0158
// LB - 0167
'use client';


import React, { useState, useEffect } from 'react';
import { useCustomRouter } from '@/libs/CustomRoute';
import useEtalaseStore from '@/store/zustand/etalasestore';
import { Loading } from '@/components/Loading/Loading';
import DeleteShowcaseModal from './components/DeleteShowcaseModal';
import BottomNavigation from './BottomNavigation';
import { EmptyEtalase } from './add/EmptyEtalase';
import { Header } from './components/Header';
import { useLanguage} from "@/providers/LanguageProvider";
import DaftarEtalaseSvg from '@/icons/Daftar Etalase.svg';
import Image from 'next/image';
import Toast from '@/components/Toast/Toast';
import toast from "@/store/zustand/toast";
import ImageComponent from "@/components/ImageComponent/ImageComponent";
import CustomLink from "@/components/CustomLink";
import { KeywordNotFoundMessage } from "./components/keywordNotFoundMessage";
import Button from "@/components/Button/Button";
import useFilterStore from '@/store/zustand/filterstore';




const formatNumber = (num) => {
  return num?.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
};
//24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0226
const SkeletonLoader = () => {
  return (
    <div className="flex flex-col mt-2 w-full gap-2">
      {[1, 2, 3].map((item) => (
        <div key={item} className="animate-pulse">
          <div className="flex flex-col w-full">
            <div className="flex overflow-hidden gap-4 px-4 py-3 w-full bg-white">
              {/* Image skeleton */}
              <div className="bg-gray-200 w-14 h-14 rounded-md shrink-0"></div>
              
              <div className="flex flex-col flex-1 shrink justify-center gap-2">
                {/* Title skeleton */}
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                
                {/* Stats skeleton */}
                <div className="flex gap-2 items-start mt-3">
                  <div className="flex gap-1 items-center w-full">
                    <div className="w-4 h-4 bg-gray-200 rounded"></div>
                    <div className="h-4 bg-gray-200 rounded w-20"></div>
                  </div>
                  <div className="flex gap-1 items-center w-full">
                    <div className="w-4 h-4 bg-gray-200 rounded"></div>
                    <div className="h-4 bg-gray-200 rounded w-20"></div>
                  </div>
                </div>
              </div>
            </div>

            {/* Action buttons skeleton */}
            <div className="flex flex-col justify-center px-4 pb-3 w-full bg-white">
              <div className="flex gap-2 items-start w-full">
                <div className="flex-1 h-7 bg-gray-200 rounded-3xl"></div>
                <div className="flex-1 h-7 bg-gray-200 rounded-3xl"></div>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

const ShowcaseLayout = () => {
  const router = useCustomRouter();
  const [searchQuery, setSearchQuery] = useState('');
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [selectedId, setSelectedId] = useState(null);
  const { t, currentLocale, changeLanguage, loading: langLoading } = useLanguage();
  const [isSearchMode, setIsSearchMode] = useState(false);
  
  const { 
    etalaseList, 
    isLoading, 
    error, 
    fetchEtalaseList,
    deleteEtalase,
    maxEtalase,
    totalEtalase
  } = useEtalaseStore();

  const { showToast, setShowToast, setDataToast } = toast();

  useEffect(() => {
    fetchEtalaseList();
    localStorage.removeItem('etalaseSourceRoute')
    useFilterStore.getState().resetFilters();
    //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0150, LB - 0156
    const toastBol = localStorage.getItem('showToast');
    const toastMessage = localStorage.getItem('toastMessage');
    const toastType = localStorage.getItem('toastType');
    if(toastBol){
      setDataToast({
        type: toastType,
        message: toastMessage
      });
      setShowToast(true);
      localStorage.removeItem('showToast');
      localStorage.removeItem('toastMessage');
      localStorage.removeItem('toastType');
    }
   
  }, []);

  const handleSearch = async (query) => {
    setSearchQuery(query);
    setIsSearchMode(true);
    try {
      await fetchEtalaseList(query);
    } catch (error) {
      setDataToast({
        type: 'error',
        message: 'Gagal melakukan pencarian'
      });
      setShowToast(true);
    }
  };

  const handleClearSearch = () => {
    setSearchQuery('');
    if (isSearchMode) {
      handleSearch('');
      setIsSearchMode(false);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') {
      handleSearch(searchQuery); // Pass the searchQuery as parameter
    }
  };

  const handleDeleteClick = (id) => {
    setSelectedId(id);
    setShowDeleteModal(true);
  };

  const handleConfirmDelete = async () => {
    try {
      await deleteEtalase(selectedId);
      setShowDeleteModal(false);
      setDataToast({
        type: 'success',
        message: 'Berhasil menghapus etalase'
      });
      setShowToast(true);
      await fetchEtalaseList();
    } catch (error) {
      setDataToast({
        type: 'error',
        message: 'Gagal menghapus etalase'
      });
      setShowToast(true);
    }
  };

  const navigateToAdd = () => {
    // Clear all data when starting fresh
    localStorage.removeItem('etalaseFormData');
    localStorage.removeItem('selectedProducts');
    localStorage.removeItem('tempProducts');
    localStorage.removeItem('returningFromPilihProduk');
    localStorage.removeItem('returningFromSusunProduk');
    router.push('/daftaretalase/mobile/add');
  };

  const navigateToEdit = (id) => router.push(`/daftaretalase/mobile/edit/${id}`);
  const navigateToSort = () => router.push('/daftaretalase/mobile/susunetalase');
  const navigateToDetail = (id) => router.push(`/daftaretalase/mobile/detail/${id}`);
  const goBack = () => router.back();

  return (
    <div className="flex flex-col mx-auto w-full max-w-[480px] h-screen">
      <div className="flex flex-col bg-white h-full overflow-auto ">
        {/* Header */}
        {/* 24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0139 */}
          <Header 
          title={t('daftarEtalase')}
          showArrangeIcon={etalaseList.length > 0 && !(etalaseList.length === 1 && etalaseList[0].id === 'all-products')}
          onArrangeClick={() => navigateToSort()}
          onBack={() =>router.push(`/dashboard`)}
              />

          {/* Search */}
        <div className="flex overflow-hidden flex-col p-4 w-full leading-none bg-white">
          <div className="relative flex gap-2 items-center px-3 py-2 w-full text-sm font-semibold bg-white rounded-md border border-solid border-neutral-500 min-h-[32px] text-neutral-500 focus-within:border-[#176CF7] transition-colors">
            {/* Search Icon */}
            <div className="absolute left-3 top-1/2 -translate-y-1/2">
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M7.33333 12.6667C10.2789 12.6667 12.6667 10.2789 12.6667 7.33333C12.6667 4.38781 10.2789 2 7.33333 2C4.38781 2 2 4.38781 2 7.33333C2 10.2789 4.38781 12.6667 7.33333 12.6667Z" stroke="#666666" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M14 14L11 11" stroke="#666666" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={t('cariNamaEtalase')}
              className="flex-1 shrink self-stretch my-auto basis-0 bg-transparent border-none outline-none text-sm font-semibold text-[#000] pl-7"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={handleClearSearch}
                className="flex shrink-0 items-center justify-center w-4 h-4"
              >
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M13 1L1 13" stroke="#999999" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M1 1L13 13" stroke="#999999" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </button>
            )}
          </div>
        </div>

        {/* Stats */}
        <div className="flex gap-10 justify-between px-4 py-2 bg-white text-xs font-medium text-black w-full">
          <div className="text-ellipsis whitespace-nowrap">{totalEtalase} {t('labelEtalase')}</div>
          <div>({t('etalaseMaks').replace('{count}', formatNumber(maxEtalase))})</div>
        </div>

        {/* List */}
        <main className="flex-1 bg-gray-100 overflow-auto">
          {isLoading ? (
            <SkeletonLoader />
          ) : error ? (
            <div className="p-4 text-red-500 text-center" role="alert">{error}</div>
          ) : etalaseList.length === 0 ? (
            <div className="h-full flex items-center justify-center">
              <KeywordNotFoundMessage customParentClass={'items-center'} customClass={'absolute top-[45%]'}/>
              {/* <div className="flex flex-col items-center justify-center p-8">
                <ImageComponent
                  src="/icons/etalase/search-not-found.png"
                  alt=""
                  width={128}
                  height={128}
                  className="mb-4"
                />
                <p className="text-[#7b7b7b] text-center">
                  {t('keywordTidakDitemukan')}
                </p>
              </div> */}
            </div>
          ) : (
            <div className="flex flex-col mt-2 w-full gap-2">
              {etalaseList.map((etalase, index) => (
                <div 
                key={etalase.id}
                onClick={() => navigateToDetail(etalase.id)}
                className={`cursor-pointer ${index === etalaseList.length - 1 ? 'pb-[120px]' : ''}`}
                >
                <div className="flex flex-col w-full">
                  <div className="flex overflow-hidden gap-4 px-4 py-3 w-full bg-white">
                  {etalase.isDefault ? (
                    <ImageComponent
                    src='/icons/etalase/semua_produk.png'
                    alt={etalase.name}
                    className="object-cover shrink-0 self-start w-14 rounded-md aspect-square"
                    />
                  ) : etalase.imageUrl ? (
                    <ImageComponent
                    src={etalase.imageUrl}
                    alt={etalase.name}
                    width={56}
                    height={56}
                    className="object-cover shrink-0 self-start rounded-md aspect-square"
                    />
                  ) : (
                    <div className="flex overflow-hidden flex-col justify-center items-center self-start w-14 h-14 bg-white rounded-md">
                    <ImageComponent
                      src='/icons/etalase/Daftar Etalase.svg'
                      alt=""
                      width={68}
                      height={56}
                      className="object-contain aspect-[1.21] w-[68px]"
                      aria-hidden="true"
                    />
                    </div>
                  )}
                  {/*// THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase  LB - 0154 */}
                  <div className="flex flex-col flex-1 shrink justify-center text-sm leading-none text-black basis-0 min-w-[240px]">
                    <div className="font-bold line-clamp-2">{etalase.name}</div>
                    <div className="flex gap-2 items-start mt-3 font-medium">
                    <div className="flex gap-1 items-center w-full">
                      <ImageComponent
                      loading="lazy"
                      src="/icons/etalase/keranjang.svg"
                      alt=""
                      className="object-contain shrink-0 self-stretch my-auto w-4 aspect-square"
                      />
                      <div className="self-stretch my-auto">
                      {t('labelProduk')} {formatNumber(etalase.totalProducts)}
                      </div>
                    </div>
                    <div className="flex gap-1 items-center w-full">
                      <ImageComponent
                      loading="lazy"
                      src="/icons/etalase/roll.svg"
                      alt=""
                      className="object-contain shrink-0 self-stretch my-auto w-4 aspect-square"
                      />
                      <div className="self-stretch my-auto">
                      {t('labelTerjual')} {formatNumber(etalase.totalSold)}
                      </div>
                    </div>
                    </div>
                  </div>
                  </div>
                  {!etalase.isDefault && (
                  <div className="flex flex-col justify-center px-4 pb-3 w-full text-xs font-semibold leading-none whitespace-nowrap bg-white">
                    <div className="flex gap-2 items-start w-full">
                    <Button
                      onClick={(e) => {
                      e.stopPropagation();
                      handleDeleteClick(etalase.id);
                      }}
                      color="error_secondary"
                      Class="flex-1 shrink gap-1 self-stretch px-6 py-2.5 text-red-500 bg-white rounded-3xl border border-red-500 border-solid min-h-[28px] min-w-[112px] sm:max-w-full"
                    >
                      {t('labelHapus')}
                    </Button>
                    <Button
                      onClick={(e) => {
                      e.stopPropagation();
                      navigateToEdit(etalase.id);
                      }}
                      color="primary_secondary"
                      Class="flex-1 shrink gap-1 self-stretch px-6 py-2.5 text-[#176CF7] bg-white rounded-3xl border border-blue-600 border-solid min-h-[28px] min-w-[112px] sm:max-w-full"
                    >
                      {t('labelUbah')}
                    </Button>
                    </div>
                  </div>
                  )}
                </div>
                </div>
              ))}
              </div>
            )}
          </main>
          </div>

          {/* Modals */}
      <DeleteShowcaseModal
        isOpen={showDeleteModal}
        onClose={() => setShowDeleteModal(false)}
        onConfirm={handleConfirmDelete}
      />

      {/* Toast - Updated positioning */}
      <div className="fixed bottom-24 left-0 right-0 flex justify-center pointer-events-none z-40">
        <Toast />
      </div>

      {/* Updated BottomNavigation z-index */}
      <div className="fixed bottom-0 left-0 right-0 z-10">
        <BottomNavigation />
      </div>
    </div>
  );
};

export default ShowcaseLayout;