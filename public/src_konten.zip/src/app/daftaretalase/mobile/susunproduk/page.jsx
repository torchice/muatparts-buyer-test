// 24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase
// LB - 0156
// LB - 0193
// LB - 0196

"use client";

import React, { useState, useEffect } from 'react';
import { useCustomRouter } from '@/libs/CustomRoute';
import { ChevronLeft, Info } from 'lucide-react';
import dynamic from 'next/dynamic';
import CustomModal from '@/components/Modal/CustomModal';
import ImageComponent from "@/components/ImageComponent/ImageComponent";
import Button from "@/components/Button/Button";



// Dynamically import drag and drop components with SSR disabled
const DragDropContext = dynamic(
  () => import('react-beautiful-dnd').then(mod => mod.DragDropContext),
  { ssr: false }
);
const Droppable = dynamic(
  () => import('react-beautiful-dnd').then(mod => mod.Droppable),
  { ssr: false }
);
const Draggable = dynamic(
  () => import('react-beautiful-dnd').then(mod => mod.Draggable),
  { ssr: false }
);

import useSusunProdukStore from '@/store/susunProdukStore';
import Toast from '@/components/Toast/Toast';
import { useLanguage } from "@/providers/LanguageProvider";
import Bottomsheet from "@/components/Bottomsheet/Bottomsheet";
import to_ast  from "@/store/zustand/toast";
//24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0226
const SkeletonLoader = () => {
  return (
    <div className="flex flex-col w-full gap-2 mt-[62px]">
      {[1, 2, 3, 4].map((item) => (
        <div key={item} className="animate-pulse">
          <div className="flex overflow-hidden gap-[12px] items-center px-4 py-3 w-full bg-white">
            <div className="flex-1 flex items-start gap-[12px]">
              {/* Image skeleton */}
              <div className="w-14 h-14 bg-gray-200 rounded-md" style={{minWidth:'56px'}}></div>
              
              <div className="flex flex-col gap-[12px] flex-1">
                {/* Title skeleton */}
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                
                {/* Price skeleton */}
                <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                
                {/* SKU, Brand, Category skeletons */}
                <div className="h-4 bg-gray-200 rounded w-1/3"></div>
                <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                <div className="h-4 bg-gray-200 rounded w-2/5"></div>
              </div>
            </div>
            
            {/* Drag handle skeleton */}
            <div className="w-6 h-6 bg-gray-200 rounded"></div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default function SusunProdukPage() {
  const { t } = useLanguage();
  const router = useCustomRouter();
  const { products, reorderProducts } = useSusunProdukStore();
  const [tempProducts, setTempProducts] = useState([...products]); // Add temporary state
  const [isLoading, setIsLoading] = useState(false);
  const [toast, setToast] = useState({
    show: false,
    status: 'success',
    text: ''
  });
  // const [showBottomsheet, setShowBottomsheet] = useState(false);
  const [showLeaveModal, setShowLeaveModal] = useState(false);
  const {
      showToast,
      dataToast,
      setShowToast,
      setDataToast,
      setShowBottomsheet,
      dataBottomsheet,
    } = to_ast();

  // Add validation check for products
  useEffect(() => {
    console.log('Initial products:', products);
    if (!Array.isArray(products) || products.length === 0) {
      router.back();
      return;
    }
  }, []);

  // Add debug logging
  useEffect(() => {
    console.log('Current products in store:', products);
  }, [products]);

  // Keep track of original products order
  const [originalProducts] = useState([...products]);

  // Simplified reorder function
  const reorder = (list, startIndex, endIndex) => {
    const result = Array.from(list);
    const [removed] = result.splice(startIndex, 1);
    result.splice(endIndex, 0, removed);
    return result;
  };

  // Update onDragEnd to use temporary state
  const onDragEnd = (result) => {
    if (!result.destination) return;
    
    const sourceProduct = tempProducts[result.source.index];
    const destinationProduct = tempProducts[result.destination.index];
    
    if (sourceProduct.stock === 0 || destinationProduct.stock === 0) {
      return;
    }

    const reorderedItems = reorder(
      tempProducts,
      result.source.index,
      result.destination.index
    );

    setTempProducts(reorderedItems); // Update temporary state instead of store
  };

  const handleSave = () => {
    setIsLoading(true);
    try {
      reorderProducts(tempProducts); // Only update store when saving
      console.log('reorderProduct', tempProducts);
      setToast({
        show: true,
        status: 'success',
        text: t('berhasilMenyusunUrutanProduk')
      });

      setTimeout(() => {
        router.back();
      }, 1500);
    } catch (error) {
      setToast({
        show: true,
        status: 'error',
        text: t('gagalMenyusunUrutanProduk')
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleBack = () => {
    // Check if we came from edit page
    const fromEdit = localStorage.getItem('editEtalaseId');
    const returnToPage = localStorage.getItem('returnToPage');
    
    // Show confirmation modal in any case
    setShowLeaveModal(true);
  };

  // Update renderProduct function with new styling
  const renderProduct = (product, provided, snapshot, index ) => {
    if (!product || typeof product !== 'object') {
      console.error('Invalid product:', product);
      return null;
    }

    return (
      <div
      ref={provided.innerRef}
      {...provided.draggableProps}
      className={`flex overflow-hidden z-0 gap-[12px] items-center px-4 py-3 w-full bg-white 
      ${index > 0 ? "mt-2" : ""}
      ${snapshot.isDragging ? "shadow-lg bg-blue-50" : ""}
      ${index === (tempProducts.length-1)?"mb-[75px]":""}
      `}
      >
        {/*24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB -  LB - 0223 */}
      <div className="flex-1 flex items-start gap-[12px]">
        {/*24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0212 */}
      <div className="w-14 h-14 rounded-md overflow-hidden"  style={{minWidth:'56px'}}>
      <ImageComponent
        src={product.imageUrl || '/images/placeholder.png'}
        alt={product.name || 'Product image'}
        width={56}
        height={56}
        className="w-full h-full object-cover"
        style={{minWidth:'56px'}}
      />
      </div>
      <div className="flex flex-col gap-[12px]">
      <div className="text-base font-bold leading-4 line-clamp-2">{product.name || 'Unnamed Product'}</div>
      <span className="text-[#000000] text-sm font-semibold">
        {product.price?.min === product.price?.max ? 
        `Rp${product.price?.min?.toLocaleString('id-ID')}` :
        `Rp${product.price?.min?.toLocaleString('id-ID')} - Rp${product.price?.max?.toLocaleString('id-ID')}`
        }
      </span>
      {/*24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0224 */}
      <div className="text-[12px]  line-clamp-1 break-all font-medium text-[#000]">SKU: {product.sku || '-'}</div>
      <div className="text-[12px] line-clamp-1 break-all font-medium text-[#000]">Brand: {product.brand || '-'}</div>
      <div className="text-[12px] line-clamp-1 break-all font-medium text-[#000]">Kategori: {(product.category && typeof product.category === 'object') ? product.category.name : (product.category || '-')}</div>
      </div>
      </div>
      <div {...provided.dragHandleProps} className={`w-6 cursor-move ${product.stock === 0?'opacity-50':''}`}>
      <ImageComponent
      src="/icons/etalase/mobile/drag-item-grey.svg"
      alt={t('labelGeser')}
      width={24}
      height={24}
      className="object-contain shrink-0 self-stretch my-auto aspect-square"
      />
      </div>
      </div>
    );
  };

  const onDragStart = (event, id) => {
    // Check if item has stock before allowing drag
    const item = products.find(item => item.id === id);
    if (item && item.stock === 0) {
      event.preventDefault(); // Prevent dragging if stock is 0
      return;
    }
    event.dataTransfer.setData('text/plain', id);
  };

  // Update the DragDropContext section
  return (
    <div className="flex flex-col h-screen w-full  relative">
      {/* Header - Fixed at top */}
      <div className="flex overflow-hidden relative gap-2.5 items-start px-4 py-3.5 bg-red-700 shadow-lg min-h-[62px] fixed top-0 left-0 right-0 z-50">
        <div className="flex z-10 gap-2 items-center min-h-[34px] min-w-[240px] w-[328px]">
          <div className="flex flex-col self-stretch my-auto w-6">
            <div 
              onClick={handleBack}
              className="flex shrink-0 w-6 h-6 bg-white rounded-xl"
            >
              <ChevronLeft className="w-6 h-6 text-red-700" />
            </div>
          </div>
          <div className="gap-4 self-stretch my-auto text-base font-bold text-white">
            {t('susunProduk')}
          </div>
          <div 
            className="flex shrink-0 self-stretch my-auto w-4 h-4"
            onClick={() => setShowBottomsheet(true)}
          >
            <Info className="w-4 h-4 text-white" />
          </div>
        </div>
        <ImageComponent
          src="/icons/etalase/mobile/header-pattern.png"
          alt=""
          width={153}
          height={62}
          className="object-contain absolute right-0 bottom-0 z-0 shrink-0 aspect-[2.47]"
        />
      </div>
  
      {/* Content - Scrollable area */}
      <div className="flex flex-col w-full overflow-y-auto  pb-[75px]">
        {isLoading ? (
          <SkeletonLoader />
        ) : !Array.isArray(products) ? (
          <div className="flex justify-center items-center h-40">
            <p>{t('memuat')}</p>
          </div>
        ) : products.length > 0 ? (
          <DragDropContext onDragEnd={onDragEnd}>
            <Droppable droppableId="droppable" touchAction="manipulation">
              {(provided, snapshot) => (
                <div
                  {...provided.droppableProps}
                  ref={provided.innerRef}
                  className="flex flex-col w-full"
                >
                  {tempProducts.map((product, index) => (
                    <Draggable
                      key={product.id?.toString() || index}
                      draggableId={product.id?.toString() || `product-${index}`}
                      index={index}
                      isDragDisabled={product.stock === 0}
                    >
                      {(provided, snapshot) => renderProduct(product, provided, snapshot, index)}
                    </Draggable>
                  ))}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          </DragDropContext>
        ) : (
          <div className="flex justify-center items-center h-40">
            <p>{t('belumAdaProduk')}</p>
          </div>
        )}
      </div>
  
      {/* Footer - Fixed at bottom */}
      <div className="fixed bottom-0 left-0 right-0 flex flex-col w-full z-50 bg-white">
        <div className="flex gap-3 items-center px-4 py-3 w-full text-sm font-semibold leading-none text-white whitespace-nowrap bg-white rounded-t-xl shadow-2xl">
          <Button
            onClick={handleSave}
            color="primary"
            Class="flex-1 shrink gap-1 self-stretch px-6 py-4 my-auto w-full bg-blue-600 rounded-3xl min-h-[40px] min-w-[160px] sm:max-w-full"
            tabIndex="0"
          >
            {t('labelSelesai')}
          </Button>
        </div>
        
      </div>
  
      {/* {showBottomsheet && ( */}
        <Bottomsheet label={t('susunProdukKamu')} >
                <div className="w-full text-start">
                  {t('susunUrutanProduk')}
                </div>
          {/* <div className="w-full max-w-screen-xl mx-auto flex flex-col items-center px-4 pt-1 pb-6 bg-white rounded-2xl shadow-lg">
            <div className="flex flex-col mt-4 w-full max-w-[1200px]">
              <div className="flex flex-col w-full">
                <div className="flex gap-10 justify-between items-center w-full font-bold leading-none text-center">
                
                    <ImageComponent
                      src="/icons/etalase/closes.svg"
                      alt={t('labelTutup')}
                      width={16}
                      height={16}
                      onClick={() => setShowBottomsheet(false)}
                      className="w-4 h-4"
                    />
                  <div className="self-stretch my-auto">
                    {t('susunProdukKamu')}
                  </div>
                  <div className="flex shrink-0 self-stretch my-auto w-6 h-6" />
                </div>
                <div className="flex flex-col mt-6 w-full font-medium leading-4">
                  <div className="w-full text-center">
                    {t('susunUrutanProduk')}
                  </div>
                </div>
              </div>
            </div>
          </div> */}
        </Bottomsheet>
      {/* )} */}
  
      <Toast />

      <CustomModal 
        isOpen={showLeaveModal}
        onClose={() => setShowLeaveModal(false)}
        onConfirm={() => {
          // Get stored return info
          const returnToPage = localStorage.getItem('returnToPage');
          const editId = localStorage.getItem('editEtalaseId');
          
          // Keep the products in store since we're returning to edit
          if (returnToPage === 'edit' && editId) {
            localStorage.setItem('returningToEdit', 'true'); // Set flag to keep products
            router.push(`/daftaretalase/mobile/edit/${editId}`);
          } else {
            // Default back behavior 
            router.back();
          }
        }}
        title={t('pindahHalaman')}
        message={t('konfirmasiPindahHalaman')}
        //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0148
        confirmText={t('labelYes')}
        cancelText={t('labelBatal')}
        showCloseIcon={true}
      />
    </div>
  );
}