// THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase
// LB - 0126
// LB - 0127
// LB - 0128
// LB - 0183
// LB - 0184
// LB - 0185
// LB - 0188
// LB - 0194
// LB - 0159
// LB - 0160
// LB - 0161
// LB - 0162
// LB - 0163
// LB - 0164
// LB - 0165
// LB - 0166
// LB - 0168
// LB - 0169
// LB - 0170
// LB - 0172
// LB - 0173
// LB - 0174
// LB - 0175
// LB - 0176
// LB - 0177
// LB - 0178
// LB - 0179
// LB - 0180
// LB - 0181
// LB - 0189
// LB - 0190
// LB - 0192

"use client";
import React, { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { MockServer_TambahEtalase } from '@/services/MockServer_TambahEtalase';
import useSusunProdukStore from '@/store/susunProdukStore';
import useEtalaseStore from '@/store/zustand/etalasestore';
import { Header } from '../../components/Header';
import { ProductForm } from '../../add/ProductForm';
import { ProductList } from '../../add/ProductList';
import { SaveButton } from '../../add/SaveButton';
import { EmptyEtalase } from '../../add/EmptyEtalase';
import { Loading } from '@/components/Loading/Loading';
import Toast from '@/components/Toast/Toast';
import { useLanguage } from "@/providers/LanguageProvider";
import toast from "@/store/zustand/toast";
import { useImageStore } from '@/store/zustand/etalase/imagestore';
import { useCustomRouter } from '@/libs/CustomRoute';
import CustomModal from '@/components/Modal/CustomModal';
import useFilterStore from '@/store/zustand/filterstore';

export default function EditShowcasePage() {
  const router = useCustomRouter();
  const params = useParams();
  const { products, setProducts } = useSusunProdukStore();
  const {setSelectedFilters,setSearchValue} = useFilterStore();
  const { t } = useLanguage();
  const { showToast, setShowToast, setDataToast } = toast();
  const cropperImage = useImageStore(state => state.cropperImage);
  const resetFilters = useFilterStore((state) => state.resetFilters);
  const { existingProducts, setExistingProducts } = useSusunProdukStore();
  
  // Form state
  const [formData, setFormData] = useState(() => {
    if (typeof window !== 'undefined') {
      const savedData = localStorage.getItem('etalaseFormData');
      return savedData ? JSON.parse(savedData) : { name: '', image: null };
    }
    return { name: '', image: null };
  });

  // UI states
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  // Add new state to track if we should skip initial load
  const [skipInitialLoad, setSkipInitialLoad] = useState(false);
  const [nameError, setNameError] = useState(false);
  const [nameErrorMessage, setNameErrorMessage] = useState('');  // Add this line
  const [showLeaveModal, setShowLeaveModal] = useState(false);
  const [originalData, setOriginalData] = useState({
    name: '',
    imageUrl: '',
    products: []
  });

  // Replace sourceRoute state with proper initialization
  const [sourceRoute, setSourceRoute] = useState(null);

  useEffect(() => {
    // Check query param first
    const searchParams = new URLSearchParams(window.location.search);
    const fromParam = searchParams.get('from');
    
    // Then check localStorage as fallback
    const storedRoute = localStorage.getItem('etalaseSourceRoute');
    
    setSourceRoute(fromParam || storedRoute || 'list');
  }, []);

  // Add this to handle reorder navigation
  const handleReorderClick = async () => {
    try {
      if (products && products.length > 0) {
        console.log('Starting reorder navigation...');
        
        // Save current form data and edit state
        await Promise.all([
          new Promise(resolve => {
            localStorage.setItem('etalaseFormData', JSON.stringify(formData));
            resolve();
          }),
          new Promise(resolve => {
            localStorage.setItem('editEtalaseId', params.id);
            resolve();
          }),
          new Promise(resolve => {
            localStorage.setItem('returnToPage', 'edit');
            resolve();
          }),
          new Promise(resolve => {
            localStorage.setItem('returningToEdit', 'reorder');
            resolve();
          })
        ]);
        
        // Update products state and wait for it
        await setProducts([...products]);
        console.log('Products state updated:', products);
        
        // Navigate using router.push()
        console.log('Navigating to susun produk...');
         router.push('/daftaretalase/mobile/susunproduk');
        
      } else {
        console.log('No products available for reordering');
      }
    } catch (error) {
      console.error('Navigation error:', error);
      // Fallback navigation
      router.push('/daftaretalase/mobile/susunproduk');
    }
  };

  const handleBack = (e) => {
    // Always prevent default navigation
    if (e) e.preventDefault();
    
    // Always show modal regardless of changes
    setShowLeaveModal(true);
    return false;
  };

  // Modify browser back button handler too
  useEffect(() => {
    const handleBrowserBack = (e) => {
      e.preventDefault();
      setShowLeaveModal(true);
      window.history.pushState(null, '', window.location.pathname);
    };

    window.history.pushState(null, '', window.location.pathname);
    window.addEventListener('popstate', handleBrowserBack);

    return () => {
      window.removeEventListener('popstate', handleBrowserBack);
    };
  }, []);

  const sortProducts = (products) => {
    const existing = new Set(existingProducts.map(p => p.id));
    //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0189
    // Create map of original positions for existing products
    const existingPositions = new Map();
    existingProducts.forEach((p, index) => {
      existingPositions.set(p.id, index);
    });

    return [...products].sort((a, b) => {
      const aIsExisting = existing.has(a.id);
      const bIsExisting = existing.has(b.id);

      // Create priority scores for sorting
      const getScore = (product, isExisting) => {
        if (isExisting && product.stock > 0) return 4; // Existing product with stock
        if (!isExisting && product.stock > 0) return 3; // New product with stock
        if (!isExisting && product.stock === 0) return 2; // New product without stock
        if (isExisting && product.stock === 0) return 1; // Existing product without stock
        return 0;
      };

      const scoreA = getScore(a, aIsExisting);
      const scoreB = getScore(b, bIsExisting);

      if (scoreA !== scoreB) {
        return scoreB - scoreA;
      }
      
      // If both are existing products with same score, use original positions
      if (aIsExisting && bIsExisting) {
        return existingPositions.get(a.id) - existingPositions.get(b.id);
      }

      // If scores are equal and both are new products, sort by creation date
      if (!aIsExisting && !bIsExisting) {
        return new Date(b.created) - new Date(a.created);
      }

      return 0;
    });
  };

  useEffect(() => {
    const loadEtalaseData = async () => {
      try {
        setIsLoading(true);
        
        // Get returning status once
        const isReturningFromSelection = localStorage.getItem('returningToEdit');
        console.log('Returning from selection:', isReturningFromSelection);
        console.log('Current products in store:', products);
        
        // if (isReturningFromSelection && products.length > 0) {
        if (isReturningFromSelection && products.length > 0) {
          // Sort existing products
          //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0189
          if(localStorage.getItem('returningToEdit') !== 'reorder'){
            setProducts(sortProducts(products));
            console.log('sort')
          }else{
            setProducts(products);
          }
          console.log('test1');
          
          // Only fetch other etalase details if we don't have them
          if (!formData.name) {
            const response = await MockServer_TambahEtalase.getEtalaseDetail(params.id);
            if (response.message.code === 200) {
              setFormData({
                name: response.data.name || '',
                imageUrl: response.data.imageUrl || '',
                image: null
              });
              setOriginalData({
                name: response.data.name || '',
                imageUrl: response.data.imageUrl || '',
                products: response.data.products || []
              });
            }
          }
        } else {
          // Load everything from API if not returning from selection
          const response = await MockServer_TambahEtalase.getEtalaseDetail(params.id);
          
          if (response.message.code === 200) {
            const data = {
              name: response.data.name || '',
              imageUrl: response.data.imageUrl || '',
              products: response.data.products || []
            };
            
            setFormData({
              name: data.name,
              imageUrl: data.imageUrl,
              image: null
            });
            setOriginalData(data);
            
            if (data.products && Array.isArray(data.products)) {
              console.log('Setting products from API:', data.products);
              setExistingProducts(data.products);
              setProducts(data.products);
            }
          }
        }
        
        // Clear the returning flag
        localStorage.removeItem('returningToEdit');
        
      } catch (error) {
        console.error('Failed to load etalase:', error);
        setDataToast({
          type: 'error',
          message: error.message || 'Gagal memuat data etalase'
        });
        setShowToast(true);
      } finally {
        setIsLoading(false);
      }
    };

    loadEtalaseData();

    // Cleanup function remains the same
    return () => {
      const nextPath = window.location.pathname;
      if (!nextPath.includes('/daftaretalase/mobile/edit') && 
          !nextPath.includes('/pilihproduk') &&
          !nextPath.includes('/susunproduk')) {
        setProducts([]);
      }
    };
  }, [params.id]);

  // Add useEffect for handling cropped images
  useEffect(() => {
    if (cropperImage) {
      handleInputChange('imageUrl', cropperImage);
      
      // Convert base64/URL to file object
      fetch(cropperImage)
        .then(res => res.blob())
        .then(blob => {
          const file = new File([blob], 'cropped-image.jpg', { type: 'image/jpeg' });
          handleInputChange('image', file);
        });
    }
  }, [cropperImage]);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleImageUpload = async (file) => {
    if (file) {
      if (file.size > 10 * 1024 * 1024) {
        setDataToast({
          type: 'error',
          message: 'Ukuran file maksimal 10MB!'
        });
        setShowToast(true);
        return;
      }
      
      if (!['image/jpeg', 'image/png'].includes(file.type)) {
        setDataToast({
          type: 'error',
          message: 'Format file tidak sesuai ketentuan!'
        });
        setShowToast(true);
        return;
      }

      // Store file information for cropper
      const fileUrl = URL.createObjectURL(file);
      localStorage.setItem('selectedImage', fileUrl);
      localStorage.setItem('selectedImageName', file.name);
      localStorage.setItem('selectedImageType', file.type);
      // Store the source page and ID information
      localStorage.setItem('cropperSource', 'edit');
      localStorage.setItem('sourceId', params.id);
      
      // Navigate to cropper page
      router.push('/daftaretalase/mobile/cropper/cropfoto');
    }
  };

  const handleSave = async () => {
    try {
      setIsSaving(true);

      if (!formData.name?.trim()) {
        setNameError(true);
        setNameErrorMessage(t('namaEtalaseWajibDiisi'));
        return;
      }
      setNameError(false);
      setNameErrorMessage('');

      const data = {
        name: formData.name.trim(),
        image: formData.imageUrl,
        products: products.map((product, index) => ({
          productId: product.id,
          position: index + 1
        }))
      };

      const response = await MockServer_TambahEtalase.updateEtalase(params.id, data);

      if (response.message.code === 200) {
       
        // Clear existing products and navigate back to list
        await new Promise((resolve) => {
          setProducts([]);
          resolve();
        });
        router.push('/daftaretalase/mobile');
        
        // Show success toast in list
        //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0178,LB - 0225
        localStorage.setItem('showToast', 'true');
        localStorage.setItem('toastMessage', t('etalasemuBerhasilDiubah'));
        localStorage.setItem('toastType', 'success');
        // setTimeout(() => {
        //   setDataToast({
        //     type: 'success',
        //     message: t('etalasemuBerhasilDiubah')
        //   });
        //   setShowToast(true);
        // }, 100);
      }
    } catch (error) {
      if (error.message === 'namaEtalaseTelahaDigunakan') {
        setNameError(true);
        setNameErrorMessage(t('namaEtalaseTelahaDigunakan'));
      } else {
        setDataToast({
          type: 'error',
          message: error.message || 'Gagal mengubah etalase'
        });
        setShowToast(true);
      }
    } finally {
      setIsSaving(false);
    }
  };

  // Modify cleanup effect to match add page
  useEffect(() => {
    return () => {
      // Only clear data when actually leaving the flow
      const nextPath = window.location.pathname;
      if (!nextPath.includes('/daftaretalase/mobile/edit') && 
          !nextPath.includes('/pilihproduk') &&
          !nextPath.includes('/susunproduk')) {
        setProducts([]);
        localStorage.removeItem('etalaseFormData');
        localStorage.removeItem('selectedProducts');
        localStorage.removeItem('tempProducts');
        localStorage.removeItem('susun-produk-storage');
      }
    };
  }, []);

  // Update handleAddProduct to save form data before navigation
  const handleAddProduct = () => {
    if (products.length > 0) {
      setExistingProducts(products);
      localStorage.setItem('existingProducts', JSON.stringify(products));
    }
    // Save current form data before navigation
    localStorage.setItem('etalaseFormData', JSON.stringify(formData));
    resetFilters();
    localStorage.setItem('returningToEdit', 'true');
    router.push(`/daftaretalase/mobile/pilihproduk?etalaseId=${params.id}`);
  };

  const handleDeleteProduct = (productId) => {
    try {
      // Langsung update state produk tanpa request API
      const updatedProducts = products.filter(p => String(p.id) !== String(productId));
      setProducts(updatedProducts);
      
      // setDataToast({
      //   type: 'success',
      //   message: 'Produk berhasil dihapus'
      // });
      // setShowToast(true);
    } catch (error) {
      setDataToast({
        type: 'error',
        message: 'Gagal menghapus produk'
      });
      setShowToast(true);
    }
  };

  const handleExitConfirm = async () => {
    try {
      // Clear all storage first
      localStorage.removeItem('etalaseFormData');
      localStorage.removeItem('selectedProducts');
      localStorage.removeItem('tempProducts');
      localStorage.removeItem('susun-produk-storage');
      //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase -  LB - 0194, LB - 0202, LB - 0219, LB - 0219
      setSelectedFilters([])
      localStorage.removeItem('susun-produk-storage');
      localStorage.removeItem('searchValue');
      setSearchValue('')
      
      // Clear state
      setProducts([]);
      
      // Navigate based on source route with small delay
      await new Promise(resolve => setTimeout(resolve, 100));
      
      if (sourceRoute === 'detail') {
        router.push(`/daftaretalase/mobile/detail/${params.id}`, undefined, { replace: true });
      } else {
        router.push('/daftaretalase/mobile', undefined, { replace: true });
      }
    } catch (error) {
      console.error('Navigation error:', error);
      // Fallback navigation
      if (sourceRoute === 'detail') {
        window.location.href = `/daftaretalase/mobile/detail/${params.id}`;
      } else {
        window.location.href = '/daftaretalase/mobile';
      }
    }
  };

  if (isLoading) {
    return <></>;
  }

  return (
    <div className="flex flex-col h-screen overflow-hidden">
      {isSaving && <></>}
      
      <Toast />
      
      <Header 
        title={t('ubahEtalase')}
        showArrangeIcon={products.length > 0}
        onArrangeClick={handleReorderClick}
        onBack={handleBack}
      />
      {/*24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0153 */}
      <div className="flex-1 overflow-y-auto ">
      <div className={`flex flex-col w-full h-full ${products.length === 0?'':''}`}>
          {/*24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0230 */}
          <ProductForm
            name={formData.name || ''}
            image={formData.imageUrl}
            imageUrl={formData.imageUrl}
            onNameChange={(value) => {
              handleInputChange('name', value);
              setNameError(false); // Clear error when user types
              setNameErrorMessage('');
            }}
            onImageUpload={(file) => {
              if (file === null) {
                setFormData(prev => ({
                  ...prev,
                  image: null,
                  imageUrl: ''
                }));
              } else {
                handleImageUpload(file);
              }
            }}
            error={nameError}
            errorMessage={nameErrorMessage}  // Add this prop
          />
          
          {products.length === 0 ? (
            <EmptyEtalase onAddProduct={handleAddProduct} />
          ) : (
            <ProductList
              products={products}
              onAddProduct={handleAddProduct}
              onDeleteProduct={handleDeleteProduct}
              loading={isLoading}
            />
          )}
          {/*24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0181 */}
          <div className="min-h-[63px]" style={{minHeight:'63px'}} /> {/* Spacer di akhir konten */}
        </div>
      </div>
      
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white border-t max-w-[480px] mx-auto">
        <SaveButton 
          onClick={handleSave}
          isLoading={isSaving}
        />
      </div>

      <CustomModal 
        isOpen={showLeaveModal}
        onClose={() => setShowLeaveModal(false)}
        onConfirm={handleExitConfirm}
        // title={t('pindahHalaman')}
        // message={t('konfirmasiPindahHalaman')}
        // confirmText={t('labelYes')}
        // cancelText={t('labelBatal')}
        //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0177
        title={t('keluarHalamanIni')}
        message={t('konfirmasiKeluarHalaman')}
        confirmText={t('labelYaKeluar')}
        cancelText={t('labelBatal')}
        showCloseIcon={true}
        textColor="#000000"
        roundedButtons={true}
      />
    </div>
  );
}