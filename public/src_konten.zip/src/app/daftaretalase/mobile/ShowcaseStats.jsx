import * as React from "react";

export const ShowcaseStats = ({ etalaseCount, maxEtalase, t }) => {
  return (
    <div className="flex gap-10 justify-between items-center px-4 pb-4 w-full text-xs font-medium text-black bg-white">
      <div className="self-stretch my-auto">{etalaseCount} {t('totalEtalase')}</div>
      <div className="self-stretch my-auto">({t('etalaseMaks')} {maxEtalase})</div>
    </div>
  );
};
