// THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase 
// LB - 0137
// LB - 0138
// LB - 0141
// LB - 0142
// LB - 0144
// LB - 0145
// LB - 0146
// LB - 0148
// LB - 0149
// LB - 0150
// LB - 0151
// LB - 0152
// LB - 0153


"use client";
import React, { useState, useEffect } from 'react';
import { useCustomRouter } from '@/libs/CustomRoute';
import { MockServer_TambahEtalase } from '@/services/MockServer_TambahEtalase';
import useSusunProdukStore from '@/store/susunProdukStore';
import { Header } from '../components/Header';
import { ProductForm } from './ProductForm';
import { ProductList } from './ProductList';
import { SaveButton } from './SaveButton';
import { EmptyEtalase } from './EmptyEtalase';
import { Loading } from '@/components/Loading/Loading';
import Toast from '@/components/Toast/Toast';
import useEtalaseStore from '@/store/zustand/etalasestore';
import { useLanguage} from "@/providers/LanguageProvider";
import toast from "@/store/zustand/toast";
import { useImageStore } from '@/store/zustand/etalase/imagestore';
import CustomModal from '@/components/Modal/CustomModal';
import useFilterStore from '@/store/zustand/filterstore'; // Add this import at the top with other imports


export default function AddShowcasePage() {
  const router = useCustomRouter();
  const { products, setProducts, existingProducts, setExistingProducts } = useSusunProdukStore();
  const { t, currentLocale, changeLanguage, loading: langLoading } = useLanguage();
  const addEtalase = useEtalaseStore((state) => state.addEtalase);  // Add this line
  const { showToast, setShowToast, setDataToast } = toast();
  const resetFilters = useFilterStore((state) => state.resetFilters); // Add this line
  
  // Modified form state initialization
  const [formData, setFormData] = useState(() => {
    if (typeof window !== 'undefined') {
      const savedData = localStorage.getItem('etalaseFormData');
      return savedData ? JSON.parse(savedData) : { name: '', image: null };
    }
    return { name: '', image: null };
  });

  // UI states
  const [isLoading, setIsLoading] = useState(false);
  const [showLeaveModal, setShowLeaveModal] = useState(false);
  const [nameError, setNameError] = useState(false);
  const [nameErrorMessage, setNameErrorMessage] = useState('');  // Add this line

  const handleBack = (e) => {
    // Always prevent default navigation
    if (e) e.preventDefault();
    
    // Always show modal regardless of changes
    setShowLeaveModal(true);
    return false;
  };

  // Modify browser back button handler too
  useEffect(() => {
    const handleBrowserBack = (e) => {
      e.preventDefault();
      setShowLeaveModal(true);
      window.history.pushState(null, '', window.location.pathname);
    };

    window.history.pushState(null, '', window.location.pathname);
    window.addEventListener('popstate', handleBrowserBack);

    return () => {
      window.removeEventListener('popstate', handleBrowserBack);
    };
  }, [formData, products]);

  const cropperImage = useImageStore(state => state.cropperImage);

  // Handle image update
  const handleImageUpload = (imageUrl) => {
    console.log(imageUrl,'imageUrl')
    setFormData(prev => ({
      ...prev,
      image: imageUrl
    }));
  };

  useEffect(() => {
    if (cropperImage) {
      handleImageUpload(cropperImage);
    }
  }, [cropperImage]);

  // Add effect to load saved form data
  useEffect(() => {
    const returningFromEdit = localStorage.getItem('returningToEdit');
    if (returningFromEdit) {
      const savedData = localStorage.getItem('etalaseFormData');
      if (savedData) {
        setFormData(JSON.parse(savedData));
      }

      // Sort products when loading from store
      if (products.length > 0) {
        const sortedProducts = sortProducts(products);
        setProducts(sortedProducts);
      }

      localStorage.removeItem('returningToEdit');
    }
  }, []);

  // Modify cleanup effect
  useEffect(() => {
    return () => {
      // Only clear data when actually leaving the flow
      const nextPath = window.location.pathname;
      if (!nextPath.includes('/daftaretalase/mobile')) {
        setProducts([]);
        localStorage.removeItem('etalaseFormData');
      }
    };
  }, []);

 const handleSave = async () => {
  try {
    setIsLoading(true);

    if (!formData.name?.trim()) {
      setNameError(true);
      setNameErrorMessage(t('namaEtalaseWajibDiisi'));
      return;
    }
    setNameError(false);
    setNameErrorMessage('');

    const data = {
      name: formData.name.trim(),
      image: formData.image,
      products: products.length > 0 ? products.map((product, index) => ({
        productId: product.id,
        position: index + 1
      })) : []
    };

    const response = await MockServer_TambahEtalase.createEtalase(data);

    if (response.message.code === 200) {
      // Create and await a Promise for addEtalase
      await new Promise((resolve) => {
        addEtalase(response.data);
        resolve();
      });
      
      // Reset store and clear localStorage after addEtalase completes
      await new Promise((resolve) => {
        setProducts([]);
        localStorage.removeItem('susun-produk-storage');
        resolve();
      });
      await new Promise((resolve) => {
        // Navigate back after success
        router.push('/daftaretalase/mobile');
        resolve();
      });
       
     
      //show the toast on daftaretalase/mobile page
      //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0150
      localStorage.setItem('showToast', 'true');
      localStorage.setItem('toastMessage', t('berhasilMenambahEtalase'));
      localStorage.setItem('toastType', 'success');
      // setTimeout(() => {
        // setDataToast({
        //   type: 'success',
        //   message: t('berhasilMenambahEtalase')
        // });
        // setShowToast(true);
      // }, 100);
    }
  } catch (error) {
    if (error.message === 'namaEtalaseTelahaDigunakan') {
      setNameError(true);
      setNameErrorMessage(t('namaEtalaseTelahaDigunakan'));
    } else {
      setDataToast({
        type: 'error',
        message: error.message || t('Terjadi kesalahan')
      });
      setShowToast(true);
    }
  } finally {
    setIsLoading(false);
  }
};

// Update sort logic to handle existing vs new products
const sortProducts = (products) => {
  const existing = new Set(existingProducts.map(p => p.id));
  
  // Create map of original positions for existing products
  const existingPositions = new Map();
  existingProducts.forEach((p, index) => {
    existingPositions.set(p.id, index);
  });
  
  return [...products].sort((a, b) => {
    const aIsExisting = existing.has(a.id);
    const bIsExisting = existing.has(b.id);

    // Buat skor prioritas untuk mengurutkan
    const getScore = (product, isExisting) => {
      if (isExisting && product.stock > 0) return 4; // Produk lama dengan stok > 0
      if (!isExisting && product.stock > 0) return 3; // Produk baru dengan stok > 0
      if (!isExisting && product.stock === 0) return 2; // Produk baru dengan stok = 0
      if (isExisting && product.stock === 0) return 1; // Produk lama dengan stok = 0
      return 0;
    };

    const scoreA = getScore(a, aIsExisting);
    const scoreB = getScore(b, bIsExisting);

    if (scoreA !== scoreB) {
      return scoreB - scoreA; // Sort by priority score
    }

    // If both are existing products with same score, use original positions
    if (aIsExisting && bIsExisting) {
      return existingPositions.get(a.id) - existingPositions.get(b.id);
    }

    // If both are new products, sort by created date
    if (!aIsExisting && !bIsExisting) {
      return new Date(b.created) - new Date(a.created);
    }

    return 0;
  });
};

// Update when component mounts
useEffect(() => {
  // Load existing products on mount
  const savedProducts = localStorage.getItem('existingProducts');
  if (savedProducts) {
    setExistingProducts(JSON.parse(savedProducts));
  }
}, []);

// When adding new products
const handleAddProduct = () => {
  // Save current products as existing before adding new ones
  if (products.length > 0) {
    setExistingProducts(products);
    localStorage.setItem('existingProducts', JSON.stringify(products));
  }
  // ...rest of handleAddProduct code...
  resetFilters();
  localStorage.setItem('etalaseFormData', JSON.stringify(formData));
  router.push('/daftaretalase/mobile/pilihproduk');
};

// When returning from product selection, sort the products
useEffect(() => {
  const returningFromSelection = localStorage.getItem('returningFromSelection');
  if (returningFromSelection) {
    if (products.length > 0) {
      const sortedProducts = sortProducts(products);
      setProducts(sortedProducts);
    }
    localStorage.removeItem('returningFromSelection');
  }
}, []);

  const handleDeleteProduct = (productId) => {
    console.log('Attempting to delete product:', productId);
    
    // Defensive programming: ensure productId is a string or number
    const idToDelete = String(productId);
    
    const updatedProducts = products.filter(p => String(p.id) !== idToDelete);
    
    console.log('Before delete:', products.length);
    console.log('After delete:', updatedProducts.length);
    
    // Only update if the number of products actually changed
    if (updatedProducts.length < products.length) {
      setProducts(updatedProducts);
      
      // Optional: Show a toast notification
      // setDataToast({
      //   type: 'success',
      //   message: t('Produk berhasil dihapus')
      // });
      // setShowToast(true);
    } else {
      // If no product was deleted, show an error
      setDataToast({
        type: 'error',
        message: 'Gagal menghapus produk'
      });
      setShowToast(true);
    }
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleReorderClick = async () => {
    try {
      if (products && products.length > 0) {
        console.log('Starting reorder navigation...');
        
        // Save form data first
        localStorage.setItem('etalaseFormData', JSON.stringify(formData));
        localStorage.setItem('returnToPage', 'add');
        
        // Update products state and wait for it
        await setProducts([...products]);
        console.log('Products state updated:', products);
        
        // Navigate using router.push()
        console.log('Navigating to susun produk...');
        await router.push('/daftaretalase/mobile/susunproduk');
      } else {
        console.log('No products available for reordering');
      }
    } catch (error) {
      console.error('Navigation error:', error);
      // Fallback navigation
      router.push('/daftaretalase/mobile/susunproduk');
    }
  };

  // Modifikasi handler exit confirmation 
  const handleExitConfirm = async () => {
    try {
      // Clear all storage first
      localStorage.removeItem('etalaseFormData');
      localStorage.removeItem('selectedProducts');
      localStorage.removeItem('tempProducts');
      localStorage.removeItem('susun-produk-storage');
      
      // Clear state
      setProducts([]);
      
      // Add small delay to ensure cleanup
      await new Promise(resolve => setTimeout(resolve, 100));
      
      // Use router.push with replace option
      await router.push('/daftaretalase/mobile', undefined, { replace: true });
    } catch (error) {
      console.error('Navigation error:', error);
      // Fallback to direct navigation if router fails
      window.location.href = '/daftaretalase/mobile';
    }
  };

  const filterProducts = () => {
    let filteredItems = [...products];
  
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      const nameMatches = [];
      const skuMatches = [];
      const brandMatches = [];
  
      filteredItems.forEach(product => {
        const name = product.name.toLowerCase();
        const sku = (product.sku || '').toLowerCase();
        const brand = (product.brand || '').toLowerCase();
        
        if (name.includes(query)) {
          nameMatches.push(product);
        } else if (sku.includes(query)) {
          skuMatches.push(product);
        } else if (brand.includes(query)) {
          brandMatches.push(product);
        }
      });
  
      // Sort each category alphabetically by their respective values
      nameMatches.sort((a, b) => a.name.localeCompare(b.name));
      skuMatches.sort((a, b) => (a.sku || '').localeCompare(b.sku || ''));
      brandMatches.sort((a, b) => (a.brand || '').localeCompare(b.brand || ''));
  
      // Combine results in priority order
      filteredItems = [...nameMatches, ...skuMatches, ...brandMatches];
    }
  
    return filteredItems;
  };

  return (
    <div className="flex flex-col w-full h-screen bg-zinc-100 overflow-hidden">
      <Toast />
      
      {/* Fixed header */}
      <div className="fixed top-0 left-0 right-0 z-50 bg-white">
        {/* <Header 
          label={t('tambahEtalase')}
          hasProducts={products.length > 0}
          onReorder={handleReorderClick}
          onBack={handleBack}
        /> */}
        <Header 
          title={t('tambahEtalase')}
          showArrangeIcon={products.length > 0}
          onArrangeClick={handleReorderClick}
          onBack={handleBack}
        />
      </div>

      {/* Scrollable content area */}
       {/*24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0153 */}
      <div className="flex-1 overflow-y-auto pt-[56px] ">
      <div className={`flex flex-col w-full h-full ${products.length === 0?'':''}`}>
          <ProductForm
            name={formData.name}
            image={formData.image}
            onNameChange={(value) => {
              handleInputChange('name', value);
              setNameError(false);
              setNameErrorMessage('');
            }}
            onImageUpload={handleImageUpload}
            error={nameError}
            errorMessage={nameErrorMessage}
          />
          
          {products.length === 0 ? (
            <EmptyEtalase onAddProduct={handleAddProduct} />
          ) : (
            <ProductList
              products={products}
              onAddProduct={handleAddProduct}
              onDeleteProduct={handleDeleteProduct}
            />
          )}
          {/*24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0205, LB - 0207 */}
          <div className="min-h-[63px]" style={{minHeight:'63px'}} /> {/* Spacer di akhir konten */}
        </div>
      </div>

      {/* Fixed save button at bottom */}
      <div className="fixed bottom-0 left-0 right-0 z-50 bg-white">
        <SaveButton onClick={handleSave} />
      </div>

      <CustomModal 
        isOpen={showLeaveModal}
        onClose={() => setShowLeaveModal(false)}
        onConfirm={handleExitConfirm}
        title={t('keluarHalamanIni')}
        message={t('konfirmasiKeluarHalaman')}
        confirmText={t('labelYaKeluar')}
        cancelText={t('labelBatal')}
        confirmButtonClass="bg-[#176CF7] rounded-full w-full" 
        cancelButtonClass="border border-[#176CF7] text-[#176CF7] rounded-full w-full"
        showCloseIcon={true}
        roundedButtons={true}
      />
    </div>
  );

}