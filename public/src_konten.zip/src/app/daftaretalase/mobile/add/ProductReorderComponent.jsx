import React, { useState, useCallback } from 'react';
import { useRouter } from 'next/router';
import Button from '@/components/Button/Button';
import { useLanguage } from "@/providers/LanguageProvider";
import ImageComponent from "@/components/ImageComponent/ImageComponent";
import { useCustomRouter } from '@/libs/CustomRoute';

export const SusunProduk = ({ products, onReorder }) => {
  const { t } = useLanguage();
  const router = useCustomRouter();
  const [draggedItem, setDraggedItem] = useState(null);
  const [items, setItems] = useState(products);

  const handleDragStart = (e, index) => {
    if (items[index].stock === 0) return; // Prevent dragging out-of-stock items
    setDraggedItem(items[index]);
    e.currentTarget.classList.add('opacity-50');
  };

  const handleDragEnd = (e) => {
    e.currentTarget.classList.remove('opacity-50');
    setDraggedItem(null);
  };

  const handleDragOver = useCallback((index) => {
    if (!draggedItem || items[index].stock === 0) return;
    
    setItems(prevItems => {
      const newItems = [...prevItems];
      const draggedIndex = newItems.findIndex(item => item.id === draggedItem.id);
      
      // Remove item from old position
      newItems.splice(draggedIndex, 1);
      // Insert at new position
      newItems.splice(index, 0, draggedItem);
      
      return newItems;
    });
  }, [draggedItem]);

  const handleSave = () => {
    onReorder(items.map(item => item.id));
    router.back();
  };

  return (
    <div className="flex flex-col min-h-screen bg-zinc-50">
      {/* Header */}
      <div className="flex flex-col items-center w-full text-sm font-semibold text-center text-black">
        <div className="flex flex-col w-full">
          <div className="flex flex-col justify-center p-4 w-full bg-white shadow-[0px_4px_15px_rgba(0,0,0,0.15)]">
            <div className="flex gap-2 justify-between items-center">
              <button 
                onClick={() => router.back()}
                className="flex items-center"
              >
                <ImageComponent
                  src="/icons/etalase/mobile/back-arrow.svg"
                  alt={t('labelKembali')}
                  width={24}
                  height={24}
                />
              </button>
              <div className="flex-1 text-center">{t('susunProduk')}</div>
              <button 
                onClick={() => {
                  // Show info tooltip/modal
                }}
                className="w-6 h-6 text-neutral-500"
              >
                i
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Product List */}
      <div className="flex flex-col flex-1 p-4">
        {items.map((item, index) => (
          <div
            key={item.id}
            draggable={item.stock > 0}
            onDragStart={(e) => handleDragStart(e, index)}
            onDragEnd={handleDragEnd}
            onDragOver={() => handleDragOver(index)}
            className={`
              flex gap-4 p-4 mb-2 bg-white rounded-lg
              ${item.stock === 0 ? 'opacity-50 cursor-not-allowed' : 'cursor-move'}
            `}
          >
            <ImageComponent
              src={item.imageUrl || '/images/placeholder.png'}
              alt={item.name}
              width={64}
              height={64}
              className="object-cover rounded-md"
            />
            <div className="flex-1 min-w-0">
              <h3 className="text-sm font-bold text-black line-clamp-2">
                {item.name}
              </h3>
              <p className="mt-1 text-sm text-neutral-500">
                Rp{item.price.toLocaleString('id-ID')}
              </p>
              {item.sku && (
                <p className="mt-1 text-xs text-neutral-500">
                  SKU: {item.sku}
                </p>
              )}
              <p className="mt-1 text-xs text-neutral-500">
                Brand: {item.brand}
              </p>
              <p className="mt-1 text-xs text-neutral-500">
                Kategori: {item.category}
              </p>
            </div>
            <div className="flex items-center">
              <ImageComponent
                src="/icons/drag-handle.svg"
                alt="Geser"
                className={`w-6 h-6 ${item.stock === 0 ? 'opacity-50' : ''}`}
              />
            </div>
          </div>
        ))}
      </div>

      {/* Save Button */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white shadow-lg">
        <Button
          onClick={handleSave}
          color="primary"
          Class="w-full"
        >
          {t('labelSelesai')}
        </Button>
      </div>
    </div>
  );
};