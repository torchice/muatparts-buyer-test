"use client";
import React, { useState, useEffect } from 'react';
import { MediaUploadOptions } from '../components/mediaUpload/MediaUploadOptions';
import { useLanguage} from "@/providers/LanguageProvider";
import Button from "@/components/Button/Button";
import ImageComponent from "@/components/ImageComponent/ImageComponent";


export const ProductForm = ({
  name,
  image,
  imageUrl,
  onNameChange,
  onImageUpload,
  error,
  errorMessage // Add this prop
}) => {
  // Set initial counter based on existing name
  const [counter, setCounter] = useState(name?.length || 0);
  const [isFocused, setIsFocused] = useState(false);
  const { t, currentLocale, changeLanguage, loading: langLoading } = useLanguage();
  

  // Update counter when name prop changes
  useEffect(() => {
    setCounter(name?.length || 0);
  }, [name]);
  //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0132
  const handleNameChange = (e) => {
    const value = e.target.value;
    const truncatedValue = value.slice(0, 80);
    setCounter(truncatedValue.length);
    onNameChange(truncatedValue);
  };

  const handleImageUpload = (fileOrUrl) => {
    // Clear image if null
    if (!fileOrUrl) {
      onImageUpload(null);
      return;
    }

    // If it's a URL from cropper
    if (typeof fileOrUrl === 'string') {
      onImageUpload(fileOrUrl);
      return;
    }

    onImageUpload(fileOrUrl);
  };

  const handleRemoveImage = () => {
    // Clear local storage
    localStorage.removeItem('selectedImage');
    localStorage.removeItem('selectedImageName');
    localStorage.removeItem('selectedImageType');
    localStorage.removeItem('croppedImage');
    
    // Clear image from form
    onImageUpload(null);
  };

  const getImageSrc = (image) => {
    if (!image) return null;
    // If image is already a URL string, return it directly
    if (typeof image === 'string') return image;
    // If image is a File/Blob, create object URL
    if (image instanceof File || image instanceof Blob) {
      return URL.createObjectURL(image);
    }
    return null;
  };
//24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0130
  return (
    <div className="flex flex-col justify-center p-4 w-full bg-white border-b border-solid border-b-stone-300">
      <div className="flex flex-col w-full">
        <div className="flex flex-col w-full leading-none">
          <label
            htmlFor="etalaseName"
            className="text-sm font-semibold text-black"
          >
            {t('namaEtalase')}*
          </label>
          <div className="flex flex-col mt-3 w-full">
            {/* 24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0204, LB - 0208 */}
            <input
              id="etalaseName"
              type="text"
              value={name}
              onChange={handleNameChange}
              onFocus={() => setIsFocused(true)}
              onBlur={() => setIsFocused(false)}
              className={`flex-1 shrink gap-2 self-stretch px-3 py-2 w-full text-sm  font-semibold bg-white rounded-md border border-[#7B7B7B] text-black focus:outline-none focus:border-blue-600 focus:ring-blue-500 ${
                error ? 'border-red-500' : ''
              }`}
              placeholder={t('masukanNamaEtalase')}
              aria-label="Nama Etalase"
            />
            <div className="flex justify-between items-center mt-3">
              {error && errorMessage ? (
                <div className="text-xs text-[#7B7B7B]">
                  {errorMessage}
                </div>
              ) : (
                <div/>
              )}
              <div className={`text-xs font-medium whitespace-nowrap ${error ? 'text-red-500' : 'text-neutral-500'}`}>
                {counter}/80
              </div>
            </div>
          </div>
        </div>

        <div className="flex flex-col mt-6 w-full">
          <div className="flex gap-1 items-center self-start font-semibold text-black">
            <label className="self-stretch my-auto text-sm leading-none">
              {t('labelGambar')}
            </label>
            <span className="self-stretch my-auto text-xs leading-none">
              {t('labelOpsional')}
            </span>
          </div>
          <div className="flex gap-3 items-center mt-4 w-full text-xs leading-none">
            {/* {image || imageUrl ? (
              <div className="relative">
                <ImageComponent
                  src={getImageSrc(image) || imageUrl}
                  alt="Preview gambar etalase"
                  className="object-contain shrink-0 self-stretch my-auto rounded-md aspect-square w-[72px]"
                />
                <Button
                  type="button"
                  onClick={handleRemoveImage}
                  className="absolute top-0 right-0 bg-red-500 text-white rounded-full w-5  h-5 flex items-center justify-center text-xs"
                >
                  X
                </Button>
              </div>
            ) : (
              <></>
            )} */}

            <div className="flex flex-col flex-1 shrink self-stretch my-auto basis-0 min-w-[240px]">
              <MediaUploadOptions
                onImageUpload={handleImageUpload}
                image={image}
                imageUrl={imageUrl}
              />
              <div className="mt-3 font-medium text-neutral-500">
                {t('formatFile')}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};