// THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase 
// LB - 0182
"use client";
import React, { useState } from 'react';
import { useLanguage} from "@/providers/LanguageProvider";
import Button from '@/components/Button/Button';
import { KeywordNotFoundMessage } from '../components/keywordNotFoundMessage';
import ImageComponent from "@/components/ImageComponent/ImageComponent";

const ProductSkeleton = () => {
  return (
    <div className="animate-pulse">
      {[1, 2, 3].map((index) => (
        <div key={index} className="flex overflow-hidden gap-2.5 items-start px-4 py-3 w-full text-xs leading-none bg-white mb-2">
          <div className="flex flex-col flex-1 shrink w-full basis-0 min-w-[240px]">
            <div className="flex gap-3 items-start w-full">
              <div className="bg-gray-200 w-[68px] h-[68px] rounded"></div>
              <div className="flex flex-col flex-1 shrink basis-0 min-w-[240px]">
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                <div className="h-4 bg-gray-200 rounded w-1/4 mt-3"></div>
                <div className="h-4 bg-gray-200 rounded w-1/2 mt-3"></div>
                <div className="h-4 bg-gray-200 rounded w-1/2 mt-3"></div>
                <div className="h-4 bg-gray-200 rounded w-1/2 mt-3"></div>
                <div className="h-8 bg-gray-200 rounded w-full mt-4"></div>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};
//24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0226
export const ProductList = ({ 
  products = [], 
  onDeleteProduct,
  onAddProduct,
  loading = false
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeSearch, setActiveSearch] = useState('');
  const { t, currentLocale, changeLanguage, loading: langLoading } = useLanguage();

  const handleSearch = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      setActiveSearch(searchQuery);
    }
  };

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };

  const handleClearSearch = () => {
    setSearchQuery('');
    setActiveSearch('');
  };

  // New function to sort and filter products
  const getFilteredAndSortedProducts = () => {
    if (!activeSearch) return products;

    const query = activeSearch.toLowerCase();
    const nameMatches = [];
    const skuMatches = [];
    const brandMatches = [];

    products.forEach(product => {
      const name = product.name.toLowerCase();
      const sku = (product.sku || '').toLowerCase();
      const brand = (product.brand || '').toLowerCase();
      
      if (name.includes(query)) {
        nameMatches.push(product);
      } else if (sku.includes(query)) {
        skuMatches.push(product);
      } else if (brand.includes(query)) {
        brandMatches.push(product);
      }
    });

    // Sort each category alphabetically
    nameMatches.sort((a, b) => a.name.localeCompare(b.name));
    skuMatches.sort((a, b) => (a.sku || '').localeCompare(b.sku || ''));
    brandMatches.sort((a, b) => (a.brand || '').localeCompare(b.brand || ''));

    // Combine all matches in priority order
    return [...nameMatches, ...skuMatches, ...brandMatches];
  };

  // Replace existing filteredProducts with new implementation
  const filteredProducts = getFilteredAndSortedProducts();

  // Format price range
  const formatPrice = (price) => {
    if (!price) return 'Rp0';
    if (price.min === price.max) {
      return `Rp${price.min.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.')}`;
    }
    return `Rp${price.min.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.')} - Rp${price.max.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.')}`;
  };

  return (
    <div className="flex flex-col w-full">
      <div className="flex flex-col p-4 mt-2 w-full text-sm leading-none bg-white">
        <div className="flex gap-10 justify-between items-center w-full">
          <div className="gap-2 self-stretch my-auto font-bold text-black">
          {t('daftarProduk')}
          </div>
          <button 
            onClick={onAddProduct}
            className="self-stretch my-auto font-semibold text-[#176CF7]"
          >
            {t('labelTambah')}
          </button>
        </div>

        {/* Search Bar */}
        <div className="relative">
          <div 
            className={`flex gap-2 items-center px-3 py-2 mt-4 w-full font-semibold bg-white rounded-md border border-solid ${searchQuery ? 'border-blue-600' : 'border-neutral-500'} min-h-[32px] text-neutral-500 focus-within:border-blue-600 transition-colors`}
          >
            <div className="object-contain shrink-0 self-stretch my-auto w-4 aspect-square">
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <g clipPath="url(#clip0_95_11966)">
                  <path fillRule="evenodd" clipRule="evenodd" d="M7.29411 11.8596C4.37025 11.8596 2 9.50324 2 6.59649C2 3.68973 4.37025 1.33334 7.29411 1.33334C10.218 1.33334 12.5882 3.68973 12.5882 6.59649C12.5882 7.98629 12.0464 9.25028 11.1612 10.191L13.8453 13.5265C14.0888 13.8292 14.0395 14.2708 13.7351 14.5129C13.4306 14.755 12.9864 14.7059 12.7429 14.4033L10.0685 11.0799C9.26177 11.5744 8.31145 11.8596 7.29411 11.8596ZM7.29411 10.4561C9.43827 10.4561 11.1765 8.72811 11.1765 6.59649C11.1765 4.46487 9.43827 2.73684 7.29411 2.73684C5.14995 2.73684 3.41176 4.46487 3.41176 6.59649C3.41176 8.72811 5.14995 10.4561 7.29411 10.4561Z" fill="#555555"/>
                </g>
                <defs>
                  <clipPath id="clip0_95_11966">
                    <rect width="16" height="16" fill="white"/>
                  </clipPath>
                </defs>
              </svg>
            </div>
            <input
              type="text"
              value={searchQuery}
              onChange={handleSearchChange}
              onKeyPress={handleSearch}
              placeholder={t('cariNamaProduk')}
              className="flex-1 shrink self-stretch my-auto basis-0 bg-transparent border-none outline-none text-black placeholder-neutral-500"
            />
            {searchQuery && (
              <button
                onClick={handleClearSearch}
                className="shrink-0 self-stretch my-auto"
              >
                <ImageComponent
                  src="/icons/etalase/close-grey.svg"
                  alt="Clear search"
                  className="w-4 h-4"
                />
              </button>
            )}
          </div>
        </div>
      </div>

      {loading ? (
        <ProductSkeleton />
      ) : (
        <>
          {/* Empty State */}
          {filteredProducts.length === 0 && (
            <KeywordNotFoundMessage />
          )}

          {/* Product List */}
          <div className="flex gap-2.5 items-center mt-2 w-full">
            <div className="flex flex-col self-stretch my-auto w-full">
              {filteredProducts.map((product,index) => (
                <div 
                  key={product.id} 
                  className={`flex overflow-hidden gap-2.5 items-start px-4 py-3 w-full text-xs leading-none bg-white mb-2 ${index === filteredProducts.length - 1 ? '' : ''}`}
                >
                  <div className="flex flex-col flex-1 shrink w-full basis-0 min-w-[240px]">
                    <div className="flex gap-3 items-start w-full font-medium text-black">
                      <ImageComponent
                        src={product.imageUrl}
                        alt={product.name}
                        className="object-contain shrink-0 rounded aspect-square w-[68px]"
                      />
                      <div className="flex flex-col flex-1 shrink basis-0 min-w-[240px]">
                        <div className="text-sm font-bold leading-4 line-clamp-2">
                          {product.name}
                        </div>
                        <div className="mt-3 text-sm font-semibold">
                          {formatPrice(product.price)}
                        </div>
                        {/*24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0209,LB - 0212 */}
                        <div className="mt-3 text-ellipsis line-clamp-1 break-all">
                          {t('labelSKU')} : {product.sku || '-'}
                        </div>
                        <div className="mt-3 text-ellipsis line-clamp-1 break-all">
                          {t('labelBrand')} : {product.brand}
                        </div>
                        <div className="mt-3 text-ellipsis line-clamp-1 break-all">
                          {t('labelKategori')} : {product.category.name}
                        </div>
                        {/* Removed stock display */}
                      </div>
                    </div>
                    <Button
                      onClick={() => onDeleteProduct(product.id)}
                      color="error_secondary"
                      Class="w-full mt-4 max-w-full"
                    >
                      {t('labelHapus')}
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default ProductList;