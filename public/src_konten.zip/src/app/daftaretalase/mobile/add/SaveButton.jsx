import * as React from "react";
import { useLanguage} from "@/providers/LanguageProvider";
import Button from '@/components/Button/Button';
//24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0159
export const SaveButton = ({ onClick, disabled }) => {
  const { t, currentLocale, changeLanguage, loading: langLoading } = useLanguage();
  return (
    <div className="fixed bottom-0 left-0 right-0 w-full text-sm font-semibold leading-none text-white">
      <div className="flex flex-col w-full">
        <div className="flex gap-3 items-center px-4 py-3 w-full bg-white  shadow-2xl" style={{boxShadow: '0px -3px 55px 0px #00000029'}}>
          <Button
            onClick={onClick}
            disabled={disabled}
            color="primary"
            Class="w-full max-w-full"
          >
            {t('labelSimpan')}
          </Button>
        </div>
      </div>
    </div>
  );
};
