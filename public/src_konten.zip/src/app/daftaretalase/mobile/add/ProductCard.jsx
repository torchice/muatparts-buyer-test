import React from "react";
import ImageComponent from "@/components/ImageComponent/ImageComponent";
import Button from '@/components/Button/Button';
import { useLanguage } from "@/providers/LanguageProvider";

export const ProductCard = ({ name, price, sku, brand, category, image, onDelete }) => {
  const { t } = useLanguage();
  
  return (
    <div className="flex overflow-hidden gap-2.5 items-start px-4 py-3 w-full text-xs leading-none bg-white mb-2">
      <div className="flex flex-col flex-1 shrink w-full basis-0 min-w-[240px]">
        <div className="flex gap-3 items-start w-full font-medium text-black">
          <ImageComponent
            src={image || '/images/placeholder.png'}
            alt={name}
            width={68}
            height={68}
            className="object-contain shrink-0 rounded aspect-square"
          />
          <div className="flex flex-col flex-1 shrink basis-0 min-w-[240px]">
            <div className="text-sm font-bold leading-4 whitespace-nowrap text-ellipsis">
              {name}
            </div>
            <div className="mt-3 text-sm font-semibold">{price}</div>
            {sku && <div className="mt-3 text-ellipsis">{t('labelSKU')} : {sku}</div>}
            {brand && <div className="mt-3 text-ellipsis">{t('labelBrand')} : {brand}</div>}
            {category && (
              <div className="mt-3 text-ellipsis">{t('labelKategori')} : {category}</div>
            )}
          </div>
        </div>
        <Button
          onClick={onDelete}
          color="error_secondary"
          Class="w-full mt-4"
        >
          {t('labelHapus')}
        </Button>
      </div>
    </div>
  );
};
