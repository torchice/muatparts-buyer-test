// 24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase
// LB - 0129
// LB - 0133
import React from 'react';
import { useCustomRouter } from '@/libs/CustomRoute';
import { useLanguage } from "@/providers/LanguageProvider";
import ImageComponent from "@/components/ImageComponent/ImageComponent";
import Button from '@/components/Button/Button';

export const Header = ({ hasProducts, onReorder,onBack }) => {
  const router = useCustomRouter();
  const { t } = useLanguage();

  const handleBack = () => {
    router.push('/daftaretalase/mobile');
  };

  return (
    <div className="flex overflow-hidden relative gap-2.5 items-start px-4 py-3.5 pb-3 text-white bg-red-700 shadow-lg min-h-[62px] items-center">
      <div className="flex flex-1 shrink gap-2 items-center w-full basis-0 min-w-[240px] z-[10]">
        <button 
          onClick={onBack}
          className="flex items-center"
          aria-label={t('labelKembali')}
        >
          <ImageComponent
            src="/icons/etalase/mobile/back-arrow.svg"
            alt={t('labelKembali')}
            width={24}
            height={24}
            className="object-contain shrink-0 self-stretch my-auto aspect-square"
          />
        </button>

        <div className="flex gap-4 justify-between items-center self-stretch my-auto w-full">
          <div className="self-stretch my-auto text-base font-bold" style={{lineHeight: 'normal'}}>
            {t('tambahEtalase')}
          </div>
          {hasProducts && (
            
             <button
             onClick={onReorder}
             className="flex flex-col items-center self-stretch my-auto text-xs font-semibold leading-none text-center whitespace-nowrap w-[38px]"
             aria-label={t('labelSusun')}
           >
             <ImageComponent
               src="/icons/etalase/mobile/arrange.svg"
               alt={t('labelSusun')}
               width={24}
               height={24}
               className="object-contain aspect-square"
             />
             <div>{t('labelSusun')}</div>
           </button>
          )}
        </div>
      </div>

      <ImageComponent
        src="/icons/etalase/mobile/header-pattern.png"
        alt=""
        width={153}
        height={62}
        className="absolute right-0 bottom-0 z-0 shrink-0 aspect-[2.47]"
      />
    </div>
  );
};


