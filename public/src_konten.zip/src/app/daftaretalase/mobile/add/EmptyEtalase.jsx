import * as React from "react";
import { useLanguage } from "@/providers/LanguageProvider";
import Button from '@/components/Button/Button';
import ImageComponent from '@/components/ImageComponent/ImageComponent';

export const EmptyEtalase = ({ onAddProduct }) => {
  const { t } = useLanguage();
  // 24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase
  // LB - 0163
  // LB - 0159
  // LB - 0163
  return (
    <div className="flex flex-col justify-center items-center mt-2 text-sm font-semibold text-center bg-white w-full min-h-[248px] h-full ">
      <div className="flex flex-col max-w-full text-center items-center justify-center h-full">
      <ImageComponent
                src="/icons/etalase/mobile/data-not-found-mobile.png"
                width={93}
                height={93}
                alt={t('isiEtalasemu')}
                className=""
              />
        <div className="mt-[18px] text-lg text-center text-[#8e8e8e] font-semibold">
          {t('isiEtalasemu')}
        </div>
        <div className=" text-sm text-[#8e8e8e] w-[70%] font-medium">
          {t('pilihProdukYangSesuai')}
        </div>
        <Button
          onClick={onAddProduct}
          color="primary"
          Class="mt-3 mx-auto w-[50%]"
        >
          {t('pilihProduk')}
        </Button>
      </div>
    </div>
  );
};