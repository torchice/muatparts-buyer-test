import * as React from "react";
import Button from "@/components/Button/Button";
import ImageComponent from "@/components/ImageComponent/ImageComponent";

const BottomNavigationItem = ({ icon, label, onClick, isActive }) => {
  return (
    <Button
      onClick={onClick}
      color="primary_secondary"
      Class={`flex flex-col items-center pt-3.5 pr-3 pb-2 pl-3 min-h-[66px] w-[70px] focus:outline-none focus:border-blue-600 focus:ring-blue-500 rounded-lg transition-colors ${
        isActive ? "text-[#176CF7]" : "text-neutral-500"
      }`}
      aria-label={label}
      role="tab"
      aria-selected={isActive}
    >
      <div className="flex flex-col items-center w-full">
        <ImageComponent
          loading="lazy"
          src={icon}
          alt=""
          className="object-contain w-6 aspect-square"
          aria-hidden="true"
        />
        <div className="mt-2 text-xs font-medium">{label}</div>
      </div>
    </Button>
  );
};

export default BottomNavigationItem;