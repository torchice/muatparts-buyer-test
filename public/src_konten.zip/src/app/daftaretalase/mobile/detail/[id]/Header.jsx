// Header.jsx
import React from 'react';
import { useCustomRouter } from '@/libs/CustomRoute';
import { useLanguage } from "@/providers/LanguageProvider";
import ImageComponent from "@/components/ImageComponent/ImageComponent";
import Button from "@/components/Button/Button";

export const Header = () => {
  const router = useCustomRouter();
  const { t } = useLanguage();

  return (
    <div className="flex overflow-hidden relative gap-2.5 items-start px-4 py-3.5 text-base font-bold text-white bg-red-700 shadow-lg min-h-[62px]">
      <div className="flex z-0 gap-2 items-center min-h-[34px] min-w-[240px] w-[328px]">
        <button onClick={() => router.push('/daftaretalase/mobile')}>
          <ImageComponent
            src="/icons/etalase/mobile/back-arrow.svg"
            alt={t('labelKembali')}
            width={24}
            height={24}
            className="object-contain shrink-0 self-stretch my-auto aspect-square"
          />
        </button>
        <div className="gap-4 self-stretch my-auto">{t('detailEtalase')}</div>
      </div>
      <ImageComponent
        src="/icons/etalase/header-pattern.png"
        alt=""
        width={153}
        height={62}
        className="object-contain absolute right-0 bottom-0 z-0 shrink-0 aspect-[2.47]"
      />
    </div>
  );
};