// components/SearchFilter.jsx
import React, { useState, useEffect } from "react";
import { useCustomRouter } from '@/libs/CustomRoute';
import { useLanguage } from "@/providers/LanguageProvider";
import useFilterStore from '@/store/zustand/filterstore';
import ImageComponent from "@/components/ImageComponent/ImageComponent";
import Button from "@/components/Button/Button";

export const SearchFilter = ({ 
  searchValue = '', 
  onSearch, 
  showFilterButton = true,
  activeFilterCount = 0,
  onClearFilter,
  etalaseId,
  filteredProducts,
  lastActivity='',
}) => {
  const router = useCustomRouter();
  const { t } = useLanguage();
  const { selectedFilters, searchValue: storedSearchValue, setSearchValue } = useFilterStore();
  const [localSearchValue, setLocalSearchValue] = useState(storedSearchValue || searchValue);
  const isSearchDisabled = (filteredProducts.length === 0 && lastActivity === 'filter' && searchValue==='') || (filteredProducts.length === 0 && lastActivity === null && searchValue==='');
  const isFilterDisabled = (filteredProducts.length === 0 && lastActivity === 'search' && activeFilterCount===0) || (filteredProducts.length === 0 && lastActivity === null && activeFilterCount===0);

  // Sync local state with store
  useEffect(() => {
    setLocalSearchValue(storedSearchValue || searchValue);
  }, [storedSearchValue, searchValue]);

  useEffect(() => {
    console.log('isSearchDisabled', isSearchDisabled);
    console.log('isFilterDisabled', isFilterDisabled);
    console.log('lastActivity', lastActivity);
    console.log('filteredProducts.length', filteredProducts.length);
  }, [isSearchDisabled, isFilterDisabled]);

  const handleSearchChange = (e) => {
    const value = e.target.value;
    setLocalSearchValue(value);
  };

  const handleReset = () => {
    setLocalSearchValue('');
    setSearchValue('');
    onSearch('');
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      setSearchValue(localSearchValue);
      onSearch(localSearchValue);
    }
  };

  const handleFilterClick = () => {
    const filterUrl = etalaseId 
      ? `/daftaretalase/mobile/filter?etalaseId=${etalaseId}`
      : '/daftaretalase/mobile/filter';
    router.push(filterUrl);
  };

  

  return (
    <div className="flex flex-col p-4 w-full text-sm bg-white border-b border-solid border-b-stone-300">
      <div className="flex gap-10 justify-between items-center w-full text-black max-w-full">
        <div className={`gap-2 self-stretch my-auto font-bold ${filteredProducts.length === 0 ? 'text-[#838383]' : ''}`}>
          {t('daftarProduk')}
        </div>
        {showFilterButton && (
          <button 
            className={`rounded-full p-[8px] ${isFilterDisabled ? 'opacity-50 cursor-not-allowed bg-[#F1F1F1]' : (activeFilterCount > 0 
              ? 'bg-[#E2F2FF] border border-[#1770F7]' 
              : 'bg-[#F1F1F1]')}`}
            onClick={handleFilterClick}
            disabled={isFilterDisabled}
          >
            <div className="flex gap-2 items-center">
              <div className={ isFilterDisabled ? 'text-[#838383]' :( activeFilterCount > 0 ? 'text-[#1770F7]' :'')}>
                {t('labelFilter')}
              </div>
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                <g clipPath="url(#clip0_95_14277)">
                  <path 
                    d="M8.29608 3.75947C9.01196 3.75947 9.59229 3.17914 9.59229 2.46327C9.59229 1.74739 9.01196 1.16706 8.29608 1.16706C7.58021 1.16706 6.99988 1.74739 6.99988 2.46327C6.99988 3.17914 7.58021 3.75947 8.29608 3.75947Z" 
                    stroke={isFilterDisabled ? "#838383" : activeFilterCount > 0 ? "#1770F7" : "black"} 
                    strokeLinecap="round" 
                    strokeLinejoin="round"
                  />
                  <path 
                    d="M8.9447 12.833C9.66058 12.833 10.2409 12.2526 10.2409 11.5368C10.2409 10.8209 9.66058 10.2406 8.9447 10.2406C8.22883 10.2406 7.6485 10.8209 7.6485 11.5368C7.6485 12.2526 8.22883 12.833 8.9447 12.833Z" 
                    stroke={isFilterDisabled ? "#838383" : activeFilterCount > 0 ? "#1770F7" : "black"}
                    strokeLinecap="round" 
                    strokeLinejoin="round"
                  />
                  <path 
                    d="M4.40747 8.29613C5.12335 8.29613 5.70368 7.7158 5.70368 6.99993C5.70368 6.28405 5.12335 5.70372 4.40747 5.70372C3.6916 5.70372 3.11127 6.28405 3.11127 6.99993C3.11127 7.7158 3.6916 8.29613 4.40747 8.29613Z" 
                    stroke={isFilterDisabled ? "#838383" : activeFilterCount > 0 ? "#1770F7" : "black"}
                    strokeLinecap="round" 
                    strokeLinejoin="round"
                  />
                  <path 
                    d="M1.16696 2.46333H6.99989M9.5928 2.46333H12.8333M1.16696 6.99999H3.11127M5.70419 6.99999H12.8333M1.16696 11.5367H7.64799M10.2399 11.5367H12.8323" 
                    stroke={isFilterDisabled ? "#838383" : activeFilterCount > 0 ? "#1770F7" : "black"}
                    strokeLinecap="round" 
                    strokeLinejoin="round"
                  />
                </g>
                <defs>
                  <clipPath id="clip0_95_14277">
                    <rect width="14" height="14" fill="white"/>
                  </clipPath>
                </defs>
              </svg>
            </div>
          </button>
        )}
      </div>

      <div className="relative mt-4">
        <input
          type="text"
          value={localSearchValue}
          placeholder={t('cariNamaProdukSKU')}
          onChange={handleSearchChange}
          onKeyPress={handleKeyPress}
          disabled={isSearchDisabled}
          className={`flex w-full pl-10 pr-8 py-2 text-sm font-medium rounded-md border border-gray-300 focus:outline-none focus:border-blue-600 focus:ring-blue-500 ${isSearchDisabled ? 'bg-gray-100 text-[#838383]' : 'bg-white'}`}
        />
        {/* Icon Search */}
        <div className="absolute left-3 top-1/2 -translate-y-1/2">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M7.33333 12.6667C10.2789 12.6667 12.6667 10.2789 12.6667 7.33333C12.6667 4.38781 10.2789 2 7.33333 2C4.38781 2 2 4.38781 2 7.33333C2 10.2789 4.38781 12.6667 7.33333 12.6667Z" stroke={filteredProducts.length === 0 ? "#838383" : "#666666"} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M14 14L11 11" stroke={filteredProducts.length === 0 ? "#838383" : "#666666"} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
        {/* Reset button */}
        {localSearchValue && (
          <button
            onClick={handleReset}
            disabled={isSearchDisabled}
            className={`absolute right-3 top-1/2 -translate-y-1/2 ${isSearchDisabled ? 'text-[#838383] cursor-not-allowed' : 'text-[#7b7b7b] hover:text-gray-700'}`}
          >
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M13 1L1 13" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M1 1L13 13" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>
        )}
      </div>
    </div>
  );
};