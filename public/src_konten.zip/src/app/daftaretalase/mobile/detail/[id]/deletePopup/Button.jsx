import * as React from "react";
import { useLanguage } from "@/providers/LanguageProvider";


export function Button({ children, variant = "primary", onClick }) {
  const { t } = useLanguage();
  const baseStyles =
    "gap-1 self-stretch px-6 py-2.5 text-xs font-semibold leading-none rounded-3xl min-h-[28px] min-w-[112px]";

  const variants = {
    primary: "text-white bg-blue-600",
    outline: "text-[#176CF7] bg-white border border-blue-600 border-solid",
  };

  return (
    <Button
      onClick={onClick}
      className={`${baseStyles} ${variants[variant]}`}
      type="button"
    >
      {children}
    </Button>
  );
}
