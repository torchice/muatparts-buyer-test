import * as React from "react";
import { useLanguage } from "@/providers/LanguageProvider";
// import { Button } from "./Button";
import Button from "@/components/Button/Button";

export default function DeleteShowcaseModal() {
  const { t } = useLanguage();

  return (
    <div className="flex flex-col mx-auto w-full max-w-[480px]">
      <div className="flex flex-col w-full">
        <div className="text-base font-bold">
          {t('hapusEtalase')}
        </div>
        <div className="mt-4 text-sm">
          {t('konfirmasiHapusEtalase')}
        </div>
        <div className="flex gap-2">
          <Button color="primary_secondary" >{t('labelBatal')}</Button>
          <Button color="primary">{t('labelHapus')}</Button>
        </div>
      </div>
    </div>
  );
}
