import React from 'react';
import { useLanguage } from "@/providers/LanguageProvider";
import CustomModal from '@/components/Modal/CustomModal';

export const DeleteModal = ({ show, onClose, onConfirm }) => {
  const { t } = useLanguage();

  return (
    <CustomModal
      isOpen={show}
      onClose={onClose}
      onConfirm={onConfirm}
      title={t('hapusEtalase')}
      message={t('konfirmasiHapusEtalase')}
      confirmText={t('labelYaHapus')}
      cancelText={t('labelBatal')}
      confirmTextColor="text-white"
      showCloseIcon={true}
    />
  );
};