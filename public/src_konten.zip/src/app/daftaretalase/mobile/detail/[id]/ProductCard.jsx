// ProductCard.jsx
import React from "react";
import { useLanguage } from "@/providers/LanguageProvider";
import ImageComponent from "@/components/ImageComponent/ImageComponent";

const formatNumber = (num) => {
  if (!num && num !== 0) return "-";
  return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
};

const getBrandDisplay = (brand) => {
  if (!brand) return '-';
  if (typeof brand === 'string') return brand;
  return brand.name || '-';
};
//24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0226
const ProductCardSkeleton = () => {
  return (
    <div className="flex overflow-hidden gap-2.5 items-start px-4 py-3 mt-2 w-full bg-white animate-pulse">
      <div className="flex flex-col flex-1 shrink w-full basis-0 min-w-[240px]">
        <div className="flex gap-3 items-start w-full">
          <div className="bg-gray-200 w-[68px] h-[68px] rounded-md"></div>
          <div className="flex flex-col flex-1 shrink basis-0 min-w-[240px]">
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/4 mt-3"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2 mt-3"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2 mt-3"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2 mt-3"></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export const ProductCard = ({ 
  name, 
  price, 
  sku = "-", 
  brand, 
  category, 
  image,
  stock,
  loading = false
}) => {
  const { t } = useLanguage();

  if (loading) {
    return <ProductCardSkeleton />;
  }

  return (
    <div className="flex overflow-hidden gap-2.5 items-start px-4 py-3 mt-2 w-full bg-white">
      <div className="flex flex-col flex-1 shrink w-full basis-0 min-w-[240px]">
        <div className="flex gap-3 items-start w-full">
          <ImageComponent
            src={image}
            alt={name}
            width={68}
            height={68}
            className="object-contain shrink-0 rounded-md aspect-square"
          />
          <div className="flex flex-col flex-1 shrink basis-0 min-w-[240px]">
            <div className="text-sm font-bold  text-ellipsis line-clamp-2">
              {name}
            </div>
            <div className="mt-3 text-sm font-semibold">{formatNumber(price)}</div>
            <div className="mt-3 text-ellipsis line-clamp-1 break-all">
              {t('labelSKU')} : {sku}
            </div>
            <div className="mt-3 text-ellipsis line-clamp-1 break-all">
              {t('labelBrand')} : {getBrandDisplay(brand)}
            </div>
            <div className="mt-3 text-ellipsis line-clamp-1 break-all">
              {t('labelKategori')} : {category}
            </div>
            {/* {stock !== undefined && (
              <div className="mt-3 text-ellipsis">
                {t('labelStok')}: {stock === 0 ? t('stokHabis') : stock}
              </div>
            )} */}
          </div>
        </div>
      </div>
    </div>
  );
};