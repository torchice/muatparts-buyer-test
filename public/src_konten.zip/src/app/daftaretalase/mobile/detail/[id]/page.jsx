// app/daftaretalase/mobile/detail/[id]/page.jsx
// THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase 
// LB - 0126
// LB - 0128
// LB - 0183
// LB - 0184
// LB - 0185
// LB - 0188
// LB - 0194

"use client";
import React, { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation'; 
import { MockServer_TambahEtalase } from '@/services/MockServer_TambahEtalase';
import { Loading } from '@/components/Loading/Loading';
import Toast from '@/components/Toast/Toast';
import { Header } from '../../components/Header';
import { ProductCard } from './ProductCard';
import { SearchFilter } from './SearchFilter';
import { DeleteModal } from './DeleteModal';
import useFilterStore from '@/store/zustand/filterstore';
import { useLanguage } from "@/providers/LanguageProvider";
import useEtalaseStore from '@/store/zustand/etalasestore';
import useSusunProdukStore from '@/store/susunProdukStore';
import toast from "@/store/zustand/toast";
import ImageComponent from "@/components/ImageComponent/ImageComponent";
import { useCustomRouter } from '@/libs/CustomRoute';
import { KeywordNotFoundMessage } from '../../components/keywordNotFoundMessage';
import NotFoundFilter from '../../pilihproduk/filternotfound/NotFoundFilter';
import Button from "@/components/Button/Button";

// Move NoProductsMessage outside the main component
const NoProductsMessage = ({ t }) => (
  <div className="flex items-center justify-center mt-2 bg-white min-h-[calc(100vh-200px)]">
    <div className="flex flex-col items-center w-[328px] gap-3">
      <ImageComponent
        src="/icons/etalase/mobile/data-not-found.png"
        width={93}
        height={93}
        alt={t('belumAdaProduk')}
      />
      <span className="text-[#7B7B7B] text-base font-semibold text-center">
        {t('belumAdaProduk')}
      </span>
      <p className="text-[#7B7B7B] text-xs font-medium text-center">
        {t('Kamu tetap bisa membuat etalase')}
        <br />
        {t('meskipun belum memiliki produk!')}
      </p>
    </div>
  </div>
);

export default function DetailShowcase() {
  // 1. All hooks declarations
  const { t } = useLanguage();
  const router = useCustomRouter();
  const params = useParams();
  const { selectedFilters, searchValue: storedSearchValue, setSearchValue, lastActivity, setLastActivity, resetLastActivity } = useFilterStore();
  const { products, setProducts } = useSusunProdukStore();  // Add this line to get products state
  const { showToast, setShowToast, setDataToast } = toast();
  
  // 2. All state declarations together
  const [etalase, setEtalase] = useState(null);
  const [searchQuery, setSearchQuery] = useState(storedSearchValue || '');
  const [isLoading, setIsLoading] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [brands, setBrands] = useState([]);
  const [brandMapping, setBrandMapping] = useState({});
  const [emptyStateSource, setEmptyStateSource] = useState(null);

  const etalaseId = params?.id;

  // 3. Computed values
  const filteredProducts = filterProducts();
  const activeFilterCount = 
    (selectedFilters?.categories?.length || 0) + 
    (selectedFilters?.brands?.length || 0);

  // 4. All useEffects together
  useEffect(() => {
    if (filteredProducts.length === 0) {
      if (searchQuery && lastActivity!=='filter') {
        setEmptyStateSource('search');
      } else if (selectedFilters.categories?.length > 0 || selectedFilters.brands?.length > 0) {
        setEmptyStateSource('filter');
      } else {
        setEmptyStateSource(null);
      }
    } else {
      setEmptyStateSource(null);
    }
  }, [filteredProducts.length, searchQuery, selectedFilters.categories, selectedFilters.brands]);

  useEffect(() => {
    const loadEtalaseData = async () => {
      if (!etalaseId) return;

      try {
        setIsLoading(true);
        const [etalaseResponse, brandsResponse] = await Promise.all([
          MockServer_TambahEtalase.getEtalaseDetail(etalaseId),
          MockServer_TambahEtalase.getBrandFilter('', etalaseId)
        ]);

        if (etalaseResponse?.data) {
          setEtalase(etalaseResponse.data);
        }

        if (brandsResponse?.data?.brands) {
          const brands = brandsResponse.data.brands;
          setBrands(brands);
          
          // Buat mapping brand name ke id
          const mapping = brands.reduce((acc, brand) => {
            acc[brand.name] = brand.id;
            return acc;
          }, {});
          setBrandMapping(mapping);
        }

        // Load products setelah mapping siap
        const productsResponse = await MockServer_TambahEtalase.getEtalaseProducts(etalaseId, {});
        if (productsResponse?.message?.code === 200) {
          setProducts(productsResponse.data.products || []);
        }

      } catch (error) {
        console.error('Error loading data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadEtalaseData();
  }, [etalaseId]);

  // Add this to debug filter state
  useEffect(() => {
    console.log('Current filter state:', selectedFilters);
  }, [selectedFilters]);

  // Tambahkan useEffect untuk debug products dan brands
  useEffect(() => {
    console.log('Products data structure:', products.map(p => ({
      id: p.id,
      brand: p.brand,
      brandId: typeof p.brand === 'object' ? p.brand.id : p.brand
    })));
    
    console.log('Brands data structure:', brands.map(b => ({
      id: b.id,
      name: b.name
    })));
  }, [products, brands]);

  // Clear lastActivity when leaving detail page
  useEffect(() => {
    console.log(lastActivity, 'last activity')
    return () => {
      if (!window.location.pathname.includes('/filter')) {
        resetLastActivity();
      }
    };
  }, []);

  // 5. Handler functions
  function filterProducts() {
    let filteredItems = [...products];
    console.log('Starting filter with:', {
      totalProducts: filteredItems.length,
      filters: selectedFilters,
      products: filteredItems
    });

    if (selectedFilters.categories?.length > 0) {
      console.log('Applying category filter:', selectedFilters.categories);
      filteredItems = filteredItems.filter(product => 
        selectedFilters.categories.includes(product.category.id)
      );
      console.log('After category filter:', filteredItems.length);
    }

    if (selectedFilters.brands?.length > 0) {
      console.log('Applying brand filter:', selectedFilters.brands);
      filteredItems = filteredItems.filter(product => {
        // Get correct brand ID whether it's an object or string
        const productBrandId = typeof product.brand === 'object' 
          ? product.brand.id 
          : brandMapping[product.brand] || product.brand;

        const isIncluded = selectedFilters.brands.includes(productBrandId);
        
        console.log('Product brand check:', {
          productId: product.id,
          brandName: product.brand,
          mappedBrandId: productBrandId,
          isIncluded
        });
        
        return isIncluded;
      });
      console.log('After brand filter:', filteredItems.length);
    }

    // Existing search logic
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      const nameMatches = [];
      const skuMatches = [];
      const brandMatches = [];

      filteredItems.forEach(product => {
        const name = product.name.toLowerCase();
        const sku = (product.sku || '').toLowerCase();
        const brand = (product.brand || '').toLowerCase();
        
        if (name.includes(query)) {
          nameMatches.push(product);
        } else if (sku.includes(query)) {
          skuMatches.push(product);
        } else if (brand.includes(query)) {
          brandMatches.push(product);
        }
      });

      // Sort each category alphabetically by their respective values
      nameMatches.sort((a, b) => a.name.localeCompare(b.name));
      skuMatches.sort((a, b) => (a.sku || '').localeCompare(b.sku || ''));
      brandMatches.sort((a, b) => (a.brand || '').localeCompare(b.brand || ''));

      // Combine results in priority order
      filteredItems = [...nameMatches, ...skuMatches, ...brandMatches];
    }

    console.log('Final filtered products:', filteredItems.length);
    return filteredItems;
  }

  const handleDeleteEtalase = async () => {
    try {
      setIsLoading(true);
      const response = await MockServer_TambahEtalase.deleteEtalase(etalaseId);
      if (response.message.code === 200) {
        
        
        await new Promise((resolve) => {
          setShowDeleteModal(false);
          resolve();
        });
        router.push('/daftaretalase/mobile')
        // LB - 0188
        localStorage.setItem('showToast', 'true');
        localStorage.setItem('toastMessage', t('berhasilMenghapusEtalase'));
        localStorage.setItem('toastType', 'success');
        // setTimeout(() => {
        //   setDataToast({
        //     type: 'success',
        //     message: t('berhasilMenghapusEtalase')
        //   });
        //   setShowToast(true);
        // }, 100);
      }
    } catch (error) {
      setDataToast({
        type: 'error',
        message: t('gagalMenghapusEtalase')
      });
      setShowToast(true);
    } finally {
      setIsLoading(false);
    }
  };

  const handleEditClick = () => {
    // Set source route di localStorage
    localStorage.setItem('etalaseSourceRoute', 'detail');
    // Navigate dengan query param
    router.push(`/daftaretalase/mobile/edit/${etalaseId}?from=detail`);
  };

  const handleBack = () => {
    // Reset filters in localStorage
    localStorage.removeItem('filterData');
    localStorage.removeItem('sortData'); 
    useFilterStore.getState().resetFilters();
    useFilterStore.getState().resetSearch();
    // Navigate back
    router.push('/daftaretalase/mobile');
  }

  const handleSearch = (value) => {
    setSearchQuery(value);
    setSearchValue(value); // This will also set lastActivity to 'search'
  };

  // 24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase
  const handleFilter = () => {
    const filterUrl = etalaseId 
    ? `/daftaretalase/mobile/filter?etalaseId=${etalaseId}`
    : '/daftaretalase/mobile/filter';
  router.push(filterUrl);
  };


  const formatPrice = (price) => {
    if (!price) return 'Rp0';
    if (typeof price === 'object') {
      if (price.min === price.max) {
        return `Rp${price.min.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.')}`;
      }
      return `Rp${price.min.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.')} - Rp${price.max.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.')}`;
    }
    return `Rp${Number(price).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.')}`;
  };

  // 6. Loading state check
  if (isLoading) {
    return (
      <div className="flex flex-col mx-auto w-full max-w-[480px] min-h-screen bg-white">
        {/* <Loading /> */}
      </div>
    );
  }

  // 7. Main render
  return (
    <div className="flex flex-col w-full h-screen bg-zinc-100">
      {/* Fixed header */}
      <div className="w-full bg-white fixed top-0 left-0 right-0 z-10">
        <Header 
          title={t('detailEtalase')}
          showArrangeIcon={false} 
          onBack={handleBack}
        />
      </div>

      {/* Scrollable content container */}
       {/*24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0153 */}
      <div className="flex-1 overflow-y-auto mt-[56px] ">
        <div className="pb-4"> {/* Added padding bottom for better scroll experience */}
          {etalase && (
            <div className="flex gap-3 p-4 bg-white min-h-[104px] mb-2">
              {etalase.isDefault ? (
                <ImageComponent
                  src='/icons/etalase/semua_produk.png'
                  alt={etalase.name}
                  className="object-cover shrink-0 self-start w-[72px] h-[72px] rounded-md aspect-square"
                />
              ) : etalase.imageUrl ? (
                <ImageComponent
                  src={etalase.imageUrl}
                  alt={etalase.name}
                  width={72}
                  height={72}
                  className="object-cover shrink-0 self-start rounded-md aspect-square"
                />
              ) : (
                <div className="flex overflow-hidden flex-col justify-center items-center self-start w-[72px] h-[72px] bg-white rounded-md">
                  <ImageComponent
                    src="/icons/etalase/Daftar Etalase.svg"
                    alt=""
                    width={72}
                    height={72}
                    className="object-contain aspect-square"
                    aria-hidden="true"
                  />
                </div>
              )}
              <div className="flex flex-col flex-1 shrink pt-3 basis-0 min-w-[240px]">
                <div className="text-base font-bold text-black">
                  {etalase.name}
                </div>
                {!etalase.isDefault && (
                  <div className="flex gap-[5px] items-center mt-4 w-full text-xs font-semibold">
                    <Button 
                      onClick={() => setShowDeleteModal(true)}
                      color="error_secondary"
                      Class="gap-1 self-stretch px-6 py-2.5 my-auto w-full text-red-500 whitespace-nowrap bg-white rounded-3xl border border-red-500 border-solid min-h-[28px] sm:max-w-full"
                    >
                      {t('hapusEtalase')}
                    </Button>
                    <Button 
                      onClick={handleEditClick}
                      color="primary_secondary"
                      Class="gap-1 self-stretch px-6 py-2.5 my-auto w-full text-blue-600 whitespace-nowrap bg-white rounded-3xl border border-blue-600 border-solid min-h-[28px] min-w-[112px] sm:max-w-full"
                    >
                      {t('labelUbah')}
                    </Button>
                  </div>
                )}
              </div>
            </div>
          )}

          <SearchFilter 
            searchValue={searchQuery}
            onSearch={handleSearch}
            showFilterButton={true}
            activeFilterCount={activeFilterCount}
            onClearFilter={() => {
              useFilterStore.getState().resetFilters();
              useFilterStore.getState().resetSearch();
            }}
            etalaseId={etalaseId}
            filteredProducts={filteredProducts}
            lastActivity={emptyStateSource}
          />

          <div className="flex flex-col w-full">
            {filteredProducts.length > 0 ? (
              filteredProducts.map(product => (
                <ProductCard
                  key={product.id}
                  name={product.name}
                  price={formatPrice(product.price)}
                  sku={product.sku || '-'}
                  brand={product.brand}
                  category={product.category.name}
                  image={product.imageUrl}
                  stock={product.stock}
                  loading={isLoading}
                />
              ))
            ) : (
              searchQuery && emptyStateSource === 'search' ? (
                <KeywordNotFoundMessage />
              ) : emptyStateSource === 'filter' ? (
                //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0227
                <NotFoundFilter onFilterClick={handleFilter} />
              ) : (
                <NoProductsMessage t={t} />
              )
            )}
          </div>
        </div>
      </div>

      <Toast />
      
      {etalase && !etalase.isDefault && (
        <DeleteModal 
          show={showDeleteModal}
          onClose={() => setShowDeleteModal(false)}
          onConfirm={handleDeleteEtalase}
        />
      )}
    </div>
  );
}