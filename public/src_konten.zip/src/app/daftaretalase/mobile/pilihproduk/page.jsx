// THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase 
// LB - 0152
"use client";
import React, { useState, useEffect } from 'react';
import { useCustomRouter } from '@/libs/CustomRoute';
import { MockServer_TambahEtalase } from '@/services/MockServer_TambahEtalase';
import useSusunProdukStore from '@/store/susunProdukStore';
import useFilterStore from '@/store/zustand/filterstore';
import { KeywordNotFoundMessage } from '../components/keywordNotFoundMessage';
import NotFoundFilter from './filternotfound/NotFoundFilter'; // Make sure this line is correct
import ProductCard from './ProductCard';
import SearchBar from './SearchBar';
import { Header } from '../components/Header';
import { useLanguage } from "@/providers/LanguageProvider";
import CustomModal from '@/components/Modal/CustomModal';
import ImageComponent from "@/components/ImageComponent/ImageComponent";
import ProductSkeleton from './components/ProductSkeleton';
import Button from "@/components/Button/Button";
import {SaveButton} from '../add/SaveButton'



const NoProductsMessage = ({ t }) => (
  <div className="flex items-center justify-center min-h-[calc(100vh-200px)]"> {/* Adjust height as needed */}
    <div className="flex flex-col items-center w-[328px] gap-3">
      <ImageComponent
        src="/icons/etalase/mobile/data-not-found.png"
        width={93}
        height={93}
        alt={t('isiEtalasemu')}
      />
      <span className="text-[#7B7B7B] text-base font-semibold text-center">
        {t('belumAdaProduk')}
      </span>
      <p className="text-[#7B7B7B] text-xs font-medium text-center">
        {t('Kamu tetap bisa membuat etalase')}
        <br />
        {t('meskipun belum memiliki produk!')}
      </p>
    </div>
  </div>
);

const PilihProdukPage = () => {
  const { t } = useLanguage();
  const router = useCustomRouter();
  const { products: storeProducts, setProducts, existingProducts } = useSusunProdukStore();
  const { selectedFilters } = useFilterStore();

  // Local states
  const [products, setLocalProducts] = useState([]);
  const [selectedProducts, setSelectedProducts] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [etalaseId, setEtalaseId] = useState('');
  const [showLeaveModal, setShowLeaveModal] = useState(false);
  const [isFilterActive, setIsFilterActive] = useState(false);
  const [masterProducts, setMasterProducts] = useState([]);
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [emptyStateSource, setEmptyStateSource] = useState(null); // 'filter' or 'search'
  const [allProducts, setAllProducts] = useState([]); // Tambahkan state untuk semua produk
const [activeFilters, setActiveFilters] = useState({ categories: [], brands: [] });
  // Modified initialization of selected products
  useEffect(() => {
    const productsFromStore = storeProducts || [];
    const savedSelectedProducts = JSON.parse(localStorage.getItem('selectedProducts') || '[]');
    const savedActiveFilters = JSON.parse(localStorage.getItem('activeFilters') || '{"categories": [], "brands": []}');
    setActiveFilters(savedActiveFilters);
    if (savedSelectedProducts.length > 0) {
      setSelectedProducts(savedSelectedProducts);
    } else if (productsFromStore.length > 0) {
      setSelectedProducts(productsFromStore.map(p => p.id));
    }

    if (productsFromStore.length > 0) {
      setLocalProducts(prevProducts => {
        if (prevProducts.length === 0) {
          return productsFromStore;
        }
        return prevProducts;
      });
    }
  }, [storeProducts]);

  // Modified useEffect for etalaseId
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const id = params.get('etalaseId');
    if (id) {
      setEtalaseId(id);
      // Don't need to call fetchProducts here as it will be triggered by dependency array
    }
  }, []);

  // Add effect to load searchTerm from localStorage
  useEffect(() => {
    const savedSearch = localStorage.getItem('pilihProdukSearch');
    if (savedSearch) {
      setSearchTerm(savedSearch);
      // localStorage.removeItem('pilihProdukSearch'); // Clear after loading
    }
  }, []);

  // Modify sorting logic in useEffect for fetching products
  useEffect(() => {
    const controller = new AbortController();
    setIsLoading(true);
    const fetchAndMergeProducts = async () => {
      try {
        setIsLoading(true);
        const params = {
          search: searchTerm, // Search term included in API params
          ...(selectedFilters.categories.length > 0 && {
            categoryId: selectedFilters.categories.join(',')
          }),
          ...(selectedFilters.brands.length > 0 && {
            brandId: selectedFilters.brands.join(',')
          }),
          ...(etalaseId && { etalaseId })
        };
        
        const response = await MockServer_TambahEtalase.getProductList(params);
        
        if (!controller.signal.aborted) {
          const newProducts = response.data.products;
          
          // Update master products untuk tampilan
          setMasterProducts(newProducts);
          setLocalProducts(newProducts);
          
          // Update allProducts dengan menggabungkan produk baru
          setAllProducts(prevAll => {
            const existingIds = new Set(prevAll.map(p => p.id));
            const newUniqueProducts = newProducts.filter(p => !existingIds.has(p.id));
            return [...prevAll, ...newUniqueProducts];
          });
          console.log('allProducts', allProducts)
          console.log('test', allProducts)

          // Determine the source of the empty state (search or filter) and update the emptyStateSource accordingly
          if (newProducts.length === 0) {
            if (searchTerm && !localStorage.getItem('pilihProdukSearch')) {
              setEmptyStateSource('search');
            } else if (selectedFilters.categories.length > 0 || selectedFilters.brands.length > 0 || localStorage.getItem('pilihProdukSearch')) {
              setEmptyStateSource('filter');
              
            } else {
              setEmptyStateSource(null);
            }
            if (searchTerm && localStorage.getItem('pilihProdukSearch')){
              localStorage.removeItem('pilihProdukSearch')
            }
          } else {
            setEmptyStateSource(null);
          }
        }
      } catch (error) {
        if (!controller.signal.aborted) {
          console.error('Error fetching products:', error);
        }
      } finally {
        if (!controller.signal.aborted) {
          setIsLoading(false);
        }
      }
    };

    // Add debounce for search
    const timeoutId = setTimeout(() => {
      fetchAndMergeProducts();
    }, 300); // 300ms delay

    return () => {
      controller.abort();
      clearTimeout(timeoutId);
    };
  }, [selectedFilters, etalaseId, searchTerm]); // Include searchTerm in dependencies

  // Remove the separate search effect since it's now handled in the API call
  // useEffect(() => {
  //   const filteredProducts = masterProducts.filter(...)
  //   setLocalProducts(filteredProducts);
  // }, [searchTerm, masterProducts]);

  useEffect(() => {
    const hasActiveFilters = selectedFilters.categories.length > 0 || selectedFilters.brands.length > 0;
    const hasNoResults = products.length === 0;
    setIsFilterActive(hasActiveFilters && hasNoResults);
  }, [products.length, selectedFilters]);

  const handleSearch = (value) => {
    setSearchTerm(value);
  };

  // Modified handleFilter
  const handleFilter = () => {
    localStorage.setItem('selectedProducts', JSON.stringify(selectedProducts));
    localStorage.setItem('pilihProdukSearch', searchTerm); // Save search term
    const filterUrl = etalaseId 
      ? `/daftaretalase/mobile/filter?etalaseId=${etalaseId}`
      : '/daftaretalase/mobile/filter';
    router.push(filterUrl);
  };

  // Modified handleSelect
  const handleSelect = (product) => {
    setSelectedProducts(prev => {
      const newSelection = prev.includes(product.id)
        ? prev.filter(id => id !== product.id)
        : [...prev, product.id];
      localStorage.setItem('selectedProducts', JSON.stringify(newSelection));
      return newSelection;
    });
  };

  // Modify handleSave to use allProducts
  //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0210
  const handleSave = () => {
    // Get full product details from allProducts for all selected IDs
    const selectedProductDetails = allProducts.filter(p => 
      selectedProducts.includes(p.id)
    );

    // Filter out existingProducts that are not in selectedProductDetails
    const existingProductIds = existingProducts.filter(existingProduct => 
      !selectedProductDetails.some(selectedProduct => selectedProduct.id === existingProduct.id)
    );
    console.log('selectedProductDetails',selectedProductDetails)
    console.log('existingProductIds',existingProductIds)
    console.log('selectedProducts',selectedProducts)
    
    // Update store with ALL selected products
    const combinedProducts = [...existingProductIds, ...selectedProductDetails];
    const finalProducts = combinedProducts.filter(p => 
      selectedProducts.includes(p.id)
    );
    setProducts(finalProducts);
    
    // Set flag to indicate we're returning to edit
    localStorage.setItem('returningToEdit', 'true');
    
    // Clear selected products from localStorage
    localStorage.removeItem('selectedProducts');
    // 24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase - LB - 0194, LB - 0202
    localStorage.removeItem('activeFilters');
    localStorage.removeItem('pilihProdukSearch')
    
    
    // Navigate back
    if (etalaseId) {
      router.push(`/daftaretalase/mobile/edit/${etalaseId}`);
    } else {
      router.push('/daftaretalase/mobile/add');
    }
  };

  // Modified handleBack to always show modal
  const handleBack = () => {
    setShowLeaveModal(true);
  };

  // Modified modal handlers
  const handleModalConfirm = () => {
    // 24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase - LB - 0194, LB - 0202, LB - 0219
    localStorage.removeItem('activeFilters');
    localStorage.removeItem('pilihProdukSearch')
    if (etalaseId) {
      router.push(`/daftaretalase/mobile/edit/${etalaseId}`);
    } else {
      router.push('/daftaretalase/mobile/add');
    }
  };

  const handleModalClose = () => {
    setShowLeaveModal(false);
  };

  // Add cleanup on unmount
  useEffect(() => {
    return () => {
      // Clean up localStorage when component unmounts
      if (!window.location.pathname.includes('/filter')) {
        // localStorage.removeItem('selectedProducts');
      }
    };
  }, []);

  const handleFilterClick = () => {
    setIsFilterOpen(true);
  };

  return (
    <div className="flex flex-col h-screen bg-zinc-100">
      <div className="fixed top-0 left-0 right-0 z-50">
        <Header 
          title={t('pilihProduk')} 
          onBack={handleBack}
        />
      </div>
      {/*24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase 
      LB - 0134 */}
      <main className={`flex-1 ${products.length === 0?'overflow-y-hidden':'overflow-y-auto'} bg-zinc-100 mt-[62px] mb-[60px]`}> {/* Add margin-top to account for fixed header */}
        {/* Search and Filter Section */}
        <div className="sticky top-0 z-10 flex overflow-hidden flex-col p-0 w-full leading-none bg-white border-b border-solid border-b-stone-300">
        {/*
        24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase  LB - 0201, LB - 0202 */}
          <SearchBar
            selectedCount={selectedProducts.length}
            onSearch={handleSearch}
            onFilter={handleFilter}
            activeFilters={selectedFilters.categories.length + selectedFilters.brands.length}
            isEmptyData={products.length === 0}
            //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0228
            disabledFilter={(emptyStateSource !== 'filter' && products.length === 0 && !(selectedFilters.categories.length > 0 || selectedFilters.brands.length > 0 )) || (activeFilters.categories.length===0 && activeFilters.brands.length===0 && emptyStateSource === 'filter') }
            disabled={emptyStateSource === 'filter' && products.length === 0 && searchTerm===''}
            initialSearchValue={searchTerm} // Add this prop
          />
        </div>
  
        {/* Product List Section */}
        {isLoading ? (
          <div className="flex flex-col gap-2">
            {[...Array(5)].map((_, index) => (
              <ProductSkeleton key={index} />
            ))}
          </div>
        ) : products.length === 0 ? (
          searchTerm && emptyStateSource !== 'filter' || (activeFilters.categories.length===0&&activeFilters.brands.length===0)? (
            <KeywordNotFoundMessage />
          ) : emptyStateSource === 'filter' ? (
            <NotFoundFilter onFilterClick={handleFilter} />
          ) : (
            <NoProductsMessage t={t} />
          )
        ) : (
          <div className="flex flex-col mt-2 w-full pb-20"> {/* Added pb-20 here */}
            {products.map((product) => (
              <div key={product.id} className={products.indexOf(product) > 0 ? "mt-2" : ""}>
                <ProductCard
                  title={product.name}
                  image={product.imageUrl}
                  price={product.price}
                  sku={product.sku}
                  brand={product.brand || '-'}
                  category={product.category}
                  isSelected={selectedProducts.includes(product.id)}
                  onSelect={() => handleSelect(product)}
                />
              </div>
            ))}
          </div>
        )}
      </main>
  
      {/* Fixed Bottom Button - Modified logic */}
      {/* {selectedProducts.length > 0 && ( */}
        <div className="fixed bottom-0 left-0 right-0 p-4 bg-white border-t border-gray-200">
          {/* <Button
            onClick={handleSave}
            color="primary"
Class="w-full py-4 text-white bg-blue-600 rounded-full font-medium sm:max-w-full"
          >
            {t('labelSimpan')}
          </Button> */}
          <SaveButton onClick={handleSave} />
        </div>
      {/* )} */}

      <CustomModal 
        isOpen={showLeaveModal}
        onClose={handleModalClose}
        onConfirm={handleModalConfirm}
        title={t('pindahHalaman')}
        message={t('konfirmasiPindahHalaman')}
        confirmText={t('labelYes')}
        cancelText={t('labelBatal')}
        confirmButtonClass="bg-[#176CF7] rounded-full w-full" 
        cancelButtonClass="border border-[#176CF7] text-[#176CF7] rounded-full w-full"
        showCloseIcon={true}
        roundedButtons={true}
      />
    </div>
  );
}

export default PilihProdukPage;