import React from "react";
import { useCustomRouter } from '@/libs/CustomRoute';
import { useLanguage } from "@/providers/LanguageProvider";
import ImageComponent from "@/components/ImageComponent/ImageComponent";
import Button from "@/components/Button/Button";
//24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0201
const NotFoundFilter = ({onFilterClick}) => {
  const { t } = useLanguage();
  const router = useCustomRouter();


  return (
    <div className="flex flex-col justify-center items-center w-full min-h-[calc(100vh-200px)]">
      <div className="flex flex-col items-center w-[228px]">
        <ImageComponent
          src="/icons/etalase/search-not-found.png"
          alt={t('dataTidakDitemukan')}
          width={107}
          height={92}
          className="object-contain aspect-[1.16]"
        />
        <div className="flex flex-col items-center mt-5">
          <div className="text-sm font-semibold text-[#7B7B7B] text-center">
            {t('dataTidakDitemukan')}
            <br />
            {t('mohonCobaHapusBeberapaFilter')}
          </div>
          <div className="mt-5 text-sm font-semibold text-[#7B7B7B] text-center">
            {t('labelAtau')}
          </div>
          <Button
            onClick={onFilterClick} // Changed from resetFilters to handleFilterClick
            color="primary"
Class="px-6 py-2.5 mt-5 text-xs font-medium text-white bg-blue-600 rounded-3xl min-h-[28px] min-w-[112px]"
          >
            {t('aturUlangFilter')}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default NotFoundFilter;