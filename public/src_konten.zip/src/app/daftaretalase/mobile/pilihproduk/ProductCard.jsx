import React from 'react';
import { useLanguage } from "@/providers/LanguageProvider";
import ImageComponent from "@/components/ImageComponent/ImageComponent";

const ProductCard = ({
  image,
  title,
  price,
  sku,
  brand,
  category,
  isSelected,
  onSelect,
}) => {
  const { t } = useLanguage();

  // Format price to display
  const formatPrice = (priceObj) => {
    if (!priceObj) return '-';
    
    const formatNumber = (num) => {
      return `Rp${num.toLocaleString('id-ID')}`;
    };

    if (priceObj.min === priceObj.max) {
      return formatNumber(priceObj.min);
    }

    return `${formatNumber(priceObj.min)} - ${formatNumber(priceObj.max)}`;
  };

  // Format category to display
  const formatCategory = (categoryObj) => {
    if (!categoryObj) return '-';
    if (typeof categoryObj === 'string') return categoryObj;
    
    // If it's a path, get the last category name
    if (categoryObj.path) {
      const categories = categoryObj.path.split(' > ');
      return categories[categories.length - 1];
    }
    
    // If no path, return the category name or default
    return categoryObj.name || '-';
  };

  return (
    <div className="flex overflow-hidden gap-2.5 px-4 py-3 w-full bg-white">
      <div className="flex flex-1 shrink gap-3 items-start basis-0 min-w-[240px]">
        <div className="flex flex-col w-4">
          <div 
            role="checkbox"
            tabIndex={0}
            aria-checked={isSelected}
            onClick={onSelect}
            onKeyPress={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                onSelect();
              }
            }}
            className={`
              flex justify-center items-center shrink-0 w-4 h-4 rounded 
              border border-solid cursor-pointer transition-colors
              ${isSelected 
                ? 'bg-blue-600 border-blue-600' 
                : 'border-neutral-500'
              }
            `}
          >
            {isSelected && (
              <svg width="10" height="8" viewBox="0 0 10 8" fill="none">
                <path d="M1 4L3.5 6.5L9 1" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            )}
          </div>
        </div>
        
        <ImageComponent
          src={image || '/images/placeholder.png'}
          alt={title}
          width={68}
          height={68}
          className="object-contain shrink-0 rounded aspect-square"
        />
        
        <div className="flex flex-col flex-1 shrink text-xs font-medium leading-none text-black basis-0">
          <div className="text-sm font-bold leading-4 line-clamp-2">
            {title}
          </div>
          <div className="mt-3 text-sm font-semibold">
            {formatPrice(price)}
          </div>
          <div className="mt-3 text-ellipsis line-clamp-1 break-all">
            {t('labelSKU')} : {' '}{sku || '-'}
          </div>
          <div className="mt-3 text-ellipsis line-clamp-1 break-all">
            {t('labelBrand')} : {' '}{brand}
          </div>
          <div className="mt-3 text-ellipsis line-clamp-1 break-all">
            {t('labelKategori')} : {' '}{formatCategory(category)}
          </div>
        </div>
      </div>
    </div>
  );
};

export { ProductCard };
export default ProductCard;