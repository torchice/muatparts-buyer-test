import React from 'react';
import { useCustomRouter } from '@/libs/CustomRoute';
import { useLanguage } from "@/providers/LanguageProvider";
import PromotionsBottomNavigation from '@/components/Promotions/BottomNavigation';
import useEtalaseStore from '@/store/zustand/etalasestore';
import toast from "@/store/zustand/toast";
import useSusunProdukStore from '@/store/susunProdukStore';


function BottomNavigation() {
  const router = useCustomRouter();
  const { t } = useLanguage();
  const { totalEtalase, maxEtalase } = useEtalaseStore();
  const { setShowToast, setDataToast } = toast();
  const { products, setProducts, clearProducts,setExistingProducts } = useSusunProdukStore();


  const handleMessageClick = () => {
    // Add message click handler
  };

  const handleProfileClick = () => {
    // Add profile click handler
  };
  const formatNumber = (num) => {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  };

  const handleCreateClick = () => {
    if (totalEtalase >= maxEtalase) {
      setDataToast({
        type: 'error',
        message: t('etalasePenjualMaks').replace('{count}', formatNumber(maxEtalase))
      });
      setShowToast(true);
      return;
    }
    // Clear all data when starting fresh
    localStorage.removeItem('etalaseFormData');
    localStorage.removeItem('selectedProducts');
    localStorage.removeItem('tempProducts');
    localStorage.removeItem('returningFromPilihProduk');
    localStorage.removeItem('returningFromSusunProduk');
    
    
    clearProducts()
    setExistingProducts([]);
    setProducts([]);
    
    router.push('/daftaretalase/mobile/add');
  };
  //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0181
  return (
    <PromotionsBottomNavigation
      onMessageClick={handleMessageClick}
      onProfileClick={handleProfileClick}
      createButtonLabel={t('tambahEtalase')}
      onCreateClick={handleCreateClick}
      className={'sm:h-fit'}
    />
  );
}

export default BottomNavigation;