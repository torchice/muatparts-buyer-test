// app/daftaretalase/detail/[id]/layout.jsx
// app/daftaretalase/edit/[id]/layout.jsx
// app/daftaretalase/susunproduk/layout.jsx

'use client';
import { LanguageProvider } from "@/providers/LanguageProvider";
import React, { useEffect } from 'react';
import headerZustand from "@/store/zustand/header";
import toast from "@/store/zustand/toast";


export default function Layout({ children }) {
  const { setShowNavMenu } = toast()
  const { setHeader } = headerZustand()

    useEffect(() => {
        console.log('cekcek brian')
        setShowNavMenu(false)
        setHeader('false')
    }, [])
  return (
    <>
    {/* //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase - LB - 0207 */}
    <div className="fixed top-0 w-full layout-mobile">
      {children}
    </div>
    </>
  );
}