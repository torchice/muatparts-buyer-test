// THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase 
// LB - 0069
// LB - 0124
// LB - 0125
'use client';
import React, { useState, useEffect, useRef } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { ChevronLeft,ChevronDown, Search, X } from 'lucide-react';
import { MockServer_TambahEtalase } from '@/services/MockServer_TambahEtalase';
import Toast from '@/components/Toast/Toast';
import BreadCrumb from '../../components/BreadCrumb';
import ConfirmationPopup from '../../popup/ConfirmationPopup';
import ProductTable from '../../components/ProductTable';
import SekeletonLoader from '../../components/SekeletonLoader';
import FilterDropdown from '../../components/FilterDropdown';
import toast from "@/store/zustand/toast";
import Image from 'next/image';
import IconBack from '@/icons/iconBack.svg';
import DaftarEtalaseSvg from '@/icons/Daftar Etalase.svg';
import ImageComponent from '@/components/ImageComponent/ImageComponent';
import CustomLink from '@/components/CustomLink';
import { useCustomRouter } from '@/libs/CustomRoute';
import Button from "@/components/Button/Button";
// 25. 05 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0867
import { useTranslation } from '@/context/TranslationProvider';

const EtalaseDetailPage=()=> {
  const router = useCustomRouter();
  const params = useParams();
  const [loading, setLoading] = useState(true);
  const [etalase, setEtalase] = useState(null);
  const [products, setProducts] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filters, setFilters] = useState({
    categories: [],
    brands: []
  });
  const [deleteConfirm, setDeleteConfirm] = useState(false);
  const { tOrEmpty } = useTranslation();
  const [searchQuery, setSearchQuery] = useState('');
  const { showToast, setShowToast, setDataToast } = toast();
  const [showScrollButtons, setShowScrollButtons] = useState(false);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(false);
  const containerRef = useRef(null);
  const [searchDisabled, setSearchDisabled] = useState(false);
  const [filterDisabled, setFilterDisabled] = useState(false);

const LoadingSkeleton = () => {
  return (
    <div className="min-h-screen   p-6 w-full">
      {/* Breadcrumb and Header */}
      <div className="mb-6">
        {/* Breadcrumb */}
        <div className="flex gap-2 items-center mb-4">
          <SekeletonLoader.Text width="w-20" className="h-4" />
          <SekeletonLoader.Text width="w-4" className="h-4" />
          <SekeletonLoader.Text width="w-24" className="h-4" />
          <SekeletonLoader.Text width="w-4" className="h-4" />
          <SekeletonLoader.Text width="w-28" className="h-4" />
        </div>

        {/* Header with Actions */}
        <div className="flex items-center justify-between mt-4">
          <div className="flex items-center gap-2">
            <SekeletonLoader.Text width="w-6" height="h-6" className="rounded-full" />
            <SekeletonLoader.Text width="w-48" height="h-8" />
          </div>
          <div className="flex gap-3">
            <SekeletonLoader.Text width="w-28" height="h-10" className="rounded-full" />
            <SekeletonLoader.Text width="w-28" height="h-10" className="rounded-full" />
          </div>
        </div>
      </div>

      {/* Etalase Info Card */}
      <div className="bg-white rounded-xl p-6 shadow-lg mb-6">
        <div className="flex items-start gap-6">
          <SekeletonLoader.Image size="w-24 h-24" />
          <div className="flex-1">
            <SekeletonLoader.Text width="w-48" height="h-6" className="mb-4" />
            <SekeletonLoader.Text width="w-32" className="mb-2" />
            <SekeletonLoader.Text width="w-32" />
          </div>
        </div>
      </div>

      {/* Product List Section */}
      <div className="bg-white rounded-xl shadow-lg">
        {/* Search and Filter */}
        <div className="p-4 border-b flex justify-between items-center">
          <SekeletonLoader.Text width="w-64" height="h-10" className="rounded-md" />
          <SekeletonLoader.Text width="w-24" height="h-10" className="rounded-md" />
        </div>

        {/* Product Table */}
        <div className="divide-y">
          {/* Table Header */}
          <div className="p-4 grid grid-cols-5 gap-4">
            <SekeletonLoader.Text width="w-48" className="h-4" />
            <SekeletonLoader.Text width="w-32" className="h-4" />
            <SekeletonLoader.Text width="w-20" className="h-4" />
            <SekeletonLoader.Text width="w-24" className="h-4" />
            <SekeletonLoader.Text width="w-16" className="h-4" />
          </div>

          {/* Table Rows */}
          {[...Array(5)].map((_, index) => (
            <div key={index} className="p-4 grid grid-cols-5 gap-4">
              <div className="flex items-center gap-3">
                <SekeletonLoader.Image />
                <div>
                  <SekeletonLoader.Text width="w-32" className="mb-1" />
                  <SekeletonLoader.Text width="w-24" />
                </div>
              </div>
              <SekeletonLoader.Text width="w-32" />
              <SekeletonLoader.Text width="w-16" />
              <SekeletonLoader.Text width="w-24" />
              <SekeletonLoader.Text width="w-16" />
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="p-4 border-t">
          <SekeletonLoader.Text width="w-32" />
        </div>
      </div>
    </div>
  );
};

  useEffect(() => {
    loadEtalaseDetails();
  }, [params.id]);

  useEffect(() => {
    // loadProducts();
  }, [searchTerm, filters]);

  const loadEtalaseDetails = async () => {
    try {
      setLoading(true);
      const response = await MockServer_TambahEtalase.getEtalaseDetail(params.id);
      setEtalase(response.data);
      setProducts(response.data.products);
    } catch (error) {
      setDataToast({
        type: 'error',
        message: tOrEmpty('pesanGagalMemuatDetail')
      });
      setShowToast(true);
    } finally {
      setLoading(false);
    }
  };

  // const loadProducts = async () => {
  //   if (!etalase) return;
    
  //   try {
  //     setLoading(true);
  //     const response = await MockServer_TambahEtalase.getEtalaseProducts(params.id, {
  //       search: searchTerm,
  //       categoryId: filters.categories.map(c => c.id).join(','),
  //       brandId: filters.brands.map(b => c.id).join(',')
  //     });
  //     setProducts(response.data.products);
  //   } catch (error) {
  //     setToast({
  //       show: true,
  //       status: 'error',
  //       text: 'Gagal memuat daftar produk'
  //     });
  //   } finally {
  //     setLoading(false);
  //   }
  // };

  const handleDelete = async () => {
    try {
      setLoading(true);
      await MockServer_TambahEtalase.deleteEtalase(params.id);
      
      // Redirect dulu baru tampilkan toast
      router.push('/daftaretalase');
      
      // Set toast setelah redirect
      localStorage.setItem('showToast', 'true');
      localStorage.setItem('toastMessage', tOrEmpty('berhasilMenghapusEtalase'));
      localStorage.setItem('toastType', 'success');
      // setTimeout(() => {
      //   setDataToast({
      //     type: 'success',
      //     message: t('berhasilMenghapusEtalase')
      //   });
      //   setShowToast(true);
      // }, 100); // Delay sedikit untuk memastikan redirect selesai

    } catch (error) {
      setDataToast({
        type: 'error',
        message: tOrEmpty('gagalHapusEtalase')
      });
      setShowToast(true);
    } finally {
      setLoading(false);
      setDeleteConfirm(false);
    }
  };

  const handleFilterSelect = (type, item) => {
    setFilters(prev => {
      const key = type === 'category' ? 'categories' : 'brands';
      const exists = prev[key].find(f => f.id === item.id);
      
      const newFilters = {
        ...prev,
        [key]: exists 
          ? prev[key].filter(f => f.id !== item.id)
          : [...prev[key], item]
      };

      // No need to trigger additional load since filteredProducts will update automatically
      return newFilters;
    });
  };

  const handleResetFilters = () => {
    setFilters({ categories: [], brands: [] });
  };

  const breadcrumbItems = [
    { text: tOrEmpty('labelDashboard'), path: '/dashboard' },
    { text: tOrEmpty('daftarEtalase'), path: '/daftaretalase' },
    { text: tOrEmpty('detailEtalase') }
  ];

  const filteredProducts = React.useMemo(() => {
    // Reset both states at start
    setSearchDisabled(false);
    setFilterDisabled(false);

    if (products.length === 0) {
      setSearchDisabled(true);
      setFilterDisabled(true);
      return [];
    }

    let filtered = products;
    const hasActiveFilters = filters.categories.length > 0 || filters.brands.length > 0;

    // Handle filter results first
    if (hasActiveFilters) {
      filtered = products.filter(product => {
        const matchesCategories = filters.categories.length === 0 || 
          filters.categories.some(c => (product.category?.path || '').includes(c.name));

        const matchesBrands = filters.brands.length === 0 || 
          filters.brands.some(b => (product.brand || '').toLowerCase().includes(b.name.toLowerCase()));

        return matchesCategories && matchesBrands;
      });

      if (filtered.length === 0 && searchTerm=== '') {
        setSearchDisabled(true);
        return [];
      }
    }

    // Handle search results
    if (searchTerm) {
      const searchLower = searchTerm.toLowerCase();
      const nameMatches = [];
      const skuMatches = [];
      const brandMatches = [];

      filtered.forEach(product => {
        const name = (product.name || '').toLowerCase();
        const sku = (product.sku || '').toLowerCase();
        const brand = (product.brand || '').toLowerCase();

        if (name.includes(searchLower)) {
          nameMatches.push(product);
        } else if (sku.includes(searchLower)) {
          skuMatches.push(product);
        } else if (brand.includes(searchLower)) {
          brandMatches.push(product);
        }
      });

      // Sort each group alphabetically
      nameMatches.sort((a, b) => a.name.localeCompare(b.name));
      skuMatches.sort((a, b) => a.sku.localeCompare(b.sku));
      brandMatches.sort((a, b) => a.brand.localeCompare(b.brand));

      const sortedResults = [...nameMatches, ...skuMatches, ...brandMatches];
      
      if (sortedResults.length === 0 && !hasActiveFilters) {
        setFilterDisabled(true);
      }
      
      return sortedResults;
    }

    return filtered;
  }, [products, searchTerm, filters]);

  const handleSearchSubmit = (e) => {
    if (e.key === 'Enter') {
      setSearchTerm(searchQuery);
    }
  };

  const handleSearchReset = () => {
    setSearchQuery('');
    setSearchTerm('');
  };

  const checkScrollable = () => {
    if (containerRef.current) {
      const { scrollWidth, clientWidth, scrollLeft } = containerRef.current;
      setShowScrollButtons(scrollWidth > clientWidth);
      setCanScrollLeft(scrollLeft > 0);
      setCanScrollRight(scrollLeft < (scrollWidth - clientWidth));
    }
  };

  const scrollFilters = (direction) => {
    const container = containerRef.current;
    const scrollAmount = 200;
    
    if (container) {
      if (direction === 'left') {
        container.scrollLeft -= scrollAmount;
      } else {
        container.scrollLeft += scrollAmount;
      }
    }
  };

  useEffect(() => {
    const container = containerRef.current;
    if (container) {
      checkScrollable();
      container.addEventListener('scroll', checkScrollable);
      window.addEventListener('resize', checkScrollable);
      
      return () => {
        container.removeEventListener('scroll', checkScrollable);
        window.removeEventListener('resize', checkScrollable);
      };
    }
  }, [filters]);

  if (loading && !etalase) {
    return <LoadingSkeleton />;
  }

  return (
    <div className="flex flex-col min-h-screen   w-full relative pb-20">
      {/* Breadcrumb and Header Section */}
      {/*24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0001 */}
      <div className =" pb-4">
        <BreadCrumb items={breadcrumbItems} />
        <div className="flex flex-wrap gap-10 justify-between items-center mt-4 w-full leading-tight">
          <div className="gap-3 self-stretch my-auto text-xl font-bold text-black min-w-[240px] w-[515px]">
            <div className="flex items-center gap-2">
              <ImageComponent 
                src={"/icons/etalase/iconBack.svg"} 
                alt={tOrEmpty('labelKembali')}
                width={24}
                height={24}
                className="w-6 h-6 cursor-pointer"
                onClick={() => router.back()}
              />
              <span>{tOrEmpty('detailEtalase')}</span>
            </div>
          </div>
          {!etalase?.isDefault && (
            <div className="flex gap-3">
              <Button
                onClick={() => setDeleteConfirm(true)}
                color="error_secondary"
                Class ="px-6 py-2 text-sm font-semibold text-red-500 border border-red-500 rounded-3xl hover:bg-red-50 min-h-[32px] bg-white"
              >
                {tOrEmpty('hapusEtalase')}
              </Button>
              <Button
                onClick={() => router.push(`/daftaretalase/edit/${params.id}`)}
                color="primary"
                Class ="px-6 py-2 text-sm font-semibold text-white border bg-blue-600 rounded-3xl hover:bg-blue-50 min-h-[32px]"
              >
                {tOrEmpty('labelUbah')}
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Etalase Info Card */}
      {/*24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0197 */}
      <div className =" pb-4">
        <div className="bg-white rounded-xl p-8 w-full shadow-lg">
          <div className="flex items-center gap-4">
            {etalase.isDefault ? (
              <ImageComponent
                src='/icons/etalase/semua_produk.png'
                alt={etalase.name}
                width={56}
                height={56}
                //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0197
                className="w-[56px] h-[56px] rounded object-cover"
              />
            ) : etalase.imageUrl ? (
              <ImageComponent
                src={etalase.imageUrl}
                alt={etalase.name}
                width={56}
                height={56}
                //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0197
                className="w-[56px] h-[56px] rounded object-cover"
              />
            ) : (
              <ImageComponent
                src={"/icons/etalase/Daftar Etalase.svg"}
                alt={etalase.name}
                width={56}
                height={56}
                //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase LB - 0197
                className="w-[56px] h-[56px] rounded object-cover"
              />
            )}
            <div>
              <h2 className="text-lg font-bold">{etalase.name}</h2>
              {/* <p className="text-sm text-[#7b7b7b]">{etalase.totalProducts} {t('labelProduk')}</p> */}
            </div>
          </div>
        </div>

        {/* Product List Section */}
        <div className="mt-4 bg-white rounded-xl pt-6 shadow-lg">
          <div className="flex justify-between items-center mb-6 gap-4 px-6">
            <h2 className="text-lg font-semibold text-black w-[130px] whitespace-nowrap">{tOrEmpty('daftarProduk')}</h2>
            <div className="flex items-center w-full justify-start gap-4">
              <div className="relative w-64">
                <input
                  type="text"
                  placeholder={tOrEmpty('cariNamaProdukSKU')}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyPress={handleSearchSubmit}
                  disabled={searchDisabled} // Use searchDisabled state
                  className={`w-full pl-10 pr-8 py-2 border border-[#7b7b7b] rounded-md transition-colors
                    ${searchDisabled 
                      ? 'bg-gray-100 cursor-not-allowed border-[#D8D8D8]' 
                      : 'hover:border-[#176CF7] focus:border-[#176CF7] focus:outline-none focus:ring-blue-500'
                    }`}
                />
                <Search className={`w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 ${
                  searchDisabled ? 'text-[#9D9D9D]' : 'text-[#55555]'
                }`} />
                {searchQuery && (
                  <button
                    onClick={handleSearchReset}
                    className="absolute right-2 top-1/2 -translate-y-1/2"
                  >
                    <X className="w-4 h-4 text-[#55555]" />
                  </button>
                )}
              </div>
              <FilterDropdown
                activeFilters={filters}
                onFilterSelect={handleFilterSelect}
                onResetFilters={handleResetFilters}
                etalaseId={params.id}
                disabled={filterDisabled} // Use filterDisabled state
              />
            </div>
          </div>

          {/* Active Filters */}
          {(filters.categories.length > 0 || filters.brands.length > 0) && (
            <div className="mt-3 flex items-center gap-2 relative mb-5 px-4">
              <button
                onClick={handleResetFilters}
                className="text-[#176CF7] text-sm font-semibold whitespace-nowrap"
              >
                {tOrEmpty('hapusSemuaFilter')}
              </button>
              
              {showScrollButtons && (
                <div 
                  onClick={() => scrollFilters('left')}
                  className={`flex-none flex items-center justify-center w-6 h-6 rounded-full border border-[#D8D8D8] bg-white hover:bg-gray-50 ${!canScrollLeft ? 'cursor-not-allowed' : 'cursor-pointer'}`}
                >
                  <svg width="8" height="12" viewBox="0 0 8 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M6.87988 0.40967C7.07756 0.607353 7.09553 0.916694 6.93379 1.13468L6.87988 1.19713L2.07689 6.00037L6.87988 10.8036C7.07756 11.0013 7.09553 11.3106 6.93379 11.5286L6.87988 11.5911C6.6822 11.7888 6.37286 11.8067 6.15487 11.645L6.09242 11.5911L0.89545 6.3941C0.697767 6.19642 0.679796 5.88708 0.841537 5.66909L0.89545 5.60664L6.09242 0.40967C6.30987 0.192219 6.66243 0.192219 6.87988 0.40967Z" 
                      fill={canScrollLeft ? "black" : "#9D9D9D"}
                    />
                  </svg>
                </div>
              )}
              
              <div 
                ref={containerRef}
                className="flex-1 overflow-x-auto flex gap-2 items-center scrollbar-hide"
                style={{ scrollBehavior: 'smooth', overflowX: 'hidden' }}
              >
                {[...filters.categories, ...filters.brands].reverse().map(filter => (
                  <span 
                    key={filter.id}
                    className="flex-none px-3 py-1 bg-white text-[#176CF7] rounded-full border border-[#176CF7] text-sm flex items-center gap-1"
                  >
                    {filter.name}
                    <div
                    className="cursor-pointer"
                      onClick={() => handleFilterSelect(
                        filters.categories.includes(filter) ? 'category' : 'brand',
                        filter
                      )}
                    >
                      <X className="w-4 h-4" />
                    </div>
                  </span>
                ))}
              </div>
              
              {showScrollButtons && (
                <div 
                  onClick={() => scrollFilters('right')}
                  className={`flex-none flex items-center justify-center w-6 h-6 rounded-full border border-[#D8D8D8] bg-white hover:bg-gray-50 ${!canScrollRight ? 'cursor-not-allowed' : 'cursor-pointer'}`}
                >
                  <svg width="8" height="12" viewBox="0 0 8 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M1.12012 0.40967C0.922437 0.607353 0.904466 0.916694 1.06621 1.13468L1.12012 1.19713L5.92311 6.00037L1.12012 10.8036C0.922437 11.0013 0.904466 11.3106 1.06621 11.5286L1.12012 11.5911C1.3178 11.7888 1.62714 11.8067 1.84513 11.645L1.90758 11.5911L7.10455 6.3941C7.30223 6.19642 7.3202 5.88708 7.15846 5.66909L7.10455 5.60664L1.90758 0.40967C1.69013 0.192219 1.33757 0.192219 1.12012 0.40967Z" 
                      fill={canScrollRight ? "black" : "#9D9D9D"}
                    />
                  </svg>
                </div>
              )}

              {/* Show chevron if filters overflow */}
              {/* <ChevronDown className="w-4 h-4 text-gray-400 flex-shrink-0" />
              <Button
                onClick={handleResetFilters}
                className="text-[#176CF7] text-sm hover:underline whitespace-nowrap"
              >
                {t('hapusSemuaFilter')}
              </Button> */}
            </div>
          )}

          {/* Products Table */}
          <ProductTable
            products={filteredProducts}
            loading={loading}
            showActions={false}
            stockLabel="Stok Habis"
            searchTerm={searchTerm}
            activeFilters={filters}
            disableStockSort={true}
          />
        </div>
      </div>

      {/* Fixed Bottom Section */}
      {/* <div className="fixed bottom-0 left-0 right-0 z-10">
        <div className="pl-[289px] bg-white border-t border-gray-200 p-4">
          <div className="text-sm font-bold text-black">
            {t('totalProduk')}: {products.length}
          </div>
        </div>
      </div> */}

      {/* Popups */}
      {deleteConfirm && (
        <ConfirmationPopup
          title = ''
          message={tOrEmpty('konfirmasiHapusEtalase')}
          onConfirm={handleDelete}
          onCancel={() => setDeleteConfirm(false)}
          confirmLabel = {tOrEmpty('labelYaHapus')}
        />
      )}

      {/* Toast Notifications */}
      <Toast />
    </div>
  );
}
export default EtalaseDetailPage