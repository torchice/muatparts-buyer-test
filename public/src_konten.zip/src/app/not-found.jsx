// LBM, IMP 0078/HW/PROG/III/2025 NOTFOUND
"use client";

import ImageComponent from "@/components/ImageComponent/ImageComponent";
import { useCustomRouter } from "@/libs/CustomRoute";
import React from "react";
import localFont from "next/font/local";
import { useTranslation } from "@/context/TranslationProvider";

const Avenir = localFont({
  src: [
    {
      path: "../fonts/AvenirNextLTPro-Bold.otf",
      weight: "700",
      style: "bolder",
    },
    {
      path: "../fonts/AvenirNextLTPro-Demi.otf",
      weight: "600",
      style: "bold",
    },
    {
      path: "../fonts/AvenirNextLTPro-Medium.otf",
      weight: "500",
      style: "normal",
    },
    {
      path: "../fonts/AvenirNextLTPro-Regular.otf",
      weight: "400",
      style: "lighter",
    },
  ],
});

export default function NotFound() {
  const router = useCustomRouter();
  const { t } = useTranslation();

  return (
    <html>
      <body className={Avenir.className + " bg-[#ffff]"}>
        <div className="w-full flex flex-col h-screen relative justify-center items-center gap-8 bg-primary-700 py-10 overflow-hidden">
          <ImageComponent
            className="z-10"
            src={"/img/muatmuat-jalan-mudah-bersama2.png"}
            width={200}
            height={56}
            alt="muat"
          />
          <ImageComponent
            src={"/img/aneh1.png"}
            className="absolute top-0 left-0 w-[150px] h-[180px]"
            width={228}
            height={231}
            alt="muat"
          />
          <ImageComponent
            src={"/img/aneh2.png"}
            className={"absolute -bottom-[50px] right-0 w-[100px] h-[180px]"}
            width={222}
            height={222}
            alt="muat"
          />
          <div className="flex flex-col gap-6">
            <div className="flex flex-col justify-center items-center">
              <ImageComponent
                src={"/img/404.png"}
                width={165}
                height={55}
                alt="muat"
              />
              <ImageComponent
                src={"/img/404_people.png"}
                width={368}
                height={198}
                alt="muat"
              />
            </div>
            <div className="flex flex-col gap-3 text-neutral-50 items-center">
              <span className="text-[24px] font-bold">
                {t("labelHalamanNotFoundMP")}
              </span>
              <span className="text-base font-medium">
                {t("labelSilahkanKembaliMP")}
              </span>
              <span
                onClick={() => router.back()}
                className="text-primary-700 semi-sm bg-[#FFC217] rounded-3xl px-6 py-[10px] text-center select-none cursor-pointer z-10"
              >
                {t("labelKembaliAwalMP")}
              </span>
            </div>
          </div>
        </div>
      </body>
    </html>
  );
}
