import { useHeader } from "@/common/ResponsiveContext";
import { useState, useEffect } from "react";
import profileSeller from "@/store/zustand/profileSeller";
import Button from "@/components/Button/Button";
import { BadgeCheck, Download, Info, PencilLine } from "lucide-react";
import IconComponent from "@/components/IconComponent/IconComponent";
import Input from "@/components/Input/Input";
import LocationManagement from "@/components/LocationManagement/LocationManagement";
import { handleCopy, handleDownload } from "@/libs/services";
import style from "./Profileseller.module.scss";
import MiniMap from "@/container/MapContainer/MiniMap";
import ModalComponent from "@/components/Modals/ModalComponent";
import { Skeleton } from "./ProfilesellerWeb";
import toast from "@/store/zustand/toast";
import EditStoreScreen from "./EditStoreScreen";
import EditCompanyScreen from "./EditCompanyScreen";
import ImageUploaderRegisterResponsive from "@/components/ImageUploader/ImageUploaderRegisterResponsive";
import SWRHandler from "@/services/useSWRHook";
import { useCustomRouter } from "@/libs/CustomRoute";
import ListManlok from "@/components/LocationManagement/Responsive/[screens]/ListManlok";
import KecamatanManlokScreen from "@/components/LocationManagement/Responsive/[screens]/KecamatanManlokScreen";
import MapContainer from "@/container/MapContainer/MapContainer";
import { useTranslation } from "@/context/TranslationProvider";

const api = process.env.NEXT_PUBLIC_GLOBAL_API + "v1/";

function ProfilesellerResponsive({ handleSaveStore, handleSaveCompany }) {
  const { t } = useTranslation();
  const { setAppBar, clearScreen, setScreen, screen } = useHeader();
  const { profileData } = profileSeller();
  const { setShowNavMenu } = toast();

  const [previousScreen, setPreviousScreen] = useState({});

  useEffect(() => {
    setShowNavMenu(false);
    setScreen("main");
    setAppBar({
      renderAppBar: <HeaderProfileResponsive t={t} />,
      shadow: false,
    });
  }, []);

  useEffect(() => {
    if (screen === "main") {
      clearScreen();
      setAppBar({
        renderAppBar: <HeaderProfileResponsive t={t} />,
        shadow: false,
      });
    } else if (screen === "editStore") {
      setShowNavMenu(false);

      setAppBar({
        title: t("labelUbahDataToko"),
        appBarType: "header_title",
        onBack: () => {
          clearScreen();
          setScreen("main");
        },
      });
    } else if (screen === "editCompany") {
      setShowNavMenu(false);
      setAppBar({
        title: t("labelUbahDataPerusahaan"),
        appBarType: "header_title",
        onBack: () => {
          clearScreen();
          setScreen("main");
        },
      });
    } else if (screen === "ListManlok") {
      // setAppBar({
      //   appBarType: "header_search_secondary",
      //   renderAppBar: "",
      //   onBack: () => {
      //     setAppBar({
      //       title: "Profil Toko",
      //       appBarType: "header_title_modal",
      //     });
      //     setScreen("");
      //   },
      // });
      // setSearch({
      //   placeholder: "Cari Lokasi",
      // });
    } else if (screen === "KecamatanManlokScreen") {
      setAppBar({
        title: t("labelPilihKecamatan"),
        appBarType: "header_title",
        onBack: () => {
          setScreen("editStore");
        },
      });
    }
  }, [screen]);

  if (!profileData) return <Skeleton fill={5} />;

  if (screen === "editStore") {
    return (
      <EditStoreScreen
        t={t}
        previousScreen={previousScreen}
        handleSaveStore={handleSaveStore}
        onCancel={() => {
          setScreen("main");
          clearScreen();
        }}
        setScreen={setScreen}
        clearScreen={clearScreen}
      />
    );
  } else if (screen === "editCompany") {
    return (
      <EditCompanyScreen
        t={t}
        previousScreen={previousScreen}
        handleSaveCompany={handleSaveCompany}
        onCancel={() => {
          setScreen("main");
          clearScreen();
        }}
        setScreen={setScreen}
        clearScreen={clearScreen}
      />
    );
  }

  // buat manlok
  if (screen === "ListManlok")
    return <ListManlok previousScreen={previousScreen} />;
  if (screen === "KecamatanManlokScreen")
    return <KecamatanManlokScreen previousScreen={previousScreen} />;
  // buat manlok

  return (
    <div className="min-h-screen relative">
      <div className="bg-[#C22716] h-[260px] relative">
        <img
          src={
            process.env.NEXT_PUBLIC_ASSET_REVERSE + "/img/fallinstartheader.png"
          }
          className="absolute right-0 top-6"
        />
      </div>
      <div className="bg-white absolute w-full top-[9%] rounded-t-[10px]">
        <div className="space-y-4 relative bg-[#F6F6F6] rounded-t-[10px] pb-[120px]">
          <ProfileHeaderContentMobile t={t} />
          <DataToko
            t={t}
            setPreviousScreen={setPreviousScreen}
            handleSaveStore={handleSaveStore}
            handleSaveCompany={handleSaveCompany}
          />
          <KelengkapanLegalitas t={t} />
        </div>
      </div>
    </div>
  );
}

export default ProfilesellerResponsive;

const HeaderProfileResponsive = ({}) => {
  const router = useCustomRouter();
  //25.03 LB-0485
  const { t } = useTranslation();
  return (
    <div className="flex justify-between items-center">
      <span
        onClick={() => router.back()}
        className="w-6 h-6 rounded-full bg-neutral-50 flex justify-center items-center cursor-pointer"
      >
        <IconComponent
          src={"/icons/chevron-left.svg"}
          classname={style.iconBackRed}
          width={24}
        />
      </span>
      <span className="font-bold text-base text-white">
        {t("labelProfileToko")}
      </span>
      <span onClick={() => router.push("/notifikasi")}>
        <IconComponent src={"/icons/notifheadermobile.svg"} width={24} />
      </span>
    </div>
  );
};

const ProfileHeaderContentMobile = ({}) => {
  const { t } = useTranslation();
  const { profileData } = profileSeller();
  const { useSWRMutateHook } = SWRHandler;
  const { trigger: changeFotoProfil } = useSWRMutateHook(
    `${api}muatparts/profile/update_avatar_url`,
    "PUT"
  );

  const changePhotoHeader = async (val) => {
    if (profileData.profile.avatar !== val) {
      try {
        const formData = new URLSearchParams();
        formData.append("file", val);
        await changeFotoProfil(formData.toString());
        // LB - 0453, 25.03
        // changeFotoProfil(`${api}muatparts/profile/update_avatar_url`);
      } catch (err) {
        console.error("Upload error:", err);
      }
    }
  };

  if (!profileData) return null;

  const verifiedBadge = (
    <span className="text-success-400 text-xs flex gap-[2px] items-center">
      <BadgeCheck fill="#0FBB81" color="white" size={16} />
      Verified
    </span>
  );

  const infoList = [
    {
      label: t("labelNomorWhatsapp"),
      value: profileData.profile.noWA,
      badge: verifiedBadge,
    },
    {
      label: "Email",
      value: profileData.profile.email,
      badge: verifiedBadge,
    },
    {
      label: t("labelJenisAkun"),
      value: profileData.profile.accountType,
    },
    {
      label: t("labelKodeReferral"),
      value: profileData.profile.refferalCode,
      copyable: true,
    },
  ];

  return (
    <div className="bg-white rounded-lg p-4 space-y-4 rounded-t-[10px]">
      <div className="flex flex-col items-center gap-4 -mt-16">
        <ImageUploaderRegisterResponsive
          isProfil={true}
          defaultValue={profileData?.profile?.avatar}
          value={
            changePhotoHeader !== profileData?.profile?.avatar &&
            changePhotoHeader
          }
          previewTitle="Ubah Foto Profil"
          // 24. THP 2 - MOD001 - MP - 015 - QC Plan - Web - MuatParts - Seller - Paket 039 A - Profil Seller - LB - 0066
          previewDescription="Format file jpg/png maks. 10MB"
        />

        <h1 className="font-bold text-sm">{profileData.profile.name}</h1>
      </div>

      <div className="space-y-3 pt-5 px-[15px]">
        {infoList.map((item) => (
          <div key={item.label} className="space-y-1">
            <p className="text-neutral-700 text-sm font-medium">{item.label}</p>
            <div className="flex items-center gap-2">
              <p className="text-sm font-semibold truncate max-w-[234px]">
                {item.value}
              </p>
              {item.badge}
              {/* LB - 0340, 25.03 */}
              {item.copyable && (
                <IconComponent
                  src="/icons/copymuatpartsred.svg"
                  size="small"
                  onclick={() => handleCopy(item.value, t("labelKodeRefSalin"))}
                />
              )}
            </div>
          </div>
        ))}
      </div>
      <hr />
    </div>
  );
};

const StoreSection = ({
  type,
  data,
  isEditMode,
  setIsEditMode,
  locationProps,
  handleSaveStore,
  handleSaveCompany,
  setPreviousScreen,
}) => {
  const {
    storeEdit,
    updateStoreField,
    updateCompanyField,
    companyEdit,
    initializeStoreEdit,
    initializeCompanyEdit,
    errors,
  } = profileSeller();
  const { setAppBar, clearScreen, setScreen } = useHeader();
  const [isOpenMap, setOpenMap] = useState(false);
  const { setShowBottomsheet, setDataBottomsheet, setTitleBottomsheet } =
    toast();
  const { t } = useTranslation();

  useEffect(() => {
    if (isEditMode) {
      if (type === "store") {
        initializeStoreEdit();
      } else {
        initializeCompanyEdit();
      }
    }
  }, [isEditMode, type]);

  const renderContent = () => {
    if (type === "company" && !data.isCross) {
      return [
        {
          label: t("labelNamaPerusahaan"),
          value: data?.companyName || "-",
          type: "text",
          key: "companyName",
        },
        {
          label: t("labelBadanUsaha"),
          value: data?.businessEntity || "-",
          type: "text",
          key: "businessEntity",
        },
      ];
    }

    const fields =
      type === "company"
        ? [
            {
              label: t("labelLogoPerusahaan"),
              value:
                data?.companyLogo ||
                "https://azlogistik.s3.ap-southeast-3.amazonaws.com/dev/file-1736414569172.webp",
              type: "logo",
              key: "companyLogo",
            },
            {
              label: t("labelNamaPerusahaan"),
              value: data?.companyName || "-",
              type: "text",
              key: "companyName",
            },
            {
              label: t("labelBadanUsaha"),
              value: data?.businessEntity || "-",
              type: "text",
              key: "businessEntity",
            },
            {
              label: t("labelBidangUsaha"),
              value: data?.businessField || "-",
              type: "text",
              key: "businessField",
            },
          ]
        : [
            {
              label: t("labelStoreName"),
              value: data?.storeName || "-",
              type: "input",
              key: "storeName",
            },
            {
              label: t("labelStoreLogo"),
              value:
                data?.storeLogo ||
                "https://azlogistik.s3.ap-southeast-3.amazonaws.com/dev/file-1736414569172.webp",
              type: "logo",
              key: "storeLogo",
            },
          ];

    if (!isEditMode) {
      return [
        ...fields,
        {
          label: t("labelAddress"),
          value: data?.address || "-",
          type: "text",
        },
        {
          label: t("labelLocation"),
          value: data?.location || "-",
          type: "text",
        },
        {
          label: t("labelDistrict"),
          value: data?.district || "-",
          type: "text",
        },
        {
          label: t("labelCity"),
          value: data?.city || "-",
          type: "text",
        },
        {
          label: t("labelProvince"),
          value: data?.province || "-",
          type: "text",
        },
        {
          label: t("labelPostalCode"),
          value: data?.postalCode || "-",
          type: "text",
        },
        {
          label: t("labelLocationPoint"),
          value:
            data?.latitude && data?.longitude
              ? `${data.latitude}, ${data.longitude}`
              : "-",
          type: "map",
          coordinates: {
            lat: Number(data?.latitude),
            long: Number(data?.longitude),
          },
          key: "coordinates",
        },
      ];
    }

    return fields;
  };

  return (
    <ContainerResponsiveData
      t={t}
      disableUbah={data.isCross}
      classname={type === "store" && "-mt-7"}
      title={type === "store" ? t("titleStoreInfo") : t("labelDataPerusahaan")}
      info={type === "store" && true}
      onClickInfo={() => {
        setShowBottomsheet(true);
        setTitleBottomsheet(t("titleStoreInfo"));
        setDataBottomsheet(
          <span className="font-medium text-sm text-neutral-900">
            {t("descStoreInfo")}
          </span>
        );
      }}
      data={data}
      type={type}
      onClickUbah={() => {
        if (type === "store") {
          setScreen("editStore");
          setPreviousScreen({
            title: t("labelUbahDataToko"),
            screen: "editStore",
          });
          setAppBar({
            title: t("labelUbahDataToko"),
            renderAppBar: "",
            appBarType: "header_title",
            onBack: () => {
              setScreen("main");
              clearScreen();
            },
          });
        } else if (type === "company" && data.isCross) {
          setScreen("editCompany");
          setPreviousScreen({
            title: t("labelMasukkanInput"),
            screen: "editCompany",
          });

          setAppBar({
            title: t("labelMasukkanInput"),
            renderAppBar: "",
            appBarType: "header_title",
            onBack: () => {
              setScreen("main");
              clearScreen();
            },
          });
        }
      }}
    >
      <>
        {[
          ...renderContent().map((field) => ({
            type: "basic",
            content: (
              <div className="flex flex-col gap-2 px-4">
                <span className="text-neutral-700 font-medium text-sm">
                  {field.label}
                </span>
                <div className="flex justify-between items-center w-full">
                  {field.type === "map" ? (
                    <div className="w-full">
                      <MiniMap
                        lat={field?.coordinates.lat || -7.250445}
                        lng={field?.coordinates.long || 112.768845}
                        onClick={() => setOpenMap(true)}
                        titleButton={t("buttonViewLocation")}
                      />
                      <ModalComponent
                        isOpen={isOpenMap}
                        setClose={() => setOpenMap(false)}
                        hideHeader
                        classnameContent="!w-[326px] !min-w-[326px] !p-[14px]"
                      >
                        <div className="flex flex-col items-start gap-3 w-full overflow-auto">
                          <div className="w-full relative rounded-lg overflow-hidden">
                            <MapContainer
                              viewOnly={true}
                              width={326}
                              height={182}
                              lat={field?.coordinates.lat || -7.250445}
                              lng={field?.coordinates.long || 112.768845}
                            />
                          </div>

                          <div className="flex flex-col gap-2">
                            <span className="text-base font-semibold text-neutral-900 w-full">
                              {t("buttonViewLocation")}
                            </span>
                            <div className="relative">
                              <IconComponent
                                classname="absolute"
                                size="medium"
                                src={"/icons/marker.svg"}
                              />
                              <span className="flex items-center gap-2 w-full font-medium text-[#868686] text-xs pl-[25px]">
                                {data?.location}
                              </span>
                            </div>
                          </div>
                        </div>
                      </ModalComponent>
                    </div>
                  ) : field.type === "logo" ? (
                    isEditMode ? (
                      <ImageUploaderRegister
                        value={(e) => {
                          if (type === "store") {
                            updateStoreField("storeLogo", e);
                          } else {
                            updateCompanyField("companyLogo", e);
                          }
                        }}
                        defaultValue={field.value}
                      />
                    ) : (
                      <div className="w-16 h-16 rounded-full overflow-hidden">
                        {/* LB - 0130, 25.03 */}
                        <img
                          src={field.value}
                          alt="Logo"
                          className="w-full h-full object-cover bg-white"
                        />
                      </div>
                    )
                  ) : field.type === "input" && isEditMode ? (
                    <Input
                      classname="!min-w-[363px]"
                      status={errors?.[field.key] ? "error" : ""}
                      maxLength="60"
                      supportiveText={{
                        title: errors?.[field.key] || "",
                        desc: `${
                          type === "store"
                            ? storeEdit?.data?.[field.key].length
                            : companyEdit?.data?.[field.key].length
                        }/60`,
                      }}
                      placeholder={`${t("labelMasukkanInput")} ${field.label}`}
                      value={
                        type === "store"
                          ? storeEdit?.data?.[field.key] || ""
                          : companyEdit?.data?.[field.key] || ""
                      }
                      changeEvent={(e) => {
                        const value = e.target.value;
                        if (type === "store") {
                          updateStoreField(field.key, value);
                        } else {
                          updateCompanyField(field.key, value);
                        }
                      }}
                    />
                  ) : (
                    <p className="font-medium text-sm text-neutral-900">
                      {field.value}
                    </p>
                  )}
                </div>
              </div>
            ),
          })),
          isEditMode
            ? {
                type: "location",
                content: (
                  <div className="manlokContainer">
                    <LocationManagement
                      value={locationProps.setManajemenLokasi}
                      defaultValue={locationProps.defaultManajemenLokasi}
                      errors={locationProps.errors}
                    />
                  </div>
                ),
              }
            : null,
        ]
          .filter(Boolean)
          .map((item, index) => (
            <>
              <div key={index} className={``}>
                {item.content}
              </div>
              <hr />
            </>
          ))}
      </>
    </ContainerResponsiveData>
  );
};

export const DataToko = ({
  handleSaveStore,
  handleSaveCompany,
  setPreviousScreen,
}) => {
  const [isEditCompany, setIsEditCompany] = useState(false);
  const [isEditStore, setIsEditStore] = useState(false);
  const [manajemenLokasi, setManajemenLokasi] = useState();
  const [defaultManajemenLokasi, setDefaultManajemenLokasi] = useState(null);
  const { profileData, errors } = profileSeller();
  const { t } = useTranslation();
  useEffect(() => {
    if (!profileData) return;

    const storeInfo =
      profileData?.profile?.accountType === "Perusahaan"
        ? profileData?.storeInformation
        : profileData?.companyData;

    if (storeInfo) {
      setDefaultManajemenLokasi({
        address: storeInfo.address,
        listPostalCodes: storeInfo.listPostalCode,
        listDistricts: storeInfo.listDistrict,
        location: { title: storeInfo.location },
        district: { name: storeInfo.district, value: storeInfo.districtID },
        city: { name: storeInfo.city, id: storeInfo.cityID },
        province: { name: storeInfo.province, id: storeInfo.provinceID },
        postalCode: { name: storeInfo.postalCode },
        coordinates: { lat: storeInfo.latitude, long: storeInfo.longitude },
      });
    }
  }, [profileData, isEditStore, isEditCompany]);

  if (!profileData) return <Skeleton fill={5} />;

  const storeInfo = profileData?.storeInformation || {};
  const companyData = profileData?.companyData || {};
  const isCompany = profileData?.profile?.accountType === "Perusahaan";
  const locationProps = {
    manajemenLokasi,
    setManajemenLokasi,
    defaultManajemenLokasi,
    errors,
  };

  return (
    <div className="space-y-4">
      <StoreSection
        type="store"
        data={storeInfo}
        isEditMode={isEditStore}
        setIsEditMode={setIsEditStore}
        locationProps={{
          manajemenLokasi,
          setManajemenLokasi,
          defaultManajemenLokasi,
          errors,
        }}
        handleSaveStore={handleSaveStore}
        handleSaveCompany={handleSaveCompany}
        setPreviousScreen={setPreviousScreen}
        t={t}
      />
      {isCompany && profileData?.companyData?.isCross && (
        <StoreSection
          type="company"
          data={companyData}
          isEditMode={isEditCompany}
          setIsEditMode={setIsEditCompany}
          locationProps={{
            manajemenLokasi,
            setManajemenLokasi,
            defaultManajemenLokasi,
            errors,
          }}
          handleSaveStore={handleSaveStore}
          handleSaveCompany={handleSaveCompany}
          setPreviousScreen={setPreviousScreen}
          t={t}
        />
      )}
      {isCompany && !profileData?.companyData?.isCross && (
        <StoreSection
          type="company"
          data={profileData?.companyData}
          isEditMode={false}
          setIsEditMode={() => {}}
          locationProps={locationProps}
          handleSaveStore={handleSaveStore}
          handleSaveCompany={handleSaveCompany}
          setPreviousScreen={setPreviousScreen}
          t={t}
        />
      )}
    </div>
  );
};

export const KelengkapanLegalitas = ({}) => {
  const { profileData } = profileSeller();
  const { t } = useTranslation();
  if (!profileData?.legality) return <Skeleton fill={3} />;

  const legalInfo = [
    {
      label: t("labelIdCard"),
      value: (
        <span className="font-semibold text-sm text-success-400">
          File {t("labelIdCard")}.png
        </span>
      ),
      button: profileData.legality.fileKTP,
    },
    { label: t("labelIdNumber"), value: profileData.legality.noKTP },
    { label: t("labelIdName"), value: profileData.legality.nameKTP },
    ...(profileData.legality.noNPWP
      ? [
          {
            label: t("labelNPWPBadanUsaha"),
            value: (
              <span className="text-success-400">
                File {t("labelNPWPBadanUsaha")}.png
              </span>
            ),
            button: profileData.legality.fileNPWP,
          },
          {
            label: t("labelNoNPWPBadanUsaha"),
            value: profileData.legality.noNPWP,
          },
        ]
      : []),
  ];

  return (
    <ContainerResponsiveData title={t("titleLegalDocs")} t={t}>
      {legalInfo.map((item, index) => (
        <>
          <div key={item.label} className="px-4">
            <span className="text-neutral-700 font-medium text-sm">
              {item.label}
            </span>
            <div className="flex justify-between items-center w-full">
              <p className="font-semibold text-sm text-neutral-900">
                {item.value}
              </p>
              {item.button && (
                <div className="flex items-center gap-1">
                  <Button
                    onClick={() =>
                      handleDownload(
                        item.button,
                        `ktp_${profileData.legality.nameKTP}_${profileData.legality.noKTP}`
                      )
                    }
                    Class="!h-8 !font-semibold !text-sm !bg-white !text-primary-700 !p-0 !min-w-fit !max-w-fit !m-0"
                  >
                    {t("buttonDownload")}
                  </Button>
                  <Download size={14} color="#176cf7" />
                </div>
              )}
            </div>
          </div>
          <hr />
        </>
      ))}
    </ContainerResponsiveData>
  );
};

const ContainerResponsiveData = ({
  title,
  info = false,
  onClickInfo,
  onClickUbah,
  classname,
  children,
  disableUbah,
  data,
  type,
}) => {
  // console.log(data, type, " puky");
  const { t } = useTranslation();
  return (
    <div className={`space-y-4 p-4 bg-white ${classname}`}>
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-2">
          <h2 className="font-bold text-sm mt-[2px]">{title}</h2>
          {info && (
            <Info
              size={14}
              color="#176cf7"
              onClick={onClickInfo}
              className="cursor-pointer"
            />
          )}
        </div>
        {/* {!disableUbah && type === "store" ? null : ( */}
        {/* iki rules gae hide tombol ubah mas, type === "company" && !data.isCross */}
        {/* LB - 0595, 25.03 */}
        {title !== t("titleLegalDocs") && (
          <div
            className={`${
              type === "company" && !data.isCross ? "hidden" : "flex"
            } items-center gap-2 cursor-pointer`}
            onClick={onClickUbah}
          >
            <span className="text-sm font-semibold text-primary-700 mt-[2px]">
              {t("labelUbahBtn")}
            </span>
            <PencilLine size={14} className="text-primary-700" />
          </div>
        )}
        {/* )} */}
      </div>
      <div className="space-y-3">{children}</div>
    </div>
  );
};
