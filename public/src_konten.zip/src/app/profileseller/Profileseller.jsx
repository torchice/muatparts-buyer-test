"use client";

import viewport from "@/store/zustand/common";
import { useState, useEffect } from "react";
import ProfilesellerResponsive from "./ProfilesellerResponsive";
import ProfilesellerWeb from "./ProfilesellerWeb";
import SWRHandler from "@/services/useSWRHook";
import profileSeller from "@/store/zustand/profileSeller";
import { useSWRConfig } from "swr";
import { useLocationStore } from "@/store/zustand/locationManagement";
import { useHeader } from "@/common/ResponsiveContext";
import { useTranslation } from "@/context/TranslationProvider";

const api = process.env.NEXT_PUBLIC_GLOBAL_API + "v1/";

function Profileseller() {
  const { t } = useTranslation();
  const { setScreen, clearScreen } = useHeader();
  const {
    profileData,
    setProfileData,
    setStoreError,
    validateStoreData,
    storeEdit,
    companyEdit,
  } = profileSeller();
  const { useSWRHook, useSWRMutateHook } = SWRHandler;
  const { isMobile } = viewport();
  const { mutate } = useSWRConfig();
  const { resetLocationStateResponsive } = useLocationStore();

  // Get initial profile data
  const { data: dataProfile } = useSWRHook(`${api}muatparts/profile`);

  // Initialize SWR Handlers dengan key yang sesuai format API
  const { trigger: updateStoreTrigger } = useSWRMutateHook(
    `${api}muatparts/profile/${profileData?.storeInformation?.id}`,
    "PUT"
  );

  const { trigger: updateCompanyTrigger } = useSWRMutateHook(
    `${api}muatparts/profile/company/${profileData?.companyData?.id}`,
    "PUT"
  );

  const handleSaveStore = async (id, data) => {
    const isValid = validateStoreData(data);

    if (!isValid) {
      return Promise.reject(new Error("Invalid store data"));
    }

    try {
      await updateStoreTrigger(
        {
          storeName: data.storeName,
          // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0374
          // address: data.address,
          // location: data.location,
          address: data.location,
          location: data.address,
          provinceID: data.provinceID,
          cityID: data.cityID,
          districtID: data.districtID,
          postalCode: data.postalCode,
          latitude: data.latitude,
          longitude: data.longitude,
          storeLogo: data.storeLogo,
        },
        `${api}muatparts/profile/${id}`
      );

      setScreen("main");
      mutate(`${api}muatparts/profile`);
      resetLocationStateResponsive();
      return Promise.resolve();
    } catch (error) {
      console.error("Save store error:", error?.response?.data);
      if (error?.response?.data?.Message?.Code === 400) {
        const validationErrors = error.response.data.Data;
        setStoreError(validationErrors.Field, validationErrors.Message);
      }
      throw error;
    }
  };

  const handleSaveCompany = async (id, data) => {
    try {
      await updateCompanyTrigger(
        {
          // address: data.address,
          // location: data.location,
          address: data.location,
          location: data.address,
          provinceID: data.provinceID,
          cityID: data.cityID,
          districtID: data.districtID,
          postalCode: data.postalCode,
          latitude: data.latitude,
          longitude: data.longitude,
          companyLogo: data.companyLogo,
        },
        `${api}muatparts/profile/company/${id}`
      ); // URL sebenarnya sebagai parameter kedua
      setScreen("main");
      mutate(`${api}muatparts/profile`);
      resetLocationStateResponsive();
    } catch (error) {
      console.error("Save company error:", error);
      throw error;
    }
  };

  useEffect(() => {
    if (dataProfile?.Data) {
      const newData = {
        ...dataProfile.Data,
        storeInformation: {
          ...dataProfile.Data.storeInformation,
          address: dataProfile.Data.storeInformation.location,
          location: dataProfile.Data.storeInformation.address,
        },
      };
      setProfileData(newData);
    }
  }, [dataProfile, setProfileData]);

  if (typeof isMobile !== "boolean") return <></>;
  if (isMobile)
    return (
      <ProfilesellerResponsive
        t={t}
        handleSaveStore={handleSaveStore}
        handleSaveCompany={handleSaveCompany}
      />
    );
  return (
    <ProfilesellerWeb
      t={t}
      handleSaveStore={handleSaveStore}
      handleSaveCompany={handleSaveCompany}
    />
  );
}

export default Profileseller;
