import React, { useState, useEffect } from "react";
import Button from "@/components/Button/Button";
import LocationManagement from "@/components/LocationManagement/LocationManagement";
import profileSeller from "@/store/zustand/profileSeller";
import ImageUploaderRegisterResponsive from "@/components/ImageUploader/ImageUploaderRegisterResponsive";
import { BatalkanPerubahan } from "./EditStoreScreen";
import NavSelectedMobile from "@/components/Bottomsheet/NavSelectedMobile";
import { TriangleAlert } from "lucide-react";
import { modal } from "@/store/zustand/modal";
import toast from "@/store/zustand/toast";

const EditCompanyScreen = ({ handleSaveCompany, previousScreen, t }) => {
  const {
    companyEdit,
    updateCompanyField,
    initializeCompanyEdit,
    validateCompanyData,
    profileData,
  } = profileSeller();
  const { setModalConfig, setModalOpen, setModalContent } = modal();

  const [manajemenLokasi, setManajemenLokasi] = useState();
  const [defaultManajemenLokasi, setDefaultManajemenLokasi] = useState(null);

  useEffect(() => {
    if (manajemenLokasi) {
      updateCompanyField("address", manajemenLokasi.address);
      updateCompanyField("location", manajemenLokasi.location?.title);
      updateCompanyField("districtID", manajemenLokasi.district?.value);
      updateCompanyField("cityID", manajemenLokasi.city?.id);
      updateCompanyField("provinceID", manajemenLokasi.province?.id);
      updateCompanyField("postalCode", manajemenLokasi.postalCode?.value);
      updateCompanyField("latitude", manajemenLokasi.coordinates?.lat);
      updateCompanyField("longitude", manajemenLokasi.coordinates?.long);
    }
  }, [manajemenLokasi]);

  useEffect(() => {
    initializeCompanyEdit();

    if (profileData?.companyData) {
      setDefaultManajemenLokasi({
        address: profileData.companyData.address,
        listPostalCodes: profileData.companyData.listPostalCode,
        listDistricts: profileData.companyData.listDistrict,
        location: { title: profileData.companyData.location },
        district: {
          name: profileData.companyData.district,
          value: profileData.companyData.districtID,
        },
        city: {
          name: profileData.companyData.city,
          id: profileData.companyData.cityID,
        },
        province: {
          name: profileData.companyData.province,
          id: profileData.companyData.provinceID,
        },
        postalCode: { name: profileData.companyData.postalCode },
        coordinates: {
          lat: profileData.companyData.latitude,
          long: profileData.companyData.longitude,
        },
      });
    }
  }, []);

  const handleSubmit = async () => {
    const isValid = validateCompanyData(companyEdit.data, t);

    if (!isValid) return;

    try {
      await handleSaveCompany(profileData?.companyData?.id, companyEdit.data);
    } catch (error) {
      console.error("Save error:", error);
    }
  };

  const ReadOnlyField = ({ label, value }) => (
    <div className="space-y-2">
      <span className="text-neutral-900 font-semibold text-sm">{label}</span>
      <p className="text-neutral-900 font-semibold text-sm">{value || "-"}</p>
    </div>
  );

  return (
    <div className="bg-white min-h-screen relative pb-20">
      <div className="p-4 space-y-4">
        <div className="flex items-center gap-2 rounded-md py-2 px-3 bg-secondary-100">
          <TriangleAlert color="#FF7A00" size={20} />
          <span className="font-medium text-xs text-neutral-900 w-[274px]">
            {t("labelDataBFTMChangePage")}
          </span>
        </div>
        {/* Company Logo */}
        <div className="space-y-2">
          <span className="text-neutral-900 font-semibold text-sm">
            {t("labelLogoPerusahaan")}
          </span>
          <ImageUploaderRegisterResponsive
            value={(file) => updateCompanyField("companyLogo", file)}
            defaultValue={companyEdit?.data?.companyLogo}
            previewTitle={t("titleUpload")}
            // 24. THP 2 - MOD001 - MP - 015 - QC Plan - Web - MuatParts - Seller - Paket 039 A - Profil Seller - LB - 0066
            previewDescription="Format file jpg/png maks. 10MB"
          />
        </div>

        {/* Read-only fields */}
        <ReadOnlyField
          label={t("labelNamaPerusahaan")}
          value={profileData?.companyData?.companyName}
        />
        <ReadOnlyField
          label={t("labelBadanUsaha")}
          value={profileData?.companyData?.businessEntity}
        />
        <ReadOnlyField
          label={t("labelBidangUsaha")}
          value={profileData?.companyData?.businessField}
        />

        {/* Location Management */}
        <div className="space-y-2">
          <LocationManagement
            value={(value) => setManajemenLokasi(value)}
            defaultValue={defaultManajemenLokasi}
            errors={companyEdit.errors?.location}
            previousScreen={previousScreen}
          />
        </div>

        {/* Action Buttons */}
        <NavSelectedMobile classname="left-0 flex items-center gap-2 justify-center !w-full">
          <Button
            onClick={() => {
              setModalContent(<BatalkanPerubahan t={t} />);
              setModalOpen(true);
              setModalConfig({
                classname: "!w-[296px]",
                withHeader: false,
                withClose: false,
              });
            }}
            Class="!min-w-[50%] !h-[40px] !text-sm !font-semibold"
            color="primary_secondary"
          >
            {t("buttonCancel")}
          </Button>
          <Button
            onClick={handleSubmit}
            Class="!min-w-[50%] !h-[40px] !text-sm !font-semibold"
          >
            {t("labelSimpanNav")}
          </Button>
        </NavSelectedMobile>
      </div>
    </div>
  );
};

export default EditCompanyScreen;
