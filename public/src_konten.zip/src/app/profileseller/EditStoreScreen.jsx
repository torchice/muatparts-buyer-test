import React, { useState, useEffect, useRef } from "react";
import { useHeader } from "@/common/ResponsiveContext";
import { X } from "lucide-react";
import Button from "@/components/Button/Button";
import Input from "@/components/Input/Input";
import LocationManagement from "@/components/LocationManagement/LocationManagement";
import profileSeller from "@/store/zustand/profileSeller";
import NavSelectedMobile from "@/components/Bottomsheet/NavSelectedMobile";
import { modal } from "@/store/zustand/modal";
import ImageUploaderRegisterResponsive from "@/components/ImageUploader/ImageUploaderRegisterResponsive";
import toast from "@/store/zustand/toast";
import { useLocationStore } from "@/store/zustand/locationManagement";

const EditStoreScreen = ({ handleSaveStore, previousScreen, t }) => {
  const {
    storeEdit,
    updateStoreField,
    initializeStoreEdit,
    validateStoreData,
    setStoreError,
    profileData,
  } = profileSeller();
  const { setModalConfig, setModalOpen, setModalContent } = modal();

  const [manajemenLokasi, setManajemenLokasi] = useState();
  const [defaultManajemenLokasi, setDefaultManajemenLokasi] = useState(null);
  const { getAllLocationData } = useLocationStore();
  const locationData = getAllLocationData();

  const hasInitValue = useRef(false);

  useEffect(() => {
    // LB - 0623 - 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2
    if (hasInitValue.current === true) return;

    // LB - 0387, 25.03
    if (!locationData) initializeStoreEdit();

    if (profileData?.storeInformation) {
      // LB - 0452, 25.03
      updateStoreField(
        "storeName",
        storeEdit.data.storeName || profileData.storeInformation.storeName || ""
      );
      updateStoreField(
        "storeLogo",
        storeEdit.data.storeLogo || profileData.storeInformation.storeLogo || ""
      );

      setDefaultManajemenLokasi({
        address: storeEdit.data.address || profileData.storeInformation.address,
        listPostalCodes:
          storeEdit.data.listPostalCode ||
          profileData.storeInformation.listPostalCode,
        listDistricts:
          storeEdit.data.listDistrict ||
          profileData.storeInformation.listDistrict,
        location: {
          title:
            storeEdit.data.location || profileData.storeInformation.location,
        },
        district: {
          name:
            storeEdit.data.district || profileData.storeInformation.district,
          value:
            storeEdit.data.districtID ||
            profileData.storeInformation.districtID,
        },
        city: {
          name: storeEdit.data.city || profileData.storeInformation.city,
          id: storeEdit.data.cityID || profileData.storeInformation.cityID,
        },
        province: {
          name:
            storeEdit.data.province || profileData.storeInformation.province,
          id:
            storeEdit.data.provinceID ||
            profileData.storeInformation.provinceID,
        },
        postalCode: {
          name:
            storeEdit.data.postalCode ||
            profileData.storeInformation.postalCode,
        },
        coordinates: {
          lat: storeEdit.data.latitude || profileData.storeInformation.latitude,
          long:
            storeEdit.data.longitude || profileData.storeInformation.longitude,
        },
      });
    }

    hasInitValue.current = true;
  }, [profileData, storeEdit]);

  useEffect(() => {
    if (manajemenLokasi) {
      updateStoreField("address", manajemenLokasi.address);
      updateStoreField("location", manajemenLokasi.location?.title);
      updateStoreField("districtID", manajemenLokasi.district?.value);
      updateStoreField("cityID", manajemenLokasi.city?.id);
      updateStoreField("provinceID", manajemenLokasi.province?.id);
      updateStoreField("postalCode", manajemenLokasi.postalCode?.value);
      updateStoreField("latitude", manajemenLokasi.coordinates?.lat);
      updateStoreField("longitude", manajemenLokasi.coordinates?.long);
    }
  }, [manajemenLokasi]);

  const handleSubmit = async () => {
    const data = storeEdit.data;
    const isValid = validateStoreData(data, t);
    if (!isValid) return;

    try {
      await handleSaveStore(profileData?.storeInformation?.id, data);
    } catch (error) {
      if (error?.response?.data?.Data?.Field === "storeName") {
        setStoreError(
          error?.response?.data?.Data?.Field,
          error?.response?.data?.Data?.Message || t("labelNamaTokoActiveDB")
        );
      }
    }
  };

  return (
    <div className="bg-white min-h-screen pb-20">
      <div className="p-4 space-y-4">
        {/* <div className="flex items-center gap-2 rounded-md py-2 px-3 bg-secondary-100">
          <TriangleAlert color="#FFCA2E" size={20} />
          <span className="font-medium text-xs text-neutral-900 w-[274px]">
            Data pada halaman profil Big Fleets / Transport Market akan berubah
            sesuai dengan data yang diubah pada halaman ini.
          </span>
        </div> */}
        {/* Store Name */}
        <div className="space-y-2">
          <span className="text-neutral-900 font-semibold text-sm">
            {t("labelStoreName")}*
          </span>
          <Input
            className="w-full"
            status={storeEdit.errors?.storeName ? "error" : ""}
            maxLength="60"
            supportiveText={{
              title: storeEdit.errors?.storeName || "",
              desc: `${storeEdit?.data?.storeName?.length || 0}/60`,
            }}
            placeholder={t("labelPlaceholderNamaToko")}
            value={storeEdit?.data?.storeName || ""}
            changeEvent={(e) => updateStoreField("storeName", e.target.value)}
          />
        </div>

        {/* Store Logo */}
        <div className="space-y-2">
          <span className="text-neutral-900 font-semibold text-sm">
            {t("labelStoreLogo")}
          </span>
          <ImageUploaderRegisterResponsive
            value={(file) => updateStoreField("storeLogo", file)}
            defaultValue={storeEdit?.data?.storeLogo}
            previewTitle={t("titleUpload")}
            // 24. THP 2 - MOD001 - MP - 015 - QC Plan - Web - MuatParts - Seller - Paket 039 A - Profil Seller - LB - 0066
            previewDescription="Format file jpg/png maks. 10MB"
          />
        </div>

        {/* Location Management */}
        <div className="space-y-2">
          <LocationManagement
            value={(value) => setManajemenLokasi(value)}
            defaultValue={defaultManajemenLokasi}
            errors={storeEdit.errors?.location}
            previousScreen={previousScreen}
          />
        </div>

        {/* Action Buttons */}
        <NavSelectedMobile classname="left-0 flex items-center gap-2 justify-center !w-full">
          <Button
            onClick={() => {
              setModalContent(<BatalkanPerubahan t={t} />);
              setModalOpen(true);
              setModalConfig({
                classname: "!w-[296px]",
                withHeader: false,
                withClose: false,
              });
            }}
            Class="!min-w-[50%] !h-[40px] !text-sm !font-semibold"
            color="primary_secondary"
          >
            {t("buttonCancel")}
          </Button>
          <Button
            onClick={handleSubmit}
            Class="!min-w-[50%] !h-[40px] !text-sm !font-semibold"
          >
            {t("labelSimpanNav")}
          </Button>
        </NavSelectedMobile>
      </div>
    </div>
  );
};

export default EditStoreScreen;

export const BatalkanPerubahan = ({ t }) => {
  const { setModalOpen } = modal();
  const { clearScreen, setScreen } = useHeader();
  const { resetLocationStateResponsive } = useLocationStore();

  return (
    <div className="px-4 py-6 flex flex-col gap-3 justify-center items-center relative">
      <X
        color="#176cf7"
        size={24}
        className="right-2 absolute top-1 cursor-pointer"
        onClick={() => setModalOpen(false)}
      />
      <span className="font-bold text-base text-neutral-900">
        {t("labelBatalkanPerubahan")}
      </span>
      <span className="font-medium text-sm text-neutral-900 text-center">
        {t("labelConfirmationPerubahan")}
      </span>
      <div className="w-full flex gap-2 justify-center">
        <Button
          onClick={() => {
            resetLocationStateResponsive();
            setModalOpen(false);
            clearScreen();
            setScreen("main");
          }}
          Class="!min-w-[112px] !h-[28px] !font-semibold !text-xs"
          color="primary_secondary"
        >
          {t("labelYakinNav")}
        </Button>
        <Button
          onClick={() => setModalOpen(false)}
          Class="!min-w-[112px] !h-[28px] !font-semibold !text-xs"
        >
          {t("labelButtonCancel")}
        </Button>
      </div>
    </div>
  );
};
