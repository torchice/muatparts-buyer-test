"use client"

import Otp from "@/container/Register/Otp";
import OtpResponsive from "@/container/Register/OtpResponsive";
import { useTranslation } from "@/context/TranslationProvider";
import { useCustomRouter } from "@/libs/CustomRoute";
import SWRHandler from "@/services/useSWRHook";
import { authZustand } from "@/store/auth/authZustand";
import { userZustand } from "@/store/auth/userZustand";
import viewport from "@/store/zustand/common";
import otpInputZustand from "@/store/zustand/otpInput";
import otpRegisterZustand from "@/store/zustand/otpRegister";
import { useEffect, useState } from "react";
// 24. THP 2 - MOD001 - MP - 012 - QC Plan - Web - Muatparts - Paket 005 A - Daftar Sebagai Seller Muatparts - LB - 0311
import registerForm from "@/store/zustand/registerForm";

const baseUrl = `${process.env.NEXT_PUBLIC_GLOBAL_API}v1/`;

const Page = () => {
    // STATE NOTIF WEB
    const [notification, setNotification] = useState(null);
    // STATE NOTIF RESPONSIVE
    const [showToast, setShowToast] = useState(false);
    const [dataToast, setDataToast] = useState({});
    // FIX BUG Daftar Sebagai Seller Muatparts LB-0312
    const { t } = useTranslation();
    // 24. THP 2 - MOD001 - MP - 012 - QC Plan - Web - Muatparts - Paket 005 A - Daftar Sebagai Seller Muatparts - LB - 0311
    const { setRegistrationStatus, setStepPage } = registerForm();
    const router = useCustomRouter();
    const { isMobile } = viewport();
    const { isTimerActive, otp, resetOtp, setIsTimerActive, setTimeLeft, timeLeft } = otpInputZustand();
    const { email,setSuccessVerifyOtp, tipeToko } = otpRegisterZustand();

    const { useSWRHook, useSWRMutateHook } = SWRHandler;
    const { data: dataTimerOtp } = useSWRHook(
        `${baseUrl}register/timer_otp?Email=${email}&Type=18`
    );
    const { data: dataResendOtp, trigger: resendOtp } = useSWRMutateHook(
        `${baseUrl}register/resend_otp`,
        "POST"
    );
    const { trigger: verifyOtp, error: errorVerifyOtp } = useSWRMutateHook(
        `${baseUrl}register/verify_otp`,
        "POST"
    );
    const { trigger: registerSeller, error: errorRegisterSeller } = useSWRMutateHook(
        tipeToko === 0
            ? `${baseUrl}register/register_merchant_personal`
            : `${baseUrl}register/register_merchant_company`,
        "PUT"
    );
    const { trigger: revokeRefreshToken } = useSWRMutateHook(
        `${baseUrl}muatparts/auth/revoke-refresh-token`,
        "POST"
    )

    const remainingTime = dataTimerOtp?.Data.Remaining;
    const expiresIn = dataResendOtp?.data.Data.expiresIn;

    useEffect(() => {
        if (!email) {
            if (!userZustand.getState().dataMatrix?.isVerifSellerMuatparts) {
                router.push(`/register`)
            } else {
                router.push(`/dashboard`)
            }
        }
    }, [email, !userZustand.getState().dataMatrix?.isVerifSellerMuatparts])

    useEffect(() => {
        if (remainingTime) {
          setTimeLeft(remainingTime);
          setIsTimerActive(true);
        }
    }, [remainingTime]);

    // Start countdown timer
    useEffect(() => {
        let timerCountdown;
        if (isTimerActive && timeLeft > 0) {
            timerCountdown = setTimeout(() => {
                setTimeLeft(timeLeft - 1);
            }, 1000);
        } else if (isTimerActive && timeLeft === 0) {
            setIsTimerActive(false);
        }
        return () => {
            if (timerCountdown) {
                clearTimeout(timerCountdown);
            }
        };
    }, [timeLeft, isTimerActive]);

    useEffect(() => {
        if (expiresIn) {
            setTimeLeft(expiresIn);
            setIsTimerActive(true);
            if (isMobile) {
                setShowToast(true);
                setDataToast({
                    message: t("messageSuccessResentOtp"),
                    type: "success",
                });
            } else {
                setNotification({
                    message: t("messageSuccessResentOtp"),
                    status: "success",
                });
            }
        }
    }, [expiresIn]);

    // set error
    useEffect(() => {
        if (errorVerifyOtp) {
            const message = errorVerifyOtp.response.data.Data
                ? errorVerifyOtp.response.data.Data.Message
                : errorVerifyOtp.response.data.error;
            const displayedMessage = message === "Kode OTP yang Anda masukkan salah" ? t("messageIncorrectOtp") : message
            if (isMobile) {
                setShowToast(true);
                setDataToast({
                    message: displayedMessage,
                    type: "error",
                });
            } else {
                setNotification({ message: displayedMessage, status: "error" });
            }
        }
    }, [JSON.stringify(errorVerifyOtp)]);

    // 24. THP 2 - MOD001 - MP - 012 - QC Plan - Web - Muatparts - Paket 005 A - Daftar Sebagai Seller Muatparts - LB - 0311
    useEffect(() => {
        if (errorRegisterSeller) {
            const message = errorRegisterSeller?.response?.data?.Data?.Message
            if (message === "Nama toko telah digunakan") {
                setRegistrationStatus({
                    status: "error",
                    message
                })
                // 24. THP 2 - MOD001 - MP - 012 - QC Plan - Web - Muatparts - Paket 005 A - Daftar Sebagai Seller Muatparts - LB - 0311
                setStepPage(0)
                router.push("/register")
            }
        }
    }, [JSON.stringify(errorRegisterSeller)])

    // Handle OTP completion
    useEffect(() => {
        const handleVerifyOtp = async () => {
            try {
                await verifyOtp({
                    Email: email,
                    Otp: otp.join(""),
                    // Role: 5,
                    // SuperMenuID: 6
                })
                await registerSeller()
                setSuccessVerifyOtp(true)
                await revokeRefreshToken({
                    refreshToken: authZustand.getState().refreshToken
                });
                authZustand.getState().clearToken();
                userZustand.getState().removeUser();
                router.push(`${process.env.NEXT_PUBLIC_INTERNAL_WEB}traffic/redirect_seller_muatparts`);
            } catch (error) {
                console.log(error);
            }
        };

        if (!otp.includes("")) {
            handleVerifyOtp();
        }
    }, [JSON.stringify(otp), email]);

    const handleResendCode = async () => {
        await resendOtp({ Email: email })
            .then(() => resetOtp())
            .catch(err => console.log(err));
    };
    
    if (isMobile) {
        return (
            <OtpResponsive
                dataToast={dataToast}
                onResendCode={handleResendCode}
                setDataToast={setDataToast}
                setShowToast={setShowToast}
                showToast={showToast}
            />
        )
    }
    return (
        <Otp
            notification={notification}
            onResendCode={handleResendCode}
            // 24. THP 2 - MOD001 - MP - 012 - QC Plan - Web - Muatparts - Paket 005 A - Daftar Sebagai Seller Muatparts - LB - 0312
            setNotification={setNotification}
        />
    )
}

export default Page