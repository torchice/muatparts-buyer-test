"use client";

import { useEffect } from "react";
import BreadCrumb from "@/components/BreadCrumb/BreadCrumb";
import Button from "@/components/Button/Button";
import IconComponent from "@/components/IconComponent/IconComponent";
import InformasiTokoAkun from "@/container/Register/InformasiTokoAkun";
import InformasiPendaftarDanRekening from "@/container/Register/InformasiPendaftarDanRekening";
import KonfirmasiData from "@/container/Register/KonfirmasiData";
import registerForm, { registerAcceptTerms } from "@/store/zustand/registerForm";
import toast from "@/store/zustand/toast";
import { useCustomRouter } from "@/libs/CustomRoute";
import { useTranslation } from "@/context/TranslationProvider";
import Checkbox from "@/components/Checkbox/Checkbox";

function RegisterWeb({ handleNext, isSubmitting, bankOptions }) {
  const { prevStep, currentStep, setStepPage } = registerForm();
  const { isAcceptTerms, setIsAcceptTerms } = registerAcceptTerms();
  const { setShowSidebar } = toast();
  const router = useCustomRouter();
  const {t} = useTranslation();
  
  const BREADCRUMB_ITEMS = [
    t('titleStoreAccount'),
    t('titleRegistrantInfo'),
    t('titleConfirmation'),
  ];

  useEffect(() => {
    setStepPage(0);
    setShowSidebar(false);
  }, []);

  const handleGoBack = () => {
    if (currentStep !== "1") {
      prevStep();
    }
  };

  return (
    <div>
      <div className="max-w-[758px] mx-auto mt-[108px] pb-5 min-h-[calc(100vh_-_130px)] w-full">
        <div
          className={`bg-white ${
            currentStep === 2
              ? "!rounded-b-none !border-none shadow-[0px_4px_11px_0px_#41414140]"
              : "shadow-muat"
          } rounded-[10px] border border-[#E5E7EB]`}
        >
          <div className={`${currentStep !== 1 ? "px-8 py-6" : "p-8"} w-[758px]`}>
            <div className="flex relative items-center justify-center sm:mx-0 mx-[14px]">
              <IconComponent
                classname="absolute left-0 top-0"
                src="/icons/arrowbackblue.svg"
                size="medium"
                onclick={
                  currentStep !== 0 ? handleGoBack : () => router.push("/landing")
                }
              />
              <div className="flex flex-col flex-1 gap-y-3 ml-8 items-center">
                <span className="text-[20px] leading-[24px] font-bold text-neutral-900">
                 { t('titleRegister')}
                </span>
                <BreadCrumb
                  data={BREADCRUMB_ITEMS.slice(0, currentStep + 1)}
                  maxWidth="190px"
                  onclick={(val) => {
                    const index = BREADCRUMB_ITEMS.findIndex(
                      (item) => item === val
                    );
                    // router.push(`/register?step=${Number(index) + 1}`);
                    setStepPage(Number(index));
                  }}
                />
              </div>
            </div>
            {currentStep === 0 ? <InformasiTokoAkun /> : null}
            {currentStep === 1 ? (
              <InformasiPendaftarDanRekening bankOptions={bankOptions} />
            ) : null}
          </div>
        </div>
        <div className="">{currentStep === 2 && <KonfirmasiData />}</div>

        <div className="mt-6 flex flex-col gap-4">
          {/* Imp Checkbox Persetujuan Syarat dan Ketentuan Registrasi Seller muatparts */}
          {currentStep === 2 && (
            <Checkbox
              onChange={({ checked }) => setIsAcceptTerms(checked)}
              checked={isAcceptTerms}
            >
              <span className="font-medium text-xs leading-[1.2] tracking-wide">
                {t("labelRegisterIAgreeTo")}{" "}
                <a 
                  className="text-primary-700" 
                  href="https://faq.muatmuat.com/list-content/Vkc1d1ZsQlJQVDA9/Vkc1d2FsQlJQVDA9/VkZaU2FrMVJQVDA9" 
                  target="_blank" 
                  rel="noopener noreferrer"
                >
                  {t("linkTerms")}
                </a>{" "}
                muatparts Mart.
              </span>
            </Checkbox>
          )}
          <div className="flex justify-center">
            <Button
              Class="!h-[32px] !font-semibold"
              name="next"
              color="primary"
              onClick={handleNext}
              disabled={isSubmitting}
            >
              {isSubmitting
                ? "Loading..."
                : currentStep === 2
                ? t('buttonRegister')
                : t('buttonNext')}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default RegisterWeb;
