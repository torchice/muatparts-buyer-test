import InformasiPendaftarDanRekeningResponsive from "@/container/Register/InformasiPendaftarDanRekeningResponsive";
import React, { useEffect, useState, useRef } from "react";
import { useHeader } from "@/common/ResponsiveContext";
import { useSearchParams } from "next/navigation";
import registerForm from "@/store/zustand/registerForm";
import InformasiTokoAkunResponsive from "@/container/Register/InformasiTokoAkunResponsive";
import NavSelectedMobile from "@/components/Bottomsheet/NavSelectedMobile";
import Button from "@/components/Button/Button";
import KonfirmasiDataResponsive from "@/container/Register/KonfirmasiDataResponsive";
import toast from "@/store/zustand/toast";
import { useCustomRouter } from "@/libs/CustomRoute";
import NavbarCount from "@/components/NavbarCount/NavbarCount";
import { modal } from "@/store/zustand/modal";
import { useTranslation } from "@/context/TranslationProvider";

function RegisterResponsive({ handleNext, isSubmitting, bankOptions }) {
  const { t } = useTranslation();
  const { prevStep, currentStep } = registerForm();
  const router = useCustomRouter();
  const { setShowNavMenu } = toast();
  const { setModalOpen, setModalConfig, setModalContent } = modal();
  const [initiate, setInitiate] = useState(false);

  const { setAppBar, screen, clearScreen } = useHeader();
  const hasInitiateAppBar = useRef(false);

  const handleGoBack = () => {
    if (currentStep + 1 !== 1) {
      prevStep();
      // router.push(`/register?step=${currentStep}`);
    }
  };

  useEffect(() => {
    // LB - 0750, LB - 0751, LB - 0752 - 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2
    if (hasInitiateAppBar.current) return;
    const title = t("titleRegisterStore");
    // Make sure the title is defined in the translation, before initiate the app bar
    if (title === "titleRegisterStore") return;

    clearScreen();
    setShowNavMenu(false);
    setAppBar({
      title,
      appBarType: "header_title",
      blankBackground: true,
      shadow: false,
      onBack: () => {
        if (currentStep !== 0) {
          prevStep();
          return;
        }
        setModalConfig({
          withHeader: false,
          withClose: true,
          classname: "!w-[296px] !h-fit",
        });
        setModalContent(
          <div className="flex flex-col items-center justify-center py-6 px-4">
            <span className="font-bold text-base text-black">
              {t("labelCancelRegistration")}
            </span>
            <span className="font-medium text-sm text-black mt-4 mb-5 text-center">
              {t("messageConfirmCancelRegistration")}
            </span>
            <div className="flex gap-2 items-center justify-center">
              <Button
                Class="!h-7 !text-xs !font-semibold"
                color="primary_secondary"
                onClick={() => {
                  setAppBar({});
                  router.push("/landing");
                  setModalOpen(false);
                }}
              >
                {t("BFTMRegisterAllSure")}
              </Button>
              <Button
                Class="!h-7 !text-xs !font-semibold"
                onClick={() => setModalOpen(false)}
              >
                {t("BFTMRegisterAllCancel")}
              </Button>
            </div>
          </div>
        );
        setModalOpen(true);
      },
    });
    setInitiate(true);
    hasInitiateAppBar.current = true;
  }, [currentStep, t]);

  if (initiate)
    return (
      <>
        <NavbarCount
          classname="w-full fixed top-[6px] left-0"
          title={t("titleRegisterStore")}
          subtitle={
            currentStep + 1 === 1
              ? t("titleStoreAccount")
              : currentStep + 1 === 2
              ? t("titleRegistrantAndBankAccountInfo")
              : t("titleConfirmation")
          }
          count="3"
          active={currentStep + 1}
          backAction={null}
        />
        <div className={`mt-[58px] ${screen && "!mt-0 absolute z-20 w-full"}`}>
          {currentStep + 1 === 1 && <InformasiTokoAkunResponsive />}
          {currentStep + 1 === 2 && (
            <InformasiPendaftarDanRekeningResponsive
              bankOptions={bankOptions}
            />
          )}
          {currentStep + 1 === 3 && <KonfirmasiDataResponsive />}
        </div>
        <NavSelectedMobile classname="left-0 flex items-center gap-2 justify-end">
          {currentStep + 1 !== 1 && (
            <Button
              color="primary_secondary"
              Class={` ${
                currentStep + 1 === 1 ? "!min-w-[160px]" : "!min-w-[50%]"
              } !h-8 !font-semibold !text-xs`}
              onClick={handleGoBack}
            >
              {t("buttonBack")}
            </Button>
          )}

          <Button
            Class={` ${
              currentStep + 1 === 1 ? "!min-w-[160px]" : "!min-w-[50%]"
            } !h-8 !font-semibold !text-xs`}
            onClick={handleNext}
            disabled={isSubmitting}
          >
            {isSubmitting
              ? "Loading..."
              : currentStep + 1 === 3
              ? "Daftar"
              : t("buttonNext")}
          </Button>
        </NavSelectedMobile>
      </>
    );
}

export default RegisterResponsive;
