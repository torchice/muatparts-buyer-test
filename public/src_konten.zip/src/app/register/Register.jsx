"use client";

import { useEffect, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import { useSWRConfig } from "swr";
import viewport from "@/store/zustand/common";
import SWRHandler from "@/services/useSWRHook";
import RegisterWeb from "./RegisterWeb";
import RegisterResponsive from "./RegisterResponsive";
import registerForm, { registerAcceptTerms } from "@/store/zustand/registerForm";
import toast from "@/store/zustand/toast";
import { ChevronDown, ChevronUp, Search } from "lucide-react";
import { useCustomRouter } from "@/libs/CustomRoute";
import IconComponent from "@/components/IconComponent/IconComponent";
import headerZustand from "@/store/zustand/header";
import { userZustand } from "@/store/auth/userZustand";
import { authZustand } from "@/store/auth/authZustand";
import otpRegisterZustand from "@/store/zustand/otpRegister";
import { useTranslation } from "@/context/TranslationProvider";

const api = process.env.NEXT_PUBLIC_GLOBAL_API + "v1/";

function Register() {
  const router = useCustomRouter();
  const step = useSearchParams().get("step") || "1";
  const { isMobile } = viewport();
  const { mutate } = useSWRConfig();
  const { useSWRHook, useSWRMutateHook } = SWRHandler;
  const {
    formData,
    currentStep,
    validateFirstStep,
    validateSecondStep,
    isSubmitting,
    setIsSubmitting,
    setFormData,
    handleInputChange,
    validateStep,
    nextStep,
    prevStep,
    formIsFilled,
    setFormIsFilled,
    setStepPage,
    setErrors,
    // 24. THP 2 - MOD001 - MP - 012 - QC Plan - Web - Muatparts - Paket 005 A - Daftar Sebagai Seller Muatparts - LB - 0311
    setRegistrationStatus,
  } = registerForm();
  const { isAcceptTerms } = registerAcceptTerms();
  const { setDataToast, setShowToast, setShowNavMenu } = toast();
  const { setHeader } = headerZustand();
  const { setEmail, setSuccessVerifyOtp, setTipeToko } = otpRegisterZustand();
  const { t } = useTranslation();

  useEffect(() => {
    setHeader("");
  }, []);

  const { trigger: submitData, error: errorSubmitData } = useSWRMutateHook(
    formData[0].tipeToko === 0
      ? `${api}register/merchant_personal`
      : `${api}register/merchant_company`,
    "POST"
  );

  const { trigger: setRegistrationOtp } = useSWRMutateHook(
    `${api}register/set_registration_otp`,
    "GET"
  );

  const { trigger: setLegality } = useSWRMutateHook(
    formData[0].tipeToko === 0
      ? `${api}register/set_merchant_legality`
      : `${api}register/set_merchant_company_legality`,
    "POST"
  );

  const { trigger: registerSeller } = useSWRMutateHook(
    formData[0].tipeToko === 0
      ? `${api}register/register_merchant_personal`
      : `${api}register/register_merchant_company`,
    "PUT"
  );

  const { data: dataBanks } = useSWRHook(`${api}register/banks`);

  const { trigger: revokeRefreshToken } = useSWRMutateHook(
    `${api}muatparts/auth/revoke-refresh-token`,
    "POST"
  );

  const banks = dataBanks?.Data || [];
  const bankOptions = banks.map((bank) => ({
    name: bank.value,
    value: bank.id,
  }));

  const handleRevokeRefreshToken = async () => {
    try {
      setSuccessVerifyOtp(true);
      await revokeRefreshToken({
        refreshToken: authZustand.getState().refreshToken,
      });
      authZustand.getState().clearToken();
      userZustand.getState().removeUser();
      router.push(
        `${process.env.NEXT_PUBLIC_INTERNAL_WEB}traffic/redirect_seller_muatparts`
      );
    } catch (err) {
      console.log(err);
    }
  };

  const handleNext = async () => {
    // Jika form sudah pernah diisi dan divalidasi sebelumnya
    // if (formIsFilled && ((currentStep === 0 && validateFirstStep()) || (currentStep === 1 && validateSecondStep()))) {
    //   setStepPage(2);
    //   return;
    // }
    if (currentStep === 0 && validateFirstStep(t)) {
      try {
        setIsSubmitting(true);
        const submitPayload = {
          ...formData[0],
          ...(formData[0].tipeToko === 0 && {
            companyName: undefined,
            businessEntityID: undefined,
          }),
          ...(formData[0].logo === null && {
            // 25. 07 - QC Plan - Web Apps - Marketing Muatparts - LB - 0011
            logo: `${process.env.NEXT_PUBLIC_S3_URL}/${process.env.NEXT_PUBLIC_ENVIRONMENT}/logo_seller.webp`,
          }),
          // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0374
          location: formData[0].address,
          address: formData[0].location,
        };

        await submitData(submitPayload)
          .then(() => {
            mutate(
              `${api}register/merchant_${
                formData[0].tipeToko === 0 ? "personal" : "company"
              }`
            );
            // setShowToast(true);
            // setDataToast({
            //   type: "success",
            //   message: "Data berhasil disimpan",
            // });

            setEmail(formData[0].email);
            setTipeToko(formData[0].tipeToko);

            // Check if formIsFilled
            if (formIsFilled) {
              // router.push("/register?step=3");
              setStepPage(2);
            } else {
              nextStep();
              // router.push(`/register?step=${currentStep}`);
              // setStepPage(currentStep);
            }
          })
          .catch((err) => {
            if (err?.response?.data?.Message?.Code === 400) {
              // LBM - multibahasa validasi 3 karakter nama perusahaan
              setDataToast({
                type: "error",
                message:
                  err?.response?.data?.Data?.Message ===
                  "Nama Perusahaan sudah harus lebih dari 3 karakter atau gabungan alphanumeric"
                    ? t("validationNamaPer3CharReg")
                    : err?.response?.data?.Data?.Message,
              });
              registerForm.setState((state) => ({
                // LB - 0391, 25.03
                errors: {
                  ...state.errors,
                  ...(err?.response?.data?.Data?.Field === "storeName" && {
                    storeName: err?.response?.data?.Data?.Message,
                  }),
                  ...(err?.response?.data?.Data?.Field === "email" && {
                    email: err?.response?.data?.Data?.Message,
                  }),
                  //  ...(err?.response?.data?.Data?.Field === "CompanyName" && {
                  //    companyName: err?.response?.data?.Data?.Message,
                  //  }),
                },
              }));
            } else {
              // LB - 0521 - 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2
              setDataToast({ type: "error", message: t("messageErrorSave") });
            }
            setShowToast(true);
            setIsSubmitting(false);
          });
      } finally {
        setIsSubmitting(false);
      }
    } else if (currentStep === 1 && validateSecondStep(t)) {
      const step2Data = {
        ...formData[1],
        ktpFile: formData[1].ktpFile.url,
        // LB - 0040 - 25. 07 - QC Plan - Web Apps - Marketing Muatparts
        ktpOgFile: formData[1].ktpFile.name,
      };
      setIsSubmitting(true);
      await setLegality(step2Data)
        .then(() => {
          setIsSubmitting(false);
          mutate(
            `${api}register/merchant_${
              formData[0].tipeToko === 0 ? "personal" : "company"
            }`
          );
          // setShowToast(true);
          // setDataToast({
          //   type: "success",
          //   message: "Data berhasil disimpan",
          // });
          // Check if formIsFilled
          if (formIsFilled) {
            // router.push("/register?step=3");
            setStepPage(2);
          } else {
            nextStep();
            // router.push(`/register?step=${currentStep}`);
            // setStepPage(currentStep);
          }
        })
        .catch((err) => {
          const ktpNoError =
            err?.response.data.Message.Text === "Nomor KTP sudah terdaftar";
          if (ktpNoError) {
            // LB - 0520 - 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2
            setErrors({
              ktpNo: t("AppMuatpartsProfilSellerIndexNoKtpTelah"),
            });
          } else {
            setShowToast(true);
            setDataToast({ type: "error", message: "Gagal menyimpan data" });
          }
          setIsSubmitting(false);
        });
    } else if (currentStep === 2) {
      // Imp Checkbox Persetujuan Syarat dan Ketentuan Registrasi Seller muatparts
      if (!isAcceptTerms) {
        const termsElement = document.getElementById("termsAndConditions");
        if (termsElement) {hob
          termsElement.scrollIntoView({ behavior: "smooth" });
          await new Promise(resolve => setTimeout(resolve, 800));
        }
        setShowToast(true);
        setDataToast({
          type: "error",
          message: t("messageMustAgreeTerms"),
        });
        setIsSubmitting(false);
      } else if (formData[0].isVerifEmail) {
        setIsSubmitting(true);
        await registerSeller()
          .then((x) => {
            setIsSubmitting(false);
            if (x.status === 400) {
              registerForm.setState((state) => ({
                errors: {
                  ...state.errors,
                  storeName: "Nama toko sudah digunakan",
                },
              }));
              setStepPage(0);
              // setShowToast(true);
              // setDataToast({ type: "error", message: x.data.Data.Message });
            } else {
              handleRevokeRefreshToken();
            }
          })
          .catch((error) => {
            // 24. THP 2 - MOD001 - MP - 012 - QC Plan - Web - Muatparts - Paket 005 A - Daftar Sebagai Seller Muatparts - LB - 0311
            const message = error?.response?.data?.Data?.Message;
            if (message === "Nama toko telah digunakan") {
              setRegistrationStatus({
                status: "error",
                message,
              });
              setIsSubmitting(false);
              setStepPage(0);
            } else {
              setShowToast(true);
              setDataToast({
                type: "error",
                message: "Gagal melakukan registrasi",
              });
              setIsSubmitting(false);
            }
          });
      } else {
        await setRegistrationOtp()
          .then(() => {
            setEmail(formData[0].email);
            setTipeToko(formData[0].tipeToko);
            router.push("/register/otp");
          })
          .catch((err) => console.log(err));
      }
    }
  };

  return isMobile ? (
    <RegisterResponsive
      handleNext={handleNext}
      isSubmitting={isSubmitting}
      bankOptions={bankOptions}
    />
  ) : (
    <RegisterWeb
      handleNext={handleNext}
      isSubmitting={isSubmitting}
      bankOptions={bankOptions}
    />
  );
}

export default Register;

export const Dropdown = ({
  withSearch,
  customLabel,
  label,
  value,
  onChange,
  options,
  disabled = false,
  error = null,
  onBeforeOpen,
  classname,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const dropdownRef = useRef(null);
  const searchInputRef = useRef(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
        setSearchTerm("");
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Focus search input when dropdown opens
  useEffect(() => {
    if (isOpen && searchInputRef.current) {
      searchInputRef.current.focus();
    }
  }, [isOpen]);

  const filteredOptions = options?.filter((option) =>
    option.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSelect = (option) => {
    onChange(option);
    setIsOpen(false);
    setSearchTerm("");
  };

  const handleDropdownClick = () => {
    // Jika disabled, tidak lakukan apa-apa
    if (disabled) return;

    // Jika ada onBeforeOpen, cek dulu apakah boleh dibuka
    if (onBeforeOpen) {
      const canOpen = onBeforeOpen();
      if (!canOpen) return;
    }

    // Jika lolos semua pengecekan, buka dropdown
    setIsOpen(!isOpen);
  };

  return (
    <div className="relative" ref={dropdownRef}>
      {/* Main dropdown button */}
      <button
        onClick={handleDropdownClick}
        className={`w-[166px] h-8 p-2.5 bg-white flex items-center justify-between border rounded-lg !font-medium !text-xs sm:!text-sm sm:!font-semibold
          ${disabled ? "bg-gray-50 cursor-not-allowed" : "cursor-pointer"}
          ${error ? "border-red-500" : "border-neutral-600"}
          ${classname}
          ${
            isOpen ? " !border-primary-700" : ""
          } hover:!border-primary-700 rounded-md`}
        type="button"
      >
        {customLabel ? (
          customLabel
        ) : (
          <span className={`${!value && "text-neutral-600"} truncate`}>
            {value || label}
          </span>
        )}
        {isOpen ? (
          <ChevronUp className="h-4 w-4" />
        ) : (
          <ChevronDown className="h-4 w-4" />
        )}
      </button>

      {/* Dropdown menu */}
      {isOpen && (
        <div className="absolute z-10 w-full mt-1 sm:mt-0 sm:border-primary-700 bg-white border border-gray-200 rounded-lg shadow-lg !font-medium !text-xs">
          {withSearch && (
            <div className="p-2">
              <div className="relative">
                <Search
                  className="absolute left-3 top-2  text-neutral-600"
                  size={16}
                />
                <input
                  ref={searchInputRef}
                  type="text"
                  className="w-full pl-9 pr-3 py-2 text-xs font-medium border border-neutral-600 rounded-lg hover:border-primary-700 focus-visible:outline-none focus:border-primary-700 placeholder:text-neutral-600"
                  placeholder="Cari Kendaraan"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
          )}

          {/* Options list */}
          <div className="max-h-[160px] scrollbar-custombadanusaha overflow-y-auto">
            {filteredOptions?.map((option) => (
              <div className="flex justify-between items-center pr-[6px]">
                <button
                  key={option}
                  className="w-full px-4 py-2 text-left hover:bg-gray-100 focus:outline-none focus:bg-gray-100 sm:text-neutral-600 sm:px-[10px] truncate"
                  onClick={() => handleSelect(option)}
                >
                  {option}
                </button>
                {option === value && (
                  <IconComponent src={"/icons/check-circle.svg"} />
                )}
              </div>
            ))}
            {filteredOptions?.length === 0 && (
              <div className="px-4 py-2 text-neutral-900 text-sm text-center">
                Data Tidak Ditemukan
              </div>
            )}
          </div>
        </div>
      )}

      {/* Error message */}
      {error && (
        <p className="mt-1 text-xs text-red-500 font-medium">{error}</p>
      )}
    </div>
  );
};
