"use client";
import { Button } from "@/components/MobileCom/button";
import { Separator } from "@/components/MobileCom/separator";
import { useTranslation } from "@/context/TranslationProvider";
import { ChevronLeft } from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
// Improvement fix wording Pak Brian
export default function Nav() {
  const {t}=useTranslation() // Improvement fix wording Pak Bryan
  const pathName = usePathname();

  return (
    <nav className="sticky top-0 z-50 bg-[#c22716] py-2 px-4 text-white">
    
      <div className="flex justify-evenly items-center gap-x-2 w-[50%]">
        {/* Aktif Button */}
        <Button
          asChild
          className={`w-full bg-transparent shadow-none hover:bg-transparent hover:text-white ${
            !pathName.includes("/voucher/riwayat")
            ? "border-b-2 border-white"
              : ""
          } rounded-none`}
        >
          {/* LBM - INEKE - ROUTE NAVIGATION - 14 April 2025 */}

          <Link
            href="/muatparts/voucher/"
            className="font-bold text-white hover:decoration-transparent"
          >
            {t("PusatPromosiKelolaVoucherResponsiveAktif")}
          </Link>
        </Button>

        <Separator orientation="vertical" className="border-white border h-7" />

        {/* Riwayat Button */}
        <Button
          asChild
          className={`w-full bg-transparent shadow-none hover:bg-transparent hover:text-white hover:border-b-2 border-white ${
            pathName.includes("/voucher/riwayat") 
              ? "border-b-2 border-white"
              : ""
          } rounded-none`}
        >
              {/* // LBM - INEKE - ROUTE NAVIGATION - 14 April 2025 */}

          <Link
            href="/muatparts/voucher/riwayat"
            className="font-bold text-white hover:decoration-transparent"
          >
            {t("PusatPromosiKelolaVoucherResponsiveRiwayat")}
          </Link>
        </Button>
      </div>
    </nav>
  );
}
