"use client";
import Toast from '@/components/Toast/Toast';
import toast from '@/store/zustand/toast'; // Import the zustand store
import { Button } from "@/components/MobileCom/button";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/MobileCom/dialog";
import { Check, X } from "lucide-react";
import { endVoucher } from '@/services/voucher';
import { useTranslation } from '@/context/TranslationProvider';
// Improvement fix wording Pak Brian
export default function ConfirmModal({ open, onOpenChange, voucherId, voucherName, onSuccess }) {
  const {t} = useTranslation()
  const { setShowToast, setDataToast } = toast(); // Destructure methods from zustand store

  const submitHandler = async () => {
    try {
      await endVoucher(voucherId, process.env.NEXT_PUBLIC_AUTH_TOKEN);

      // Close modal first
      onOpenChange(false);
      
      // Show success toast
      setDataToast({ 
        type: 'success', 
        message: "Berhasil Mengakhiri Voucher" 
      });
      setShowToast(true);

      // Trigger parent component to update list
      if (onSuccess) {
        onSuccess(voucherId);
      }
    } catch (error) {
      // Show error toast
      setDataToast({ 
        type: 'error', 
        message: "Gagal mengakhiri voucher" 
      });
      setShowToast(true);
    }
  };

  return (
    <>
      <Toast /> {/* Add this to render the toast */}
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent>
          <DialogHeader className="items-center">
            <DialogTitle>{t("PusatPromosiModalAkhiriVoucherAkhiriVoucher")}</DialogTitle>
          </DialogHeader>
          <p className="font-medium text-sm text-center">
            {/*  // 25. 11 - QC Plan - Web - Ronda Live Mei - LB - 0184 */}
            {/* Apakah kamu yakin mengakhiri Voucher {voucherName} ? */}
            {t("PusatPromosiModalAkhiriVoucherApakahkamuyakinmengakhiriVoucher{render}?").replace("{render}",voucherName)}
          </p>
          <DialogFooter className="flex gap-x-2 flex-row">
            <DialogClose className="w-1/2" asChild>
              <Button className="bg-white text-blue-500 border-blue-500 border rounded-full">
                {t("PusatPromosiModalAkhiriVoucherBatal")}
              </Button>
            </DialogClose>
            <DialogClose className="w-1/2" asChild>
              <Button
                className="rounded-full bg-blue-500 text-white"
                onClick={submitHandler}
              >
                {t("PusatPromosiModalAkhiriVoucherYa")}
              </Button>
            </DialogClose>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}