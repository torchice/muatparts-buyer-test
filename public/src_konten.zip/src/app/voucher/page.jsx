"use client"

import { viewport } from "@/store/zustand/viewport";
import VoucherResponsive from "./VoucherResponsive";
import VoucherSeller from "./VoucherWeb";
import { authZustand as useToken } from "@/store/auth/authZustand";

function Page() {

	const { isMobile } = viewport();
	// LB 0102, 0059
	const isLogin = useToken?.getState()?.accessToken;

	if (typeof isMobile !== "boolean") return <></>; //buat skeleton
	if (isMobile) return <VoucherResponsive />;
	
	return (
		<VoucherSeller/>
	);
}

export default Page;
