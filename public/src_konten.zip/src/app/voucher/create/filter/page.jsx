"use client";
import { Button } from "@/components/MobileCom/button";
import { Separator } from '@/components/MobileCom/separator';
import { useHeader } from '@/common/ResponsiveContext';
import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import ListBrandPage from "./listbrand";
import ListCategoryPage from "./listcategory";



const FilterPage = ({ isOpen, onClose, onApply, toggleFilter, filterCriteria, brands, categories }) => {
  if (!isOpen) return null;
  if (!brands || brands.length === 0) return <p>loading</p>;
  const [isBrandOpen, setBrandOpen] = useState(false);
  const [isCategoryOpen, setCategoryOpen] = useState(false);

    // Display first 5 categories
    const displayCategories = categories.slice(0, 5).map(category => {
    const isSelected = filterCriteria.kategori.includes(category.category_id);
      
      return (
        <Button
          key={category.category_id}
          variant={isSelected ? "type1" : "secondaryRounded"}
          className="cursor-default"
          onClick={() => toggleFilter("kategori", { category_id: category.category_id })} // Using same structure as brand for consistency
        >
          {category.name}
        </Button>
      );
    });
  

    // Display first 5 brands
    const displayBrands = brands.slice(0, 5).map(brand => {
    const isSelected = filterCriteria.brand.includes(brand.brand_id);
      
      return (
        <Button
          key={brand.brand_id}
          variant={isSelected ? "type1" : "secondaryRounded"}
          className="cursor-default"
          onClick={() => toggleFilter("brand", brand)}
        >
          {brand.name}
        </Button>
      );
    });
  return (
    <div className="fixed inset-0 bg-white flex flex-col h-full w-full overflow-auto rounded-none" style={{ zIndex: 100 }}>
      
      {/* Header */}
      <div className="p-4 border-b flex justify-between items-center bg-white shadow-md">
        <button onClick={onClose} className="text-[#176cf7] text-2xl font-semibold">✕</button>
        <h2 className="text-lg font-semibold">Filter</h2>
        <div></div>
      </div>

      {/* Filter Content */}
      <div className="flex-1 p-5 shadow-md">
        {/* Category Section */}
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <h5 className="font-medium">Kategori</h5>
            <Button
              onClick={() => setCategoryOpen(true)}
              variant="ghost"
              className="text-blue-600 p-0 hover:bg-transparent"
            >
              Lihat Semua
            </Button>
            <ListCategoryPage
              isCategoryOpen={isCategoryOpen}
              onCategoryClose={() => setCategoryOpen(false)}
              categories={categories}
              filterCriteria={filterCriteria}
              toggleFilter={toggleFilter}
              onApply={onApply}
            />
          </div>
          <div className="flex flex-wrap gap-2">
            {displayCategories}
            {categories.length > 5 && (
              <span className="text-sm text-muted-foreground py-2">
                +{categories.length - 5}
              </span>
            )}
          </div>
          <Separator className="my-4" />
        </div>

        {/* Brand Section */}
        <div className="space-y-2 border-t-[1px] border-t-gray-400 pt-4">
          <div className="flex justify-between items-center">
            <h5 className="font-medium">Brand</h5>
            <Button
              onClick={() => setBrandOpen(true)}
              variant="ghost"
              className="text-blue-600 p-0 hover:bg-transparent"
            >
              Lihat Semua
            </Button>
            <ListBrandPage
              isBrandOpen={isBrandOpen}
              onBrandClose={() => setBrandOpen(false)}
              brands={brands}
              filterCriteria={filterCriteria}
              toggleFilter={toggleFilter}
              onApply={onApply}
             />
          </div>
          <div className="flex flex-wrap gap-2">
            {displayBrands}
            {brands.length > 5 && (
              <span className="text-sm text-muted-foreground py-2">
                +{brands.length - 5}
              </span>
            )}
          </div>
          <Separator className="my-4" />
        </div>

        {/* Produk Section */}
        <div className="space-y-2 border-t-[1px] border-t-gray-400 pt-4">
          <h5 className="font-medium">Ketersediaan Produk</h5>
          <div className="flex gap-x-2">
            <Button
              variant={filterCriteria.stok === "0" ? "type1" : "secondaryRounded"}
              onClick={() => toggleFilter("stok", "0")}
            >
              Produk Tidak Tersedia
            </Button>
            <Button
              variant={filterCriteria.stok === "1" ? "type1" : "secondaryRounded"}
              onClick={() => toggleFilter("stok", "1")}
            >
              Produk Tersedia
            </Button>
          </div>
          <Separator className="my-4" />
        </div>
      </div>

      {/* Bottom Action Bar */}
      <div className="fixed bottom-0 left-0 right-0 px-4 py-4 bg-white border-t shadow-lg">
        <div className="flex space-x-4 max-w-md mx-auto">
          <Button
            variant="secondaryRounded"
            className="flex-1 border-blue-500 text-blue-500 border-[2px]"
            onClick={onClose}
          >
            Batal
          </Button>
          <Button
            variant="secondaryRounded"
            className="flex-1 bg-blue-500 text-white"
            onClick={onApply}
          >
            Terapkan
          </Button>
        </div>
      </div>
    </div>
  );
};
export default FilterPage;
