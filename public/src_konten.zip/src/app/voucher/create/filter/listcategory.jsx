"use client";
import { Button } from "@/components/MobileCom/button";
import { Separator } from '@/components/MobileCom/separator';
import { useHeader } from '@/common/ResponsiveContext';
import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Search } from 'lucide-react';
import Input from "@/components/Input/Input";
import Checkbox from "@/components/Checkbox/Checkbox";
import Header from '../choose-product/_components/Header';

const ListCategoryPage = ({ isCategoryOpen, onCategoryClose, categories, filterCriteria, toggleFilter, onApply }) => {
  const [searchQuery, setSearchQuery] = useState('');

  if (!isCategoryOpen) return null;

  // Filter categories based on search query
  const filteredCategories = categories.filter(category => 
    category.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Reset all category selections
  const handleReset = () => {
    filterCriteria.kategori.forEach(categoryId => {
      const category = categories.find(c => c.category_id === categoryId);
      if (category) {
        toggleFilter('kategori', { category_id: category.category_id });
      }
    });
  };

  return (
    <div className="fixed inset-0 bg-white flex flex-col h-full w-full overflow-auto rounded-none" style={{zIndex:101}}>
      {/* Header */}
      <div className="p-4 gap-4 border-b flex items-center bg-white shadow-md">
        <button onClick={onCategoryClose} className="text-[#176cf7] text-2xl font-semibold shrink-0">✕</button>
        <div className="flex-1"> {/* This wrapper ensures Header takes remaining space */}
          <form action="">
            <div className="flex gap-x-2 w-full rounded-lg px-4 py-2 bg-white border border-gray-500">
              <Search className="text-slate-500 h-6 w-6" />
              <input
                type="text"
                name="search"
                placeholder="Cari Kategori"
                autoComplete="off"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)} // Update query
                className="outline-none border-none bg-transparent text-slate-500 w-full"
              />
            </div>
          </form>
        </div>
        <div className="shrink-0"></div>
      </div>

      {/* Categories List */}
      <div className="flex-1 overflow-auto px-4">
        {filteredCategories.length === 0 ? (
          <div className="flex items-center justify-center h-full">
            Tidak menemukan kategori...
          </div>
        ) : (
          <div className="space-y-2 py-2">
            {filteredCategories.map((category) => {
              console.log(category)
              const isSelected = filterCriteria.kategori.includes(category.category_id);
              return (
                <React.Fragment key={category.category_id}>
                  <div className="flex items-center space-x-3 p-2 transition-colors duration-200 border-b-gray-500 border-b-[1px]">
                    <Checkbox 
                      key={`checkbox-${category.category_id}`}
                      label= {category.name}
                      id={`checkbox-${category.category_id}`}
                      checked={isSelected}
                      onChange={() => toggleFilter('kategori',category)}
                      className={`rounded-[4px] border-gray-400 ${
                        isSelected ? 'bg-blue-500 border-blue-500 text-white' : ''
                      }`}
                    />
                  </div>
                  <Separator/>
                </React.Fragment>
              );
            })}
          </div>
        )}
      </div>

      {/* Bottom Action Bar */}
      <div className="fixed bottom-0 left-0 right-0 px-4 py-4 bg-white border-t shadow-lg">
        <div className="flex space-x-4 max-w-md mx-auto">
          <Button
            variant="secondaryRounded"
            className="flex-1 border-blue-500 text-blue-500 border-[2px]"
            onClick={handleReset}
          >
            Reset
          </Button>
          <Button
            variant="secondaryRounded"
            className="flex-1 bg-blue-500 text-white"
            onClick={() => {
              onApply();
              onCategoryClose();
            }}
          >
            Terapkan ({filterCriteria.kategori.length})
          </Button>
        </div>
      </div>
    </div>
  );
};
export default ListCategoryPage;
