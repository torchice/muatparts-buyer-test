"use client";
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/MobileCom/button';
import { useHeader } from '@/common/ResponsiveContext';
import { SearchX, SlidersHorizontal } from "lucide-react";
import Header from '../../choose-product/_components/Header';
import { Badge } from "@/components/MobileCom/badge";
import { Checkbox } from "@/components/MobileCom/checkbox-2";
import FilterPage from '@/app/buatVoucher/filter/page';
const SelectedProductsPage = ({ isProductSelectedOnlyOpen, onProductSelectedOnlyClose, selectedProducts }) => {
  const [searchQuery, setSearchQuery] = useState("");
  console.log(selectedProducts)
  const handleSave = () => {
    localStorage.removeItem("selectedProducts");
    // Store selected products in localStorage
    localStorage.setItem('selectedProducts', JSON.stringify(selectedProducts));
    
    // Get stored form data
    const formData = localStorage.getItem('voucherFormData');
    if (formData) {
      // Update the stored form data with the selected products
      const updatedFormData = JSON.parse(formData);
      updatedFormData.step3.target_produk = 'produk_tertentu';
      updatedFormData.step3.productList = selectedProducts.map((p)=>p.id);
      localStorage.setItem('voucherFormData', JSON.stringify(updatedFormData));

      localStorage.setItem('product_tertentu',true)
    }
    
    //25.03 LB 0604 , 0535
    // Navigate back to step 3
    router.push('/muatparts/voucher?currentStep=3&produk_tertentu=1');
  };
  return isProductSelectedOnlyOpen ? (
    <>
   

      <div className="bg-white min-h-screen flex flex-col pb-20"> {/* Added pb-20 for button spacing */}
        <div className="py-4 space-y-4 flex-grow">
          <div className="px-4 space-y-4">
            <Header searchQuery={searchQuery} setSearchQuery={setSearchQuery} />
            <div>

           

            </div>
          </div>
          <div className="flex-grow bg-gray-100">
            <div className="space-y-2 mt-2">
              { (
                selectedProducts.map(product => (
                  <div
                    key={product.ID}
                    onClick={() => toggleselectedProductselection(product)}
                    className={`border p-4 bg-card text-card-foreground shadow flex items-start p-2 cursor-pointer ${
                      selectedProducts.some(p => p.ID === product.ID)
                        ? 'bg-blue-100 border-blue-500'
                        : 'bg-white'
                    }`}
                  >
                    <Checkbox
                      type="checkbox"
                      checked={selectedProducts.some(p => p.ID === product.ID)}
                      readOnly
                      className={`rounded-[4px] mr-4 border-gray-400 ${
                        selectedProducts.some(p => p.ID === product.ID) 
                          ? 'bg-blue-500 border-blue-500 text-white' 
                          : ''
                      }`}
                    />
                    <img
                      src="/img/product-image.png"
                      alt={product.title}
                      className="w-16 h-16 object-cover rounded-md mr-3"
                    />
                    <div className='flex flex-col gap-4'>
                      <div className='flex flex-col'>
                        <span className='font-bold leading-[18px] text-[14px]'>{product.Name}</span>
                        <span className='text-[12px] leading-[16px]'>SKU : {product.Sku}</span>
                        <span className='text-[12px] leading-[16px]'>Rp.{product.PriceLabel}</span>
                      </div>
                      <div className='flex gap-4 items-center'>
                        <span className='text-[12px]'>Stok : {product.Stock}</span>
                        <Badge
                          variant="primary"
                          className="min-w-6 justify-center py-1 capitalize border-[#e2f2ff] bg-[#e2f2ff] text-[#176cf7]"
                        >
                          {product.variant.length} Varian
                        </Badge>
                      </div>
                    </div>
                  </div>
                ))
             
              )}
            </div>
          </div>
        </div>

        {/* Fixed button at bottom */}
        <div className="fixed bottom-0 left-0 right-0 px-4 py-4 bg-white border-t shadow-lg">
          <Button
            onClick={handleSave}
            disabled={selectedProducts.length === 0}
            className="w-full bg-blue-500 text-white rounded-xl hover:bg-blue-600 disabled:bg-gray-300"
          >
            Simpan ({selectedProducts.length} Produk)
          </Button>
        </div>
      </div>
    </>
  ): null;
};
export default SelectedProductsPage;
