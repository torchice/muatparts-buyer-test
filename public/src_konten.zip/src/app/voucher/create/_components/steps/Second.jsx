"use client";
import { RadioGroup, RadioGroupItem } from "@/components/MobileCom/radio-group";
import { Button } from "@/components/MobileCom/button";
import {
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/MobileCom/form";
import { UseFormReturn } from "react-hook-form";
import { CreateVoucherSchema } from "@/schema";
import { Input } from "@/components/MobileCom/input";
import { useEffect } from "react";
import { useTranslation } from "@/context/TranslationProvider";

export default function Second({
  form,
  next,
  prev,
  type,
}) {
  // 25.03 LB 0536, LB0606
  // Calculate max allowed minimum pembelian when discount type is Nominal
  const {t} = useTranslation() // Improvement fix wording pak Bryan
  const calculateMaxMinimumPembelian = () => {
    const discountType = form.watch("step2.jenis_Diskon");
    const discountValue = form.watch("step2.diskon");
    
    if (discountType === "Nominal" && discountValue) {
      const diskon = parseInt(discountValue, 10);
      if (!isNaN(diskon)) {
        return diskon + (diskon * 0.6); // 60% more than diskon
      }
    }
    return null;
  };

  // Watch for changes in discount value to update minimum pembelian validation
  useEffect(() => {
    const discountType = form.watch("step2.jenis_Diskon");
    const discountValue = form.watch("step2.diskon");
    const minPembelian = form.watch("step2.minimun_pembelian");
    
    if (discountType === "Nominal" && discountValue && minPembelian) {
      const diskon = parseInt(discountValue, 10);
      const minimum = parseInt(minPembelian, 10);
      
      if (!isNaN(diskon) && !isNaN(minimum)) {
        const maxAllowed = diskon + (diskon * 0.6);
        
        if (minimum > maxAllowed) {
          form.setValue("step2.minimun_pembelian", maxAllowed.toString());
        }
      }
    }
  }, [form.watch("step2.diskon"), form.watch("step2.jenis_Diskon")]);

  const maxMinimumPembelian = calculateMaxMinimumPembelian();

  // Handle non-negative input for numeric fields
  const handleNumericInput = (e, field) => {
    // Remove non-numeric characters
    const numericValue = e.target.value.replace(/[^0-9]/g, '');
    field.onChange(numericValue);
  };

  return (
    <div className="">
      <FormField
        control={form.control}
        name="step2.jenis_voucher"
        render={({ field }) => (
          <FormItem >
            <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-700">{t("PusatPromosiKelolaVoucherFormVoucherDetailJenisVoucher")}*</span>
            <FormControl>
              <RadioGroup
                onValueChange={field.onChange}
                defaultValue={field.value}
                className="flex flex-col"
              >
                <FormItem className="flex items-center space-x-3 items-center">
                  <FormControl>
                    <RadioGroupItem className="mt-0" value="Diskon Produk" />
                  </FormControl>
                  <div style={{marginLeft:'0px'}}>
                  <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-700">{t("PusatPromosiKelolaVoucherFormVoucherDetailDiskonProduk")}</span>
                  </div>
                </FormItem>
                <FormItem className="flex items-center space-x-3 space-y-0  items-center">
                  <FormControl>
                    <RadioGroupItem className="mt-0" value="Biaya Pengiriman" />
                  </FormControl>
                  <div className="flex items-center" style={{marginLeft:'0px'}}>
                    <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-700">{t("PusatPromosiKelolaVoucherFormVoucherDetailBiayaPengiriman")}</span>
                  </div>
                </FormItem>
              </RadioGroup>
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />
      {form.watch("step2.jenis_voucher") !== "Biaya Pengiriman" && (
        <FormField
          control={form.control}
          name="step2.jenis_Diskon"
          render={({ field }) => (
            <FormItem>
              <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-700">{t("PusatPromosiKelolaVoucherFormVoucherDetailJenisDiskon")}*</span>
              <FormControl>
                <RadioGroup
                  onValueChange={field.onChange}
                  defaultValue={field.value}
                  className="flex flex-col space-y-1"
                >
                  <FormItem className="flex items-center space-x-3 space-y-0 items-center">
                    <FormControl>
                      <RadioGroupItem className="mt-0" value="Nominal" />
                    </FormControl>
                   
                  <div style={{marginLeft:'0px'}}>
                    <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-700">{t("PusatPromosiKelolaVoucherFormVoucherDetailNominal(Rp)")}</span>
                  </div>
                  </FormItem>
                  <FormItem className="flex items-center space-x-3 space-y-0 items-center">
                    <FormControl>
                      <RadioGroupItem className="mt-0" value="Persentase" />
                    </FormControl>
                   
                    <div className="flex items-center" style={{marginLeft:'0px'}}>
                    <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-700">{t("PusatPromosiKelolaVoucherFormVoucherDetailPersentase(%)")}</span>
                    </div>
                  </FormItem>
                </RadioGroup>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
      )}
      <FormField
        control={form.control}
        name="step2.diskon"
        render={({ field }) => (
          <FormItem className="space-y-2">
            <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-700">{t("PusatPromosiKelolaVoucherFormVoucherDetailDiskon")}*</span>
            <FormControl>
              <div className="relative">
              {form.watch("step2.jenis_Diskon") === "Nominal" && (
                <>
                <div className="absolute left-3 top-1/2 -translate-y-1/2 font-semibold text-neutral-700">
                  Rp
                </div>
                <Input 
                  type="text" 
                  className="pl-[calc(1.5rem+theme(spacing.3))]" 
                  placeholder="Contoh : 1.000.000" 
                  value={field.value
                    ? new Intl.NumberFormat('id-ID').format(parseInt(field.value) || 0)
                    : ''
                  }
                  onChange={(e) => {
                    // Remove all non-digit characters (dots, commas, spaces, etc.)
                    const numericValue = e.target.value.replace(/\D/g, '');
                    
                    // Always update the field with the raw numeric value
                    field.onChange(numericValue);
                  }}
                />
                </>
              )}
              {form.watch("step2.jenis_Diskon") === "Persentase" && (
                <>
                <div className="absolute right-3 top-1/2 -translate-y-1/2 font-semibold text-neutral-700">
                  %
                </div>
                <Input 
                  type="number" 
                  className="pr-[calc(2rem+theme(spacing.3))]" 
                  placeholder={t("PusatPromosiKelolaVoucherFormVoucherDetailContoh:10")} 
                  min="1"
                  max="60"
                  onChange={(e) => {
                    const value = e.target.value;
                    const numericValue = value.replace(/[^0-9]/g, '');
                    const intValue = parseInt(numericValue, 10);
                    
                    if (numericValue === '' || isNaN(intValue)) {
                      field.onChange('');
                    } else if (intValue > 60) {
                      field.onChange('60');
                    } else if (intValue < 0) {
                      field.onChange('1');
                    } else {
                      field.onChange(intValue.toString());
                    }
                  }}
                  value={field.value}
                />
                </>
              )}
            </div>
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />
      <FormField
        control={form.control}
        name="step2.minimun_pembelian"
        render={({ field }) => (
          <FormItem className="space-y-2">
            <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-700">Minimun Pembelian*</span>
            <FormControl>
            <div className="relative">
              <div className="absolute left-3 top-1/2 -translate-y-1/2 font-semibold text-neutral-700">
                    Rp
              </div>
              <Input 
                type="text" 
                className="pl-[calc(1.5rem+theme(spacing.3))]" 
                placeholder="Contoh : 1.000.000" 
                value={field.value
                  ? new Intl.NumberFormat('id-ID').format(parseInt(field.value) || 0)
                  : ''
                }
                onChange={(e) => {
                  // Remove non-numeric characters (dots, commas, etc)
                  const numericValue = e.target.value.replace(/[^\d]/g, '');
                  
                  // Only update the field value if it's empty or a valid number
                  if (numericValue === '' || !isNaN(parseInt(numericValue, 10))) {
                    field.onChange(numericValue);
                  }
                  
                  // If in Nominal mode, validate against minimum required
                  if (form.watch("step2.jenis_Diskon") === "Nominal" && form.watch("step2.diskon")) {
                    const diskon = parseInt(form.watch("step2.diskon"), 10);
                    const minRequired = diskon + (diskon * 0.6);
                    
                    if (parseInt(numericValue, 10) < minRequired) {
                      form.setError("step2.minimun_pembelian", {
                        type: "manual",
                        message: `Minimum pembelian harus minimal Rp${new Intl.NumberFormat('id-ID').format(minRequired)}`
                      });
                    } else {
                      form.clearErrors("step2.minimun_pembelian");
                    }
                  }
                }}
                onBlur={() => {
                  // Check if value is numerical and meets minimum requirement
                  if (field.value && !isNaN(parseInt(field.value, 10))) {
                    // Additional validation can be handled here if needed
                  }
                }}
              />
            </div>
            </FormControl>
            {form.watch("step2.jenis_Diskon") === "Nominal" && minimumPembelianValue && (
              <div className="text-xs text-gray-500">
                Minimum pembelian harus minimal Rp{new Intl.NumberFormat('id-ID').format(minimumPembelianValue)}
              </div>
            )}
            <FormMessage />
          </FormItem>
        )}
      />
      {form.watch("step2.jenis_Diskon") === "Persentase" && (
        <FormField
          control={form.control}
          name="step2.maksimum_diskon.mode"
          render={({ field }) => (
            <FormItem className="space-x-2">
              <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-700">Maksimum Diskon</span>
              <FormControl>
                <RadioGroup
                  onValueChange={field.onChange}
                  defaultValue={field.value}
                  className="flex flex-col"
                  style={{marginLeft:"0px"}}
                >
                  <FormItem className="flex items-center space-x-3">
                    <FormControl>
                      <RadioGroupItem className="mt-0" value="tidak_terbatas" />
                    </FormControl>
                    <div style={{marginLeft:'0px'}}>
                      <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-700 ml-0">Tidak Terbatas</span>
                    </div>
                  </FormItem>
                  <FormItem className="flex items-center space-x-3">
                    <FormControl>
                      <RadioGroupItem className="mt-0" value="atur_batas" />
                    </FormControl>
                    <div style={{marginLeft:'0px'}}>
                      <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-700 ml-0">Atur Batas Maksimum Diskon</span>
                    </div>
                  </FormItem>
                </RadioGroup>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
      )}
      {form.watch("step2.maksimum_diskon.mode") === "atur_batas" && (
        <FormField
          control={form.control}
          name="step2.maksimum_diskon.value"
          render={({ field }) => (
            <FormItem>
              <FormControl>
                <div className="relative">
                  <div className="absolute left-3 top-1/2 -translate-y-1/2 font-semibold text-neutral-700">
                    Rp
                  </div>
                  <Input
                    type="text"
                    className="pl-[calc(1.5rem+theme(spacing.3))]"
                    placeholder="Masukkan nominal"
                    value={field.value
                      ? new Intl.NumberFormat('id-ID').format(parseInt(field.value) || 0)
                      : ''
                    }
                    onChange={(e) => {
                      // Remove non-numeric characters
                      const numericValue = e.target.value.replace(/[^0-9]/g, '');
                      if (numericValue === '' || parseInt(numericValue, 10) >= 0) {
                        field.onChange(numericValue);
                      }
                    }}
                  />
                </div>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
      )}
      <FormField
        control={form.control}
        name="step2.kuota_pemakaian"
        render={({ field }) => (
          <FormItem className="space-y-2">
            <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-700">Kuota Pemakaian*</span>
            <FormControl>
              <Input 
                type="number" 
                placeholder="Contoh:10" 
                min="1"
                onChange={(e) => {
                  const numericValue = e.target.value.replace(/[^0-9]/g, '');
                  if (numericValue === '' || parseInt(numericValue, 10) >= 0) {
                    field.onChange(numericValue);
                  }
                }}
                value={field.value?parseInt(field.value):0}
              />
            </FormControl>
            <FormDescription>Maksimal penggunaan kuota voucher</FormDescription>
            <FormMessage />
          </FormItem>
        )}
      />
      <FormField
        control={form.control}
        name="step2.kuota_pemakaian_per_pembeli"
        render={({ field }) => (
          <FormItem className="space-y-2">
            <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-700">Kuota Pemakaian per Pembeli*</span>
            <FormControl>
              <Input 
                type="number" 
                placeholder="Contoh:10" 
                min="1"
                onChange={(e) => {
                  const value = e.target.value;
                  const numericValue = value.replace(/[^0-9]/g, '');
                  const intValue = parseInt(numericValue, 10);
                  
                  if (numericValue === '' || isNaN(intValue)) {
                    field.onChange('');
                  } else if (intValue < 1) {
                    field.onChange('1');
                  } else {
                    const maxKuota = form.watch("step2.kuota_pemakaian");
                    if (maxKuota && parseInt(maxKuota) < intValue) {
                      field.onChange(maxKuota);
                    } else {
                      field.onChange(intValue.toString());
                    }
                  }
                }}
                value={field.value}
              />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />
      <div className="fixed bottom-0 left-0 w-full p-4 bg-white shadow-button-container">
        <div className="flex gap-x-2">
          <Button
            onClick={prev}
            className="bg-white text-blue-500 w-full border-blue-500 border rounded-full"
          >
            Sebelumnya
          </Button>
          <Button
            onClick={() => {
              // First, validate if minimum pembelian meets the requirement for Nominal discount type
              if (form.watch("step2.jenis_Diskon") === "Nominal" && form.watch("step2.diskon")) {
                const diskon = parseInt(form.watch("step2.diskon"), 10);
                const minPembelian = parseInt(form.watch("step2.minimun_pembelian"), 10);
                
                if (!isNaN(diskon)) {
                  const minRequired = diskon + (diskon * 0.6);
                  
                  if (isNaN(minPembelian) || minPembelian < minRequired) {
                    form.setError("step2.minimun_pembelian", {
                      type: "manual",
                      message: `Minimum pembelian harus minimal Rp${new Intl.NumberFormat('id-ID').format(minRequired)}`
                    });
                    return; // Prevent going to next step
                  } else {
                    form.clearErrors("step2.minimun_pembelian");
                  }
                }
              }
              
              // Continue with next step
              next();
            }}
            className="rounded-full bg-blue-500 text-white w-full"
          >
            Selanjutnya
          </Button>
        </div>
      </div>
    </div>
  );
}