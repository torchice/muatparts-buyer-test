"use client";
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '../../../../components/MobileCom/button';
import { useHeader } from '@/common/ResponsiveContext'

export default function ChooseProduct() {
  const [products, setProducts] = useState([]);
  const [selectedProducts, setSelectedProducts] = useState([]);
  const router = useRouter();
  const {
		appBarType, //pilih salah satu : 'header_title_secondary' || 'header_search_secondary' || 'default_search_navbar_mobile' || 'header_search' || 'header_title'
		appBar, // muncul ini : {onBack:null,title:'',showBackButton:true,appBarType:'',appBar:null,header:null}
		renderAppBarMobile, // untuk render komponen header mobile dengan memasukkanya ke useEffect atau by trigger function / closer
		setAppBar, // tambahkan payload seperti ini setAppBar({onBack:()=>setScreen('namaScreen'),title:'Title header',appBarType:'type'})
		handleBack, // dipanggil di dalam button di luar header, guna untuk kembali ke screen sebelumnya 
		clearScreen,// reset appBar
		setScreen, // set screen
		screen, // get screen,
		search, // {placeholder:'muatparts',value:'',type:'text'}
		setSearch, // tambahkan payload seperti ini {placeholder:'Pencarian',value:'',type:'text'}
	}=useHeader()
  useEffect(() => {
    setAppBar({
			title:'Pilih Produuk',
			appBarType:'header_title',
		  })
    const fetchProducts = async () => {
      try {
        // Replace with your actual API call to fetch products
        const response = await fetch('/api/products');
        const data = await response.json();
        setProducts(data);
      } catch (error) {
        console.error('Failed to fetch products', error);
      }
    };

    fetchProducts();
  }, []);

  const toggleProductSelection = (product) => {
    setSelectedProducts(prev => 
      prev.some(p => p.id === product.id)
        ? prev.filter(p => p.id !== product.id)
        : [...prev, product]
    );
  };

  const handleSave = () => {
    if (selectedProducts.length === 0) {
      alert('Pilih setidaknya satu produk');
      return;
    }
    
    // Assuming you want to pass selected products back to previous page
    router.push({
      pathname: '/voucher',
      query: { 
        selectedProducts: JSON.stringify(selectedProducts),
        step: 3 
      }
    });
  };

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Pilih Produk</h2>
      <div className="space-y-4">
        {products.map(product => (
          <div 
            key={product.id}
            onClick={() => toggleProductSelection(product)}
            className={`flex items-center p-2 border rounded-lg cursor-pointer ${
              selectedProducts.some(p => p.id === product.id) 
                ? 'bg-blue-100 border-blue-500' 
                : 'bg-white'
            }`}
          >
            <input 
              type="checkbox"
              checked={selectedProducts.some(p => p.id === product.id)}
              readOnly
              className="mr-3"
            />
            <img 
              src={product.image} 
              alt={product.name} 
              className="w-16 h-16 object-cover rounded-md mr-3" 
            />
            <span>{product.name}</span>
          </div>
        ))}
      </div>
      <Button 
        onClick={handleSave}
        disabled={selectedProducts.length === 0}
        className="mt-4 w-full"
      >
        Simpan
      </Button>
    </div>
  );
}