import { Button } from "@/components/MobileCom/button";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/MobileCom/dialog";
import Link from "next/link";

export default function ConfirmModal({ children }) {
  return (
    <Dialog>
      <DialogTrigger>{children}</DialogTrigger>
      <DialogContent>
        <DialogHeader className="items-center">
          <DialogTitle>Keluar Halaman Ini?</DialogTitle>
        </DialogHeader>
        <p className="font-medium text-sm text-center">
          Data voucher tidak akan tersimpan sebelum kamu klik Simpan
        </p>
        <DialogFooter className="flex gap-x-2 w-full">
          <DialogClose className="w-full" asChild>
            <Button
              className="bg-white text-blue-500 w-full border-blue-500 border rounded-full "
              asChild
            >
              <Link href="/">Ya keluar</Link>
            </Button>
          </DialogClose>
          <DialogClose className="w-full" asChild>
            <Button className="rounded-lg bg-blue-500 text-white w-full ">
              Batal
            </Button>
          </DialogClose>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
