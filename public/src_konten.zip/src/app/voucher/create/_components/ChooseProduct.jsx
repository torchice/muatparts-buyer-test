"use client";
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useHeader } from '@/common/ResponsiveContext';
import Nav from "./Nav";
import { SearchX, SlidersHorizontal } from "lucide-react";
import { Badge } from "@/components/MobileCom/badge";
import { Checkbox } from "@/components/MobileCom/checkbox-2";
import { Button } from '@/components/MobileCom/button';
import { getProducts } from '@/services/voucher';
import Header from '@/app/voucherseller/aktif/_components/Header';
import FilterPage from '@/app/buatVoucher/_components/Filter';

export default function ChooseProduct() {
  const [products, setProducts] = useState([]);
  const [selectedProducts, setSelectedProducts] = useState([]);
  const router = useRouter();
  const [searchQuery, setSearchQuery] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [filterCriteria, setFilterCriteria] = useState({
    status: "",
    jenisVoucher: "",
    targetVoucher: "",
    produk: "",
  });
 
  const handleSaveFilter = (newFilters) => {
    setFilters(newFilters);
    // You can also perform additional actions here like:
    // - Making API calls
    // - Updating other components
    // - Saving to localStorage
    console.log('Filters saved:', newFilters);
  };

  const { setAppBar } = useHeader();

  // Load any previously selected products and form data when component mounts
  useEffect(() => {
    setAppBar({
			title:'Pilih Produk',
			appBarType:'header_title',
		  })
    const savedProducts = localStorage.getItem('selectedProducts');
    if (savedProducts) {
      setSelectedProducts(JSON.parse(savedProducts));
    }
  }, []);

  const fetchProducts = async () => {
    try {
      setIsLoading(true);
      const params = {
        page_size: 10,
        page: 1
      };
      const body = {
        search: searchQuery,
      };
      const response = await getProducts('/stores/98da2571-d600-4dc5-85e6-ee290bc193e4/products', body, process.env.NEXT_PUBLIC_AUTH_TOKEN);
      const data = response.Data.products;
      setProducts(data);
    } catch (error) {
      console.error('Failed to fetch products', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleFilterClick = () => {
    router.push('/voucher/filter'); // Adjust this path to match your routing structure
  };
  useEffect(() => {
    setAppBar({
      title: 'Pilih Produk',
      appBarType: 'header_title',
    });
    fetchProducts();
  }, [filterCriteria, searchQuery]);

  const filteredProducts = Array.isArray(products) ? products.filter((p) => {
    const matchesSearch = p.title
      ?.toLowerCase()
      .includes(searchQuery.toLowerCase());
    const matchesStatus =
      !filterCriteria.status || p.status === filterCriteria.status;
    const matchesJenisVoucher =
      !filterCriteria.jenisVoucher ||
      p.voucher_type === filterCriteria.jenisVoucher;
    const matchesTargetVoucher =
      !filterCriteria.targetVoucher ||
      p.target === filterCriteria.targetVoucher;
    const matchesProduk =
      !filterCriteria.produk || p.is_all_product === filterCriteria.produk;

    return (
      matchesSearch &&
      matchesStatus &&
      matchesJenisVoucher &&
      matchesTargetVoucher &&
      matchesProduk
    );
  }) : [];

  const resetFilter = () => {
    setFilterCriteria({
      status: "",
      jenisVoucher: "",
      targetVoucher: "",
      produk: "",
    });
  };

  const toggleProductSelection = (product) => {
    setSelectedProducts(prev =>
      prev.some(p => p.id === product.id)
        ? prev.filter(p => p.id !== product.id)
        : [...prev, product]
    );
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat('id-ID').format(price);
  };

  const handleSave = () => {
    if (selectedProducts.length === 0) {
      alert('Pilih setidaknya satu produk');
      return;
    }

    // Store selected products in localStorage
    localStorage.setItem('selectedProducts', JSON.stringify(selectedProducts));
    
    // Get stored form data
    const formData = localStorage.getItem('voucherFormData');
    if (formData) {
      // Update the stored form data with the selected products
      const updatedFormData = JSON.parse(formData);
      updatedFormData.step3.target_produk = 'produk_tertentu';
      updatedFormData.step3.productList = selectedProducts.map((p)=>p.id);
      localStorage.setItem('voucherFormData', JSON.stringify(updatedFormData));

      localStorage.setItem('product_tertentu',true)
    }
    // 25.03 LB 0604

    // Navigate back to step 3
    router.push('/muatparts/voucher?currentStep=3&produk_tertentu=1');
  };
  

  return (
    <>
      <Nav />
 
        <FilterPage
          type='riwayat'
          isOpen={isFilterOpen}
          onClose={() => setFilterOpen(false)}
					onApply={handleApplyFilters}
					toggleFilter={toggleFilter} // Pass toggleFilter function
					filterCriteria={filterCriteria} // Pass selected filters
          fetchProducts={fetchProducts}
        />
      <div className="bg-white min-h-screen flex flex-col pb-20"> {/* Added pb-20 for button spacing */}
        <div className="py-4 space-y-4 flex-grow">
          <div className="px-4 space-y-4">
            <Header searchQuery={searchQuery} setSearchQuery={setSearchQuery} />
            <div>
            <Button 
                variant="secondary" 
                className="bg-[#F1F1F1] rounded-2xl"
                onClick={handleFilterClick}
                
                initialFilter={filterCriteria}
                onSaveFilter={handleSaveFilter}

              >
              Filters <SlidersHorizontal />
            </Button>
            </div>
          </div>
          <div className="flex-grow bg-gray-100">
            <div className="space-y-2 mt-2">
              {isLoading ? (
                <div className="text-center py-4">Loading...</div>
              ) : filteredProducts.length > 0 ? (
                filteredProducts.map(product => (
                  <div
                    key={product.id}
                    onClick={() => toggleProductSelection(product)}
                    className={`border p-4 bg-card text-card-foreground shadow flex items-start p-2 cursor-pointer ${
                      selectedProducts.some(p => p.id === product.id)
                        ? 'bg-blue-100 border-blue-500'
                        : 'bg-white'
                    }`}
                  >
                    <Checkbox
                      type="checkbox"
                      checked={selectedProducts.some(p => p.id === product.id)}
                      readOnly
                      className={`rounded-[4px] mr-4 border-gray-400 ${
                        selectedProducts.some(p => p.id === product.id) ? 'bg-blue-500 border-blue-500 text-white' : ''
                      }`}
                    />
                    <img
                      src="/img/product-image.png"
                      alt={product.title}
                      className="w-16 h-16 object-cover rounded-md mr-3"
                    />
                    <div className='flex flex-col gap-4'>
                      <div className='flex flex-col'>
                        <span className='font-bold leading-[18px] text-[14px]'>{product.title}</span>
                        <span className='text-[12px] leading-[16px]'>SKU : {product.sku}</span>
                        <span className='text-[12px] leading-[16px]'>Rp.{formatPrice(product.originalPrice)}</span>
                      </div>
                      <div className='flex gap-4 items-center'>
                        <span className='text-[12px]'>Stok : {formatPrice(product.stock)}</span>
                        <Badge
                          variant="primary"
                          className="min-w-6 justify-center py-1 capitalize border-[#e2f2ff] bg-[#e2f2ff] text-[#176cf7]"
                        >
                          {product.variantCount} Varian
                        </Badge>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center min-h-[400px] flex flex-col items-center justify-center">
                  <SearchX className="h-12 w-12" />
                  <h3 className="font-semibold capitalize text-muted-foreground">
                    Data tidak Ditemukan. Mohon coba hapus beberapa filter.
                  </h3>
                  <h3 className="font-semibold capitalize text-muted-foreground">
                    atau
                  </h3>
                  <Button
                    onClick={resetFilter}
                    className="bg-blue-500 text-white capitalize font-semibold rounded-full hover:bg-blue-600"
                  >
                    Atur ulang filter
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Fixed button at bottom */}
        <div className="fixed bottom-0 left-0 right-0 px-4 py-4 bg-white border-t shadow-lg">
          <Button
            onClick={handleSave}
            disabled={selectedProducts.length === 0}
            className="w-full bg-blue-500 text-white rounded-xl hover:bg-blue-600 disabled:bg-gray-300"
          >
            Simpan ({selectedProducts.length} Produk)
          </Button>
        </div>
      </div>
    </>
  );
}