import { Separator } from "@radix-ui/react-separator";
import { ChevronLeft } from "lucide-react";
import StepIndicator from "./StepperIndicator";
import ConfirmModal from "./ConfirmModal";
import { useTranslation } from "@/context/TranslationProvider";

export default function Nav({ step }) {
  const {t} = useTranslation()// Improvement fix wording pak Bryan
  //25.03 LB 0539 , 0538
  // Get the correct label based on the step number
  const getStepLabel = () => {
    switch (step) {
      case 1:
        return "PusatPromosiKelolaVoucherFormVoucherInfoInformasiVoucher";
      case 2:
        return "PusatPromosiKelolaVoucherFormVoucherDetailDetailVoucher";
      case 3:
        return "PusatPromosiKelolaVoucherFormProductListResponsiveDaftarProdukuntukVoucher";
      default:
        return "PusatPromosiKelolaVoucherFormVoucherInfoInformasiVoucher";
    }
  };

  return (
    <nav className="sticky top-0 z-50 bg-[#c22716] py-2 border-t-0 border-white px-4 flex flex-col justify-between items-start text-white">
      <Separator />

      <div className="flex justify-between w-full items-center">
        <p className="font-semibold text-md">{t(getStepLabel())}</p>
        <StepIndicator step={step} />
      </div>
    </nav>
  );
}