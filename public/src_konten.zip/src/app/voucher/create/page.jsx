"use client"

import { viewport } from "@/store/zustand/viewport";
import VoucherResponsive from "./VoucherResponsive";
import VoucherWeb from "./VoucherWeb";

function Page() {

	const { isMobile } = viewport();

	if (typeof isMobile !== "boolean") return <></>; //buat skeleton
	if (isMobile) return <VoucherResponsive />;
	
	return (
		<VoucherWeb/>
	);
}

export default Page;
