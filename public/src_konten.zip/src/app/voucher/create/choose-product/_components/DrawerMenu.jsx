import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { SlidersHorizontal } from 'lucide-react';
import {
  Drawer,
  DrawerClose,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from "@/components/MobileCom/drawer";
import { Button } from "@/components/MobileCom/button";
import { Separator } from '@/components/MobileCom/separator';

export default function DrawerMenu({ initialFilter, onSaveFilter }) {
  const router = useRouter();
  const [selected, setSelected] = useState(initialFilter);
  const [selectedBrands, setSelectedBrands] = useState([]);

  // Load selected brands from localStorage when component mounts
  useEffect(() => {
    const savedBrands = localStorage.getItem('selectedBrands');
    if (savedBrands) {
      const brands = JSON.parse(savedBrands);
      setSelectedBrands(brands);
      handleSelect('brands', brands);
    }
  }, []);

  // Check for selected brands on focus
  useEffect(() => {
    const handleFocus = () => {
      const savedBrands = localStorage.getItem('selectedBrands');
      if (savedBrands) {
        const brands = JSON.parse(savedBrands);
        setSelectedBrands(brands);
        handleSelect('brands', brands);
      }
    };

    window.addEventListener('focus', handleFocus);
    
    return () => {
      window.removeEventListener('focus', handleFocus);
    };
  }, []);

  const handleSelect = (category, value) => {
    setSelected(prev => ({
      ...prev,
      [category]: value,
    }));
  };

  const navigateToBrandsPage = () => {
    router.push('/voucher/choose-brands');
  };
  return (
    <Drawer>
      <DrawerTrigger asChild>
        <Button variant="secondary" className="bg-[#F1F1F1] rounded-2xl">
          Filters <SlidersHorizontal />
        </Button>
      </DrawerTrigger>
      <DrawerContent className="max-w-screen-sm mx-auto min-h-[500px]">
        <DrawerHeader className="space-y-4">
          {/* Brand Section */}
          <div className="space-y-2 text-left">
            <div className="flex justify-between items-center">
              <h5>Brand</h5>
              <Button
                variant="ghost"
                className="text-[#176cf7] p-0 hover:bg-transparent"
                onClick={navigateToBrandsPage}
              >
                Lihat Semua
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {selectedBrands.slice(0, 5).map((brand) => (
                <Button
                  key={brand.id}
                  variant="type1"
                  className="cursor-default"
                >
                  {brand.name}
                </Button>
              ))}
              {selectedBrands.length > 5 && (
                <span className="text-sm text-muted-foreground py-2">
                  +{selectedBrands.length - 5} more
                </span>
              )}
              {selectedBrands.length === 0 && (
                <span className="text-sm text-muted-foreground py-2">
                  No brands selected
                </span>
              )}
            </div>
            <Separator />
          </div>

          {/* Rest of your drawer content */}
          {/* Produk Section */}
          <div className="space-y-2 text-left">
            <DrawerTitle>Ketersediaan Produk</DrawerTitle>
            <div className="flex gap-x-2">
              <Button
                variant={
                  selected.produk === "Semua Produk"
                    ? "type1"
                    : "secondaryRounded"
                }
                onClick={() => handleSelect("produk", "Semua Produk")}
              >
                Produk Tidak Tersedia
              </Button>
              <Button
                variant={
                  selected.produk === "Produk Tertentu"
                    ? "type1"
                    : "secondaryRounded"
                }
                onClick={() => handleSelect("produk", "Produk Tertentu")}
              >
                Produk Tersedia
              </Button>
            </div>
            <Separator />
          </div>
        </DrawerHeader>
      </DrawerContent>
    </Drawer>
  );
}