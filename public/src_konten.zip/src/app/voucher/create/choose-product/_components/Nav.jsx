"use client";
import { Button } from "@/components/MobileCom/button";
import { Separator } from "@/components/MobileCom/separator";
import { ChevronLeft } from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";

export default function Nav() {
  const pathName = usePathname();
  //LB 0102, 0059

  return (
    <nav className="bg-[#c22716] py-2 px-4 text-white">
    
      <div className="flex justify-evenly items-center gap-x-2">
        {/* Aktif Button */}
        <Button
          asChild
          className={`w-full bg-transparent shadow-none hover:bg-transparent hover:text-white ${
            pathName === "/voucherseller/aktif"
              ? "border-b-2 border-white"
              : ""
          } rounded-none`}
        >
          <Link
            href="/voucherseller/aktif"
            className="font-bold text-white hover:decoration-transparent"
          >
            Aktif
          </Link>
        </Button>

        <Separator orientation="vertical" className="border-white border h-7" />

        {/* Riwayat Button */}
        <Button
          asChild
          className={`w-full bg-transparent shadow-none hover:bg-transparent hover:text-white hover:border-b-2 border-white ${
            pathName === "/voucherseller/riwayat"
              ? "border-b-2 border-white"
              : ""
          } rounded-none`}
        >
          <Link
            href="/voucherseller/riwayat"
            className="font-bold text-white hover:decoration-transparent"
          >
            Riwayat
          </Link>
        </Button>
      </div>
    </nav>
  );
}
