"use client";
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/MobileCom/button';
import { getProducts, getBrands } from '@/services/voucher';

import { useHeader } from '@/common/ResponsiveContext';
import Nav from "../_components/Nav";
import { SearchX, SlidersHorizontal } from "lucide-react";
import DrawerMenu from './_components/DrawerMenu';
import Header from './_components/Header';
import { Badge } from "@/components/MobileCom/badge";
import { Checkbox } from "@/components/MobileCom/checkbox-2";
import FilterPage from '@/app/buatVoucher/filter/page';
import { Label } from '@radix-ui/react-label';
// import { Button } from '@/components/ui/button';
// import { Checkbox } from '@/components/ui/checkbox';
// import { Badge } from '@/components/ui/badge';
// import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/MobileCom/dialog";
import { Trash2 } from 'lucide-react';
import toast from '@/store/zustand/toast'; // Import the zustand store
import { useRouter, useSearchParams } from "next/navigation"

export default function SelectedProduct() {
	const router = useRouter();
  const searchParam = useSearchParams();

	const [selectedProducts, setSelectedProducts] = useState([]);
	const [searchQuery, setSearchQuery] = useState("");
	const [showCheckboxes, setShowCheckboxes] = useState(false);
	const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
	const { setAppBar } = useHeader();
	const { setShowToast, setDataToast } = toast();
	const [checkedProducts, setCheckedProducts] = useState(new Set());
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [isDetail, setIsDetail] = useState(false);
  const id = searchParam.get("id");

	useEffect(() => {
		setAppBar({
			title: `Daftar Produk Voucher`,
			appBarType: "header_title",
		});


		const savedProducts = localStorage.getItem("selectedProducts");
		if (savedProducts) {
			const parsedProducts = JSON.parse(savedProducts);
			if (Array.isArray(parsedProducts)) {
				setSelectedProducts(parsedProducts);

			}
		}
    
    if(id){
      setIsDetail(true);
    }

	}, []);
	useEffect(() => {
  
    if (!Array.isArray(selectedProducts)) {
      setFilteredProducts([]); // Ensure it's always an array
      return;
    }
  
    setFilteredProducts(
      selectedProducts.filter(product =>
        product.Name.toLowerCase().includes(searchQuery.toLowerCase())
      )
    );
  }, [searchQuery, selectedProducts]);
  
	// Toggle individual product selection
	const toggleProductSelection = (productID) => {
		setCheckedProducts((prev) => {
			const newSet = new Set(prev);
			if (newSet.has(productID)) {
				newSet.delete(productID);
			} else {
				newSet.add(productID);
			}
			setShowCheckboxes(newSet.size > 0); // Show/hide checkboxes dynamically
			return newSet;
		});
	};

	// Show checkbox when trash icon is clicked
	const handleTrashClick = (e, productID) => {
		e.stopPropagation();
		setCheckedProducts((prev) => new Set([...prev, productID])); // Add product to checked list
		setShowCheckboxes(true);
	};

	// Handle mass delete (select all)
	const handleMassDelete = () => {
		const allProductIds = new Set(selectedProducts.map((p) => p.ID));
		setCheckedProducts(allProductIds);
		setShowCheckboxes(true);
	};

	// Confirm delete action
	const handleDeleteConfirmed = () => {
		const remainingProducts = selectedProducts.filter((p) => !checkedProducts.has(p.ID));
		localStorage.setItem("selectedProducts", JSON.stringify(remainingProducts));
		setSelectedProducts(remainingProducts);
		setCheckedProducts(new Set());
		setShowCheckboxes(false);
		setIsDeleteModalOpen(false);
		window.location.reload();
	};

	// Determine bottom button text
	const getBottomButtonText = () => {
		return checkedProducts.size > 0
			? `Hapus ${checkedProducts.size} produk sekaligus`
			: "Tambah";
	};

	// Handle bottom button click
	const handleBottomButtonClick = () => {
		if (checkedProducts.size > 0) {
			setIsDeleteModalOpen(true);
		} else {
			//25.03 LB 0604 , 0535
			router.push("/muatparts/voucher/create/choose-product");
		}
	};

	return (
		<>
			<div className="bg-white min-h-screen flex flex-col pb-20">
				<div className="py-4 space-y-4 flex-grow">
					<div className="px-4 space-y-4">
						<Header searchQuery={searchQuery} setSearchQuery={setSearchQuery} />

						<div className={`flex justify-between ${isDetail ? 'hidden':''}`}>
							<span className="font-semibold">{selectedProducts.length} Produk</span>
							{!showCheckboxes && (
								<span className="font-semibold text-red-600 cursor-pointer" onClick={handleMassDelete}>
									Hapus Massal
								</span>
							)}
						</div>
					</div>

					<div className="flex-grow bg-gray-100">
						<div className="space-y-2 mt-2">
							{filteredProducts.map((product) => (
								<div key={product.ID} className="border p-4 bg-white shadow flex items-center cursor-pointer">
									{/* Checkbox (shown only if product is selected) */}
									{showCheckboxes && (
										<Checkbox
											checked={checkedProducts.has(product.ID)}
											onCheckedChange={() => toggleProductSelection(product.ID)}
											className="mr-4 border-gray-400"
										/>
									)}
									{/* LB 0102, 0059 */}

									<img src={process.env.NEXT_PUBLIC_ASSET_REVERSE +"/img/product-image.png"} alt={product.title} className="w-16 h-16 object-cover rounded-md mr-3" />

									<div className="flex flex-col flex-grow gap-2">
										<span className="font-bold text-sm">{product.Name}</span>
										<span className="text-xs">SKU: {product.Sku}</span>
										<span className="text-xs">Rp.{product.PriceLabel}</span>
										<span className="text-xs">Stok: {product.Stock}</span>
									</div>

									{/* Trash icon (hidden when checkbox is visible) */}
									{!checkedProducts.has(product.ID) && isDetail == false && (
										<Trash2 className="text-red-600 cursor-pointer" onClick={(e) => handleTrashClick(e, product.ID)} />
									)}
								</div>
							))}
						</div>
					</div>
				</div>

				{/* Bottom Action Button */}
				<div className={`fixed bottom-0 left-0 right-0 px-4 py-4 bg-white border-t shadow-lg ${isDetail ? 'hidden':''}`}>
					<Button
						onClick={handleBottomButtonClick}
						disabled={checkedProducts.size === 0 && selectedProducts.length === 0}
						className="w-full bg-blue-500 text-white rounded-full hover:bg-blue-600 disabled:bg-gray-300"
					>
						{getBottomButtonText()}
					</Button>
				</div>
			</div>

			{/* Confirmation Modal */}
			<Dialog open={isDeleteModalOpen} onOpenChange={setIsDeleteModalOpen}>
				<DialogContent>
					<DialogHeader>
						<DialogTitle className="text-center font-bold">Hapus Produk</DialogTitle>
						<p className="font-medium text-sm text-center">
							Apakah Anda yakin ingin menghapus {checkedProducts.size} produk sekaligus?
						</p>
					</DialogHeader>
					<DialogFooter>
						<DialogClose asChild>
							<Button className="w-1/2 bg-white text-blue-500 border-blue-500 border rounded-full">Batal</Button>
						</DialogClose>
						<Button className="w-1/2 rounded-full bg-blue-500 text-white" onClick={handleDeleteConfirmed}>
							Ya
						</Button>
					</DialogFooter>
				</DialogContent>
			</Dialog>
		</>
	);
}