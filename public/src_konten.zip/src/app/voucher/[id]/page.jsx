"use client"

import { viewport } from "@/store/zustand/viewport";
import VoucherDetailResponsive from "./VoucherDetailResponsive";
import VoucherDetailWeb from "./VoucherDetailWeb";

function Page() {

	const { isMobile } = viewport();

	if (typeof isMobile !== "boolean") return <></>; //buat skeleton
	if (isMobile) return <VoucherDetailResponsive />;
	
	return (
		<VoucherDetailWeb/>
	);
}

export default Page;
