import { Separator } from "@radix-ui/react-separator";
import { ChevronLeft } from "lucide-react";
import StepIndicator from "./StepperIndicator";
import Link from "next/link";
import { useTranslation } from "@/context/TranslationProvider";
// Improvement fix wording Pak Brian
export default function Nav({ step }) {
  const {t} = useTranslation()
  return (
    <nav className="py-2 px-4 flex flex-col justify-between items-start bg-red-700 text-white space-y-4">
     
      <Separator />
      <div className="flex justify-between w-full items-center">
        <p className="font-semibold text-md">
          {step === 1 ? t("PusatPromosiKelolaVoucherVoucherDetailResponsiveInformasiVoucher") : t("PusatPromosiKelolaVoucherDetailDaftarPesanan")}
        </p>
        <StepIndicator step={step} />
      </div>
    </nav>
  );
}