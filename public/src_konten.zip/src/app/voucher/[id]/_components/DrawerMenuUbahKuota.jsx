import { Button } from "@/components/MobileCom/button";
import {
  Drawer,
  DrawerClose,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
} from "@/components/MobileCom/drawer";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/MobileCom/form";
import { Input } from "@/components/MobileCom/input";
import { UbahKuotaVoucherSchema } from "@/schema";
import { zodResolver } from "@hookform/resolvers/zod";
import { X } from "lucide-react";
import { useForm } from "react-hook-form";
// Improvement fix wording Pak Brian
export default function DrawerMenuUbahKuota({
  open,
  onOpenChange,
}) {
  const {t} = useTranslation()
  const form = useForm({
    resolver: zodResolver(UbahKuotaVoucherSchema),
    defaultValues: {
      kuota: "",
    },
  });

  function onSubmit(values) {
    // Do something with the form values.
    // ✅ This will be type-safe and validated.
    console.log(values);
  }

  return (
    <Drawer open={open} onOpenChange={onOpenChange}>
      <DrawerContent className="max-w-screen-sm mx-auto">
        <DrawerHeader className="text-center relative">
          <DrawerClose asChild className="absolute left-4">
            <X className="h-6 w-6 text-blue-500 cursor-pointer" />
          </DrawerClose>
          <DrawerTitle className="text-center capitalize mb-4">
            {t("PusatPromosiKelolaVoucherFormVoucherDetailResponsiveUbahKuotaVoucher")}
          </DrawerTitle>
          <Form {...form}>
            <form
              onSubmit={form.handleSubmit(onSubmit)}
              className="space-y-4 text-left"
            >
              <FormField
                control={form.control}
                name="kuota"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Input type="number" placeholder={t("PusatPromosiKelolaVoucherFormVoucherDetailResponsiveContoh:10")} {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button
                className="bg-blue-700 text-white capitalize font-semibold rounded-full hover:bg-blue-800 w-full"
                type="submit"
              >
                {t("PusatPromosiKelolaVoucherFormVoucherDetailResponsiveTerapkan")}
              </Button>
            </form>
          </Form>
        </DrawerHeader>
      </DrawerContent>
    </Drawer>
  );
}
