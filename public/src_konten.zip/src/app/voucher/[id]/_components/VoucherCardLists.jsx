import VoucherCard from "./VoucherCard";

export default function VoucherCardLists({ orderVouchers }) {
  return (
    <div className="flex flex-col gap-y-2">
      {orderVouchers.length > 0 ? (
        orderVouchers.map((item, i) => <VoucherCard key={i} data={item} />)
      ) : (
        <div className="text-center">
          <h3 className="font-semibold capitalize text-muted-foreground">
            Tidak ada voucher yang sesuai
          </h3>
        </div>
      )}
    </div>
  );
}
