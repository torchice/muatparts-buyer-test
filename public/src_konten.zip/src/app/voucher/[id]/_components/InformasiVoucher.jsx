"use client";
import { useEffect, useState } from "react";
import { Badge } from "@/components/MobileCom/badge";
import { Button } from "@/components/MobileCom/button";
import { Separator } from "@/components/MobileCom/separator";
import { Info, Clipboard } from "lucide-react";
import { usePathname } from "next/navigation";
import { formatDate, formatCurrency } from "@/libs/formaters";
import { useHeader } from '@/common/ResponsiveContext'
import { getDetailVoucher,getOrderVoucher} from '@/services/voucher'; 
import { useRouter } from 'next/navigation';
import { useTranslation } from "@/context/TranslationProvider";
import { t } from "i18next";
// Improvement fix wording Pak Brian
export default function InformasiVoucher({ next }) {
  //  // 25. 11 - QC Plan - Web - Ronda Live Mei - LB - 0184
  const {t, langReady} = useTranslation()
  const [voucherData, setVoucherData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isLoading, setIsLoading] = useState(true);

  const [error, setError] = useState(null);
  const pathname = usePathname();
  const [rawData, setRawData] = useState(null);
  const voucherId = pathname.split('voucher/')[1];
  const router = useRouter();
  const [transactions, setTransactions] = useState([]);

  // Period filter states
  const [selectedPeriod, setSelectedPeriod] = useState("all");
  const [dateRange, setDateRange] = useState({
    from: null,
    to: null
  });

  const {
		appBarType, //pilih salah satu : 'header_title_secondary' || 'header_search_secondary' || 'default_search_navbar_mobile' || 'header_search' || 'header_title'
		appBar, // muncul ini : {onBack:null,title:'',showBackButton:true,appBarType:'',appBar:null,header:null}
		renderAppBarMobile, // untuk render komponen header mobile dengan memasukkanya ke useEffect atau by trigger function / closer
		setAppBar, // tambahkan payload seperti ini setAppBar({onBack:()=>setScreen('namaScreen'),title:'Title header',appBarType:'type'})
		handleBack, // dipanggil di dalam button di luar header, guna untuk kembali ke screen sebelumnya 
		clearScreen,// reset appBar
		setScreen, // set screen
		screen, // get screen,
		search, // {placeholder:'muatparts',value:'',type:'text'}
		setSearch, // tambahkan payload seperti ini {placeholder:'Pencarian',value:'',type:'text'}
	}=useHeader()

  

  useEffect(() => {

   
    const fetchVoucherData = async () => {
      try {
        setLoading(true);
        const response = await getDetailVoucher(`/voucher/${voucherId}`, process.env.NEXT_PUBLIC_AUTH_TOKEN);

        console.log('API Response:', response.Data); // Debug log to check data
        const products = response.Data.products;
        if (!response.Data) {
          throw new Error('No data received from API');
        }

        let startDate, endDate;

        switch (selectedPeriod) {
          case "today":
            startDate = new Date();
            endDate = new Date();
            break;
          case "week":
            endDate = new Date();
            startDate = new Date();
            startDate.setDate(startDate.getDate() - 7);
            break;
          case "custom":
            startDate = dateRange.from;
            endDate = dateRange.to;
            break;
          default:
            startDate = null;
            endDate = null;
        }
  
        const body = {
          page: 1,
          page_size: 100,
          start_date: startDate ? format(startDate, "yyyy-MM-dd") : null,
          end_date: endDate ? format(endDate, "yyyy-MM-dd") : null
        };

        const responseOrder = await getOrderVoucher(`/voucher/order-voucher/${voucherId}`, body, process.env.NEXT_PUBLIC_AUTH_TOKEN);
        
        setTransactions(responseOrder.Data.transactions || []);
        console.log(responseOrder.Data)
        setError(null);

        const transformedData = [
          {
            label: t("PusatPromosiKelolaVoucherInformasiVoucher"),
            fields: [
              {
                label: t("PusatPromosiKelolaVoucherDetailPerformaVoucher"),
                value: `${response.Data.total_used_voucher || 0}/${response.Data.usage_quota || 0} ${t("PusatPromosiKelolaVoucherDetailKuotaTerpakai")}`
              },
              {
                label: t("PusatPromosiKelolaVoucherVoucherDetailResponsivePeriode"),
                value: `${formatDate(response.Data.start_date)} s/d ${formatDate(response.Data.end_date)}`
              },
              {
                label: t("PusatPromosiKelolaVoucherDetailTarget"),
                value: response.Data.target || t("PusatPromosiKelolaVoucherPublik")
              },
              {
                label: t("PusatPromosiKelolaVoucherVoucherDetailResponsiveStatus"),
                value: response.Data.status || t("PusatPromosiKelolaVoucherAktif")
              }
            ]
          },
          {
            label: t("PusatPromosiKelolaVoucherDetailDetailVoucher"),
            fields: [
              {
                label: t("PusatPromosiKelolaVoucherDetailJenisVoucher"),
                value: response.Data.voucher_type || '-'
              },
              {
                label: t("PusatPromosiKelolaVoucherVoucherDetailResponsiveJenisDiskon"),
                value: response.Data.discount_type === 'Nominal' 
                  ? `Rp ${formatCurrency(response.Data.discount_value)}`
                  : t("PusatPromosiKelolaVoucherVoucherDetailResponsivePersentase(%)")
              },
              {
                label: t("PusatPromosiKelolaVoucherDetailDiskon"),
                value: `Rp ${formatCurrency(response.Data.discount_value || 0)}`
              },
              {
                label: t("PusatPromosiKelolaVoucherDetailMinimumPembelian"),
                value: `Rp ${formatCurrency(response.Data.minimum_transaction || 0)}`
              },
              {
                label: t("PusatPromosiKelolaVoucherDetailTarget"),
                value: response.Data.target || t("PusatPromosiKelolaVoucherPublik")
              },
              {
                label: t("PusatPromosiKelolaVoucherDetailKuotaPemakaian"),
                value: response.Data.usage_quota || 0
              },
              {
                label: t("PusatPromosiKelolaVoucherDetailKuotaPemakaianperPembeli"),
                value: response.Data.usage_limit_user || 0
              }
            ]
          },
          {
            label: t("PusatPromosiKelolaVoucherVoucherDetailResponsiveDaftarProdukuntukVoucher"),
            fields: [
              {
                label: t("PusatPromosiKelolaVoucherDetailProdukTerdaftar"),
                value: response.Data.is_all_product ? t("PusatPromosiKelolaVoucherVoucherDetailResponsiveSemuaProduk") : response.Data.products.length + ` ${t("PusatPromosiKelolaVoucherVoucherDetailResponsiveProduk")}`
              }
            ]
          }
        ];
        if(products.length >0){
          updateSelectedProducts(products)
        }
        setRawData(response.Data);
        setVoucherData(transformedData);
        setError(null);

        console.log("rawData",rawData)
      } catch (err) {
        setError(err.message);
        console.error("Error fetching voucher data:", err);
      } finally {
        setLoading(false);
      }
    };
    



    if (voucherId) {
      fetchVoucherData();
    }
  }, [voucherId]);

  useEffect(()=>{
    setAppBar({
			title:t("PusatPromosiKelolaVoucherDetailDetailVoucher"),
			appBarType:'header_title',
		})
  },[langReady])
  // Function to transform and update the products
  function updateSelectedProducts(apiProducts) {
    // Transform API products to match the required format
    const transformedProducts = apiProducts.map(product => ({
      ID: product.id,
      Name: product.name,
      Stock: product.stock.toString(),
      PriceLabel: product.price.toLocaleString('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
      }).replace('IDR', 'Rp'),
      Sku: product.sku || '',
      variant: [] // Empty array since we don't need variant info in new format
    }));

    // Save to localStorage
    localStorage.setItem('selectedProducts', JSON.stringify(transformedProducts));
    
    return transformedProducts;
  }
  if (loading) {
    return <div className="flex justify-center items-center min-h-screen">Loading...</div>;
  }

  if (error) {
    return <div className="flex justify-center items-center min-h-screen text-red-500">Error: {error}</div>;
  }

  if (!voucherData || !rawData) {
    console.log(rawData)
    return <div className="flex justify-center items-center min-h-screen">No voucher data found</div>;
  }
  const formatNumber = (number) => {
    return new Intl.NumberFormat('id-ID').format(number);
  };
  const calculatedTotal = rawData.total_used_voucher == 0 ? 
    0 : 
    formatNumber(rawData.total_used_voucher * rawData.discount_value);

  return (
    <>
    <div className="bg-[#770000] relative">
      <div className="min-h-20 "></div>
      <Ticket
        title={rawData.voucher_name || ''}
        code={rawData.code || ''}
      />
      
      <div className="bg-gray-100 space-y-4 pb-4 ">
        {voucherData.map((item, i) => (
          <InformasiVoucherSection item={item} voucherId={voucherId} router={router} key={i} />
        ))}
       
      </div>
       
    </div>
    <div className="bg-gray-100 space-y-4 ">

    <TotalPengeluaranSection total={calculatedTotal} next={next}/>
    </div>
    </>
  );
}


function InformasiVoucherSection({ item , voucherId , router}) {
  const {t} = useTranslation()
  const handleRedirect = (step) => {
    
    // LBM - INEKE - ROUTE NAVIGATION - 14 April 2025
    router.push(`/muatparts/voucher/create?id=${voucherId}&type=ubah&currentStep=${step}`);
  };
  const handleLihatProduk = (voucherId) => {
    
    // LBM - INEKE - ROUTE NAVIGATION - 14 April 2025
    router.push(`/muatparts/voucher/create/selected-product?id=${voucherId}`);
  };
  return (
    <div
      className={`space-y-2 bg-white p-4 ${
        item.label.includes(t("PusatPromosiKelolaVoucherInformasiVoucher"))? "pt-20" : ""
      }`}
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-bold text-[16px]">{t(item.label)}</h3>
        <Button
          variant="link"
          className="text-blue-500 font-semibold capitalize px-0 hover:no-underline"
          onClick={() => handleRedirect(
            item.label.toLowerCase() === t("PusatPromosiKelolaVoucherInformasiVoucher")?.toLowerCase() ? 1 : 
            item.label.toLowerCase() === t("PusatPromosiKelolaVoucherDetailDetailVoucher")?.toLowerCase() ? 2 : 3
          )}
        >
          {t("PusatPromosiKelolaVoucherUbah")}
        </Button>
      </div>
      {item.fields.map((field, i) => (
        <div key={i}>
          <div className="flex items-center justify-between mb-2">
            <p className="text-muted-foreground capitalize">{t(field.label)}</p>
            {field.label === "status" ? (
              <Badge variant="success" className="capitalize">
                {t(field.value)}
              </Badge>
            ) : (
              (
                <p className={`font-semibold ${field.label == 'Periode'? '':'capitalize'}`}>{t(field.value)}</p>

              )
            )}
           
          </div>
          {field.label === "Produk Terdaftar" && field.value !== "Semua Produk" && (
            <div className="flex justify-end">
              <Button
                variant="link"
                className="font-semibold capitalize text-blue-500 px-0 hover:no-underline"
                onClick={() => handleLihatProduk(voucherId)}
              >
                Lihat Produk
              </Button>
            </div>
          )}
          {i !== item.fields.length - 1 && <Separator className="border-[1px]" />}
          </div>
      ))}
    </div>
  );
}
function TotalPengeluaranSection({ total , next}) {
  const {t} = useTranslation()
  return (
    <div className="flex flex-col bg-white p-4 gap-4 mb-4">
      <div className="flex items-center justify-start gap-x-1">
        <h3 className="font-bold">{t("PusatPromosiKelolaVoucherVoucherDetailResponsiveTotalPengeluaran")}</h3>
        <Info />
      </div>
      <div className="flex items-center justify-between border-transparent bg-green-100 py-2 px-4 rounded-lg">
        <p className="text-primary capitalize">{t("PusatPromosiKelolaVoucherVoucherDetailResponsiveDipotongdariTransaksi")}</p>
        <p className="font-semibold capitalize">Rp {total || 0}</p>
      </div>
      
      <Button
          onClick={next}
          className="rounded-full bg-blue-500 text-white w-full hover:bg-blue-700"
        >
       {t("PusatPromosiKelolaVoucherVoucherDetailResponsiveSelanjutnya")}
        </Button>
    </div>
    
  );

}
  //LB 0102, 0059

function Ticket({ title, code }) {
  return (
    <div className="flex items-center space-x-4 bg-white border border-[2px] border-l-[12px] border-[#52b2ff] rounded-xl shadow-md p-4 w-11/12 absolute top-20 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
      {/* Icon */}
      <div className="flex items-center justify-center w-12 h-12 rounded-full">
        <img src={process.env.NEXT_PUBLIC_ASSET_REVERSE +"/img/icon-voucher.png"} className="h-12 w-12"/>
      </div>
      <div className="relative flex items-center justify-center w-6 h-20 ">
        {/* Vertical Dotted Line */}
        <div className="absolute w-[2px] h-full bg-transparent border-l-2 border-dotted "></div>

        {/* Top Circle */}
        <div className="absolute top-[-27px]  left-1/2 -translate-x-1/2 w-6 h-6 bg-[#770000] border-[2px] border-[#52b2ff] border-t-0 border-r-0 border-l-0 rounded-full"></div>

        {/* Bottom Circle */}
        <div className="absolute bottom-[-29px]  left-1/2 -translate-x-1/2 w-6 h-6 bg-white border-[2px] border-[#52b2ff] border-b-0 border-r-0 border-l-0 rounded-full"></div>
      </div>
      {/* Ticket Content */}
      <div className="flex-1">
        <h1 className="font-bold capitalize text-primary text-xl">{title}</h1>
        <div className="flex items-center space-x-2 mt-2">
          <p className="text-blue-600 text-sm font-medium">{code}</p>
          <button
            className="p-1 rounded-md bg-transparent hover:bg-blue-200 text-blue-600"
            onClick={() => navigator.clipboard.writeText(code)}
          >
            <Clipboard className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}