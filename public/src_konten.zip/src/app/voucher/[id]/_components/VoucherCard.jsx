import { Badge } from "@/components/MobileCom/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/MobileCom/card";
import { Ticket } from "lucide-react";
import DrawerMore from "./DrawerMore";
import { formatDate,formatCurrency } from "@/libs/formaters";

//LB 0102, 0059

export default function VoucherCard({ data }) {
  return (
    <Card className="w-full border border-gray-200 bg-white p-4 shadow-md relative">
      {/* Header */}
      <div className="absolute top-4 right-2">
        <DrawerMore voucher={data} />
      </div>
      <CardHeader className="p-0 flex flex-row items-top space-x-4">
        <div className="flex-shrink-0 rounded-lg items-center justify-center">
          <img src={process.env.NEXT_PUBLIC_ASSET_REVERSE +"/img/voucher.png"} alt="ticket" className="w-18 h-18" />

        </div>
        <div className="space-y-2 w-[85%]">
          <CardTitle className="text-[14px] leading-4 capitalize">{data.voucher_name}</CardTitle>
          <CardDescription className="capitalize text-[12px]">
            {data.voucher_type} <span className="text-black">Rp {data.discount_value}</span>
          </CardDescription>
          <Badge
           
            className="mt-2 min-w-6 justify-center py-1 capitalize bg-[#F1F1F1] text-gray-500" 
          >
            {data.status}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="py-2 px-0">
        <p className="text-[12px] leading-3.5 font-medium text-muted-foreground">Periode</p>
        <p className="text-[12px] m-0 leading-3.5 text-primary font-bold">
          {data.start_date} s/d {data.end_date}
        </p>
      </CardContent>

      <CardFooter className="flex justify-between items-center py-2 px-0">
        <div>
          <p className="text-[12px] leading-3.5 font-medium text-muted-foreground">Produk</p>
          <p className="text-[12px] m-0 leading-3.5 text-primary font-bold">
            {data.is_all_product ? 'Semua Produk':'Produk Tertentu'}
          </p>
        </div>
        <div>
          <p className="text-[12px] leading-3.5 font-medium text-muted-foreground">
            Kuota Terpakai
          </p>
          <p className="text-[12px] m-0 leading-3.5 text-primary font-bold">
            {data.total_used_voucher}/{data.usage_quota}
          </p>
        </div>
        <div>
          <p className="text-[12px] leading-3.5 font-medium text-muted-foreground">
            Target Voucher
          </p>
          <p className="text-[12px] m-0 leading-3.5 text-primary font-bold">
            {data.target}
          </p>
        </div>
      </CardFooter>
    </Card>
  );
}
