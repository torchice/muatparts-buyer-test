"use client";
import { useEffect, useState } from "react";
import Header from "./_components/Header";
import VoucherCardLists from "./_components/VoucherCardLists";
import { dummyVouchers } from "@/app/_Data";
import DrawerMenu from "../_components/DrawerMenu";
import { SearchX, SlidersHorizontal } from "lucide-react";
import { Button } from "@/components/MobileCom/button";
import Nav from "../_components/Nav";
import { useHeader } from '@/common/ResponsiveContext'
import { getVoucher } from '../../../services/voucher'; // Assume this is your API call function
import axios from 'axios';
import FilterPage from "../_components/Filter";
import BottomNavigation from "@/components/Promotions/BottomNavigation";
import { useTranslation } from "@/context/TranslationProvider";
// Improvement fix wording Pak Brian
export default function Page() {
  const { t } = useTranslation()
  const [searchQuery, setSearchQuery] = useState("");
  const [vouchers, setVouchers] = useState([]);
  const [initialDataFetched, setInitialDataFetched] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const {
    appBarType, //pilih salah satu : 'header_title_secondary' || 'header_search_secondary' || 'default_search_navbar_mobile' || 'header_search' || 'header_title'
    appBar, // muncul ini : {onBack:null,title:'',showBackButton:true,appBarType:'',appBar:null,header:null}
    renderAppBarMobile, // untuk render komponen header mobile dengan memasukkanya ke useEffect atau by trigger function / closer
    setAppBar, // tambahkan payload seperti ini setAppBar({onBack:()=>setScreen('namaScreen'),title:'Title header',appBarType:'type'})
    handleBack, // dipanggil di dalam button di luar header, guna untuk kembali ke screen sebelumnya 
    clearScreen,// reset appBar
    setScreen, // set screen
    screen, // get screen,
    search, // {placeholder:'muatparts',value:'',type:'text'}
    setSearch, // tambahkan payload seperti ini {placeholder:'Pencarian',value:'',type:'text'}
  } = useHeader()

  const [filterCriteria, setFilterCriteria] = useState({
    status: "",
    jenisVoucher: "",
    targetVoucher: "",
    produk: "",
  });

  // Only show controls if there's initial data or filters are active
  const [isFilterOpen, setFilterOpen] = useState(false);
  const [activeFilters, setActiveFilters] = useState({});

  const toggleFilter = (category, value) => {
    setFilterCriteria((prev) => {
      const currentValues = prev[category] ? prev[category].split(",") : [];
      let newValues;

      if (currentValues.includes(value)) {
        newValues = currentValues.filter((v) => v !== value);
      } else {
        newValues = [...currentValues, value];
      }

      return {
        ...prev,
        [category]: newValues.length > 0 ? newValues.join(",") : "",
      };
    });
  };

  // Helper function to check if any filter is active
  const isAnyFilterActive = () => {
    console.log(Object.values(filterCriteria).some((value) => value !== ""))

    return Object.values(filterCriteria).some((value) => value !== "") || searchQuery !== "";
  };

  // Helper function to check if data exists
  const hasData = () => {
    return initialDataFetched && Array.isArray(vouchers) && vouchers.length > 0;
  };

  // Function to apply filters and close the filter page
  const handleApplyFilters = () => {
    const hasFilters = Object.values(filterCriteria).some((value) => value !== "");
    const finalFilters = hasFilters ? filterCriteria : {};
    setActiveFilters(finalFilters);
    setFilterOpen(false);
  };

  const handleVoucherDelete = (endedVoucherId) => {
    // Remove the specific voucher from the list
    setVouchers(prevVouchers =>
      prevVouchers.filter(voucher => voucher.uuid !== endedVoucherId)
    );
  };
  const handleVoucherEnd = (endedVoucherId) => {
    // Remove the specific voucher from the list
    setVouchers(prevVouchers =>
      prevVouchers.filter(voucher => voucher.uuid !== endedVoucherId)
    );
  };
  const handleQuotaChange = (voucherId, newQuota) => {
    console.log(voucherId)
    console.log(newQuota)
    setVouchers(prevVouchers =>
      prevVouchers.map(voucher =>
        voucher.uuid === voucherId
          ? { ...voucher, usage_quota: newQuota }
          : voucher
      )
    );
    console.log('vouchers state:', vouchers);  // Log the full vouchers state

  }
  const shouldShowControls = hasData() || isAnyFilterActive();

  // Fetch vouchers from API
  const fetchVouchers = async (filters) => {
    var defaultStatus = "Berakhir";

    try {
      setIsLoading(true);
      const body = {
        page: 1,                    // Page number for pagination
        page_size: 100,                  // Number of items per page
        status: defaultStatus,
        voucher_type: filters.jenisVoucher,
        target: filters.targetVoucher,
        product: filters.produk,
        q: searchQuery,
        sort: "created_at",
        order: "desc"
      }
      const response = await getVoucher('/voucher', body, process.env.NEXT_PUBLIC_AUTH_TOKEN);
      const data = response;
      console.log("API response data:", data); // This will show the data immediately

      setVouchers(data.Data); // Access the correct property and provide a default empty array
      if (!initialDataFetched) setInitialDataFetched(true);

    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };



  useEffect(() => {
		setAppBar({
			title:t("PusatPromosiKelolaVoucherResponsiveVoucherPenjual"),
			appBarType:'header_title',
		  })
      fetchVouchers(activeFilters);

  }, [activeFilters, searchQuery]);

  const resetFilter = () => {
    setFilterCriteria({
      status: "",
      jenisVoucher: "",
      targetVoucher: "",
      produk: "",
    });
  };
  // LB 0102, 0059

  const renderEmptyStateIcon = () => {
    if (isAnyFilterActive()) {
      return <img src={process.env.NEXT_PUBLIC_ASSET_REVERSE + "/img/search-icon.png"} className="h-24 mb-4" alt="Filter no results" />;
    }
    return <img src={process.env.NEXT_PUBLIC_ASSET_REVERSE + "/img/empty-icon.png"} className="h-24 mb-4" alt="No vouchers" />;
  };


  return (
    <>
      <Nav />
      <FilterPage
        type='riwayat'
        isOpen={isFilterOpen}
        onClose={() => setFilterOpen(false)}
        onApply={handleApplyFilters}
        toggleFilter={toggleFilter} // Pass toggleFilter function
        filterCriteria={filterCriteria} // Pass selected filters

      />
      <div className="bg-white py-4 space-y-4 z-10">
        <div className="px-4 space-y-4">
          <Header disabled={!shouldShowControls} searchQuery={searchQuery} setSearchQuery={setSearchQuery} />
          <div>

            <Button
              onClick={() => setFilterOpen(true)}
              disabled={!shouldShowControls}
              variant="secondary"
              className={`
                rounded-2xl ${!shouldShowControls
                  ? 'bg-gray-300'
                  : Object.keys(activeFilters).length // Changed from filterCriteria to activeFilters
                    ? "border-[#176cf7] border-[1px] bg-blue-100 text-[#176cf7]"
                    : ""
                }`}
            >
              Filters <SlidersHorizontal />
            </Button>
          </div>
        </div>

        <div className="min-h-screen bg-gray-100 flex flex-col">
          {vouchers.length > 0 ? (
            <VoucherCardLists
              vouchers={vouchers}
              onVoucherEnd={handleVoucherEnd}
              onChangeQuota={handleQuotaChange}
              onVoucherDelete={handleVoucherDelete}
            />
          ) : (
            <div className="text-center min-h-[600px] flex flex-col items-center justify-center">
              {renderEmptyStateIcon()}
              {isAnyFilterActive() ? (
              <>
                <p className="font-semibold text-[14px] text-muted-foreground">
                  {/* Data tidak Ditemukan. <br />Mohon coba hapus beberapa filter. */}
                  {t("PusatPromosiKelolaVoucherResponsiveDatatidakDitemukan.{render}Mohoncobahapusbeberapafilter.").replace("{render}",'\n')}
                </p>
                <p className="font-semibold text-[14px] text-muted-foreground mb-4">
                  {t("PusatPromosiKelolaVoucherDetailAtau")}
                </p>
                <Button
                  onClick={resetFilter}
                  className="bg-blue-500 text-white text-[14px] font-semibold rounded-full hover:bg-blue-600"
                >
                  {t("PusatPromosiKelolaVoucherResponsiveAturulangfilter")}
              </Button>
           </>
              ) : (
                <>
                {/* // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0937 */}
                <p className="font-semibold text-[14px] text-muted-foreground">
                  {t("PusatPromosiKelolaVoucherBelumadavoucheryangAktif")}
                </p>
                <p className="text-[12px] text-muted-foreground">
                  {t("PusatPromosiKelolaVoucherBuatvouchermusekarang!")}
                </p>
                </>
              )}
            </div>
          )}
        </div>
        <div className="fixed bottom-0 left-0 right-0 z-100">
          <BottomNavigation
            onMessageClick={() => router.push('/pesan')}
            onProfileClick={() => router.push('/profile')}
            onCreateClick={() => router.push('/voucher/create')}
            createButtonLabel={('Buat Voucher')}
            messageIcon="/promo/icons/grey/Chat.svg"
            plusIcon="/promo/icons/grey/Plus Square.svg"
            profileIcon="/promo/icons/grey/Profile.svg"
          />
        </div>
      </div>
    </>
  );
}
