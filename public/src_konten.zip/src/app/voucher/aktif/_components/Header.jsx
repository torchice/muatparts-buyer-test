import { useTranslation } from "@/context/TranslationProvider";
import { Search } from "lucide-react";

export default function Header({ disabled, searchQuery, setSearchQuery }) {
  const {t} = useTranslation() // Improvement fix wording Pak Bryan
  return (
    <>
      <form action="">
        <div className={`flex gap-x-2 w-full rounded-lg px-4 py-2 border border-gray-500 ${disabled ? 'bg-gray-100' : 'bg-white'}`}>
          <Search className="text-slate-500 h-6 w-6" />
          <input
            disabled={disabled}
            type="text"
            name="search"
            placeholder={t("PusatPromosiKelolaVoucherCariNama/KodeVoucher")}
            autoComplete="off"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)} // Update query
            className="outline-none border-none bg-transparent text-slate-500 w-full "
          />
        </div>
      </form>
    </>
  );
}
