import { useTranslation } from "@/context/TranslationProvider";
import VoucherCard from "./VoucherCard";

export default function VoucherCardLists({ vouchers,onVoucherEnd,onChangeQuota,onVoucherDelete }) {
  const {t} = useTranslation() // Improvement fix wording Pak Bryan
  return (
    <div className="flex flex-col gap-y-2">
      {vouchers.length > 0 ? (
        vouchers.map((item, i) => <VoucherCard key={i} data={item} onVoucherEnd={onVoucherEnd } onChangeQuota={onChangeQuota} onVoucherDelete={onVoucherDelete}  />)
      ) : (
        <div className="text-center">
          <h3 className="font-semibold capitalize text-muted-foreground">
            {t("PusatPromosiKelolaVoucherResponsiveTidakadavoucheryangsesuai")}
          </h3>
        </div>
      )}
    </div>
  );
}
