"use client";
import {
  Drawer,
  DrawerClose,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from "@/components/MobileCom/drawer";
import { Separator } from "@/components/MobileCom/separator";
import { EllipsisVertical, X } from "lucide-react";
import ConfirmModal from "../../_components/ConfirmModal";
import { useState } from "react";
import DrawerMenuUbahKuota from "../../_components/DrawerMenuUbahKuota";
import ConfirmModalHapus from "../../_components/ConfirmModalHapus";
import Link from "next/link";
import { t } from "i18next";
import { useTranslation } from "@/context/TranslationProvider";
// Improvement fix wording Pak Brian
export default function DrawerMore({ voucher,onVoucherEnd,onChangeQuota,onVoucherDelete  }) {
  const {t} = useTranslation() // Improvement fix wording Pak Bryan
  const [isModalAkhiriOpen, setIsModalAkhiriOpen] = useState(false);
  const [isModalKuotaOpen, setIsModalKuotaOpen] = useState(false);
  const [isModalHapusOpen, setIsModalHapusOpen] = useState(false);
  const [selectedVoucherId, setSelectedVoucherId] = useState(null);
  const [voucherName, setVoucherName] = useState("");

  const handleSuccess = () => {
    
    // This will be called after successful voucher end
    window.location.reload();
  };

  return (
    <>
      <Drawer>
        <DrawerTrigger>
          <EllipsisVertical className="h-6 w-6" />
        </DrawerTrigger>
        <DrawerContent className="max-w-screen-sm mx-auto min-h-3.5">
          <DrawerHeader className="text-center relative">
            <DrawerTitle className="text-center text-[14px] leading-4">{t("PusatPromosiDrawerMoreAtur")}</DrawerTitle>
            <DrawerClose asChild className="absolute left-4">
              {/* <Button variant="ghost" className="p-0"> */}
              <X className="h-8 w-8 text-blue-500 cursor-pointer" />
              {/* </Button> */}
            </DrawerClose>
          </DrawerHeader>
          <div className="p-4 space-y-4">
            <div>
              <DrawerClose asChild>
              <Link href={`/voucher/${voucher.uuid}`} className=" hover:no-underline">
                <h3 className="capitalize text-[#343434] font-semibold text-[14px] leading-4 cursor-pointer">
                  {t("PusatPromosiDrawerMoreDetail")}
                </h3>
              </Link>
              </DrawerClose>
              <Separator className="" />
            </div>
            <div>
              <DrawerClose>
                <h3
                  className="capitalize font-semibold text-[14px] leading-4"
                  onClick={() => {
                    setSelectedVoucherId(voucher.uuid); // Store the selected voucher ID
                    setIsModalKuotaOpen(true); // Membuka modal
                  }}
                >
                  {t("PusatPromosiDrawerMoreUbahKuota")}
                </h3>
                <Separator className="" />
              </DrawerClose>
            </div>
            {/* // LBM - INEKE - ROUTE NAVIGATION - 14 April 2025 */}

            <div>
              <Link href={`/muatparts/voucher/create?id=${voucher.uuid}&type=salin`} className=" hover:no-underline">
                <h3 className="capitalize text-[#343434] font-semibold text-[14px] leading-4 cursor-pointer">
                  {t("PusatPromosiDrawerMoreSalin")}
                </h3>
              </Link>
              <Separator className="" />
            </div>

            <div>
             {/* Replace your existing DrawerClose with this conditional rendering */}
              {voucher.status === 'Aktif' ? (
                <DrawerClose>
                  <h3
                    className="capitalize font-semibold text-[14px] leading-4"
                    onClick={() => {
                      setSelectedVoucherId(voucher.uuid);
                      setVoucherName(voucher.voucher_name);
                      setIsModalAkhiriOpen(true);
                      
                    }}
                  >
                    {t("PusatPromosiDrawerMoreAkhiri")}
                  </h3>
                  <Separator className="" />
                </DrawerClose>
              ) : voucher.status === 'Akan Datang' ? (
                <DrawerClose>
                  <h3
                    className="capitalize font-semibold text-[14px] leading-4"
                    onClick={() => {
                      setSelectedVoucherId(voucher.uuid);
                      setVoucherName(voucher.voucher_name);
                      setIsModalHapusOpen(true); // Make sure to create this state
                    }}
                  >
                    {t("PusatPromosiDrawerMoreHapus")}
                  </h3>
                  <Separator className="" />
                </DrawerClose>
              ) : null}
            </div>
          </div>
        </DrawerContent>
      </Drawer>
      <DrawerMenuUbahKuota
        open={isModalKuotaOpen}
        onOpenChange={setIsModalKuotaOpen}
        voucherId={selectedVoucherId} // Pass the ID to modal
        onSuccess={(voucherId, newQuota) => {  // Add newQuota parameter here
          if (onChangeQuota) {
            onChangeQuota(voucherId, newQuota);  // Pass both voucherId and newQuota
          }
        }}
      />
      <ConfirmModal
        open={isModalAkhiriOpen}
        onOpenChange={setIsModalAkhiriOpen}
        voucherId={selectedVoucherId} // Pass the ID to modal
        voucherName={voucherName}
        onSuccess={() => {
          if (onVoucherEnd) {
            onVoucherEnd(voucher.uuid);
          }
        }}

      />
       <ConfirmModalHapus
        open={isModalHapusOpen}
        onOpenChange={setIsModalHapusOpen}
        voucherId={selectedVoucherId} // Pass the ID to modal
        voucherName={voucherName}
        onSuccess={() => {
          if (onVoucherDelete) {
            onVoucherDelete(voucher.uuid);
          }
        }}

      />
    </>
  );
}
