import React from 'react'
import RekeningPencairanContainer from '@/container/RekeningPencairanContainer'

function page() {
  return (
    <RekeningPencairanContainer/>
  )
}

export default page