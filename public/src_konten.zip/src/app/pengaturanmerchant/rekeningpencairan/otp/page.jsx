import OTPRekening from '@/container/RekeningPencairanContainer/otp'
import React from 'react'

function page() {
  return (
    <OTPRekening/>
  )
}

export default page