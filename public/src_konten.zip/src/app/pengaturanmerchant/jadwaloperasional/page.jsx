import React from 'react'
import JadwalOperasional from '.'

function page() {
  return (
    <JadwalOperasional/>
  )
}

export default page
