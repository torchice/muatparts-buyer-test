"use client"
import HeaderMobile from '@/container/HeaderMobile/HeaderMobile'
import React, { useEffect, useState } from 'react'
import ListOperational from './screens/ListOperational'
import AturJamOperasional from './screens/AturJamOperasional'
import toast from '@/store/zustand/toast'
import Toast from '@/components/Toast/Toast'
import AturJamOperasionalMassal from './screens/AturJamOperasionalMassal'
import { useCustomRouter } from '@/libs/CustomRoute'
import { useTranslation } from '@/context/TranslationProvider'

function JamOperasionalMobile({
  isClosed,
  groupingOperationalHours,
  closingSchedules,
  forceOpenStore,
  setClosingSchedule,
  updateClosingSchedule
}) {
  const router = useCustomRouter();
  const { t } = useTranslation();

  const [getScreen,setScreen]=useState('home')
  const [getScreenStack,setScreenStack]=useState([])

  const {
    setShowNavMenu,
    setDataNavMenu
  } = toast();

  // FIX BUG Setting Jam Opersional LB-0025
  useEffect(() => {
    setShowNavMenu(true)
    setDataNavMenu({
      title: "Home",
      action: "/dashboard",
      type: 2
    })
  }, [])
  
  function handleScreen(value,pop) {
    setScreen(value)
    setScreenStack(prev=>([...getScreenStack,value]))
    setShowNavMenu(false)
  }

  const handleBack = () => {
    if (getScreen === "home") {
      router.back()
    } else if (getScreen === "atur_jam_operasional_massal") {
      setScreen("atur_jam_operasional")
    } else {
      setScreen("home")
      setShowNavMenu(true)
    }
  }

  return (
    <>
      <HeaderMobile onBack={handleBack} title={getScreen==='home' ? t("titleOperationalSchedule") : t("titleSetHours")} /> 
      <div className='h-full w-full flex flex-col gap-2 mt-[8px]'>
          {getScreen==='home'&& (
            <ListOperational
              isClosed={isClosed}
              forceOpenStore={forceOpenStore}
              groupingOperationalHours={groupingOperationalHours}
              closingSchedules={closingSchedules}
              setScreen={handleScreen}
              setClosingSchedule={setClosingSchedule}
              updateClosingSchedule={updateClosingSchedule}
            />
          )}
          {getScreen==='atur_jam_operasional'&& (
            <AturJamOperasional
              setScreen={handleScreen}
            />
          )}
          {getScreen === "atur_jam_operasional_massal" && (
            <AturJamOperasionalMassal
              setScreen={handleScreen}
            />
          )}
      </div>
      <Toast/>
    </>
  )
}

export default JamOperasionalMobile
