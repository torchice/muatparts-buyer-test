"use client";
import viewport from "@/store/zustand/common";
import JadwalOperasionalMobile from "./JadwalOperasionalMobile";
import JadwalOperasionalWeb from "./JadwalOperasionalWeb";
import SWRHandler from "@/services/useSWRHook";
import jadwalTutup from "@/store/zustand/jadwaloperasional/jadwalTutup";
import jamOperasional from "@/store/zustand/jadwaloperasional/jamOperasional";
import { useEffect } from "react";

const baseUrl = `${process.env.NEXT_PUBLIC_GLOBAL_API}v1/`

function JadwalOperasional() {
  const { isMobile } = viewport();
  const { setOperationalHours } = jamOperasional();
  const { scheduleId } = jadwalTutup();

  const { useSWRHook, useSWRMutateHook } = SWRHandler;
  const { data } = useSWRHook(
    `${baseUrl}muatparts/store/operational_hours`
  );
  const { trigger: forceOpenStore } = useSWRMutateHook(
    `${baseUrl}muatparts/store/force_open`,
    "DELETE"
  );

  const {
    trigger: setClosingSchedule,
  } = useSWRMutateHook(
    `${baseUrl}muatparts/store/closing_schedules`,
    "POST"
  );

  const { trigger: updateClosingSchedule } = useSWRMutateHook(
    `${baseUrl}muatparts/store/closing_schedules/${scheduleId}`,
    "PUT"
  );

  const isClosed = data?.Data.isStoreClosed;
  const groupingOperationalHours = data?.Data.groupingOperationalHours || [];
  const operationalHours = data?.Data.operationalHours || [];
  const closingSchedules = data?.Data.closingSchedules || [];

  useEffect(() => {
    if (operationalHours.length > 0) {
      setOperationalHours(operationalHours)
    }
  }, [JSON.stringify(operationalHours)])

  if (isMobile)
    return (
      <JadwalOperasionalMobile
        isClosed={isClosed}
        groupingOperationalHours={groupingOperationalHours}
        closingSchedules={closingSchedules}
        forceOpenStore={forceOpenStore}
        setClosingSchedule={setClosingSchedule}
        updateClosingSchedule={updateClosingSchedule}
      />
    );
  return (
    <JadwalOperasionalWeb
      isClosed={isClosed}
      groupingOperationalHours={groupingOperationalHours}
      closingSchedules={closingSchedules}
      forceOpenStore={forceOpenStore}
      setClosingSchedule={setClosingSchedule}
      updateClosingSchedule={updateClosingSchedule}
    />
  );
}

export default JadwalOperasional;
