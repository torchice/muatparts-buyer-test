// LBM - OLIVER - MULTIBAHASA JADWAL OPERASIONAL - MP - 018
import { useTranslation } from '@/context/TranslationProvider';
import React, { useState } from 'react';

const TimeSelector = ({ isOpen, onClose, onApply, title = "Jam Buka" }) => {
  // LBM - OLIVER - MULTIBAHASA JADWAL OPERASIONAL - MP - 018
  const { t } = useTranslation();
  const [selectedHour, setSelectedHour] = useState(20);
  const [selectedMinute, setSelectedMinute] = useState(0);

  const hours = Array.from({ length: 24 }, (_, i) => String(i).padStart(2, '0'));
  const minutes = Array.from({ length: 60 }, (_, i) => String(i).padStart(2, '0'));

  const handleApply = () => {
    onApply(`${selectedHour}:${String(selectedMinute).padStart(2, '0')}`);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl w-full max-w-[296px] relative">
        <div className="flex justify-between items-center px-4 py-3 border-b border-gray-200">
          <h2 className="text-base font-bold text-black">{title}</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
              <path d="M18 6L6 18M6 6L18 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
            </svg>
          </button>
        </div>
        
        <div className="px-4 py-6">
          <div className="flex gap-2 justify-center">
            <div className="flex-1">
              <div className="h-[240px] overflow-y-auto flex flex-col">
                {hours.map((hour) => (
                  <button
                    key={hour}
                    className={`py-2 text-center ${
                      selectedHour === parseInt(hour)
                        ? 'text-blue-600 font-bold text-lg'
                        : 'text-gray-600'
                    }`}
                    onClick={() => setSelectedHour(parseInt(hour))}
                  >
                    {hour}
                  </button>
                ))}
              </div>
            </div>
            
            <div className="text-2xl font-bold text-black self-center">:</div>
            
            <div className="flex-1">
              <div className="h-[240px] overflow-y-auto flex flex-col">
                {minutes.map((minute) => (
                  <button
                    key={minute}
                    className={`py-2 text-center ${
                      selectedMinute === parseInt(minute)
                        ? 'text-blue-600 font-bold text-lg'
                        : 'text-gray-600'
                    }`}
                    onClick={() => setSelectedMinute(parseInt(minute))}
                  >
                    {minute}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="px-4 py-3 border-t border-gray-200">
          <button
            onClick={handleApply}
            className="w-full bg-blue-600 text-white rounded-lg py-2 font-semibold hover:bg-blue-700"
          >
            {/* LBM - OLIVER - MULTIBAHASA JADWAL OPERASIONAL - MP - 018 */}
            {t("buttonApply")}
          </button>
        </div>
      </div>
    </div>
  );
};

export default TimeSelector;