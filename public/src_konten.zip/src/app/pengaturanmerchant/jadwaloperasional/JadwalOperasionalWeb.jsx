import Button from "@/components/Button/Button";
import IconComponent from "@/components/IconComponent/IconComponent";
import ImageComponent from "@/components/ImageComponent/ImageComponent";
import Modal from "@/components/Modals/modal";
import Toast from "@/components/Toast/Toast";
import CustomDatePicker from "@/container/JadwalOperasional/Web/CustomDatePicker";
import OperatingHourRow from "@/container/JadwalOperasional/Web/OperatingHourRow";
import OperationalHoursMassalModal from "@/container/JadwalOperasional/Web/OperationalHoursMassalModal";
import OperationalHoursModal from "@/container/JadwalOperasional/Web/OperationalHoursModal";
import ScheduleCard from "@/container/JadwalOperasional/Web/ScheduleCard";
import { StoreStatus } from "@/container/JadwalOperasional/Web/StoreStatus";
import { formatDateAPI } from "@/libs/services";
import jadwalTutup from "@/store/zustand/jadwaloperasional/jadwalTutup";
import toast from "@/store/zustand/toast";
import { Fragment, useState } from "react";
import { useSWRConfig } from "swr";
import { useTranslation } from "@/context/TranslationProvider";
import { isDateRangeOverlapping } from "@/libs/jadwalOperasionalUtils";

const baseUrl = `${process.env.NEXT_PUBLIC_GLOBAL_API}v1/`

export default function JadwalOperasionalWeb({
  isClosed,
  groupingOperationalHours,
  closingSchedules,
  forceOpenStore,
  setClosingSchedule,
  updateClosingSchedule,
}) {
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [modalType, setModalType] = useState("")
  const [isOperationalModalOpen, setIsOperationalModalOpen] = useState(false);
  const [isMassalModalOpen, setIsMassalModalOpen] = useState(false);
  const [error, setError] = useState({});

  const { mutate } = useSWRConfig()

  const { 
    startDate,
    setStartDate,
    endDate,
    setEndDate,
    scheduleId,
    setScheduleId,
  } = jadwalTutup()
  const {
    showToast,
    dataToast,
    setShowToast,
    setDataToast
  } = toast();

  const today = new Date()
  const { t } = useTranslation();

  const clearModal = () => {
    setIsModalOpen(false)
    setModalType("")
    setEndDate(null)
    setStartDate(null)
  }

  const validateAddEditClosingSchedule = () => {
    // Reset errors
    setError({});
    
    // Validate inputs
    if (!startDate) {
      setError(prev => ({ ...prev, startDate: t("messageStartRequired") }));
      return;
    }
    if (!endDate) {
      setError(prev => ({ ...prev, endDate: t('messageEndRequired') }));
      return;
    }
    // FIX BUG Pengecekan Ronda Muatparts LB-0134
    if (scheduleId) {
      const filteredClosingSchedules = closingSchedules.filter(item => item.id !== scheduleId)
      if (isDateRangeOverlapping(formatDateAPI(startDate), formatDateAPI(endDate), filteredClosingSchedules)) {
        setDataToast({
          type: "error",
          message: t('messageClosingExists'),
        });
        setShowToast(true);
        return;
      }
    } else {
      if (isDateRangeOverlapping(formatDateAPI(startDate), formatDateAPI(endDate), closingSchedules)) {
        setDataToast({
          type: "error",
          message: t('messageClosingExists'),
        });
        setShowToast(true);
        return;
      }
    }
    // if (!startDate || !endDate) {
    //   return;
    // }
    if (!scheduleId) {
      setModalType("confirmAddClosingSchedule")
    } else {
      handleAddEditClosingSchedule()
    }
  }

  const handleAddEditClosingSchedule = async() => {
    const data = {
      startDate: formatDateAPI(startDate),
      endDate: formatDateAPI(endDate)
    }
    if (!scheduleId) {
      await setClosingSchedule(data)
        .then(() => {
          clearModal()
          mutate(`${baseUrl}muatparts/store/operational_hours`)
          setDataToast({
            type: "success",
            message: t('messageSuccessClosing'),
          });
          setShowToast(true);
        })
        .catch((err) => {
          const overlapError = err?.response.data.Data.Message === "Jadwal overlap dengan tanggal tutup yang sudah ada"
          if (overlapError) {
            setDataToast({
              type: "error",
              message: t('messageClosingExists'),
            });
            setShowToast(true);
          }
          clearModal()
        })
    } else {
      await updateClosingSchedule(data)
        .then(() => {
          clearModal()
          mutate(`${baseUrl}muatparts/store/operational_hours`)
          setDataToast({
            type: "success",
            message: t("messageSuccessChangeClosingDate"),
          });
          setShowToast(true);
        })
        .catch((err) => {
          const overlapError = err?.response.data.Data.Message === t('messageOverlapError')
          if (overlapError) {
            setDataToast({
              type: "error",
              message: t('messageClosingExist'),
            });
            setShowToast(true);
          }
          clearModal()
        })
    }
  }

  const handleEditClosingSchedule = (schedule) => {
    const { id, raw_end_date, raw_start_date } = schedule
    setIsModalOpen(true)
    setModalType("addEditClosingSchedule")
    setScheduleId(id)
    setStartDate(new Date(raw_start_date))
    setEndDate(new Date(raw_end_date))
    setError({})
  }

  const handleForceOpenStore = async () => {
    await forceOpenStore()
      .then(() => {
        setIsModalOpen(false)
        setModalType("")
        mutate(`${baseUrl}muatparts/store/operational_hours`)
        setDataToast({
          type: "success",
          message: t('titleSuccessReopen'),
        });
        setShowToast(true);
      })
      .catch(() => {
        setIsModalOpen(false)
        setModalType("")
      })
  }

  return (
    <Fragment>
      <div className="flex w-full h-full min-h-[calc(100vh_-_100px)]">
        <div className="flex flex-col self-start mr-0 w-full">
          <div className="flex flex-col w-full gap-y-4">
            <div className="flex flex-col w-full font-bold text-black">
              <div className="gap-2 self-stretch my-auto min-w-[240px] w-[941px] text-[20px] leading-[24px]">
              {/* {Atur Jadwal Operasional} */}
              {t('titleOperationalSchedule')}
              </div>
            </div>
            <div className="flex flex-col gap-y-6">
              {isClosed ? <StoreStatus setIsModalOpen={setIsModalOpen} setModalType={setModalType} /> : null}
              <div className="flex overflow-hidden items-start p-6 w-full bg-white rounded-xl shadow-muat">
                <div className="flex flex-col gap-y-6 justify-center w-full text-sm bg-white">
                  <div>
                    <div className="flex gap-6 items-center w-full">
                      <div className="flex flex-col grow shrink justify-center self-stretch my-auto text-black min-w-[240px]">
                        <div className="flex gap-3 items-center w-fit font-bold">
                          <ImageComponent
                            src={`/img/24-hours.png`}
                            alt="24 jam"
                            width={24}
                            height={24}
                          />
                          <div className="flex-1 shrink self-stretch my-auto basis-0 text-[18px] leading-[21.6px]">
                          {/* {  Jam Operasional} */}
                          {t('titleOperationalHours')}
                          </div>
                        </div>
                        <div className="mt-4 font-medium text-[12px] leading-[14.4px] max-w-full">
                        {/* {  Kamu dapat menentukan hari dan jam operasional
                          merchantmu untuk melayani pembeli. Pada hari toko tidak
                          beroperasional maka Pembeli tidak dapat memesan
                          produkmu.} */}
                              {t('descOperationalHours')}
                        </div>
                      </div>
                      <Button
                        Class="h-8 px-6 max-w-[128px] w-full flex items-center"
                        color="primary_secondary"
                        onClick={() => setIsOperationalModalOpen(true)}
                      >
                        {groupingOperationalHours.length > 0 ? t("buttonChange") : t('buttonAturJadwal')}
                      </Button>
                    </div>
                  </div>
                  {groupingOperationalHours.length > 0 ? (
                    <div className="px-4 py-[16.5px] rounded-md border border-neutral-400">
                      {groupingOperationalHours.map((item, index) => (
                        <div key={index} className={index > 0 ? "mt-3" : ""}>
                          <OperatingHourRow {...item} />
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="flex flex-col w-full font-medium leading-tight text-black">
                      <div className="flex overflow-hidden gap-2.5 justify-center items-center px-6 py-4 w-full bg-secondary-100 rounded-md">
                        <div className="flex flex-wrap flex-1 shrink gap-2 items-center self-stretch my-auto w-full basis-0 min-w-[240px]">
                          <IconComponent
                            size="medium"
                            src="/icons/warning.svg"
                          />
                          <div className="flex-1 shrink self-stretch my-auto font-medium text-[12px] leading-[14.4px]">
                            {t('warningOperationalMessage')}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
              <div className="flex flex-col gap-y-6 justify-center p-6 w-full text-sm bg-white rounded-xl shadow-muat">
                <div className="flex flex-col flex-1 shrink w-full basis-0 min-w-[240px]">
                  <div className="flex gap-5 items-center w-full">
                    <div className="flex flex-col flex-1 shrink justify-center self-stretch my-auto text-black basis-12 min-w-[240px]">
                      <div className="flex gap-3 items-center w-full font-bold">
                        <ImageComponent
                          src={`/img/closed.png`}
                          alt="24 jam"
                          width={24}
                          height={24}
                        />
                        <div className="flex-1 shrink self-stretch my-auto basis-0 text-[18px] leading-[21.6px]">
                        {t('titleClosingSchedule')}
                        </div>
                      </div>
                      <div className="flex-1 shrink gap-2.5 self-stretch mt-3 w-full font-medium text-[12px] leading-[14.4px]">
                        {t('descClosingSchedule')}
                      </div>
                    </div>
                    <Button
                      Class="h-8"
                      color="primary_secondary"
                      iconLeft="/icons/Plus.svg"
                      onClick={() => {
                        setIsModalOpen(true)
                        setModalType("addEditClosingSchedule")
                        setError({})
                        setScheduleId(null)
                        setStartDate(null)
                        setEndDate(null)
                      }}
                    >
                          {t('buttonTambah')}
                    </Button>
                  </div>
                </div>
                {closingSchedules.length > 0 ? (
                  <div className="p-6 rounded-md border border-neutral-400 flex flex-col gap-y-4">
                    {closingSchedules.map((schedule, index) => (
                      <Fragment key={index}>
                        <ScheduleCard
                          schedule={schedule}
                          onEditClosingSchedule={handleEditClosingSchedule}
                        />
                      </Fragment>
                    ))}
                  </div>
                ) : null}
              </div>
            </div>
          </div>
        </div>
      </div>
      <OperationalHoursModal
        isOpen={isOperationalModalOpen}
        onClose={() => setIsOperationalModalOpen(false)}
        onOpenMassalModal={() => setIsMassalModalOpen(true)}
      />
      <OperationalHoursMassalModal
        isOpen={isMassalModalOpen}
        onClose={() => setIsMassalModalOpen(false)}
        setIsOperationalModalOpen={setIsOperationalModalOpen}
      />
      {/* FORCE OPEN STORE MODAL */}
      {modalType === "forceOpen" ? (
        <Modal
          isOpen={isModalOpen}
          setIsOpen={setIsModalOpen}
          closeArea={false}
          closeBtn={true}
          title={t('titleReadyToOperate')}
          desc={t('descReadyToOperate')}
          action1={{
            action: () => {
              setIsModalOpen(false)
              setModalType("")
            },
            text: t('buttonCancel'),
            style: "outline",
            color: "#176CF7",
            customStyle: {
              width: "112px",
            },
          }}
          action2={{
            action: handleForceOpenStore,
            text: t('buttonOpenStore'),
            style: "full",
            color: "#176CF7",
            customStyle: {
              width: "115px",
              color: "#ffffff",
            },
          }}
        />
      ) : null}
      {/* TAMBAH JADWAL TUTUP MODAL */}
      {modalType === "addEditClosingSchedule" ? (
        <Modal
          isOpen={isModalOpen}
          setIsOpen={setIsModalOpen}
          closeArea={false}
          closeBtn={true}
        >
          <div className="flex flex-col gap-y-6">
            <span className="font-bold text-[16px] leading-[19.2px] text-center">
              {!scheduleId ? t("titleAddClosingDate") : t("titleChangeClosingDate") }
            </span>
            <div className="flex gap-x-2 self-center">
              <div className="flex-1 flex flex-col">
                <div className="h-[32px]">
                  <CustomDatePicker
                    isError={error?.startDate}
                    placeholder={t("labelStart")}
                    onChange={(date) => {
                      setStartDate(date);
                      setError(prev => ({ ...prev, startDate: undefined }));
                    }}
                    value={startDate}
                    maxDate={endDate ? endDate : undefined}
                    minDate={today}
                    // LBM - OLIVER - FIX STYLING DATE PICKER JADWAL OPERASIONAL - MP - 018
                    wrapperClassName={`w-[136px]`}
                  />
                </div>
                {error?.startDate && (
                  <span className="font-medium text-[12px] leading-[14.4px] text-error-400 mt-2">
                    {error.startDate}
                  </span>
                )}
              </div>
              
              <div className="flex items-center h-[32px]">
                <span className="font-semibold text-[12px] leading-[16.8px] text-neutral-600">
                  {t("labelTo")}
                </span>
              </div>

              <div className="flex-1 flex flex-col">
                <div className="h-[32px]">
                  <CustomDatePicker
                    isError={error?.endDate}
                    placeholder={t("labelEnd")}
                    onChange={(date) => {
                      setEndDate(date);
                      setError(prev => ({ ...prev, endDate: undefined }));
                    }}
                    value={endDate}
                    disabled={!startDate}
                    minDate={startDate ? startDate : undefined}
                    // LBM - OLIVER - FIX STYLING DATE PICKER JADWAL OPERASIONAL - MP - 018
                    wrapperClassName={`w-[136px]`}
                  />
                </div>
                {error?.endDate && (
                  <span className="font-medium text-[12px] leading-[14.4px] text-error-400 mt-2">
                    {error.endDate}
                  </span>
                )}
              </div>
            </div>

            <Button
              Class="h-8 self-center"
              color="primary"
              onClick={validateAddEditClosingSchedule}
            >
              {t('buttonApply')}
            </Button>
          </div>
        </Modal>
      ) : null}
      {/* KONFIRMASI TAMBAH JADWAL TUTUP MODAL */}
      {modalType === "confirmAddClosingSchedule" ? (
        <Modal
          isOpen={isModalOpen}
          setIsOpen={setIsModalOpen}
          closeArea={false}
          closeBtn={true}
          title={t('titleNotification') + "?"} 
          desc={t('descNotification')}
          action1={{
            action: () => {
              setModalType("addEditClosingSchedule")
            },
            text: t('buttonCancel'),
            style: "outline",
            color: "#176CF7",
            customStyle: {
              width: "112px",
            },
          }}
          action2={{
            action: handleAddEditClosingSchedule,
            text: t('buttonSave'),
            style: "full",
            color: "#176CF7",
            customStyle: {
              width: "115px",
              color: "#ffffff",
            },
          }}
        />
      ) : null}
      <Toast/>
    </Fragment>
  );
}