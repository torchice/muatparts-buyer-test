import Bottomsheet from "@/components/Bottomsheet/Bottomsheet"
import Button from "@/components/Button/Button"
import IconComponent from "@/components/IconComponent/IconComponent"
import ImageComponent from "@/components/ImageComponent/ImageComponent"
import Modal from "@/components/Modals/modal"
import ClosingScheduleResponsive from "@/container/JadwalOperasional/Responsive/ClosingScheduleResponsive"
import CustomDatePicker from "@/container/JadwalOperasional/Web/CustomDatePicker"
import { useTranslation } from "@/context/TranslationProvider"
import { isDateRangeOverlapping } from "@/libs/jadwalOperasionalUtils"
import { formatDateAPI } from "@/libs/services"
import jadwalTutup from "@/store/zustand/jadwaloperasional/jadwalTutup"
import toast from "@/store/zustand/toast"
import React, { Fragment, useRef, useState } from "react"
import { useSWRConfig } from "swr"

const baseUrl = `${process.env.NEXT_PUBLIC_GLOBAL_API}v1/`

function ListOperational({
  isClosed,
  forceOpenStore,
  closingSchedules,
  groupingOperationalHours,
  setScreen,
  setClosingSchedule,
  updateClosingSchedule
}) {
  const [error, setError] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalType, setModalType] = useState("")
  const {
    startDate,
    setStartDate,
    endDate,
    setEndDate,
    scheduleId,
    setScheduleId
  } = jadwalTutup()
  const { mutate } = useSWRConfig()
  const { setDataToast, setShowBottomsheet, setShowToast, setTitleBottomsheet } = toast();
  const  { t } = useTranslation();
  // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0162
  // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0489
  const startDateRef = useRef();
  const endDateRef = useRef();

  const isEmptyOperationalHours = groupingOperationalHours.length === 0
  const isEmptyClosingSchedules = closingSchedules.length === 0

  const clearBottomsheet = () => {
    setShowBottomsheet(false)
    setTitleBottomsheet("")
    setEndDate(null)
    setStartDate(null)
  }

  const clearModal = () => {
    setIsModalOpen(false)
    setModalType("")
  }

  const handleAddEditClosingSchedule = async() => {
    const data = {
      startDate: formatDateAPI(startDate),
      endDate: formatDateAPI(endDate)
    }
    if (!scheduleId) {
      await setClosingSchedule(data)
        .then(() => {
          clearModal()
          mutate(`${baseUrl}muatparts/store/operational_hours`)
          setDataToast({
            type: "success",
            message: t("messageSuccessClosing"),
          });
          setShowToast(true);
        })
        .catch(() => clearModal())
    } else {
      await updateClosingSchedule(data)
        .then(() => {
          clearBottomsheet()
          mutate(`${baseUrl}muatparts/store/operational_hours`)
          setDataToast({
            type: "success",
            message: t("messageSuccessChangeClosingDateResponsive"),
          });
          setShowToast(true);
        })
        .catch(() => clearBottomsheet())
    }
  }

  const handleEditClosingSchedule = (schedule) => {
    const { id, raw_end_date, raw_start_date } = schedule
    setShowBottomsheet(true)
    setTitleBottomsheet(t("titleChangeClosingDate"))
    setScheduleId(id)
    setStartDate(new Date(raw_start_date))
    setEndDate(new Date(raw_end_date))
  }

  const handleForceOpenStore = async () => {
    await forceOpenStore()
      .then(() => {
        setIsModalOpen(false)
        setModalType("")
        mutate(`${baseUrl}muatparts/store/operational_hours`)
        setDataToast({
          type: "success",
          message: t("titleSuccessReopen"),
        });
        setShowToast(true);
      })
      .catch(() => {
        setIsModalOpen(false)
        setModalType("")
      })
  }

  const handleConfirmAddClosingSchedule = () => {
    setModalType("confirmAddClosingSchedule")
    setIsModalOpen(true)
    setShowBottomsheet(false)
  }

  // FIX BUG Pengecekan Ronda Muatparts LB-0163
  // FIX BUG Pengecekan Ronda Muatparts LB-0385
  const validateAddEditClosingSchedule = () => {
    setError("");
    if (scheduleId) {
      const filteredClosingSchedules = closingSchedules.filter(item => item.id !== scheduleId)
      if (isDateRangeOverlapping(formatDateAPI(startDate), formatDateAPI(endDate), filteredClosingSchedules)) {
        setError(t('messageClosingExists'))
        return false;
      }
    } else {
      if (isDateRangeOverlapping(formatDateAPI(startDate), formatDateAPI(endDate), closingSchedules)) {
        setError(t('messageClosingExists'))
        return false;
      }
    }
    return true
  }

  const typeMapping = [
    { key: "24h", value: t("labelOpen24") },
    { key: "closed", value: t("labelClosed") },
    { key: "custom", value: "custom" },
  ]
  const days = [
    t("labelMonday"),
    t("labelTuesday"),
    t("labelWednesday"),
    t("labelThursday"),
    t("labelFriday"),
    t("labelSaturday"),
    t("labelSunday")
  ]

  // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0162
  // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0489
  // Get today's date in YYYY-MM-DD format
  const getTodayFormatted = () => {
    const today = new Date();
    return today.toISOString().split('T')[0];
  };

  // Calculate the min date for end date (start date + 1 day)
  const getMinEndDate = () => {
    if (!startDate) return "";
    
    const nextDay = new Date(startDate);
    nextDay.setDate(nextDay.getDate());
    return nextDay.toISOString().split('T')[0]; // Format as YYYY-MM-DD
  };

  // Calculate the max date for start date (end date - 1 day)
  const getMaxStartDate = () => {
    if (!endDate) return "";
    
    const previousDay = new Date(endDate);
    previousDay.setDate(previousDay.getDate());
    return previousDay.toISOString().split('T')[0]; // Format as YYYY-MM-DD
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const day = date.getDate().toString().padStart(2, '0');
    const month = date.toLocaleString('en-US', { month: 'short' });
    const year = date.getFullYear();
    return `${day} ${month} ${year}`;
  };

  return (
    <>
      <div className="pb-36 flex flex-col gap-y-2">
        {isClosed ? (
          <div className="flex flex-row justify-between bg-primary-50 py-5 px-4 items-center">
            <div className="flex flex-row gap-x-3 items-center">
              <ImageComponent
                src={`/img/store.png`}
                alt="Store status indicator icon"
                height={42}
                width={42}
              />
              <span className="font-semibold text-[14px] leading-[15.4px]">
                {t("labelStoreIsClosed")}
              </span>
            </div>
            <Button
              Class="h-7"
              color="primary_secondary"
              onClick={() => {
                setIsModalOpen(true)
                setModalType("forceOpen")
              }}
            >
              {t("buttonOpenStore")}
            </Button>
          </div>
        ) : null}
        <section className={`flex flex-col bg-white pb-5 px-4 ${isClosed ? "pt-5" : "pt-[26px]"}`}>
          <span className="font-semibold text-[14px] leading-[15.4px]">
            {t("titleOperationalHours")}
          </span>
          {!isEmptyOperationalHours ? (
            <div className="flex flex-col gap-y-4 mt-6">
              {groupingOperationalHours.map((item, index) => {
                const isLastChild = groupingOperationalHours.length - 1 === index
                const typeValue = typeMapping.find(type => type.key === item.type).value
                return (
                  <div className={`flex justify-between ${isLastChild ? "" : "pb-4 border-b border-b-neutral-400"}`} key={index}>
                    <span className="font-semibold text-[12px] leading-[13.2px]">
                      {item.day.split("-").map(item => days[Number(item-1)]).join(" - ")}
                    </span>
                    <span className="font-semibold text-[12px] leading-[13.2px]">
                      {typeValue === "custom" ? `${[item.openTime, item.closeTime].join(" - ")} WIB` : typeValue}
                    </span>
                  </div>
                )
              })}
            </div>
          ) : (
            <div className={`mt-4 flex flex-col gap-y-3`}>
              <span className="font-medium text-[12px] leading-[14.4px] text-neutral-600">
                {t("descOperationalHoursResponsive")}
              </span>
              <div className="flex items-center gap-2.5 bg-warning-100 p-2 rounded-md">
                <ImageComponent src={`/icons/warning.svg`} width={20} height={20} alt="warning" />
                <span className="font-medium text-[12px] leading-[14.4px]">
                  {t("warningOperationalMessage")}
                </span>
              </div>
            </div>
          )}
          <Button
            onClick={()=>setScreen("atur_jam_operasional")}
            Class={`${!isEmptyOperationalHours ? "mt-4" : "mt-3"} w-full h-8 max-w-full`}
            color="primary_secondary"
          >
            {t("titleSetHours")}
          </Button>
        </section>
        <section className={`flex flex-col bg-white py-5 px-4 ${!isEmptyClosingSchedules ? "gap-y-6" : ""}`}>
          <span className="font-semibold text-[14px] leading-[15.4px]">
            {t("labelClosingDate")}
          </span>
          {!isEmptyClosingSchedules ? (
            <div className="flex flex-col gap-y-4">
              {closingSchedules.map((closingSchedule, key) => {
                const isLastChild = closingSchedules.length - 1 === key
                return (
                  <Fragment key={key}>
                    <ClosingScheduleResponsive
                      closingSchedule={closingSchedule}
                      isLastChild={isLastChild}
                      onEditClosingSchedule={handleEditClosingSchedule}
                    />
                  </Fragment>
                )
              })}
            </div>
          ) : (
            <span
              className={`font-medium text-[12px] leading-[14.4px] text-neutral-600
                ${isEmptyClosingSchedules ? "mt-4" : ""}
              `}
            >
              {t("descClosingScheduleResponsive")}
            </span>
          )}
          <Button
            onClick={()=> {
              setShowBottomsheet(true)
              setTitleBottomsheet(t("titleAddClosingDate"))
              setStartDate(null)
              setEndDate(null)
            }}
            Class={`w-full h-8 max-w-full
              ${isEmptyClosingSchedules ? "mt-3" : ""}
            `}
            color="primary_secondary"
            iconLeft="/icons/plus.svg"
          >
            {t("buttonTambah")}
          </Button>
        </section>
      </div>
      <Bottomsheet>
        <div className="flex flex-col w-full">
          <div className="flex gap-x-3 items-center">
            {/* 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0162 */}
            {/* 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0489 */}
            <div 
              className="relative w-full flex h-8 px-3 border border-neutral-600 rounded-md items-center justify-between"
              onClick={() => startDateRef.current && startDateRef.current.showPicker()}
            >
              <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-600">
                {startDate ? formatDate(startDate) : t("labelStart")}
              </span>
              <IconComponent
                src="/icons/calendar2.svg"
                width={16}
                height={16}
              />
              <input
                className="absolute -top-[305px] left-0"
                type="date"
                value={startDate || ""}
                onChange={(e) => setStartDate(e.target.value)}
                ref={startDateRef}
                max={getMaxStartDate()}
                min={getTodayFormatted()}
              />
            </div>
            <span className="font-semibold text-[12px] leading-[16.8px] text-neutral-600">
              {t("labelTo")}
            </span>
            {/* 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0162 */}
            {/* 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0489 */}
            <div 
              className="relative w-full flex h-8 px-3 border border-neutral-600 rounded-md items-center justify-between"
              onClick={() => endDateRef.current && endDateRef.current.showPicker()}
            >
              <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-600">
                {endDate ? formatDate(endDate) : t("labelEnd")}
              </span>
              <IconComponent
                src="/icons/calendar2.svg"
                width={16}
                height={16}
              />
              <input
                className="absolute -top-[305px] -left-[50px]"
                type="date"
                value={endDate || ""}
                onChange={(e) => setEndDate(e.target.value)}
                ref={endDateRef}
                min={getMinEndDate()}
              />
            </div>
          </div>
          {/* FIX BUG Pengecekan Ronda Muatparts LB-0163 */}
          {/* FIX BUG Pengecekan Ronda Muatparts LB-0385 */}
          {error ? (
            <div className="mt-3 font-medium text-[12px] leading-[13.2px] text-error-400">
              {error}
            </div>
          ) : null}
          <div className="mt-4">
            <Button
              Class={`h-10 w-full max-w-full`}
              color="primary"
              onClick={() => {
                // FIX BUG Pengecekan Ronda Muatparts LB-0163
                // FIX BUG Pengecekan Ronda Muatparts LB-0385
                if (!validateAddEditClosingSchedule()) {
                  return
                }
                if (scheduleId) {
                  handleAddEditClosingSchedule()
                } else {
                  handleConfirmAddClosingSchedule()
                }
              }}
              disabled={!startDate || !endDate}
            >
              <span className="font-semibiold text-[14px] leading-[15.4px]">{t("buttonApply")}</span>
            </Button>
          </div>
        </div>
      </Bottomsheet>
      {/* FORCE OPEN STORE MODAL */}
      {modalType === "forceOpen" ? (
        <Modal
          isOpen={isModalOpen}
          setIsOpen={setIsModalOpen}
          closeArea={false}
          closeBtn={true}
          title={t("titleReadyToOperate")}
          desc={t("descReadyToOperate")}
          action1={{
            action: () => setIsModalOpen(false),
            text: t("buttonCancel"),
            style: "outline",
            color: "#176CF7",
            customStyle: {
              width: "112px",
            },
          }}
          action2={{
            action: handleForceOpenStore,
            text: t("buttonOpenStore"),
            style: "full",
            color: "#176CF7",
            customStyle: {
              width: "115px",
              color: "#ffffff",
            },
          }}
        />
      ) : null}
      {/* KONFIRMASI TAMBAH JADWAL TUTUP MODAL */}
      {modalType === "confirmAddClosingSchedule" ? (
        <Modal
          isOpen={isModalOpen}
          setIsOpen={setIsModalOpen}
          closeArea={false}
          closeBtn={true}
          title={t("titleNotification")}
          desc={t("descNotification")}
          action1={{
            action: handleAddEditClosingSchedule,
            text: t("buttonSave"),
            style: "full",
            color: "#176CF7",
            customStyle: {
              width: "115px",
              color: "#ffffff",
            },
          }}
        />
      ) : null}
    </>
  )
}

export default ListOperational
