import Bottomsheet from "@/container/JadwalOperasional/Responsive/Bottomsheet";
import Button from "@/components/Button/Button";
import Checkbox from "@/components/Checkbox/Checkbox";
import CustomTimePicker from "@/container/JadwalOperasional/Web/CustomTimePicker";
import SWRHandler from "@/services/useSWRHook";
import toast from "@/store/zustand/toast";
import { useEffect, useState } from "react";
import { useSWRConfig } from "swr";
import ImageComponent from "@/components/ImageComponent/ImageComponent";
import jamOperasional from "@/store/zustand/jadwaloperasional/jamOperasional";
import { useTranslation } from "@/context/TranslationProvider";

const baseUrl = `${process.env.NEXT_PUBLIC_GLOBAL_API}v1/`

const AturJamOperasionalMassal = ({ setScreen }) => {
  const { t } = useTranslation();
  const [isAllDaysSelected, setIsAllDaysSelected] = useState(false);
  const [selectedDays, setSelectedDays] = useState([]);
  const [openTime, setOpenTime] = useState("");
  const [closeTime, setCloseTime] = useState("");
  const [showOpenTimePicker, setShowOpenTimePicker] = useState(false);
  const [showCloseTimePicker, setShowCloseTimePicker] = useState(false);

  const days = [
    { id: "senin", label: t("labelMonday") },
    { id: "selasa", label: t("labelTuesday") },
    { id: "rabu", label: t("labelWednesday") },
    { id: "kamis", label: t("labelThursday") },
    { id: "jumat", label: t("labelFriday") },
    { id: "sabtu", label: t("labelSaturday") },
    { id: "minggu", label: t("labelSunday") },
  ];

  const { mutate } = useSWRConfig();
  const { useSWRMutateHook } = SWRHandler;
  const {
    data: dataBulkOperationalHours,
    error: errorBulkOperationalHours,
    trigger: bulkOperationalHours,
    isMutating: mutatingBulkOperationalHours,
  } = useSWRMutateHook(
    `${baseUrl}muatparts/store/bulk_operational_hours`,
    "POST"
  );

  const {
    setDataToast,
    setShowBottomsheet,
    setShowNavMenu,
    setShowToast,
    setTitleBottomsheet,
  } = toast();
  const { operationalHours, setOperationalHours } = jamOperasional();

  useEffect(() => {
    setIsAllDaysSelected(selectedDays.length === 7 ? true : false);
  }, [JSON.stringify(selectedDays)]);

  const handleSelectAllDays = ({ checked }) => {
    if (isAllDaysSelected) {
      setSelectedDays([]);
    } else {
      setSelectedDays(days.map((day) => day.id));
    }
    setIsAllDaysSelected(checked);
  };

  const handleCheckDay = ({ value }) => {
    setSelectedDays(
      (prevState) =>
        prevState.includes(value)
          ? prevState.filter((i) => i !== value) // Remove the item if it's already selected
          : [...prevState, value] // Add the item if it's not selected
    );
  };

  const handleTimeSelect = (time, isOpenTime) => {
    if (isOpenTime) {
      setOpenTime(time);
    } else {
      setCloseTime(time);
    }
  };

  const convertDayToNumber = (day) => {
    const dayMap = {
      senin: "1",
      selasa: "2",
      rabu: "3",
      kamis: "4",
      jumat: "5",
      sabtu: "6",
      minggu: "7",
    };
    return dayMap[day] || 0;
  };

  const clearBottomsheet = () => {
    setShowBottomsheet(false);
    setTitleBottomsheet("");
    setScreen("atur_jam_operasional");
  };

  const handleSave = async () => {
    const selectedDaysArray = Array.from(selectedDays)
      .filter((day) => day !== "all") // Remove 'all' from selection if present
      .map((day) => convertDayToNumber(day)) // Convert day names to numbers
      .sort((a, b) => a - b); // Sort numerically
    const newOperationalHours = operationalHours.map(item => {
      if (selectedDaysArray.includes(item.day)) {
        return {
          day: item.day,
          openTime,
          closeTime,
          type: "custom"
        }
      }
      return item
    })
    setOperationalHours(newOperationalHours)
    clearBottomsheet();

    // await bulkOperationalHours({
    //   days: selectedDaysArray,
    //   openTime,
    //   closeTime,
    //   type: "custom",
    // })
    //   .then(() => {
    //     clearBottomsheet();
    //     mutate(
    //       `${baseUrl}muatparts/store/operational_hours`
    //     );
    //     setDataToast({
    //       type: "success",
    //       message: `Berhasil mengatur Jam Operasional`,
    //     });
    //     setShowToast(true);
    //   })
    //   .catch(() => clearBottomsheet());
  };

  return (
    <>
      <div className="pb-12 flex flex-col gap-y-2">
        <div className="py-5 px-4 bg-neutral-50 flex justify-between">
          <Checkbox
            checked={isAllDaysSelected}
            onChange={(e) => handleSelectAllDays(e)}
          >
            <span className={`font-semibold text-[14px] leading-[15.4px]`}>
              {t("labelSelectAll")}
            </span>
          </Checkbox>
          <button
            className="font-semibold text-[14px] leading-[15.4px] text-error-400"
            onClick={() => setSelectedDays([])}
          >
            {t("buttonCancel")}
          </button>
        </div>
        <div className="p-4 bg-neutral-50 flex flex-col gap-y-4">
          {days.map((day, key) => {
            const isLastChild = days.length - 1 === key;
            return (
              <div
                className={`${
                  isLastChild ? "" : "pb-4 border-b border-b-neutral-400"
                }`}
                key={key}
              >
                <Checkbox
                  checked={selectedDays.find((item) => item === day.id)}
                  onChange={(e) => handleCheckDay(e)}
                  value={day.id}
                >
                  <span
                    className={`font-semibold text-[14px] leading-[15.4px]`}
                  >
                    {day.label}
                  </span>
                </Checkbox>
              </div>
            );
          })}
        </div>
        {selectedDays.length > 0 ? (
          <div className="fixed bottom-0 left-0 bg-neutral-50 w-full py-3 px-4 shadow-muat">
            <Button
              Class="h-10 w-full max-w-full"
              color="primary"
              onClick={() => {
                setTitleBottomsheet(t("titleSetHours"));
                setShowBottomsheet(true);
                setOpenTime(null);
                setCloseTime(null);
              }}
            >
              {`${t("labelSet")} ${selectedDays.length} ${t("labelAllDays")}`}
            </Button>
          </div>
        ) : null}
      </div>
      <Bottomsheet>
        <div className="flex flex-col gap-y-4 w-full">
          <div className="flex gap-x-3 items-center">
            <div className="relative w-full">
              <button
                onClick={() => setShowOpenTimePicker(true)}
                className={`w-full min-w-[141.5px] h-[32px] px-3 rounded-lg text-[12px] leading-[14.4px] font-medium text-left flex items-center justify-between border border-[#7B7B7B] bg-[#FFFFFF]`}
              >
                <span className={openTime ? "text-black" : "text-[#7B7B7B]"}>
                  {openTime || t("labelOpeningHours")}
                </span>
                <ImageComponent
                  alt="clock"
                  height={16}
                  width={16}
                  src={`/icons/clock.svg`}
                />
              </button>
              <CustomTimePicker
                isOpen={showOpenTimePicker}
                onClose={() => setShowOpenTimePicker(false)}
                onSelect={(time) => handleTimeSelect(time, true)}
                selectedTime={openTime}
                maxTime={closeTime}
              />
            </div>
            <span className="font-semibold text-[12px] leading-[16.8px] text-neutral-600">
              {t("labelTo")}
            </span>
            <div className="relative w-full">
              <button
                onClick={() => setShowCloseTimePicker(true)}
                className={`w-full min-w-[141.5px] h-[32px] px-3 rounded-lg text-[12px] leading-[14.4px] font-medium text-left flex items-center justify-between border border-[#7B7B7B] bg-[#FFFFFF]`}
              >
                <span className={closeTime ? "text-black" : "text-[#7B7B7B]"}>
                  {closeTime || t("labelClosingHours")}
                </span>
                <ImageComponent
                  alt="clock"
                  height={16}
                  width={16}
                  src={`/icons/clock.svg`}
                />
              </button>
              <CustomTimePicker
                isOpen={showCloseTimePicker}
                onClose={() => setShowCloseTimePicker(false)}
                onSelect={(time) => handleTimeSelect(time, false)}
                selectedTime={closeTime}
                minTime={openTime}
              />
            </div>
          </div>
          <Button
            Class={`h-10 w-full max-w-full`}
            color="primary"
            disabled={!openTime || !closeTime}
            onClick={handleSave}
          >
            <span className="font-semibiold text-[14px] leading-[15.4px]">
              {t("buttonApply")}
            </span>
          </Button>
        </div>
      </Bottomsheet>
    </>
  );
};

export default AturJamOperasionalMassal;
