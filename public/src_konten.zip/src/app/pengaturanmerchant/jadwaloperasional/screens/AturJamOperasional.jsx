import React, { Fragment } from "react";
import DaySchedule from "@/container/JadwalOperasional/Responsive/DaySchedule";
import Button from "@/components/Button/Button";
import { useSWRConfig } from "swr";
import SWRHandler from "@/services/useSWRHook";
import toast from "@/store/zustand/toast";
import jamOperasional from "@/store/zustand/jadwaloperasional/jamOperasional";
import { useTranslation } from "@/context/TranslationProvider";

const baseUrl = `${process.env.NEXT_PUBLIC_GLOBAL_API}v1/`

function AturJamOperasional({ setScreen }) {
  const { setShowToast, setDataToast, setShowNavMenu } = toast();
  const { operationalHours, updateOperationalHourByDay } = jamOperasional();

  const { mutate } = useSWRConfig();
  const { useSWRMutateHook } = SWRHandler;
  const { trigger: saveOperationalHours } = useSWRMutateHook(
    `${baseUrl}muatparts/store/operational_hours`,
    "POST"
  );

  const { t } = useTranslation();

  const handleOptionChange = (day, value) => {
    updateOperationalHourByDay({ day, type: value, openTime: null, closeTime: null })
  };

  // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0164
  const validateOperationalHours = () => {
    let validOpenTime = true;
    let validCloseTime = true;
    
    for (let i = 0; i < operationalHours.length; i++) {
      const item = operationalHours[i];
      
      if (item.type !== "custom") {
        continue;
      }
      
      if (!item.openTime) {
        validOpenTime = false;
        setDataToast({
          type: "error",
          message: t("messageOpeningHoursValidationResponsive"),
        });
        setShowToast(true);
        break; // Stop the loop once we find an invalid openTime
      }
      
      if (!item.closeTime) {
        validCloseTime = false;
        setDataToast({
          type: "error",
          message: t("messageClosingHoursValidationResponsive"),
        });
        setShowToast(true);
        break; // Stop the loop once we find an invalid closeTime
      }
    }
    return validOpenTime && validCloseTime;
  }

  const handleSave = async () => {
    // Implement save logic here
    await saveOperationalHours({ data: operationalHours })
      .then(() => {
        setScreen("home");
        mutate(
          `${baseUrl}muatparts/store/operational_hours`
        );
        setDataToast({
          type: "success",
          message: t('titleSuccessSchedule'),
        });
        setShowToast(true);
        setShowNavMenu(true);
      })
      .catch(() => {
        setScreen("home");
        setShowNavMenu(true);
      });
  };

  return (
    <div className="pb-28">
      <div
        onClick={() => setScreen("atur_jam_operasional_massal")}
        className="py-5 px-4 w-full text-primary-700 text-sm font-semibold bg-white"
      >
        <span className="cursor-pointer">
          {t("buttonSetInBulk")}
        </span>
      </div>
      <div className="flex flex-col gap-4 p-4 bg-white mt-2">
        {operationalHours.map((operationalHour, key) => (
          <Fragment key={key}>
            <DaySchedule
              operationalHour={operationalHour}
              onOptionChange={handleOptionChange}
            />
          </Fragment>
        ))}
      </div>
      <div className="fixed bottom-0 left-0 bg-neutral-50 w-full py-3 px-4 shadow-muat">
        <Button
          Class="h-10 w-full max-w-full"
          color="primary"
          onClick={() => {
            // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0164
            if (!validateOperationalHours()) {
              return;
            }
            handleSave();
          }}
        >
          { t('buttonSave')}
        </Button>
      </div>
    </div>
  );
}

export default AturJamOperasional;
