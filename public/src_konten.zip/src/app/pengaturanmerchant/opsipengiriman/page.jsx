import OpsiPengiriman from "./OpsiPengiriman";

function Page() {
  return (
    <div className='w-full'>
      <OpsiPengiriman />
    </div>
  );
}

export default Page;
