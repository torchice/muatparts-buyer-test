    "use client"

import viewport from '@/store/zustand/common'
import OpsiPengirimanWeb from "./OpsiPengirimanWeb";
import SWRHandler from "@/services/useSWRHook";
import { mutate } from "swr";
import OpsiPengirimanResponsive from "./OpsiPengirimanResponsive";
import { useMemo } from 'react';
import toast from '@/store/zustand/toast';
import Toast from '@/components/Toast/Toast';
import { useTranslation } from "@/context/TranslationProvider";

const baseUrl = `${process.env.NEXT_PUBLIC_GLOBAL_API}v1/`

const OpsiPengiriman = () => {
    const { t } = useTranslation();
    const { setShowToast, setDataToast } = toast();
    const { useSWRHook, useSWRMutateHook } = SWRHandler;
    const { data: shippingOptionData } = useSWRHook(`${baseUrl}muatparts/shipping_option`);

    const { trigger: setPickup } = useSWRMutateHook(
        `${baseUrl}muatparts/shipping_option/pickup`,
        "POST"
    );

    const { trigger: toogleGroupExpedition } = useSWRMutateHook(
        `${baseUrl}muatparts/shipping_option/expedition/group/status`,
        "POST"
    );

    const { trigger: toogleItemExpedition } = useSWRMutateHook(
        `${baseUrl}muatparts/shipping_option/expedition/status`,
        "POST"
    );

    const fullAddress = shippingOptionData?.Data.store_address.full_address
    const pickupOption = shippingOptionData?.Data.pickup_option
    const storeCourier = shippingOptionData?.Data.store_courier
    const shippingGroups = shippingOptionData?.Data.shipping_groups || []

    const shippingCount = useMemo(() => {
        let count = 0
        if (pickupOption?.is_active) {
            count += 1
        }
        // UNTUK SEMENTARA DI COMMENT
        // if (storeCourier?.total_provinces > 0) {
        //     count += storeCourier?.total_provinces
        // }
        shippingGroups.forEach(item => count += item.active_couriers)
        return count
    }, [JSON.stringify(pickupOption), JSON.stringify(storeCourier), JSON.stringify(shippingGroups)])

    const validateToogleShipping = (value) => {
        if (value >= shippingCount) {
            setDataToast({
                type: "error",
                message: t("messageMinShippingValidation"),
            });
            setShowToast(true);
            handleRefresh()
            return false
        }
        return true
    }

    const handleToogleAmbilLangsung = async() => {
        const data = { is_active: !pickupOption?.is_active }
        await setPickup(data)
            .then(() => {
                handleRefresh()
        })
    }

    const handleRefresh = () => {
        mutate(`${baseUrl}muatparts/shipping_option`)
    }

    const { isMobile } = viewport();

    const sharedProps = {
        // swr
        toogleGroupExpedition,
        toogleItemExpedition,
        // func
        handleToogleAmbilLangsung,
        handleRefresh,
        validateToogleShipping,
        // data
        fullAddress,
        pickupOption,
        storeCourier,
        shippingGroups
    }

    if (typeof isMobile !== "boolean") return null;

    return (
        <>
            {isMobile ? (
                <OpsiPengirimanResponsive
                    {...sharedProps}
                />
            ) : (
                <OpsiPengirimanWeb
                    {...sharedProps}
                />
            )}
            <Toast/>
        </>
    );
}

export default OpsiPengiriman