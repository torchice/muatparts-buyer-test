import IconComponent from "@/components/IconComponent/IconComponent";
import AddressCard from "@/container/OpsiPengiriman/Responsive/AddressCard";
import AmbilLangsungCard from "@/container/OpsiPengiriman/Responsive/AmbilLangsungCard";
import ExpedisiCard from "@/container/OpsiPengiriman/Responsive/ExpedisiCard";
import KurirTokoCard from "@/container/OpsiPengiriman/Responsive/KurirTokoCard";
import headerZustand from "@/store/zustand/header";
import { Fragment, useEffect } from "react";
import styles from "./OpsiPengirimanResponsive.module.scss"
import toast from "@/store/zustand/toast";
import Bottomsheet from "@/components/Bottomsheet/Bottomsheet";
import { useTranslation } from "@/context/TranslationProvider";

const OpsiPengirimaResponsive = ({
    // swr
    setPickup,
    toogleGroupExpedition,
    toogleItemExpedition,
    // func
    handleToogleAmbilLangsung,
    handleRefresh,
    validateToogleShipping,
    // data
    fullAddress,
    pickupOption,
    storeCourier,
    shippingGroups
}) => {
    const {
        setShowBottomsheet,
        setTitleBottomsheet,
        setDataBottomsheet,
        setShowNavMenu,
        setDataNavMenu
    } = toast();
    const { setTitle } = headerZustand();
    const { t } = useTranslation();
    const title = t("titleShippingOptions")
    const description = t('descShippingOptions')

    // LBM - OLIVER - CENTRALISASI TAMPILAN NAVBAR MOBILE - MP - 028
    useEffect(() => {
        setShowNavMenu(true)
        setDataNavMenu({
            title: "Home",
            action: "/dashboard",
            type: 2
        })
    }, [])

    useEffect(() => {
        setTitle(
            <div className="flex gap-x-2 items-center">
                <span className="font-bold text-[16px] leading-[19.2px] normal-case">{title}</span>
                <button
                    className="z-[51]"
                    onClick={() => {
                        setShowBottomsheet(true)
                        setTitleBottomsheet(title)
                        setDataBottomsheet(
                            <span className="font-medium text-[14px] leading-[15.4px]">
                                {description}
                            </span>
                        )
                    }}
                >
                    <IconComponent
                        classname={styles.icon_info}
                        src="/icons/Info.svg"
                    />
                </button>
            </div>
        )
    }, [description, title])

    return (
        <>
            <div className="flex flex-col gap-y-2 mt-[6px] pb-[140px]">
                <AddressCard fullAddress={fullAddress}/>
                <AmbilLangsungCard
                    onToogleAmbilLangsung={handleToogleAmbilLangsung}
                    pickupOption={pickupOption}
                    validateToogleShipping={validateToogleShipping}
                />
                <KurirTokoCard {...storeCourier}/>
                {shippingGroups.map((shippingGroup, key) => {
                    if (shippingGroup.couriers.length === 0) {
                        return null
                    }
                    return (
                        <Fragment key={key}>
                            <ExpedisiCard
                                {...shippingGroup}
                                onRefresh={handleRefresh}
                                toogleGroupExpedition={toogleGroupExpedition}
                                toogleItemExpedition={toogleItemExpedition}
                                validateToogleShipping={validateToogleShipping}
                            />
                        </Fragment>
                    )
                })}
            </div>
            <Bottomsheet/>
        </>
    )
}

export default OpsiPengirimaResponsive;