import KurirToko from "./KurirToko";

function Page() {
  return (
    <div className='w-full'>
      <KurirToko />
    </div>
  );
}

export default Page;
