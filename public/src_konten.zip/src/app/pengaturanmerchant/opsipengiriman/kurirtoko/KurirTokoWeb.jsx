
import BreadCrumb from "@/components/BreadCrumb/BreadCrumb";
import Button from "@/components/Button/Button";
import IconComponent from "@/components/IconComponent/IconComponent";
import Modal from "@/components/Modals/modal";
import ShippingArea from "@/container/OpsiPengiriman/Web/KurirToko/ShippingArea";
import { CustomTooltip } from "@/container/Register/InformasiPendaftarDanRekening";
import { useTranslation } from "@/context/TranslationProvider";
import { useCustomRouter } from "@/libs/CustomRoute";
import kurirTokoZustand from "@/store/zustand/kurirToko";
import { useState } from "react";

const KurirTokoWeb = ({
    addCourierProvince,
    handleSave: onSave,
    handleRefresh,
    validateFormData,
    provinceIds,
    // isDirty,
    // setIsDirty
}) => {
    const { isDirty } = kurirTokoZustand();
    const router = useCustomRouter();
    const [isModalOpen, setIsModalOpen] = useState(false)
    const [modalType, setModalType] = useState("")
    const { t } = useTranslation();
    
    const breadcrumbData = [t("labelDashboard"), t('titleShippingOptions'), t("labelSetStoreCourier")]

    const handleConfirmExitPage = () => {
        if (!isDirty) {
            return router.push("/pengaturanmerchant/opsipengiriman")
        }
        setIsModalOpen(true)
        setModalType("backConfirmation")
    }

    const handleClickBreadCrumb = (value) => {
        if (value === "Dashboard") {
            router.push("/dashboard")
        }
        if (value === "Opsi Pengiriman") {
            handleConfirmExitPage()
        }
    }

    return (
        <>
            <div className="flex flex-col gap-y-4 ml-2 pb-[72px] min-h-[calc(100vh_-_100px)]">
                <BreadCrumb data={breadcrumbData} onclick={handleClickBreadCrumb} maxWidth="92px" />
                <div className="flex gap-x-3 items-center">
                    <IconComponent
                        src="/icons/arrowbackblue.svg"
                        size="medium"
                        onclick={handleConfirmExitPage}
                    />
                    <span className="font-bold text-[20px] leading-[24px] text-neutral-900">{t("labelSetStoreCourier")}</span>
                    <CustomTooltip
                        content={<span className="leading-[16.8px]">{t("tooltipStoreCourier")}</span>}
                    >
                        <IconComponent
                            src="/icons/Info.svg"
                        />
                    </CustomTooltip>
                </div>
                <ShippingArea
                    addCourierProvince={addCourierProvince}
                    onRefresh={handleRefresh}
                    provinceIds={provinceIds}
                    // setIsDirty={setIsDirty}
                />
                {/* <div className="absolute z-[50] bg-neutral-50 w-full left-0 bottom-0 py-5 px-12 flex justify-end"></div> */}
                <div className="fixed bg-neutral-50 w-[calc(100%_-_240px)] bottom-0 py-5 px-12 flex justify-end">
                    <Button
                        Class="px-[31.5px] h-8 flex items-center !font-semibold text-[14px] leading-[16.8px]"
                        onClick={() => {
                            if (validateFormData()) {
                                setIsModalOpen(true)
                                setModalType("saveConfirmation")
                            }
                        }}
                    >
                        {t('buttonSave')}
                    </Button>
                </div>
            </div>
            {modalType === "saveConfirmation" ? (
                <Modal
                    isOpen={isModalOpen}
                    setIsOpen={setIsModalOpen}
                    closeArea={false}
                    closeBtn={true}
                    desc={t("descConfirmationSaveData")}
                    action1={{
                        action: () => setIsModalOpen(false),
                        // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0703
                        text: t('buttonNo'),
                        style: "outline",
                        color: "#176CF7",
                            customStyle: {
                                width: "112px",
                        },
                    }}
                    action2={{
                        action: onSave,
                        text: t('buttonYes'),
                        style: "full",
                        color: "#176CF7",
                        customStyle: {
                            width: "112px",
                            color: "#ffffff",
                        },
                    }}
                />
            ) : null}
            {modalType === "backConfirmation" ? (
                <Modal
                    isOpen={isModalOpen}
                    setIsOpen={setIsModalOpen}
                    closeArea={false}
                    closeBtn={true}
                    desc={<div className="w-[338px]">{t("descExitSetCourierStore")}</div>}
                    action1={{
                        action: () => setIsModalOpen(false),
                        text: t('buttonNo'),
                        style: "outline",
                        color: "#176CF7",
                            customStyle: {
                                width: "112px",
                        },
                    }}
                    action2={{
                        action: () => {
                            router.push("/pengaturanmerchant/opsipengiriman")
                        },
                        text: t('buttonYes'),
                        style: "full",
                        color: "#176CF7",
                        customStyle: {
                            width: "112px",
                            color: "#ffffff",
                        },
                    }}
                />
            ) : null}
        </>
    )
}

export default KurirTokoWeb