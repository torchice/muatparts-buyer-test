"use client"

import viewport from '@/store/zustand/common'
import KurirTokoWeb from "./KurirTokoWeb";
import SWRHandler from "@/services/useSWRHook";
import { useEffect, useRef, /*useState*/ } from "react";
import toast from "@/store/zustand/toast";
import KurirTokoResponsive from "./KurirTokoResponsive";
import Toast from '@/components/Toast/Toast';
import { useCustomRouter } from '@/libs/CustomRoute';
import kurirTokoZustand from '@/store/zustand/kurirToko';
import { useTranslation } from '@/context/TranslationProvider';
import { useSWRConfig } from 'swr'

const baseUrl = process.env.NEXT_PUBLIC_GLOBAL_API

const KurirToko = () => {
    // const [isDirty, setIsDirty] = useState(false)
    const firstTimeRef = useRef(true)
    const { t } = useTranslation();
    const { cache } = useSWRConfig();

    const router = useCustomRouter();
    const { isMobile } = viewport();
    const { setShowToast, setDataToast, setShowNavMenu } = toast();
    const { hiddenProvinceIds, formData, setFormData, tempData, setTempData, resetStore } = kurirTokoZustand();

    const { useSWRHook, useSWRMutateHook } = SWRHandler;
    const { data: courierStoreData, mutate: mutateCourierStore, isValidating: isValidatingCourierStore } = useSWRHook(
        `${baseUrl}v1/muatparts/shipping_option/courier_store?first_time=${firstTimeRef.current}`
    );

    const { trigger: addCourierProvince } = useSWRMutateHook(`${baseUrl}v1/muatparts/shipping_option/courier_store/province`, "POST");
    // const { trigger: deleteProvince } = useSWRMutateHook(`${baseUrl}v1/muatparts/shipping_option/courier_store/province`, "DELETE");
    const { trigger: addCourierCostCities } = useSWRMutateHook(`${baseUrl}v1/muatparts/shipping_option/courier_store/cost`, "POST");

    const address = courierStoreData?.Data.address
    const lists = courierStoreData?.Data.lists || []
    const provinceIds = courierStoreData?.Data.provinces.map(item => item.provinceID)

    // FIX BUG Opsi Pengiriman LB-0022
    const tempDataRef = useRef(tempData);
    const formDataRef = useRef(formData);

    useEffect(() => {
        tempDataRef.current = tempData;
        formDataRef.current = formData;
    }, [tempData, formData]);

    useEffect(() => {
        if (!isValidatingCourierStore) {
            const firstTime = firstTimeRef.current
            const initialFormData = lists.map(province => {
                if (!firstTime) {
                    const tempData = tempDataRef.current
                    const tempProvinceData = tempData.find(tempProvince => tempProvince.provinceID === province.provinceID)
                    if (tempProvinceData) {
                        return tempProvinceData
                    }
                }
                return {
                    ...province,
                    cities: province.cities.map(city => {
                        const price = city.price === 0 ? "" : parseFloat(city.price).toLocaleString().replace(/,/g, ".")
                        return {
                            ...city,
                            price
                        }
                    })
                }
            })
            setFormData(initialFormData)
            if (firstTime) {
                firstTimeRef.current = false;
                setTempData(initialFormData)
            }
        }
    }, [JSON.stringify(lists), isValidatingCourierStore])

    useEffect(() => {
        return () => {
            // FIX BUG Opsi Pengiriman LB-0022
            cache.delete(`${baseUrl}v1/muatparts/shipping_option/courier_store?first_time=true`)
            cache.delete(`${baseUrl}v1/muatparts/shipping_option/courier_store?first_time=false`)
            resetStore();
        };
    }, []);
    // FIX BUG Opsi Pengiriman LB-0022

    const validateFormData = () => {
        const hasCityWithEmptyPrice = formData
            .filter(province => !hiddenProvinceIds.includes(province.provinceID))
            .some(item => item.cities.some(city => city.isActive && !city.price && city.price !== 0))
        if (!isMobile && hasCityWithEmptyPrice) {
            setShowToast(true)
            setDataToast({
                type: "error",
                message: t("messageEmptyFields"),
            });
            setFormData(formData.map(item => ({
                ...item,
                cities: item.cities.map(city => ({ ...city, status: city.isActive && !city.price && city.price !== 0 ? "error" : "" }))
            })))
            return false;
        }
        const hasProvinceWithNoActiveCity = formData
            .filter(province => !hiddenProvinceIds.includes(province.provinceID))
            .some(item => !item.cities.some(city => city.isActive))
        setFormData(formData.map(item => {
            const hasNoConfiguredCity = !item.cities.some(city => city.isActive)
            return {
                ...item,
                hasNoConfiguredCity,
                cities: item.cities.map(city => ({ ...city, status: city.isActive && !city.price && city.price !== 0 ? "error" : "" }))
            }
        }))
        if (hasProvinceWithNoActiveCity) {
            if (!isMobile) {
                setShowToast(true)
                setDataToast({
                    type: "error",
                    message: t("messageEmptyCostValidation"),
                });   
            }
            return false;
        }
        return true;
    }
      
    const handleSave = async() => {
        await addCourierCostCities({
            lists: formData
                .filter(province => !hiddenProvinceIds.includes(province.provinceID))
                .map(province => ({ id: province.id, cities: province.cities.filter(city => city.isActive).map(city => ({ cityID: city.cityID, price: Number(city.price.replace(/\./g, "")) }))}))
        })
        .then(() => {
            setShowToast(true)
            setDataToast({
                type: "success",
                message: "Berhasil menyimpan data",
            });
            if (isMobile) {
                setShowNavMenu(true)
            }
            mutateCourierStore();
            router.push("/pengaturanmerchant/opsipengiriman")
        })
        .catch(() => {
            if (!navigator.onLine) {
                setShowToast(true)
                setDataToast({
                    type: "error",
                    message: "Koneksi internet Anda terputus. Mohon ulangi kembali.",
                });
            }
        })
    }

    const handleRefresh = () => mutateCourierStore()

    const sharedProps = {
        // useSWRMutateHook
        addCourierProvince,
        handleSave,
        handleRefresh,
        address,
        // count,
        provinceIds,
        // lists,
        // formData,
        // setFormData,
        // isDirty,
        // setIsDirty,
        validateFormData
    }

    if (typeof isMobile !== "boolean") return null;

    return (
        <>
            {isMobile ? (
                <KurirTokoResponsive
                    {...sharedProps}
                />
            ) : (
                <KurirTokoWeb
                    {...sharedProps}
                />
            )}
            <Toast/>
        </>
    );
}

export  default KurirToko