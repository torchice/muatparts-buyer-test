import Button from "@/components/Button/Button"
import Checkbox from "@/components/Checkbox/Checkbox"
import IconComponent from "@/components/IconComponent/IconComponent"
import Input from "@/components/Input/Input"
import DataNotFound from "@/container/OpsiPengiriman/DataNotFound"
import { useTranslation } from "@/context/TranslationProvider"
import SWRHandler from "@/services/useSWRHook"
import kurirTokoZustand from "@/store/zustand/kurirToko"
import { addArraysUnique, getElementsNotInSecondArray } from "@/utils/array"
import { useEffect, useMemo, useState } from "react"

const baseUrl = process.env.NEXT_PUBLIC_GLOBAL_API

const PilihProvinsi = ({
    addCourierProvince,
    onRefresh,
    onBack,
    selectedProvinces,
    setSelectedProvinces,
    provinceIds
}) => {
    const { t }= useTranslation();
    // FIX BUG Opsi Pengiriman LB-0019
    const { formData, hiddenProvinceIds, setHiddenProvinceIds } = kurirTokoZustand();
    const [search, setSearch] = useState("")
    const [isAllChecked, setIsAllChecked] = useState(false)

    const { useSWRHook } = SWRHandler;
    const { data: provinceGroupData } = useSWRHook(`${baseUrl}v1/province_group`);

    const provinces = Object.entries(provinceGroupData?.Data || {}).map(([key, value]) => ({ key, value }))
    const allProvinceIds = useMemo(() => provinces.reduce((arr, item) => [...arr, ...item.value.map(item => item.ProvinceID)], [], [provinces]))
    const nonHiddenProvinces = formData.filter(province => !hiddenProvinceIds.includes(province.provinceID))
    const count = nonHiddenProvinces.length

    const filteredProvinces = useMemo(() => {
        if (search) {
            return provinces.reduce((arr, item) => {
                const value = item.value.filter(item => item.Province.toLowerCase().includes(search.toLowerCase()))
                if (value.length > 0) {
                    return [...arr, { ...item, value }]
                }
                return arr
            }, [])
        }
        return provinces
    }, [JSON.stringify(provinces), search])

    useEffect(() => {
        if (allProvinceIds.length > 0) {
            const sortedAllProvinceIds = allProvinceIds.sort((a, b) => b - a)
            const sortedSelectedProvinces = selectedProvinces.sort((a, b) => b - a)
            const isAllChecked = JSON.stringify(sortedAllProvinceIds) === JSON.stringify(sortedSelectedProvinces)
            setIsAllChecked(isAllChecked)
        }
    }, [JSON.stringify(allProvinceIds), JSON.stringify(selectedProvinces)])

    const handleSave = async () => {
        const newHiddenProvinceIds = getElementsNotInSecondArray(provinceIds, selectedProvinces)
        setHiddenProvinceIds(newHiddenProvinceIds)
        await addCourierProvince({ provinceID: addArraysUnique(selectedProvinces, provinceIds) })
            .then(() => {
                onRefresh()
                onBack()
            })
            .catch(() => {
                onBack()
            })
    }

    const handleToogleCheckAll = (checked) => {
        if (checked) {
            setSelectedProvinces(allProvinceIds)
        } else {
            setSelectedProvinces([])
        }
        setIsAllChecked(checked)
    }

    return (
        <div className="py-5 px-4 flex flex-col gap-y-5 bg-neutral-50 min-h-[calc(100vh_-_88px)] pb-[124px]">
            <Input
                classname={`w-full`}
                placeholder={t("labelSearchProvince")}
                icon={{
                    left: (
                        <IconComponent src={"/icons/search.svg"} />
                    ),
                    right: search ? (
                        <IconComponent
                            src={"/icons/silang.svg"}
                            onclick={() => {
                                setSearch("")
                            }}
                        />
                    ) : null,
                }}
                value={search}
                changeEvent={(e) => setSearch(e.target.value)}
            />
            {filteredProvinces.length > 0 ? (
                <>
                    <div className="pb-3 border-b border-b-neutral-800 flex justify-between items-center">
                        <span className="font-semibold text-[16px] leading-[17.6px]">
                            {t("checkboxSelectAll")}
                        </span>
                        <Checkbox
                            classname="!gap-0"
                            disabled={count > 0}
                            label=""
                            checked={isAllChecked}
                            onChange={(e) => handleToogleCheckAll(e.checked)}
                        />
                    </div>
                    <div className="flex flex-col gap-y-[18px]">
                        {filteredProvinces.map((item, key) => (
                            <div className="flex flex-col gap-y-3" key={key}>
                                <span className="font-bold text-[18px] leading-[21.6px]">{item.key}</span>
                                <div className="flex flex-col gap-y-4">
                                    {item.value.map((province, key) => {
                                        const isLastChild = item.value.length - 1 === key
                                        const isChecked = selectedProvinces.includes(province.ProvinceID)
                                        return (
                                            <div
                                                className={`${isLastChild ? "" : "border-b border-b-neutral-400 pb-4"}
                                                    flex justify-between items-center
                                                `}
                                            >
                                                <span className="font-bold text-[16px] leading-[19.2px] text-neutral-600">
                                                    {province.Province}
                                                </span>
                                                <Checkbox
                                                    classname="!gap-0"
                                                    label=""
                                                    checked={isChecked}
                                                    onChange={(e) => setSelectedProvinces(prevState => {
                                                        if (!e.checked) {
                                                          return prevState.filter(provinceId => provinceId !== province.ProvinceID)
                                                        } 
                                                        return [...prevState, province.ProvinceID]
                                                    })}
                                                />
                                            </div>
                                        )
                                    })}
                                </div>
                            </div>
                        ))}
                    </div>
                </>
            ) : (
                <div className="min-h-[calc(100vh_-_232px)] flex">
                    <DataNotFound
                        classname="gap-y-3 m-auto"
                        textClass="max-w-[111px] font-semibold text-[14px] leading-[16.8px]"
                        title={t("labelKeywordNotFound")}
                    />
                </div>
            )}
            <div className="fixed bottom-0 left-0 bg-neutral-50 w-full py-3 px-4 shadow-muat gap-x-2 flex">
                <Button
                    Class="h-10 w-full max-w-full !font-semibold flex items-center"
                    color="primary_secondary"
                    onClick={onBack}
                >
                    {t("buttonCancel")}
                </Button>
                <Button
                    Class="h-10 w-full max-w-full !font-semibold flex items-center"
                    onClick={handleSave}
                >
                    {t("buttonSave")}
                </Button>
            </div>
        </div>
    )
}

export default PilihProvinsi