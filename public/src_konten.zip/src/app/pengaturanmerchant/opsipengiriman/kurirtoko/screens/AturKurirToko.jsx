import Button from "@/components/Button/Button"
import Modal from "@/components/Modals/modal"
import AddressCard from "@/container/OpsiPengiriman/Responsive/AddressCard"
import AreaPengirimanCard from "@/container/OpsiPengiriman/Responsive/KurirToko/AreaPengirimanCard"
import CariProvinsiCard from "@/container/OpsiPengiriman/Responsive/KurirToko/CariProvinsiCard"
import ProvinceCard from "@/container/OpsiPengiriman/Responsive/KurirToko/ProvinceCard"
import { useTranslation } from "@/context/TranslationProvider"
import kurirTokoZustand from "@/store/zustand/kurirToko"
import { Fragment, useMemo, useState } from "react"

const AturKurirToko = ({
    validateFormData,
    address,
    // count,
    // formData,
    // lists,
    onRefresh,
    onSave,
    setScreen,
    onOpenAturBiayaPengiriman
}) => {
    const { t } = useTranslation();
    const { formData, hiddenProvinceIds } = kurirTokoZustand();
    const [search, setSearch] = useState("")
    const [isModalOpen, setIsModalOpen] = useState(false)
    console.log("form",formData)
    const filteredFormData = useMemo(() => {
        if (search === "") {
            return formData.filter(province => !hiddenProvinceIds.includes(province.provinceID))
        }
        return formData
            .filter(province => !hiddenProvinceIds.includes(province.provinceID))
            .filter(item => item.provinceName.toLowerCase().includes(search.toLowerCase()))
    }, [JSON.stringify(formData), search, JSON.stringify(hiddenProvinceIds)])
    const count = formData.filter(province => !hiddenProvinceIds.includes(province.provinceID)).length

    return (
        <>
            <div className="flex flex-col gap-y-2 pb-[100px]">
                <AddressCard fullAddress={address}/>
                <AreaPengirimanCard setScreen={setScreen}/>
                {count > 0 ? (
                    <>
                    {formData.filter(province => !hiddenProvinceIds.includes(province.provinceID)).length > 0 ? (
                        <CariProvinsiCard
                            search={search}
                            setSearch={setSearch}
                        />
                    ) : null}
                    {filteredFormData.map((province, key) => (
                        <Fragment key={key}>
                            <ProvinceCard {...province} onRefresh={onRefresh} onOpenAturBiayaPengiriman={onOpenAturBiayaPengiriman}/>
                        </Fragment>
                    ))}
                    </>
                ) : null}
                <div className="fixed bottom-0 left-0 py-3 px-4 bg-neutral-50 w-full">
                    <Button
                        Class="!max-w-full w-full h-10 !font-semibold flex items-center"
                        onClick={() => {
                            if (validateFormData()) {
                                setIsModalOpen(true)
                                // setModalType("saveConfirmation")
                            }
                        }}
                    >
                        {t("buttonSave")}
                    </Button>
                </div>
            </div>
            <Modal
                isOpen={isModalOpen}
                setIsOpen={setIsModalOpen}
                closeArea={false}
                closeBtn={true}
                title={t("titleConfirmationSaveData")}
                desc={t("descConfirmationSaveData")}
                action1={{
                    action: () => setIsModalOpen(false),
                    text: t("buttonNo"),
                    style: "outline",
                    color: "#176CF7",
                        customStyle: {
                            width: "112px",
                    },
                }}
                action2={{
                    action: onSave,
                    text: t("buttonYes"),
                    style: "full",
                    color: "#176CF7",
                    customStyle: {
                        width: "112px",
                        color: "#ffffff",
                    },
                }}
            />
        </>
    )
}

export default AturKurirToko