import Input from "@/components/Input/Input"
import Card from "@/container/OpsiPengiriman/Responsive/Card"
import styles from "./AturBiayaPengiriman.module.scss"
import { useEffect, useMemo, useState } from "react"
import Button from "@/components/Button/Button"
import Checkbox from "@/components/Checkbox/Checkbox"
import DataNotFound from "@/container/OpsiPengiriman/DataNotFound"
import { handleInput } from "@/libs/NumberFormat"
import { useTranslation } from "@/context/TranslationProvider"

const AturBiayaPengiriman = ({
    search,
    tempProvince,
    setTempProvince,
    onApplyBiayaPengiriman
}) => {
    const [allCitiesCost, setAllCitiesCost] = useState("")
    const [isAllChecked, setIsAllChecked] = useState(false)
    const { t }= useTranslation();

    const filteredProvince = useMemo(() => {
        if (search === "") {
            return tempProvince
        }
        return {
            ...tempProvince,
            cities: tempProvince.cities.filter(city => city.cityName.toLowerCase().includes(search.toLowerCase()))
        }
    }, [JSON.stringify(tempProvince), search])

    useEffect(() => {
        const isAllCitiesSelected = !tempProvince.cities.some(item => !item.isActive)
        setIsAllChecked(isAllCitiesSelected)
    }, [JSON.stringify(tempProvince.cities)])

    const handleApplyToAllCities = () => {
        setTempProvince(prevState => ({
            ...prevState,
            cities: prevState.cities.map(city => city.isActive ? { ...city, price: allCitiesCost } : city)
        }))
        setAllCitiesCost("")
    }

    const handleToogleCheckAll = (checked) => {
        setTempProvince(prevState => ({
            ...prevState,
            cities: prevState.cities.map(city => ({ ...city, price: checked ? city.price : "", isActive: checked }))
        }))
    }

    const handleChangeCheckbox = (checked, cityID) => {
        setTempProvince(prevState => ({
            ...prevState,
            cities: prevState.cities.map(city => city.cityID === cityID ? { ...city, isActive: checked, price: "" } : city)
        }))
    }

    const handleChangeInput = (value, cityID) => {
        setTempProvince(prevState => ({
            ...prevState,
            cities: prevState.cities.map(city => city.cityID === cityID ? { ...city, price: value } : city)
        }))
    }

    if (filteredProvince.cities.length === 0) {
        return (
            <div className="min-h-[calc(100vh_-_98px)] flex">
                <DataNotFound
                    classname="gap-y-3.5 m-auto"
                >
                    <div className="flex flex-col max-w-[128px] text-center text-neutral-600 font-semibold text-[14px] leading-[16.8px]">
                        <span>{t("labelKeyword")}</span>
                        <span>{t("labelNotFound")}</span>
                    </div>
                </DataNotFound>
            </div>
        )
    }

    return (
        <div className="flex flex-col gap-y-2 pb-[100px]">
            <Card>
                <div className="py-4 px-2 flex flex-col gap-y-3 bg-primary-50 rounded-md">
                    <span className="font-semibold text-[12px] leading-[13.2px]">
                        {t('buttonFillAll')}
                    </span>
                    <div className="flex items-center justify-between gap-x-[13px]">
                        <Input
                            classname={`min-w-[1px] max-w-full ${styles.input_search}`}
                            text={{ left: "Rp" }}
                            placeholder="0"
                            value={allCitiesCost}
                            changeEvent={(e) => setAllCitiesCost(e.target.value)}
                            onInput={handleInput}
                            maxLength={11}
                        />
                        <Button
                            Class="!font-medium !h-7 px-[30.5px] max-w-[112px]"
                            onClick={handleApplyToAllCities}
                        >
                            {t("buttonApply")}
                        </Button>
                    </div>
                </div>
            </Card>
            {filteredProvince.cities.length > 1 ? (
                <Card>
                    <Checkbox
                        label={<span className="font-semibold text-[14px] leading-[15.4px]">{t("labelSelectAllCities")}</span>}
                        checked={isAllChecked}
                        onChange={(e) => handleToogleCheckAll(e.checked)}
                    />
                </Card>
            ) : null}
            {filteredProvince.cities.length > 0 ? (
                <Card>
                    {filteredProvince.cities.map((city, key) => {
                        return (
                            <div
                                className="flex items-center justify-between pb-4 border-b border-b-neutral-400"
                                key={key}
                            >
                                <Checkbox
                                    label={<span className="font-semibold text-[14px] leading-[15.4px]">{city.cityName}</span>}
                                    checked={city.isActive}
                                    onChange={(e) => handleChangeCheckbox(e.checked, city.cityID)}
                                />
                                <Input
                                    classname={`w-[154px] ${styles.input_price} ${city.isActive ? "" : "cursor-not-allowed"}`}
                                    classInput={`${city.isActive ? "" : "text-neutral-600 cursor-not-allowed"}`}
                                    disabled={!city.isActive}
                                    text={{ left: "Rp" }}
                                    placeholder="0"
                                    value={city.price}
                                    changeEvent={(e) => handleChangeInput(e.target.value, city.cityID)}
                                    onInput={handleInput}
                                    status={city.status}
                                    supportiveText={{ title: city.message }}
                                    maxLength={11}
                                />
                            </div>
                        )
                    })}
                </Card>
            ) : null}
            <div className="fixed bottom-0 left-0 bg-neutral-50 w-full py-3 px-4 shadow-muat">
                <Button
                    Class="h-10 w-full max-w-full !font-semibold flex items-center"
                    onClick={onApplyBiayaPengiriman}
                >
                    {t("buttonSave")}
                </Button>
            </div>
        </div>
    )
}

export default AturBiayaPengiriman