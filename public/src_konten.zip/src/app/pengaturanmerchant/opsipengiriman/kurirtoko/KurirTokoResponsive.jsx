import AturKurirToko from "./screens/AturKurirToko"
import PilihProvinsi from "./screens/PilihProvinsi"
import HeaderMobile from "@/container/HeaderMobile/HeaderMobile"
import { useEffect, useState } from "react"
import toast from "@/store/zustand/toast"
import Modal from "@/components/Modals/modal"
import styles from "./KurirTokoResponsive.module.scss"
import IconComponent from "@/components/IconComponent/IconComponent"
import Bottomsheet from "@/components/Bottomsheet/Bottomsheet"
import AturBiayaPengiriman from "./screens/AturBiayaPengiriman"
import Input from "@/components/Input/Input"
import { useCustomRouter } from "@/libs/CustomRoute"
import ImageComponent from "@/components/ImageComponent/ImageComponent"
import kurirTokoZustand from "@/store/zustand/kurirToko"
import { useTranslation } from "@/context/TranslationProvider"

const KurirTokoResponsive = ({
    addCourierProvince,
    handleSave,
    handleRefresh,
    address,
    // count,
    provinceIds,
    // lists,
    // formData,
    // setFormData,
    validateFormData,
}) => {
    const router = useCustomRouter();
    const [getScreen,setScreen]=useState('aturKurirToko')
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [selectedProvinces, setSelectedProvinces] = useState([])
    const [tempProvince, setTempProvince] = useState(null)
    const [search, setSearch] = useState("")
    const { t } = useTranslation();
    const {
        setShowBottomsheet,
        setTitleBottomsheet,
        setDataBottomsheet,
        setShowNavMenu,
        setShowToast,
        setDataToast
    } = toast();
    const { formData, setFormData, tempData, setTempData } = kurirTokoZustand();

    useEffect(() => {
        setShowNavMenu(false)
    }, [])

    useEffect(() => {
        if (getScreen === 'pilihProvinsi') {
            const provinceIds = formData.map(item => item.provinceID)
            setSelectedProvinces(provinceIds)
        }
    }, [getScreen])

    const handleBack = () => {
        if (getScreen === "aturKurirToko") {
            setShowNavMenu(true)
            router.push("/pengaturanmerchant/opsipengiriman")
        } else {
            setScreen("aturKurirToko")
        }
    }

    const handleOpenAturBiayaPengiriman = (provinceID) => {
        const selectedProvince = formData.find(item => item.provinceID === provinceID)
        setTempProvince(selectedProvince)
        setSearch("")
        setScreen("aturBiayaPengiriman")
    }

    const validateProvinceData = () => {
        const hasCityWithEmptyPrice = tempProvince.cities.some(city => city.isActive && !city.price && city.price !== 0)
        if (hasCityWithEmptyPrice) {
            setTempProvince(prevState => ({
                ...prevState,
                cities: prevState.cities.map(city => ({
                    ...city,
                    ...(city.isActive && !city.price && city.price !== 0
                        ? { status: "error", message: "Field harus diisi" } :
                        { status: "", message: "" })
                }))
            }))
            return false;
        }
        const hasNoActiveCity = tempProvince.cities.some(city => city.isActive)
        if (!hasNoActiveCity) {
            setShowToast(true)
            setDataToast({
                type: "error",
                message: t("messageEmptyCostValidation"),
            });
            return false;
        }
        return true;
    }

    const handleApplyBiayaPengiriman = () => {
        const isValid = validateProvinceData()
        if (isValid) {
            const newTempData = formData.map(item => {
                if (item.provinceID !== tempProvince.provinceID) {
                  return item
                }
                return {
                    ...tempProvince,
                    count: tempProvince.cities.filter(item => item.isActive).length
                }
            })
            setTempData(newTempData)
            setFormData(newTempData)
            setScreen("aturKurirToko")
        }
    }

    return (
        <>
            <div className={getScreen === "aturBiayaPengiriman" ? styles.header_atur_biaya_pengiriman : ""}>
                <HeaderMobile>
                    {getScreen !== "aturBiayaPengiriman" ? (
                        <div className="flex items-center gap-x-2 py-[5px]">
                            <div
                                className="cursor-pointer"
                                onClick={() => {
                                    if (getScreen === "aturKurirToko") {
                                        setIsModalOpen(true)
                                    } else if (getScreen === "pilihProvinsi") {
                                        handleBack()
                                    }
                                }}
                            >
                                <ImageComponent
                                    src={`/icons/back-icon-mobile.svg`}
                                    priority
                                    width={24}
                                    height={24}
                                    alt="back"
                                />
                            </div>
                            <span className="font-bold text-[16px] leading-[19.2px] text-neutral-50">
                                {getScreen === "aturKurirToko" ? t("labelSetStoreCourier") : ""}
                                {getScreen === "pilihProvinsi" ? t('titleSelectProvince') : ""}
                            </span>
                            {getScreen === "aturKurirToko" ? (
                                <IconComponent
                                    classname={styles.icon_info}
                                    src="/icons/Info.svg"
                                    onclick={() => {
                                        setShowBottomsheet(true)
                                        setTitleBottomsheet(t("labelSetStoreCourier"))
                                        setDataBottomsheet(
                                            <span className="font-medium text-[14px] leading-[15.4px]">
                                                {t("tooltipStoreCourier")}
                                            </span>
                                        )
                                    }}
                                />
                            ) : null}
                        </div>
                    ) : (
                        <div className="flex flex-col gap-y-2 w-full">
                            <div className="flex items-center gap-x-2 py-[5px]">
                                <div
                                    className="cursor-pointer"
                                    onClick={handleBack}
                                >
                                    <ImageComponent
                                        src={`/icons/back-icon-mobile.svg`}
                                        priority
                                        width={24}
                                        height={24}
                                        alt="back"
                                    />
                                </div>
                                <span className="font-bold text-[16px] leading-[19.2px] text-neutral-50">
                                    {tempProvince.provinceName}
                                </span>
                            </div>
                            <Input
                                classname={`w-full max-w-full ${styles.input_search}`}
                                placeholder={t("labelSearchCityRegency")}
                                icon={{
                                left: (
                                    <IconComponent src={"/icons/search.svg"} />
                                ),
                                right: search ? (
                                    <IconComponent
                                        src={"/icons/silang.svg"}
                                        onclick={() => {
                                            setSearch("")
                                        }}
                                    />
                                ) : null,
                                }}
                                value={search}
                                changeEvent={(e) => setSearch(e.target.value)}
                            />
                        </div>
                    )}
                </HeaderMobile>
            </div>
            <div className={getScreen === "aturBiayaPengiriman" ? "mt-[46px]" : "mt-[10px]"}>
                {getScreen === "aturKurirToko" ? (
                    <AturKurirToko
                        address={address}
                        // count={count}
                        formData={formData}
                        // lists={lists}
                        onRefresh={handleRefresh}
                        onSave={handleSave}
                        validateFormData={validateFormData}
                        setScreen={setScreen}
                        onOpenAturBiayaPengiriman={handleOpenAturBiayaPengiriman}
                    />
                ) : null}
                {getScreen === "pilihProvinsi" ? (
                    <PilihProvinsi
                        addCourierProvince={addCourierProvince}
                        onRefresh={handleRefresh}
                        selectedProvinces={selectedProvinces}
                        setSelectedProvinces={setSelectedProvinces}
                        onBack={handleBack}
                        provinceIds={provinceIds}
                    />
                ) : null}
                {getScreen === "aturBiayaPengiriman" ? (
                    <AturBiayaPengiriman
                        search={search}
                        tempProvince={tempProvince}
                        setTempProvince={setTempProvince}
                        onApplyBiayaPengiriman={handleApplyBiayaPengiriman}
                    />
                ) : null}
            </div>
            <Modal
                isOpen={isModalOpen}
                setIsOpen={setIsModalOpen}
                closeArea={false}
                closeBtn={true}
                title={t("titleExitSetCourierStore")}
                desc={t("descExitSetCourierStore")}
                action1={{
                    action: () => setIsModalOpen(false),
                    text: "Tidak",
                    style: "outline",
                    color: "#176CF7",
                        customStyle: {
                        width: "112px",
                    },
                }}
                action2={{
                    action: handleBack,
                    text: "Ya",
                    style: "full",
                    color: "#176CF7",
                    customStyle: {
                        width: "112px",
                        color: "#ffffff",
                    },
                }}
            />
            <Bottomsheet/>
        </>
    )
}

export default KurirTokoResponsive