import IconComponent from "@/components/IconComponent/IconComponent"
import AmbilLangsungCard from "@/container/OpsiPengiriman/Web/AmbilLangsungCard"
import ExpedisiCard from "@/container/OpsiPengiriman/Web/ExpedisiCard"
import KurirTokoCard from "@/container/OpsiPengiriman/Web/KurirTokoCard"
import { CustomTooltip } from "@/container/Register/InformasiPendaftarDanRekening"
import { Fragment } from "react"
import { useTranslation } from "@/context/TranslationProvider"

const OpsiPengirimanWeb = ({
    toogleGroupExpedition,
    toogleItemExpedition,
    handleToogleAmbilLangsung,
    handleRefresh,
    validateToogleShipping,
    pickupOption,
    storeCourier,
    shippingGroups
}) => {
    const { t }= useTranslation();

    return (
        <div className="flex flex-col gap-y-6 min-h-[calc(100vh_-_100px)]">
            <div className="flex gap-x-2 items-center">
                <span className="font-bold text-[20px] leading-[24px]">{t('titleShippingOptions')}</span>
                <CustomTooltip
                  content={<span className="leading-[16.8px]">{t('descShippingOptions')}</span>}
                >
                    <IconComponent
                        src="/icons/Info.svg"
                    />
                </CustomTooltip>
            </div>
            <AmbilLangsungCard
                onToogleAmbilLangsung={handleToogleAmbilLangsung}
                pickupOption={pickupOption}
                validateToogleShipping={validateToogleShipping}
            />
            <KurirTokoCard
                {...storeCourier}
            />
            {shippingGroups.map((shippingGroup, key) => {
                if (shippingGroup.couriers.length === 0) {
                    return null
                }
                return (
                    <Fragment key={key}>
                        <ExpedisiCard
                            {...shippingGroup}
                            onRefresh={handleRefresh}
                            toogleGroupExpedition={toogleGroupExpedition}
                            toogleItemExpedition={toogleItemExpedition}
                            validateToogleShipping={validateToogleShipping}
                        />
                    </Fragment>
                )
            })}
        </div>
    )
}

export default OpsiPengirimanWeb