"use client";
import { Button } from "@/components/MobileCom/button";
import { Separator } from '@/components/MobileCom/separator';
import { useHeader } from '@/common/ResponsiveContext';
import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { getBrands } from '../../../services/voucher';

const defaultFilter = {
  produk: "Semua Produk",
  brands: []
};

export default function FilterPage({ 
    isOpen, 
    onClose,
    initialFilter = defaultFilter, 
    onSaveFilter = () => {} 
  }) {
  if (!isOpen) return null;

  
  const router = useRouter();
  const [selected, setSelected] = useState(initialFilter || defaultFilter);
  const [allBrands, setAllBrands] = useState([]); // Store all available brands
  const [selectedBrands, setSelectedBrands] = useState([]);
  const {setAppBar } = useHeader();
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    setAppBar({
      title: 'Filter',
      appBarType: 'header_title',
    });
  }, []);
  

  // Fetch both all brands and selected brands on component mount
  useEffect(() => {
    const fetchInitialData = async () => {
      try {
        const params = {
            page_size: 10,
            page: 1
          };
          const body = {
            search: searchQuery,
          };
        // Fetch first 8 brands from API (or however many you want to show)
        const response = await getBrands('/stores/98da2571-d600-4dc5-85e6-ee290bc193e4/brands', body, process.env.NEXT_PUBLIC_AUTH_TOKEN);
        const data = await response.Data;
        setAllBrands(data);

        // Get selected brands from localStorage
        const savedBrands = localStorage.getItem('selectedBrands');
        if (savedBrands) {
          const brands = JSON.parse(savedBrands);
          setSelectedBrands(brands);
          handleSelect('brands', brands);
        }
      } catch (error) {
        console.error('Failed to fetch brands:', error);
      }
    };

    fetchInitialData();
  }, []);

  const handleBrandSelect = (brand) => {
    const isSelected = selectedBrands.some(b => b.brand_id === brand.brand_id);
      if (isSelected) {
        setSelectedBrands(prev => prev.filter(b => b.brand_id !== brand.brand_id));
      } else {
        setSelectedBrands(prev => [...prev, brand]);
      }

  };
  const handleSelect = (category, value) => {
    setSelected(prev => ({
      ...prev,
      [category]: value,
    }));
  };

  const navigateToBrandsPage = () => {
    router.push('/buatVoucher/choose-brands');
  };
  const navigateToCategoryPage = () => {
    router.push('/buatVoucher/choose-category');
  };

  const handleApply = () => {
    try {
        //kirim param disini
        onSaveFilter(selected);
        localStorage.setItem('selectedBrands', JSON.stringify(selectedBrands));

      } catch (error) {
        console.error('Error saving filters:', error);
        // You could add error handling here if needed
      }
      onClose;
      //router.back();
  };

  // Display first 5 brands, marking them as selected if they're in selectedBrands
  const displayBrands = allBrands.slice(0, 5).map(brand => {
    const isSelected = selectedBrands.some(b => b.brand_id === brand.brand_id);
    return (
      <Button
        key={brand.brand_id}
        variant={isSelected ? "type1" : "secondaryRounded"}
        className="cursor-default"
        onClick={() => handleBrandSelect( brand)}

      >
        {brand.name}
      </Button>
    );
  });

  return (
    <div className="fixed inset-0 bg-white flex flex-col h-full w-full overflow-auto rounded-none" style={{zIndex:100}}>
			{/* Header */}
        <div className="p-4 border-b flex justify-between items-center bg-white shadow-md">
          <button onClick={onClose} className="text-[#176cf7] text-2xl font-semibold">✕</button>
          <h2 className="text-lg font-semibold">Filter</h2>
          <div></div>
        </div>

        {/* Filter Content */}
        <div className="flex-1 p-5 shadow-md">
          {/* Category Section */}
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <h5 className="font-medium">Kategori</h5>
              <Button
                variant="ghost"
                className="text-blue-600 p-0 hover:bg-transparent"
                onClick={navigateToCategoryPage}
              >
                Lihat Semua
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {displayBrands}
              {allBrands.length > 5 && (
                <span className="text-sm text-muted-foreground py-2">
                  +{allBrands.length - 5} more
                </span>
              )}
            </div>
            <Separator className="my-4" />
          </div>

          {/* Brand Section */}
          <div className="space-y-2 border-t-[1px] border-t-gray-400 pt-4">
            <div className="flex justify-between items-center">
              <h5 className="font-medium">Brand</h5>
              <Button
                variant="ghost"
                className="text-blue-600 p-0 hover:bg-transparent"
                onClick={navigateToBrandsPage}
              >
                Lihat Semua
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {displayBrands}
              {allBrands.length > 5 && (
                <span className="text-sm text-muted-foreground py-2">
                  +{allBrands.length - 5} more
                </span>
              )}
            </div>
            <Separator className="my-4" />
          </div>

          {/* Produk Section */}
          <div className="space-y-2 border-t-[1px] border-t-gray-400 pt-4">
            <h5 className="font-medium">Ketersediaan Produk</h5>
            <div className="flex gap-x-2">
              <Button
                variant={selected.produk === "Semua Produk" ? "type1" : "secondaryRounded"}
                onClick={() => handleSelect("produk", "Semua Produk")}
              >
                Produk Tidak Tersedia
              </Button>
              <Button
                variant={selected.produk === "Produk Tertentu" ? "type1" : "secondaryRounded"}
                onClick={() => handleSelect("produk", "Produk Tertentu")}
              >
                Produk Tersedia
              </Button>
            </div>
            <Separator className="my-4" />
          </div>
        </div>

        {/* Bottom Action Bar */}
        <div className="fixed bottom-0 left-0 right-0 px-4 py-4 bg-white border-t shadow-lg">
          <div className="flex space-x-4 max-w-md mx-auto">
            <Button
              variant="secondaryRounded"
              className="flex-1 border-blue-500 text-blue-500 border-[2px] "
              onClick={() => router.back()}
            >
              Batal
            </Button>
            <Button
              variant="secondaryRounded"
              className="flex-1 bg-blue-500 text-white "
              onClick={handleApply}
              // onClick={onApply}

            >
              Terapkan
            </Button>
          </div>
        </div>
    </div>
  );
}