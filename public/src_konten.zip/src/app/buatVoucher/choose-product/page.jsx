"use client";
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '../../../components/MobileCom/button';
import { getProducts } from '../../../services/voucher';

import { useHeader } from '@/common/ResponsiveContext';
import Nav from "../_components/Nav";
import { SearchX, SlidersHorizontal } from "lucide-react";
import DrawerMenu from './_components/DrawerMenu';
import Header from './_components/Header';
import { Badge } from "@/components/MobileCom/badge";
import { Checkbox } from "@/components/MobileCom/checkbox-2";
import FilterPage from '@/app/buatVoucher/filter/page';
import { useTranslation } from '@/context/TranslationProvider';

export default function ChooseProduct() {
  const { t } = useTranslation();
  const [products, setProducts] = useState([]);
  const [brands, setBrands] = useState([]);
  const [selectedProducts, setSelectedProducts] = useState([]);
  const router = useRouter();
  const [searchQuery, setSearchQuery] = useState("");
  const [initialDataFetched, setInitialDataFetched] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isFilterOpen, setFilterOpen] = useState(false);
  const [activeFilters, setActiveFilters] = useState({});
  const [selectedBrands, setSelectedBrands] = useState([]);
  const [categories, setCategories] = useState([]);


  const [filterCriteria, setFilterCriteria] = useState({
    brand: [],
    kategori: [],
    stok: ""
  });
  const [selectedStok, setSelectedStok] = useState(filterCriteria);

  const handleBrandSelect = (brand) => {
    const isSelected = selectedBrands.some(b => b.brand_id === brand.brand_id);
    if (isSelected) {
      setSelectedBrands(prev => prev.filter(b => b.brand_id !== brand.brand_id));
    } else {
      setSelectedBrands(prev => [...prev, brand]);
    }

  };


  const toggleFilter = (category, value) => {
    setFilterCriteria(prev => {
      if (category === 'stok') {
        // Toggle stock filter: if same value, clear it, otherwise set new value
        return {
          ...prev,
          stok: prev.stok === value ? "" : value
        };
      } else {
        // Handle brand and kategori
        const currentArray = [...(prev[category] || [])];
        const valueId = category === 'kategori' ? value.category_id : value.brand_id;

        if (currentArray.includes(valueId)) {
          // Remove if already selected
          return {
            ...prev,
            [category]: currentArray.filter(id => id !== valueId)
          };
        } else {
          // Add if not selected
          return {
            ...prev,
            [category]: [...currentArray, valueId]
          };
        }
      }
    });
  };
  const isAnyFilterActive = () => {
    console.log(Object.values(filterCriteria).some((value) => value !== ""))

    return Object.values(filterCriteria).some((value) => value !== "") || searchQuery !== "";
  };

  // Helper function to check if data exists
  const hasData = () => {
    return initialDataFetched && Array.isArray(products) && products.length > 0;
  };


  const handleApplyFilters = () => {
    // Check if any filters are active
    const hasFilters = Object.values(filterCriteria).some(value =>
      Array.isArray(value) ? value.length > 0 : value !== ""
    );

    // Convert arrays to comma-separated strings for API
    const formattedFilters = {
      brand: filterCriteria.brand,
      kategori: filterCriteria.kategori,
      stok: filterCriteria.stok
    };

    setActiveFilters(hasFilters ? formattedFilters : {});
    setFilterOpen(false);
  };
  const { setAppBar } = useHeader();
  const shouldShowControls = hasData() || isAnyFilterActive();

  // Load any previously selected products and form data when component mounts
  useEffect(() => {
    setAppBar({
      title: 'Pilih Produk',
      appBarType: 'header_title',
    })

    try {
      const savedProducts = localStorage.getItem('selectedProducts');
      if (savedProducts) {
        const parsedProducts = JSON.parse(savedProducts);
        // Ensure we have an array
        if (Array.isArray(parsedProducts)) {
          setSelectedProducts(parsedProducts);
        }
        console.log(parsedProducts)

      }
    } catch (error) {
      console.error('Error loading saved products:', error);
      // Reset to empty array if there's an error
      setSelectedProducts([]);
    }
    console.log(filteredProducts)
  }, []);

  const fetchProducts = async (filters) => {
    try {
      setIsLoading(true);

      const body = {
        status: ['Active'],
        kategori: filters.kategori,
        brand: filters.brand,
        stok: filters.stok,
        search: searchQuery,
        page_size: 100,
        page: 1
      };
      const response = await getProducts('/product/lists', body, process.env.NEXT_PUBLIC_AUTH_TOKEN);
      const data = response.Data;
      setProducts(data);

      // Assuming the products are in data.Data
      const processedBrands = processBrands(data);
      setBrands(processedBrands);

      // Assuming the products are in data.Data
      const processedCategories = processCategories(data);
      setCategories(processedCategories);
      if (!initialDataFetched) setInitialDataFetched(true);

    } catch (error) {
      console.error('Failed to fetch products', error);
    } finally {
      setIsLoading(false);
    }
  };

  // const handleFilterClick = () => {
  //   router.push('/buatVoucher/filter'); // Adjust this path to match your routing structure
  // };
  useEffect(() => {
    setAppBar({
      title: 'Pilih Produk',
      appBarType: 'header_title',
    });

    fetchProducts(activeFilters);

  }, [activeFilters, searchQuery]);

  const filteredProducts = Array.isArray(products) ? products.filter((p) => {
    const matchesSearch = p.title
      ?.toLowerCase()
      .includes(searchQuery.toLowerCase());
    const matchesStatus =
      !filterCriteria.status || p.status === filterCriteria.status;
    const matchesJenisVoucher =
      !filterCriteria.jenisVoucher ||
      p.voucher_type === filterCriteria.jenisVoucher;
    const matchesTargetVoucher =
      !filterCriteria.targetVoucher ||
      p.target === filterCriteria.targetVoucher;
    const matchesProduk =
      !filterCriteria.produk || p.is_all_product === filterCriteria.produk;

    return (
      matchesSearch &&
      matchesStatus &&
      matchesJenisVoucher &&
      matchesTargetVoucher &&
      matchesProduk
    );
  }) : [];

  const resetFilter = () => {
    setFilterCriteria({
      status: "",
      jenisVoucher: "",
      targetVoucher: "",
      produk: "",
    });
  };

  const toggleProductSelection = (product) => {
    setSelectedProducts(prev =>
      prev.some(p => p.ID === product.ID)
        ? prev.filter(p => p.ID !== product.ID)
        : [...prev, product]
    );
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat('id-ID').format(price);
  };

  const handleSave = () => {
    if (selectedProducts.length === 0) {
      alert('Pilih setidaknya satu produk');
      return;
    }

    // Store selected products in localStorage
    localStorage.setItem('selectedProducts', JSON.stringify(selectedProducts));

    // Get stored form data
    const formData = localStorage.getItem('voucherFormData');
    if (formData) {
      // Update the stored form data with the selected products
      const updatedFormData = JSON.parse(formData);
      updatedFormData.step3.target_produk = 'produk_tertentu';
      updatedFormData.step3.productList = selectedProducts.map((p) => p.id);
      localStorage.setItem('voucherFormData', JSON.stringify(updatedFormData));

      localStorage.setItem('product_tertentu', true)
    }

    // Navigate back to step 3
    router.push('/buatVoucher?currentStep=3&produk_tertentu=1');
  };
  // Function to process brands from API data
  const processBrands = (data) => {
    // Extract all brands from products, excluding null BrandIDs
    const allBrands = data.reduce((acc, product) => {
      if (product.BrandID && product.Brand) {
        acc.push({
          brand_id: product.BrandID,
          name: product.Brand
        });
      }
      return acc;
    }, []);

    // Remove duplicates based on brand_id
    const uniqueBrands = Array.from(
      new Map(allBrands.map(brand => [brand.brand_id, brand])).values()
    );

    // Sort brands alphabetically by name
    return uniqueBrands.sort((a, b) => a.name.localeCompare(b.name));
  };
  const processCategories = (data) => {
    // Extract all categories from each product
    const allCategories = data.reduce((acc, product) => {
      // Combine CategoryID and Category arrays into objects
      const productCategories = product.Category.map((cat, index) => ({
        category_id: product.CategoryID[index],
        name: cat
      }));

      return [...acc, ...productCategories];
    }, []);

    // Remove duplicates based on category_id
    const uniqueCategories = Array.from(
      new Map(allCategories.map(cat => [cat.category_id, cat])).values()
    );

    return uniqueCategories.sort((a, b) => a.name.localeCompare(b.name));
  };
  const renderEmptyStateIcon = () => {
    if (isAnyFilterActive()) {
      return <img src="/img/search-icon.png" className="h-24 mb-4" alt="Filter no results" />;
    }
    return <img src="/img/empty-icon.png" className="h-24 mb-4" alt="No vouchers" />;
  };


  return (
    <>

      <div className="bg-white min-h-screen flex flex-col pb-20"> {/* Added pb-20 for button spacing */}
        <div className="py-4 space-y-4 flex-grow">
          <div className="px-4 space-y-4">
            <Header searchQuery={searchQuery} setSearchQuery={setSearchQuery} />
            <div>

              <Button
                onClick={() => setFilterOpen(true)}
                variant="secondary"
                className={`
                rounded-2xl ${!shouldShowControls
                    ? 'bg-gray-300'
                    : Object.keys(activeFilters).length // Changed from filterCriteria to activeFilters
                      ? "border-[#176cf7] border-[1px] bg-blue-100 text-[#176cf7]"
                      : ""
                  }`}
              >
                Filters <SlidersHorizontal />
              </Button>

              <FilterPage
                isOpen={isFilterOpen}
                onClose={() => setFilterOpen(false)}
                onApply={handleApplyFilters}
                toggleFilter={toggleFilter}
                filterCriteria={filterCriteria}
                brands={brands}
                categories={categories}
              // isOpen={isFilterOpen}
              // onClose={() => setFilterOpen(false)}
              // onApply={handleApplyFilters}
              // toggleFilter={toggleFilter}
              // filterCriteria={filterCriteria}
              // brands={brands}
              // selectedBrands={selectedBrands}
              // handleBrandSelect={handleBrandSelect}
              />
            </div>
          </div>
          <div className="flex-grow bg-gray-100">
            <div className="space-y-2 mt-2">
              {isLoading ? (
                <div className="text-center py-4">Loading...</div>
              ) : products.length > 0 ? (
                products.map(product => (
                  <div
                    key={product.ID}
                    onClick={() => toggleProductSelection(product)}
                    className={`border p-4 bg-card text-card-foreground shadow flex items-start p-2 cursor-pointer bg-white `}
                  >
                    <Checkbox
                      type="checkbox"
                      checked={selectedProducts.some(p => p.ID === product.ID)}
                      readOnly
                      className={`rounded-[4px] mr-4 border-gray-400 ${selectedProducts.some(p => p.ID === product.ID)
                        ? 'bg-blue-500 border-blue-500 text-white'
                        : ''
                        }`}
                    />
                    <img
                      src="/img/product-image.png"
                      alt={product.title}
                      className="w-16 h-16 object-cover rounded-md mr-3"
                    />
                    <div className='flex flex-col gap-4'>
                      <div className='flex flex-col'>
                        <span className='font-bold leading-[18px] text-[14px]'>{product.Name}</span>
                        <span className='text-[12px] leading-[16px]'>SKU : {product.Sku}</span>
                        <span className='text-[12px] leading-[16px]'>Rp.{product.PriceLabel}</span>
                      </div>
                      <div className='flex gap-4 items-center'>
                        <span className='text-[12px]'>Stok : {formatPrice(product.Stock)}</span>
                        <Badge
                          variant="primary"
                          className="min-w-6 justify-center py-1 capitalize border-[#e2f2ff] bg-[#e2f2ff] text-[#176cf7]"
                        >
                          {product.variant.length} Varian
                        </Badge>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center min-h-[600px] flex flex-col items-center justify-center">
                  {renderEmptyStateIcon()}
                  {isAnyFilterActive() ? (
                    <>
                      <p className="font-semibold text-[14px] text-muted-foreground">
                        Data tidak Ditemukan. <br />Mohon coba hapus beberapa filter.
                      </p>
                      <p className="font-semibold text-[14px] text-muted-foreground mb-4">
                        atau
                      </p>
                      <Button
                        onClick={resetFilter}
                        className="bg-blue-500 text-white text-[14px] font-semibold rounded-full hover:bg-blue-600"
                      >
                        Atur ulang filter
                      </Button>
                    </>
                  ) : (
                    <>

                      <p className="font-semibold text-[14px] text-muted-foreground">
                        {/* Improvement fix wording pak Bryan */}
                        {t("PusatPromosiKelolaVoucherBelumadavoucheryangAktif")}
                      </p>
                      <p className="text-[12px] text-muted-foreground">
                        Buat Voucher sekarang!
                      </p>
                    </>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Fixed button at bottom */}
        <div className="fixed bottom-0 left-0 right-0 px-4 py-4 bg-white border-t shadow-lg">
          <Button
            onClick={handleSave}
            disabled={selectedProducts.length === 0}
            className="w-full bg-blue-500 text-white rounded-xl hover:bg-blue-600 disabled:bg-gray-300"
          >
            Simpan ({selectedProducts.length} Produk)
          </Button>
        </div>
      </div>
    </>
  );
}