import { Button } from "@/components/MobileCom/button";
import { useEffect, useState } from "react";

import {
  Drawer,
  DrawerClose,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
} from "@/components/MobileCom/drawer";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/MobileCom/form";
import { Input } from "@/components/MobileCom/input";
import { UbahKuotaVoucherSchema } from "@/schema";
import { zodResolver } from "@hookform/resolvers/zod";
import { X } from "lucide-react";
import { useForm } from "react-hook-form";
import { z } from "zod";

export default function DrawerMenuUbahKuota({ open, onOpenChange, voucherId, onSuccess}) {
  const [apiError, setApiError] = useState(null);
  
  const form = useForm({
    resolver: zodResolver(UbahKuotaVoucherSchema),
    defaultValues: {
      kuota: "",
    },
  });

  async function onSubmit(values) {
    try {
      setApiError(null); // Clear any previous errors
      
      const response = await fetch(`http://192.168.7.77:3019/v1/muatparts/voucher/${voucherId}/quota`, {
        method: 'PUT',
        headers: {
          'Authorization': 'Bearer YOUR_TOKEN',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ new_quota: parseInt(values.kuota) })
      });

      if (response.status === 500) {
        setApiError("Terjadi kesalahan server. Silakan coba lagi nanti.");
        return;
      }

      if (!response.ok) {
        throw new Error('Failed to update quota');
      }

      // If successful
      toast.success("Berhasil mengubah kuota voucher", {
        position: "bottom-center",
        className: "border-green-400 bg-green-100 mb-24",
        duration: 2000,
        action: {
          label: <X className="h-4 w-4" />,
          onClick: (event) => event.cancelable,
        },
        icon: <Check className="h-4 w-4 text-green-500" />,
      });

      onOpenChange(false); // Close drawer
      if (onSuccess) {
        setTimeout(() => {
          onSuccess();
        }, 1000);
      }

    } catch (error) {
      setApiError(error.Message);
    }
  }

  return (
    <Drawer open={open} onOpenChange={onOpenChange}>
      <DrawerContent className="max-w-screen-sm mx-auto">
        <DrawerHeader className="text-center relative">
          <DrawerClose asChild className="absolute left-4">
            <X className="h-8 w-8 text-blue-500 cursor-pointer" />
          </DrawerClose>
          <DrawerTitle className="text-center capitalize mb-4">
            Ubah Kuota Voucher
          </DrawerTitle>
          <Form {...form}>
            <form
              onSubmit={form.handleSubmit(onSubmit)}
              className="space-y-4 text-left"
            >
              <FormField
                control={form.control}
                name="kuota"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Input 
                        type="number" 
                        placeholder="Contoh:10" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {apiError && (
                <p className="text-sm text-red-500 mt-1">
                  {apiError}
                </p>
              )}

              <Button
                className="bg-blue-700 text-white capitalize font-semibold rounded-full hover:bg-blue-800 w-full"
                type="submit"
              >
                Terapkan
              </Button>
            </form>
          </Form>
        </DrawerHeader>
      </DrawerContent>
    </Drawer>
  );
}