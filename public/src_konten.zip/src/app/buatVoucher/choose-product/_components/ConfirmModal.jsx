"use client";
import { toast } from "sonner";
import { Button } from "@/components/MobileCom/button";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/MobileCom/dialog";
import { Check, X } from "lucide-react";
import { useTranslation } from "@/context/TranslationProvider";
// Improvement fix wording Pak Brian
// export default function ConfirmModal({ open, onOpenChange, voucherId }) {
//   const submitHandler = () => {
//     return toast("Berhasil Mengakhiri Voucher", {
//       position: "bottom-center",
//       className: "border-green-400 bg-green-100 mb-24",
//       actionButtonStyle: { backgroundColor: "transparent", color: "gray" },
//       action: {
//         label: <X className="h-4 w-4 bg-transparent" />,
//         onClick(event) {
//           return event.cancelable;
//         },
//       },
//       icon: <Check className="text-green-400" />,
//     });
//   };
export default function ConfirmModal({ open, onOpenChange, voucherId, voucherName, onSuccess }) {
  const {t} = useTranslation()
  const submitHandler = async () => {
    try {
      const response = await fetch(`http://192.168.7.77:3019/v1/muatparts/voucher/${voucherId}/end`, {
        method: 'PUT',
        headers: {
          'Authorization': 'Bearer YOUR_TOKEN',
          'Content-Type': 'application/json',
        }
      });

      if (!response.ok) {
        throw new Error('Failed to end voucher');
      }

      // Close modal first
      onOpenChange(false);

      
      // Show success toast and wait for it to be visible
      toast.success("Berhasil Mengakhiri Voucher", {
        position: "bottom-center",
        className: "border-green-400 bg-green-100 mb-24",
        duration: 2000, // Show for 2 seconds
        action: {
          label: <X className="h-4 w-4" />,
          onClick: (event) => event.cancelable,
        },
        icon: <Check className="h-4 w-4 text-green-500" />,
      });

      
      // // Wait for toast to be visible before reloading
      // setTimeout(() => {
      //   if (onSuccess) {
      //     onSuccess();
      //   }
      //   window.location.reload();
      // }, 1000); // Wait 1 second before reloading

    } catch (error) {
      toast.error("Gagal mengakhiri voucher", {
        position: "bottom-center",
        className: "border-red-400 bg-red-100 mb-24",
        duration: 3000,
      });
    }
  };


  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader className="items-center">
          <DialogTitle>{t("PusatPromosiModalAkhiriVoucherAkhiriVoucher")}</DialogTitle>
        </DialogHeader>
        <p className="font-medium text-sm text-center">
          {/* Apakah kamu yakin mengakhiri Voucher {voucherName} ? */}
          {t("PusatPromosiModalAkhiriVoucherApakahkamuyakinmengakhiriVoucher{render}?").replace("{render}",voucherName)}
        </p>
        <DialogFooter className="flex gap-x-2 flex-row">
          <DialogClose className="w-1/2" asChild>
            <Button className="bg-white text-blue-500  border-blue-500 border rounded-full">
              {t("PusatPromosiModalAkhiriVoucherBatal")}
            </Button>
          </DialogClose>
          <DialogClose className="w-1/2" asChild>
            <Button
              className="rounded-full bg-blue-500 text-white"
              onClick={submitHandler}
            >
              {t("PusatPromosiModalAkhiriVoucherYa")}
            </Button>
          </DialogClose>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
