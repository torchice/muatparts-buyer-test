import { Search } from "lucide-react";

export default function Header({ searchQuery, setSearchQuery }) {
  return (
    <>
      <form action="">
        <div className="flex gap-x-2 w-full rounded-lg px-4 py-2 bg-white border border-gray-500">
          <Search className="text-slate-500 h-6 w-6" />
          <input
            type="text"
            name="search"
            placeholder="Cari Nama Produk / SKU"
            autoComplete="off"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)} // Update query
            className="outline-none border-none bg-transparent text-slate-500 w-full"
          />
        </div>
      </form>
    </>
  );
}
