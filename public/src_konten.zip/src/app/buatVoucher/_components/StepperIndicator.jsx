import clsx from "clsx";

export default function StepIndicator({ step }) {
  return (
    <div className="flex items-center justify-center">
      {/* Step 1 */}
      <div className="flex items-center text-xs">
        <div
          className={clsx(
            "w-8 h-8 flex items-center justify-center font-bold rounded-full border-2",
            {
              "bg-white text-red-600 border-white": step === 1,
              "text-white border-white": step !== 1,
            }
          )}
        >
          1
        </div>
        <div className="w-6 h-1 bg-white"></div>
      </div>

      {/* Step 2 */}
      <div className="flex items-center text-xs">
        <div
          className={clsx(
            "w-8 h-8 flex items-center justify-center font-bold rounded-full border-2",
            {
              "bg-white text-red-600 border-white": step === 2,
              "text-white border-white": step !== 2,
            }
          )}
        >
          2
        </div>
        <div className="w-6 h-1 bg-white"></div>
      </div>

      {/* Step 3 */}
      <div className="flex items-center text-xs">
        <div
          className={clsx(
            "w-8 h-8 flex items-center justify-center font-bold rounded-full border-2",
            {
              "bg-white text-red-600 border-white": step === 3,
              "text-white border-white": step !== 3,
            }
          )}
        >
          3
        </div>
      </div>
    </div>
  );
}
