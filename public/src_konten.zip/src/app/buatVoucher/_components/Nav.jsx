import { Separator } from "@radix-ui/react-separator";
import { ChevronLeft } from "lucide-react";
import StepIndicator from "./StepperIndicator";
import ConfirmModal from "./ConfirmModal";

export default function Nav({ step }) {
  return (
    <nav className="bg-error-700 py-2 border-t-0 border-white px-4 flex flex-col justify-between items-start text-white">
     
      <Separator />

      <div className="flex justify-between w-full items-center">
        <p className="font-semibold text-md">Informasi Voucher</p>
        <StepIndicator step={step} />
      </div>
    </nav>
  );
}
