import { Button } from "@/components/MobileCom/button";
import React from "react";

const FilterPage = ({type, isOpen, onClose, onApply, toggleFilter, filterCriteria,fetchProducts }) => {
	if (!isOpen) return null;
    console.log(type)

	return (
		<div className="fixed inset-0 bg-white flex flex-col h-full w-full overflow-auto rounded-none" style={{zIndex:100}}>
			{/* Header */}
			<div className="p-4 border-b flex justify-between items-center bg-white shadow-md">
				<button onClick={onClose} className="text-[#176cf7] text-2xl font-semibold">✕</button>
				<h2 className="text-lg font-semibold">Filter</h2>
				<div></div>
			</div>

			{/* Filter Content */}
			<div className="flex-1 p-5 shadow-md">
				{/* Brand Product */}
				
				<div className="mb-5 border-gray-500 border-b pb-5">
					<p className="text-gray-700 font-semibold">Brand</p>
					<div className="flex space-x-2 mt-[10px]">
						{fetchProducts.map((item) => (
							<Button
							key={item}
							onClick={() => toggleFilter("brand", item)} 
							variant={`${filterCriteria?.brand.includes(item)  ? "type1" : "secondaryRounded"}`}
							>
							item
							</Button>
						))}
					</div>
				</div>

				{/* Target Voucher */}
				<div className="mb-5 border-gray-500 border-b pb-5 ">
					<p className="text-gray-700 font-semibold">Target Voucher</p>
					<div className="flex space-x-2 mt-[10px]">
						
							{/* <Button
								onClick={() => toggleFilter("targetVoucher", "Publik")} 
                                variant={`${filterCriteria.targetVoucher.includes("Publik")  ? "type1" : "secondaryRounded"}`}
							>
							Publik
							</Button>
							<Button
								onClick={() => toggleFilter("targetVoucher", "Terbatas")}
                                variant={`${filterCriteria.targetVoucher?.includes("Terbatas") ? "type1" : "secondaryRounded"}`}
							>
							Terbatas
							</Button> */}
					</div>
				</div>

				{/* Produk */}
				<div className="mb-5">
					<p className="text-gray-700 font-semibold">Produk</p>
					<div className="flex space-x-2 mt-[10px]">

						{/* <Button
								onClick={() => toggleFilter("produk", "1")} 
                                variant={`${filterCriteria.produk.includes("1")  ? "type1" : "secondaryRounded"}`}
							>
							Semua Produk
							</Button>
							<Button
								onClick={() => toggleFilter("produk", "0")}
                                variant={`${filterCriteria.produk?.includes("0") ? "type1" : "secondaryRounded"}`}
							>
							Produk Tertentu
							</Button> */}
					</div>
				</div>
			</div>

			{/* Footer Buttons */}
			<div className="p-4 border-t bg-white flex justify-between gap-2 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.1),0_-2px_4px_-1px_rgba(0,0,0,0.06)]">
				<button onClick={onClose} className=" border-[#176cf7] border-[2px] text-[#176cf7] px-4 py-2 w-full rounded-full">Batal</button>
				<button
					// onClick={() => onApply(filterCriteria)}
					onClick={onApply}
					className="bg-blue-500 text-white px-4 py-2 w-full rounded-full"
				>
					Simpan
				</button>
			</div>
		</div>
	);
};

export default FilterPage;
