"use client";
import { RadioGroup, RadioGroupItem } from "../../../../components/MobileCom/radio-group";
import { Button } from "../../../../components/MobileCom/button";
import {
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "../../../../components/MobileCom/form";
import { UseFormReturn } from "react-hook-form";
import { CreateVoucherSchema } from "../../../../schema";
import { Input } from "../../../../components/MobileCom/input";

export default function Second({
  form,
  next,
  prev,
  type,
}) {
  return (
    <div className="">
      <FormField
        control={form.control}
        name="step2.jenis_voucher"
        render={({ field }) => (
          <FormItem >
            <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-700">Jenis Voucher*</span>
            <FormControl>
              <RadioGroup
                onValueChange={field.onChange}
                defaultValue={field.value}
                className="flex flex-col"
              >
                <FormItem className="flex items-center space-x-3 items-center">
                  <FormControl>
                    <RadioGroupItem className="mt-0" value="Diskon Produk" />
                  </FormControl>
                  <div style={{marginLeft:'0px'}}>
                  <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-700">Diskon Produk</span>
                  </div>
                </FormItem>
                <FormItem className="flex items-center space-x-3 space-y-0  items-center">
                  <FormControl>
                    <RadioGroupItem className="mt-0" value="Biaya Pengiriman" />
                  </FormControl>
                  <div className="flex items-center" style={{marginLeft:'0px'}}>
                    <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-700">Biaya Pengiriman</span>
                  </div>
                </FormItem>
              </RadioGroup>
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />
      {form.watch("step2.jenis_voucher") !== "Biaya Pengiriman" && (
        <FormField
          control={form.control}
          name="step2.jenis_Diskon"
          render={({ field }) => (
            <FormItem>
              <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-700">Jenis Diskon*</span>
              <FormControl>
                <RadioGroup
                  onValueChange={field.onChange}
                  defaultValue={field.value}
                  className="flex flex-col space-y-1"
                >
                  <FormItem className="flex items-center space-x-3 space-y-0 items-center">
                    <FormControl>
                      <RadioGroupItem className="mt-0" value="Nominal" />
                    </FormControl>
                   
                  <div style={{marginLeft:'0px'}}>
                    <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-700">Nominal (Rp)</span>
                  </div>
                  </FormItem>
                  <FormItem className="flex items-center space-x-3 space-y-0 items-center">
                    <FormControl>
                      <RadioGroupItem className="mt-0" value="Persentase" />
                    </FormControl>
                   
                    <div className="flex items-center" style={{marginLeft:'0px'}}>
                    <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-700">Presentase (%)</span>
                    </div>
                  </FormItem>
                </RadioGroup>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
      )}
      <FormField
        control={form.control}
        name="step2.diskon"
        render={({ field }) => (
          <FormItem className="space-y-2">
            <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-700">Diskon*</span>
            <FormControl>
              <div className="relative">
              {form.watch("step2.jenis_Diskon") === "Nominal" && (
                <>
                <div className="absolute left-3 top-1/2 -translate-y-1/2 font-semibold text-neutral-700">
                  Rp
                </div>
                <Input 
                  type="text" 
                  className="pl-[calc(1.5rem+theme(spacing.3))]" 
                  placeholder="Contoh : 1.000.000" 
                  value={form.watch("step2.diskon")
                    ? new Intl.NumberFormat('id-ID').format(parseInt(form.watch("step2.diskon")))
                    : ''
                  }
                  onChange={(e) => {
                    // Remove non-numeric characters
                    const numericValue = e.target.value.replace(/[^0-9]/g, '');
                    field.onChange(numericValue);
                  }}
                   />
                </>
              )}
              {form.watch("step2.jenis_Diskon") === "Persentase" && (
                <>
                <div className="absolute right-3 top-1/2 -translate-y-1/2 font-semibold text-neutral-700">
                  %
                </div>
                <Input 
                  type="number" 
                  className="pr-[calc(2rem+theme(spacing.3))]" 
                  placeholder="Contoh : 10" 
                  {...field} 
                  max="60"
                />
                </>
                )}
            
            </div>

            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />
      <FormField
        control={form.control}
        name="step2.minimun_pembelian"
        render={({ field }) => (
          <FormItem className="space-y-2">
            <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-700">Minimun Pembelian*</span>
            <FormControl>
            <div className="relative">
              <div className="absolute left-3 top-1/2 -translate-y-1/2 font-semibold text-neutral-700">
                    Rp
              </div>
              <Input 
                type="number" 
                className="pl-[calc(1.5rem+theme(spacing.3))] " 
                placeholder="Contoh : 1.000.000" 
                {...field} 
                value={ new Intl.NumberFormat('id-ID').format(parseInt(form.watch("step2.minimun_pembelian")))}
                onChange={(e) => {
                  // Remove non-numeric characters
                  const numericValue = e.target.value.replace(/[^0-9]/g, '');
                  field.onChange(numericValue);
                }}
                />
            </div>
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />
      {form.watch("step2.jenis_Diskon") === "Persentase" && (
        <FormField
          control={form.control}
          name="step2.maksimum_diskon.mode"
          render={({ field }) => (
            <FormItem className="space-x-2">
              <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-700">Maksimum Diskon</span>
              <FormControl>
                <RadioGroup
                  onValueChange={field.onChange}
                  defaultValue={field.value}
                  className="flex flex-col"
                  style={{marginLeft:"0px"}}
                >
                  <FormItem className="flex items-center space-x-3">
                    <FormControl>
                      <RadioGroupItem className="mt-0" value="tidak_terbatas" />
                    </FormControl>
                    <div style={{marginLeft:'0px'}}>

                    <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-700 ml-0">Tidak Terbatas</span>
                    </div>

                  </FormItem>
                  <FormItem className="flex items-center space-x-3">
                    <FormControl>
                      <RadioGroupItem className="mt-0" value="atur_batas" />
                    </FormControl>
                    <div style={{marginLeft:'0px'}}>

                    <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-700 ml-0">Atur Batas Maksimum Diskon</span>
                    </div>

                  </FormItem>
                </RadioGroup>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
      )}
      {form.watch("step2.maksimum_diskon.mode") === "atur_batas" && (
        <FormField
          control={form.control}
          name="step2.maksimum_diskon.value"
          render={({ field }) => (
            <FormItem>
              <FormControl>
                <Input
                  type="number"
                  placeholder="Masukkan nominal"
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
      )}
      <FormField
        control={form.control}
        name="step2.kuota_pemakaian"
        render={({ field }) => (
          <FormItem className="space-y-2">
            <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-700">Kuota Pemakaian*</span>
            <FormControl>
              <Input type="number" placeholder="Contoh:10" {...field} />
            </FormControl>
            <FormDescription>Maksimal penggunaan voucher</FormDescription>
            <FormMessage />
          </FormItem>
        )}
      />
      <FormField
        control={form.control}
        name="step2.kuota_pemakaian_per_pembeli"
        render={({ field }) => (
          <FormItem className="space-y-2">
            
            <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-700">Kuota Pemakaian per Pembeli*</span>

            <FormControl>
              <Input type="number" placeholder="Contoh:10" {...field} />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />
      <div className="flex gap-x-2">
        <Button
          // type="submit"
          onClick={prev}
          className="bg-white text-blue-500 w-full border-blue-500 border  rounded-full"
        >
          Sebelumnya
        </Button>
        <Button
          // type="submit"
          onClick={next}
          className="rounded-full bg-blue-500 text-white w-full "
        >
          Selanjutnya
        </Button>
      </div>
    </div>
  );
}
