"use client";
import { RadioGroup, RadioGroupItem } from "../../../../components/MobileCom/radio-group";
import { Button } from "../../../../components/MobileCom/button";
import {
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "../../../../components/MobileCom/form";
import { UseFormReturn } from "react-hook-form";
import { CreateVoucherSchema } from "../../../../schema";
import { Input } from "../../../../components/MobileCom/input";
import { useEffect,useState } from "react";
import { useRouter,useSearchParams } from "next/navigation"
import ChooseProduct from "../../_components/ChooseProduct";
import SelectedProductsPage from "./SelectedProductOnly";

export default function Third({form, prev, type}) {
  const [selectedProducts, setSelectedProducts] = useState([]);
  const router = useRouter(); // Assuming Next.js routing
  const searchParam = useSearchParams();
	const [isChooseOpen, setChooseOpen] = useState(false);
  const [isProductSelectedOnly, setProductSelectedOnlyOpen] = useState(false);

  const handleProductSelection = () => {
    localStorage.setItem('voucherFormData', JSON.stringify(form.getValues()));
    router.push('/buatVoucher/choose-product');
  };

  const handleProductSelectionOnly = ()=>{
    router.push('/buatVoucher/selected-product');
  }
   // Function to apply filters and close the filter page
  const handleApplyFilters = () => {
    const hasFilters = Object.values(filterCriteria).some((value) => value !== "");
    const finalFilters = hasFilters ? filterCriteria : {};
    setActiveFilters(finalFilters);
    setChooseOpen(false);
  };
  const fetchProducts = async () => {
    try {
      setIsLoading(true);
      const params = {
        page_size: 10,
        page: 1
      };
      const body = {
        search: searchQuery,
      };
      const response = await getProducts('/stores/98da2571-d600-4dc5-85e6-ee290bc193e4/products', body, process.env.NEXT_PUBLIC_AUTH_TOKEN);
      const data = response.Data.products;
      setProducts(data);
    } catch (error) {
      console.error('Failed to fetch products', error);
    } finally {
      setIsLoading(false);
    }
  };


  useEffect(() => {
    const savedProducts = localStorage.getItem('selectedProducts');
    const produk_tertentu = searchParam.get("produk_tertentu");

    if (savedProducts) {
      setSelectedProducts(JSON.parse(savedProducts));
      // localStorage.removeItem('selectedProducts'); // Clear after loading
    }
    console.log(produk_tertentu)
     // Set form value correctly
    if(produk_tertentu == "1") {
      form.setValue('step3.target_produk', 'produk_tertentu');
    }
  }, [searchParam]);
  return (
    <>
    <div className="space-y-6">
      <FormField
        control={form.control}
        name="step3.target_produk"
        render={({ field }) => (
          <FormItem>
            <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-700">Target Produk*</span>
            <FormControl>
              <RadioGroup
                onValueChange={field.onChange}
                value={field.value}
                className="flex flex-col space-y-1"
              >
                <FormItem className="flex space-x-3 space-y-0">
                  <FormControl>
                    <RadioGroupItem value="semua_produk" />
                  </FormControl>
                  <div  style={{marginLeft:'0px'}}>
                    <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-700">Semua Produk</span>
                    <FormDescription>
                      Voucher dapat digunakan untuk semua produk
                    </FormDescription>
                  </div>
                </FormItem>
                <FormItem className="flex space-x-3 space-y-0">
                  <FormControl>
                    <RadioGroupItem value="produk_tertentu" />
                  </FormControl>
                  <div style={{marginLeft:'0px'}}>
                  <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-700">Produk Tertentu</span>
                  <FormDescription>
                      Voucher hanya berlaku untuk produk terpilih
                    </FormDescription>
                  </div>
                </FormItem>
              </RadioGroup>
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />
      
      {form.watch("step3.target_produk") === "produk_tertentu" && (
        <>
          {selectedProducts.length === 0 ? (
            <div 
              className="mt-0 w-24 h-24 border-dotted border-2 border-gray-400 rounded-2xl flex items-center justify-center text-gray-500"
              style={{marginTop:0, marginLeft:"22px"}}
              onClick={handleProductSelection}
              // onClick={() => setChooseOpen(true)}

            >
              <div className="flex flex-col gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                </svg>
                <span className="text-[12px] text-neutral-700">Pilih</span>
              </div>
            </div>
          ) : (
            <div className="flex space-x-2">
              {selectedProducts.slice(0, 4).map((product,index,arr) => (
              <div key={product.ID} className="relative inline-block">
                <img 
                  key={product.ID} 
                  src={product.Photo} 
                  alt={product.Name} 
                  className="w-24 h-24 object-cover rounded-2xl"
       
                />
                {index === arr.length - 1 && (
                  <div 
                  onClick={handleProductSelectionOnly}
                  className="absolute rounded-2xl inset-0 flex items-center text-center justify-center bg-black bg-opacity-50 text-white"
                  >Lihat<br></br>Semua</div>
                  
                )}
              </div>
              
                
              ))}
              {/* {(selectedProducts.length > 3 || selectedProducts.length == 4) && (
                <div
                onClick={handleProductSelection}
                className="w-24 h-24 bg-gray-200 rounded-2xl flex items-center justify-center">
                  Lihat Semua
                </div>
              )} */}
              <SelectedProductsPage
                isProductSelectedOnly={isProductSelectedOnly}
                onProductSelectedOnlyClose={() => setProductSelectedOnlyOpen(false)}
                selectedProducts={selectedProducts}
              />
            </div>
          )}
        </>
      )}
      <div className="flex gap-x-2">
        <Button
          // type="submit"
          onClick={prev}
          className="bg-white text-blue-500 w-full border-blue-500 border rounded-xl"
        >
          Sebelumnya
        </Button>
        <Button
          type="submit"
          // onClick={next}
          className="rounded-xl bg-blue-500 text-white w-full"
        >
          Simpan
        </Button>
      </div>
    </div>
    </>
  );
}
