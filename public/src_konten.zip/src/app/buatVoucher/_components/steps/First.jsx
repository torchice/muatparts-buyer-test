"use client";
import { Input } from "../../../../components/MobileCom/input";
import { RadioGroup, RadioGroupItem } from "../../../../components/MobileCom/radio-group";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "../../../../components/MobileCom/popover";
import { cn } from "../../../../libs/utils";
import { CalendarIcon } from "lucide-react";
import { Calendar } from "../../../../components/MobileCom/calendar";
import dateFormater from "../../../../libs/formaters";
import { Button } from "../../../../components/MobileCom/button";
import {
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "../../../../components/MobileCom/form";
import { Fragment, useState } from "react";
import periode from "../../../../store/zustand/voucher/buatvoucher";
import "./DatePickerCustom.css"; // Custom styles for icons/margins
import CustomDatePicker from "../../../../components/MobileCom/custom-datepicker";
import { checkVoucherCodeUniqueness, getProfileSeller } from '../../../../services/voucher'; // Assume this is your API call function
import { useEffect } from "react";
import { addDays,format } from "date-fns";
import { useTranslation } from "@/context/TranslationProvider";
// Improvement fix wording Pak Brian
export default function First({ form, next, type }) {
  const {t} = useTranslation()
  const now = new Date();
  const maxDate = addDays(now,30);
  const [error, setError] = useState({});
  const [date, setDate] = useState(null)
  const [isCodeUnique, setIsCodeUnique] = useState(null);
  const [storePrefix, setStorePrefix] = useState('');
  const [selectedStartDate, setSelectedStartDate]=useState(now)
  const [selectedEndDate, setSelectedEndDate]=useState(maxDate)
 
  
  const currentTimePlaceholder = new Date().toLocaleString("en-US", {
    year: "numeric",
    month: "short",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
  const minutes = ["00", "15", "30", "45"]
  const hours = Array.from({ length: 24 }, (_, i) => 
    i.toString().padStart(2, "0")
  )

  const { 
    startDate,
    setStartDate,
    endDate,
    setEndDate,
  } = periode()
 
  const validateAddEditClosingSchedule = () => {
    // Reset errors
    setError({});
    
    // Validate inputs
    if (!startDate) {
      setError(prev => ({ ...prev, startDate: "Tanggal mulai wajib diisi" }));
      return;
    }
  }

  // Fetch store prefix when component mounts
  useEffect(() => {
    const fetchStorePrefix = async () => {
      try {
        const profileData = await getProfileSeller('/profile', process.env.NEXT_PUBLIC_AUTH_TOKEN);
        // Extract first 4 characters of store name and convert to uppercase
        const prefix = profileData.Data.storeInformation.storeName.slice(0, 4).toUpperCase();
        setStorePrefix(prefix);
        // console.log(storePrefix)
        // // Set initial form value with prefix
        // form.setValue('step1.kode', prefix);

        const currentCode = form.getValues('step1.kode');
        if (!currentCode) {
          form.setValue('step1.kode', prefix);
        }
      } catch (error) {
        console.error('Failed to fetch store prefix', error);
      }
    };

    fetchStorePrefix();
  }, []);
  const handleDateChange = (date, fieldName) => {
    form.setValue(`step1.${fieldName}`, date);
  };
  const handleNext = async () => {
    // Validate form first
    const isValid = await form.trigger('step1.kode');
    console.log("isValid",isValid)
    if (isValid ) {
      const code = form.getValues('step1.kode');
      try {
        const isUnique = await checkVoucherCodeUniqueness(`/voucher/check-voucher/${code}`,process.env.NEXT_PUBLIC_AUTH_TOKEN);
        console.log("isUnique ",isUnique.Data)

        if (isUnique.Data === true) {
          // Set error if code is not unique
          form.setError('step1.kode', {
            type: 'manual',
            message: 'Kode voucher sudah digunakan'
          });
          setIsCodeUnique(false);
          return;
        }
        
        // If code is unique, proceed to next step
        setIsCodeUnique(true);
        next();
      } catch (error) {
        form.setError('step1.kode', {
          type: 'manual',
          message: 'Gagal memeriksa kode. Coba lagi.'
        });
      }
    }
  };
  
  return (
    <div className="flex flex-col gap-4">
      <div className="flex-grow overflow-y-auto">
        <FormField
          control={form.control}
          name="step1.nama"
          render={({ field }) => {
            const charCount = form.watch("step1.nama")?.length || 0;
            const MAX_CHARACTERS = 60;
            return (
              <FormItem>
                <div className="space-y-2">
                  
                  <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-700">Nama Voucher*</span>
                  <FormControl>
                  <Input placeholder="Contoh : Diskon Tahun Baru"  
                    {...field}
                    maxLength={MAX_CHARACTERS}
                    onChange={(e) => {
                      const value = e.target.value.slice(0, MAX_CHARACTERS);
                      field.onChange(value);
                    }} />
                  </FormControl>
                  <div className="flex justify-between space-x-4">
                    <FormDescription>
                      Catatan: Nama Voucher tidak tampil di sisi pembeli
                    </FormDescription>
                    <div
                      className={cn(
                        "text-sm",
                        charCount > MAX_CHARACTERS
                          ? "text-red-500"
                          : "text-[#7B7B7B]"
                      )}
                    >
                      {charCount}/{MAX_CHARACTERS}
                    </div>
                  </div>
                  <FormMessage />

                </div>
              </FormItem>
            );
          }}
        />
       <FormField
        control={form.control}
        name="step1.kode"
        render={({ field }) => {
          
          
          return (
            <FormItem>
              <div className="space-y-2">
                <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-700">Kode*</span>
                <FormControl>
                <div className="relative">
                  <div className="absolute left-3 top-1/2 -translate-y-1/2 font-semibold text-neutral-700">
                    {storePrefix}
                  </div>
                  <Input
                    placeholder="8 karakter terakhir"
                    {...field}
                    maxLength={8}
                    className="pl-[calc(3rem+theme(spacing.3))] uppercase placeholder:capitalize"
                    onChange={(e) => {
                      // Only allow input for last 4 characters
                      const value = e.target.value.slice(0, 8).toUpperCase();
                      form.setValue('step1.kode', `${storePrefix}${value}`);
                    }}
                    value={field.value.slice(4)} 
                  />
                </div>
                </FormControl>
              
                <FormMessage />
              </div>
            </FormItem>
          );
        }}
      />
        <FormField
          control={form.control}
          name="step1.target_produk"
          render={({ field }) => (
            <FormItem>
                <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-700">Target Produk*</span>
                <FormControl>
                <RadioGroup
                  onValueChange={field.onChange}
                  defaultValue={field.value}
                  className="flex flex-col "
                >
                  <FormItem className="flex space-y-0">
                    <FormControl>
                      <RadioGroupItem value="Publik" />
                    </FormControl>
                    <div className="ml-0">
                    <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-700 mb-2">Publik</span>
                    <FormDescription className="mt-[0.3rem]">
                        Semua pembeli dapat melihat dan menggunakan voucher
                      </FormDescription>
                    </div>
                  </FormItem>
                  <FormItem className="flex space-y-0">
                    <FormControl>
                      <RadioGroupItem value="Terbatas" />
                    </FormControl>
                    <div>
                    <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-700">Terbatas</span>
                      <FormDescription className="mt-[0.3rem]">
                        Hanya pembeli yang kamu berikan kode, dapat menggunakan
                        voucher
                      </FormDescription>
                    </div>
                  </FormItem>
                </RadioGroup>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="step1.masa_berlaku_awal"
          render={({ field }) => (
            <FormItem className="flex flex-col">
             
             <div className="space-y-2">
                <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-700">Masa Berlaku Awal*</span>
                  
                <CustomDatePicker
                  // selected={selectedStartDate}
                  // onChange={(date)=>setSelectedStartDate(date)}
                  selected={field.value}
                  onChange={(date) => handleDateChange(date, 'masa_berlaku_awal')}
                  minDate={new Date()} // If you want to disable past dates
                  dateFormat="dd MMM yyyy HH:mm"
                  showTimeSelect
                  timeIntervals={15}
                />
              </div>
            </FormItem>
            
          )}
        />
        <input  control={form.control} type="hidden" name="step1.masa_berlaku_awal" value={selectedStartDate?format(selectedStartDate,"yyyy-MM-dd HH:mm"):""}/>

        <FormField
          control={form.control}
          name="step1.masa_berlaku_akhir"
          render={({ field }) => (
            <FormItem className="flex flex-col">
               <div className="space-y-2">
                <span className="font-semibold text-[14px] leading-[15.4px] text-neutral-700">Masa Berlaku Akhir*</span>
                  
                <CustomDatePicker
                  // selected={selectedEndDate}
                  // onChange={(date)=>setSelectedEndDate(date)}
                  selected={field.value}
                  onChange={(date) => handleDateChange(date, 'masa_berlaku_akhir')}
                  minDate={startDate || new Date()}
                  dateFormat="dd MMM yyyy HH:mm"
                  showTimeSelect
                  timeIntervals={15}
                />
              </div>
            </FormItem>
          )}
        />
      </div>
      <div className="mt-auto flex justify-end">
        <Button
          onClick={handleNext}
          className="rounded-full bg-blue-500 text-white w-full "
        >
          {t("PusatPromosiKelolaVoucherFormVoucherDetailResponsiveSelanjutnya")}
        </Button>
      </div>
    </div>
  );
}
