"use client";
import { CreateVoucherSchema } from "../../schema";
import Nav from "./_components/Nav";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { Form } from "../../components/MobileCom/form";
import { addDays, addMinutes, format } from "date-fns";
import First from "./_components/steps/First";
import { useEffect, useState } from "react";
import Second from "./_components/steps/Second";
import Third from "./_components/steps/Third";
import { useHeader } from '../../common/ResponsiveContext'
import { storeVoucher , getDetailVoucher} from '../../services/voucher'; 
import toast from '@/store/zustand/toast'; // Import the zustand store
import { useRouter, useSearchParams } from "next/navigation"

export default function Page() {
  const router = useRouter();
  const searchParam = useSearchParams();
  const type = searchParam.get("type");
  const id = searchParam.get("id");
  const stepParam = searchParam.get("currentStep");
  const { setShowToast, setDataToast } = toast(); // Destructure methods from zustand store

  const now = new Date();
  const defaultStartDate = addMinutes(now, 15);
  const [currentStep, setCurrentStep] = useState(stepParam ? parseInt(stepParam) : 1);
  const defaultEndDate = addDays(defaultStartDate, 30);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
	const {
		appBarType, //pilih salah satu : 'header_title_secondary' || 'header_search_secondary' || 'default_search_navbar_mobile' || 'header_search' || 'header_title'
		appBar, // muncul ini : {onBack:null,title:'',showBackButton:true,appBarType:'',appBar:null,header:null}
		renderAppBarMobile, // untuk render komponen header mobile dengan memasukkanya ke useEffect atau by trigger function / closer
		setAppBar, // tambahkan payload seperti ini setAppBar({onBack:()=>setScreen('namaScreen'),title:'Title header',appBarType:'type'})
		handleBack, // dipanggil di dalam button di luar header, guna untuk kembali ke screen sebelumnya 
		clearScreen,// reset appBar
		setScreen, // set screen
		screen, // get screen,
		search, // {placeholder:'muatparts',value:'',type:'text'}
		setSearch, // tambahkan payload seperti ini {placeholder:'Pencarian',value:'',type:'text'}
	}=useHeader()
  
  const form = useForm({
    resolver: zodResolver(CreateVoucherSchema),
    defaultValues: {
      step1: {
        nama: "",
        kode: "",
        target_produk: "Publik",  
        masa_berlaku_awal: new Date(),
        masa_berlaku_akhir: new Date(Date.now() + (30 * 24 * 60 * 60 * 1000)),
      
      },
      step2: {
        jenis_voucher: "Diskon Produk",
        jenis_Diskon: "Nominal",
        diskon: "",
        minimun_pembelian: "",
        kuota_pemakaian: "",
        kuota_pemakaian_per_pembeli: "",
        maksimum_diskon: { mode: "tidak_terbatas", value: "" },
      },
      step3: {
        target_produk: "semua_produk",
        gambar_produk: "",
      },
    },
  });


  const next = async () => {
    const fieldsToValidate = `step${currentStep}`;
    const isValid = await form.trigger(fieldsToValidate);
    console.log(isValid)
    if (isValid && currentStep < 3) {
    // if(currentStep < 3){
      router.push(`/buatVoucher?currentStep=${currentStep + 1}`);

      setCurrentStep((step) => step + 1);

    }
  };
  const prev = () => {
    if (currentStep > 0){
      setCurrentStep((step) => step - 1);
      router.push(`/buatVoucher?currentStep=${currentStep - 1}`);
    }

  };
    // Load saved form data when component mounts
  useEffect(() => {
    var title ="Buat Voucher";
    if(type == 'salin')
      title = 'Buat Voucher';
    else if(type == 'ubah')
      title = 'Ubah Voucher';

    setAppBar({
      title:title,
      appBarType:'header_title',
    })
      const savedFormData = localStorage.getItem('voucherFormData');
      console.log(savedFormData)
      if (savedFormData) {
        try {
          const parsedData = JSON.parse(savedFormData);
          
          // Convert date strings back to Date objects
          if (parsedData.step1) {
            if (parsedData.step1.masa_berlaku_awal) {
              parsedData.step1.masa_berlaku_awal = new Date(parsedData.step1.masa_berlaku_awal);
            }
            if (parsedData.step1.masa_berlaku_akhir) {
              parsedData.step1.masa_berlaku_akhir = new Date(parsedData.step1.masa_berlaku_akhir);
            }
          }
          
          form.reset(parsedData);
  
          if (stepParam === '3') {
            setCurrentStep(3);
          }
        } catch (error) {
          console.error('Error parsing saved form data:', error);
        }
      }
  }, []);
  
  useEffect(() => {
    const subscription = form.watch((formData) => {
      if (formData) {
        try {
          // Create a copy of the form data to modify
          const dataToSave = JSON.parse(JSON.stringify(formData));
          
          // Ensure dates are properly formatted before saving
          if (dataToSave.step1) {
            if (dataToSave.step1.masa_berlaku_awal) {
              dataToSave.step1.masa_berlaku_awal = new Date(dataToSave.step1.masa_berlaku_awal).toISOString();
            }
            if (dataToSave.step1.masa_berlaku_akhir) {
              dataToSave.step1.masa_berlaku_akhir = new Date(dataToSave.step1.masa_berlaku_akhir).toISOString();
            }
          }
          
          localStorage.setItem('voucherFormData', JSON.stringify(dataToSave));
        } catch (error) {
          console.error('Error saving form data:', error);
        }
      }
    });

    return () => subscription.unsubscribe();
  }, [form.watch]);

 // Fetch voucher data when in copy mode
  useEffect(() => {
      const fetchVoucherData = async () => {
    
      if ((type === 'salin' || type==='ubah' )&& id) {
        setIsLoading(true);
        try {
          const response = await getDetailVoucher(`/voucher/${id}`, process.env.NEXT_PUBLIC_AUTH_TOKEN);

          const data = response.Data;
          
          // Pre-fill the form with existing data
          form.reset({
            step1: {
              nama: `${data.voucher_name}`,
              kode: `${type === "salin"? '': data.code}`,
              target_produk: data.target,
              masa_berlaku_awal: new Date(Date.now() + (15* 60 * 1000)), // Use new dates for the copy
              masa_berlaku_akhir:  new Date(Date.now() + (30 * 24 * 60 * 60 * 1000)),
            },
            step2: {
              jenis_voucher: data.voucher_type,
              jenis_Diskon: data.discount_type,
              diskon: data.discount_value,
              minimun_pembelian: data.minimum_transaction,
              kuota_pemakaian: data.usage_quota,
              kuota_pemakaian_per_pembeli: data.usage_limit_user,
              maksimum_diskon: {
                mode: data.is_unlimited ? "tidak_terbatas" : "terbatas",
                value: data.discount_max || "",
              },
            },
            step3: {
              target_produk: data.is_all_product ? "semua_produk" : "produk_tertentu",
              gambar_produk: "",
            },
          });
        } catch (error) {
          console.error('Error fetching voucher data:', error);
          toast.error('Gagal mengambil data voucher');
        } finally {
          setIsLoading(false);
        }
      }
    };

    fetchVoucherData();
  }, [type, id, form]);
  async function onSubmit(values) {
    console.log("onSubmit started", values);
  
    try {
      // Return early if not on final step or already submitting
      if (currentStep !== 3) {
        console.log("Not on final step, returning");
        return;
      }
  
      // if (isSubmitting) {
      //   console.log("Already submitting, returning");
      //   return;
      // }
  
      setIsSubmitting(true);
  
      // Calculate is_unlimited and maximum_discount
      const is_unlimited = values.step2.jenis_Diskon === 'Nominal' 
        ? true 
        : values.step2.maksimum_diskon.mode === "tidak terbatas";
      
      const maksimum_discount = values.step2.jenis_Diskon === 'Nominal' 
        ? 0 
        : (values.step2.maksimum_diskon.mode === "tidak terbatas" ? 0 : values.step2.maksimum_diskon.value);
  
      // Get and update stored form data
      const products = localStorage.getItem('selectedProducts');
      let productList = [];
      
      if (products) {
        const updatedFormData = JSON.parse(products);
        productList = updatedFormData.map((p) => p.ID);
       
      }
  
      const body = {
        voucher_name: values.step1.nama,
        code: values.step1.kode,
        target: values.step1.target_produk,
        start_date: format(values.step1.masa_berlaku_awal, "yyyy-MM-dd HH:mm:ss"),
        end_date: format(values.step1.masa_berlaku_akhir, "yyyy-MM-dd HH:mm:ss"),
        voucher_type: values.step2.jenis_voucher,
        discount_type: values.step2.jenis_Diskon,
        discount_value: values.step2.diskon,
        transaction_min: values.step2.minimun_pembelian,
        discount_max: maksimum_discount,
        is_unlimited: is_unlimited,
        is_all_product: values.step3.target_produk === 'semua_produk',
        usage_quota: values.step2.kuota_pemakaian,
        usage_limit_user: values.step2.kuota_pemakaian_per_pembeli,
        productList: values.step3.target_produk === 'produk_tertentu' ? productList : []
      };
  
      let response;
      if (type === 'update') {
        response = await updateVoucher('/voucher', body, process.env.NEXT_PUBLIC_AUTH_TOKEN);
      } else {
        response = await storeVoucher('/voucher', body, process.env.NEXT_PUBLIC_AUTH_TOKEN);
      }
  
      if (response.Data) {
        localStorage.removeItem('voucherFormData');
        setDataToast({
          type: 'success',
          message: 'Voucher berhasil dibuat'
        });
        setShowToast(true);
        router.push('/voucherseller/aktif');

        
        return;
      } else {
        throw new Error('Response data is empty');
      }
  
    } catch (error) {
      console.error("Error submitting voucher:", error);
      setDataToast({
        type: 'error',
        message: error.message || 'Terjadi kesalahan saat membuat voucher'
      });
      setShowToast(true);
    } finally {
      setIsSubmitting(false);
    }
  }
  return (
    <section className="bg-white max-w-screen-sm min-h-fit  mx-auto">
      <Nav step={currentStep} />
      <div className=" px-4 py-4">
        <Form {...form}>
          <form 
          onSubmit={async (e) => {
            e.preventDefault();
            console.log("Form submitted"); 

            // Add validation check here
            const isValid = await form.trigger();
            console.log("Form validation:", isValid);
            console.log("Form errors:", form.formState.errors);
            
            // if (isValid) {
               const values = form.getValues();
              onSubmit(values);
            // }
          }}
          >
            {currentStep === 1 && <First form={form} next={next} />}
            {currentStep === 2 && (
              <Second form={form} next={next} prev={prev} />
            )}
            {currentStep === 3 && <Third form={form} prev={prev}             
            // isSubmitting={isSubmitting}

            />}
          </form>
        </Form>
      </div>
    </section>
  );
}
