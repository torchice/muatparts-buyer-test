import Bubble from '@/components/Bubble/Bubble'
import ButtonBottomMobile from '@/components/ButtonBottomMobile/ButtonBottomMobile'
import { capitalizeText } from '@/libs/TypographServices'
import React, { useEffect, useState } from 'react'

function FilterkelolaPesanan({data, getFilterData,onBatal,onSimpan}) {
  const [getFilter,setFilter]=useState()
  function handleSetFilter(field,value) {
    if(getFilter?.[field]===value) setFilter(a=>({...a,[field]:''}))
    else setFilter(a=>({...a,[field]:value}))
  }
  useEffect(()=>{
    if(!getFilter) setFilter(data.reduce((acc, item) => {
      acc[item.key] = getFilterData[item.key]
      return acc
  }, {}))
  },[data])
  return (
    <div className='flex flex-col w-full bg-neutral-50 py-5 px-4 text-neutral-900 gap-5'>
     {data?.map(val=><div key={val?.key} className='flex flex-col gap-4 pb-5'>
        <span className='semi-sm'>{capitalizeText(val?.type)}</span>
        <div className='flex flex-wrap gap-2'>
          {val?.options?.map(op=> <Bubble key={op.value} onClick={()=>handleSetFilter(val?.key,op?.value)} classname={`${getFilter?.[val?.key]===op?.value?'!bg-primary-50':'!text-neutral-900 !bg-neutral-200 border-transparent'}`}>{op?.value}</Bubble>)}
        </div>
      </div>)}
      <ButtonBottomMobile textLeft={'Batal'} textRight={'Simpan'} onClickLeft={onBatal} onClickRight={()=>onSimpan(getFilter)} />
    </div>
  )
}

export default FilterkelolaPesanan
