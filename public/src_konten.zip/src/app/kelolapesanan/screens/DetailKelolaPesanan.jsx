import { useHeader } from '@/common/ResponsiveContext'
import Button from '@/components/Button/Button'
import ButtonBottomMobile from '@/components/ButtonBottomMobile/ButtonBottomMobile'
import { CardManageOrderDetailMobile } from '@/components/CardManageOrderMobile/CardManageOrderMobile'
import IconComponent from '@/components/IconComponent/IconComponent'
import { formatDate } from '@/libs/DateFormat'
import { numberFormatMoney } from '@/libs/NumberFormat'
import toast from '@/store/zustand/toast'
import React, { useEffect } from 'react'

function DetailKelolaPesanan({
  status, 
  statusBuyer, 
  cancellationDate, 
  paymentDate, 
  completionDate, 
  languageID, 
  buyerInfo, 
  shippingInfo, 
  orderDetails, 
  serviceFees, 
  pricing,
  onClickTrack,
  onCLickChat,
  downloadInvoice
}) {
  const {setShowNavMenu}=toast()
  useEffect(()=>{setShowNavMenu(false)},[])
  return (
    <div className='flex flex-col gap-2 w-full text-neutral-900 bg-neutral-200 pb-[70px]'>
      <div className='py-6 px-4 flex flex-col gap-4 bg-neutral-50'>
        <div className='flex justify-between pb-4 border-b border-neutral-400 items-center'>
          <span className='medium-xs text-neutral-600'>Nama Pembeli</span>
          <span className='semi-xs'>{buyerInfo?.name}</span>
        </div>
        <div className='flex justify-between pb-4 border-b border-neutral-400 items-center'>
          <span className='medium-xs text-neutral-600'>Kurir</span>
          <span className='semi-xs'>{buyerInfo?.shippingName}</span>
        </div>
        <div className='flex justify-between pb-4 border-b border-neutral-400 items-center'>
          <span className='medium-xs text-neutral-600'>Tanggal Pesanan</span>
          <span className='semi-xs'>{formatDate(buyerInfo?.orderTime)}</span>
        </div>
        <div className='flex justify-between pb-4 border-b border-neutral-400 items-center'>
          <span className='medium-xs text-neutral-600'>No. Invoice</span>
          <span className='semi-xs flex gap-1 text-primary-700' onClick={downloadInvoice}>{buyerInfo?.invoiceNumber} <span><IconComponent src={'/icons/download.svg'} classname={'icon-blue'} /></span></span>
        </div>
      </div>
      <div className='py-6 px-4 flex justify-between items-center bg-neutral-50' onClick={()=>onCLickChat(buyerInfo?.usersId)}>
        <div className='flex gap-3 items-center'>
          <IconComponent src={'/icons/chat.svg'} width={24} height={24} />
          <span className='semi-sm'>Chat Pembeli</span>
        </div>
        <IconComponent src={'/icons/chevron-right.svg'} width={24} height={24} />
      </div>
      <div className='py-6 px-4 flex flex-col gap-6 bg-neutral-50'>
        <span className='semi-sm'>Rincian Pesanan</span>
        {
          orderDetails?.map(val=><CardManageOrderDetailMobile image={val?.productImage} afterPrice={val?.discountedPrice} beforePrice={val?.basePrice} name={val?.name} tipe={val?.type} SKU={val?.sku} amount={val?.quantity} productName={val?.name} discount={val?.discountPercentage} />)
        }
        
        {orderDetails?.length>1&&<span className='semi-xs text-primary-700 self-end'>+{products?.length-1} produk lainnya</span>}
      </div>
      <div className='py-6 px-4 flex flex-col gap-6 bg-neutral-50'>
        <span className='flex justify-between items-center'>
          <span className='semi-sm'>Rincian Pembayaran</span>
          <span className='bold-sm'>{numberFormatMoney(pricing?.grandTotal)}</span>
        </span>
        <div className='flex flex-col gap-4'>
          <span className='flex justify-between items-center pb-4 border-b border-neutral-400'>
            <span className='medium-xs text-neutral-600'>Total Harga ({orderDetails?.length} item)</span>
            <span className='semi-sm whitespace-nowrap'>{numberFormatMoney(pricing?.totalProductsPrice)}</span>
          </span>
          {pricing?.vouchers?.map(val=><span className='flex justify-between items-center '>
            <span className='medium-xs text-neutral-600'>{val?.title} {`(${val?.code})`}</span>
            <span className='semi-sm whitespace-nowrap'>-{numberFormatMoney(val?.claimedAmount)}</span>
          </span>)}
          {<span className='flex justify-between items-center '>
            <span className='medium-xs text-neutral-600'>Biaya Pengiriman ({pricing?.shippingDetails?.name} - {pricing?.shippingDetails?.weight/1000}Kg)</span>
            <span className='semi-sm whitespace-nowrap'>-{numberFormatMoney(pricing?.shippingDetails?.cost)}</span>
          </span>}
          {serviceFees?.breakdown?.map(val=><span className='flex justify-between items-center '>
            <span className='medium-xs text-neutral-600'>{val?.description}</span>
            <span className='semi-sm whitespace-nowrap'>-{numberFormatMoney(val?.serviceFee)}</span>
          </span>)}
        </div>
      </div>
      <div className='py-6 px-4 flex justify-between items-center bg-neutral-50' onClick={()=>{}}>
        <div className='flex gap-3 items-center' onClick={onClickTrack}>
          <IconComponent src={'/icons/posisi-truk.svg'} width={24} height={24} />
          <span className='semi-sm'>Lacak Pesanan</span>
        </div>
        <IconComponent src={'/icons/chevron-right.svg'} width={24} height={24} />
      </div>
      <ButtonBottomMobile classname={'py-3 px-4'} isSingleButton textSingleButton={'Chat Pembeli'} onClickSingleButton={()=>onCLickChat(buyerInfo?.usersId)} />
    </div>
  )
}

export default DetailKelolaPesanan
