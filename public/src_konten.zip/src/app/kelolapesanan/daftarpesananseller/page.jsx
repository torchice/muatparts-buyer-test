"use client";
// LBM - Bahasa - Andrew - 16 April 2025
import { useEffect, useState, useMemo, useRef, useCallback, useContext } from "react";
import { useRouter } from "next/navigation";
import SWRHandler from "@/services/useSWRHook";
import { serializeParam } from "@/components/KelolaPesananComponent/shared/utils/query-params";

// Components
import EmptyPage from "@/components/KelolaPesananComponent/404/emptyPage";
import { DialogComponents, Modal, Snackbar } from "@/components/KelolaPesananComponent/dialog";
import { BottomSheet } from "@/components/KelolaPesananComponent/dialog/bottom-sheet";
import Divider from "@/components/KelolaPesananComponent/divider";
import NavbarCover from "@/components/KelolaPesananComponent/navbar";
import OrderCard from "@/components/KelolaPesananComponent/OrderCard";
import OrderHeader from "@/components/KelolaPesananComponent/OrderHeader";
import OrderTabs from "@/components/KelolaPesananComponent/OrderTabs";
import OrderSearch from "@/components/KelolaPesananComponent/SearchBar";
import Pagination from "@/components/KelolaPesananComponent/pagination";
import Tooltip from "@/components/KelolaPesananComponent/tooltip";
import ProductCard from "@/components/KelolaPesananComponent/product";
import MobileFilter from "@/components/KelolaPesananComponent/MobileFilter";
import MobileHeader from "@/components/KelolaPesananComponent/MobileHeader";
import MobileOrderCard from "@/components/KelolaPesananComponent/MobileOrderCard";
import ModalSearch from "@/components/KelolaPesananComponent/ModalSearch";
import FilterBubbles from "@/components/KelolaPesananComponent/FilterBubbles";
import OrderModal from "@/components/KelolaPesananComponent/OrderModal";

// Input components
import { Button } from "@/components/KelolaPesananComponent/inputs/Button";
import { Select } from "@/components/KelolaPesananComponent/inputs/Select";
import CheckboxComponents from "@/components/KelolaPesananComponent/inputs/Checkbox";
import RadioButton from "@/components/KelolaPesananComponent/inputs/RadioButton";

// Data and utilities
import { setupAll, sortFilter, rejectionOptions } from "@/components/KelolaPesananComponent/helper/data";
import { ICCross, ICChevron } from '@/icons/kelolapesanan';
import ReasonOption from "@/components/KelolaPesananComponent/reject/RejectionOptions";

// Styles
import "@/components/KelolaPesananComponent/kelolapesanan.css";

import toast from "@/store/zustand/toast";
import headerZustand from "@/store/zustand/header";

import { useSearchParams } from 'next/navigation';

const baseUrl = `${process.env.NEXT_PUBLIC_GLOBAL_API}v1/`;

import { useTranslation } from "@/context/TranslationProvider";
import SkeletonDaftarPesanan from "@/components/KelolaPesananComponent/SkeletonDaftarPesanan";

// 25.03 Web Ronda LB - 0412, MP - 031 LB - 0024, LB - 0036, LB - 0037, LB - 0038, LB - 0066

// Empty State Component
const EmptyStateComponent = () => (
  <div className="flex flex-col items-center justify-center py-16 w-full">
    <img 
      src="https://cdn.builder.io/api/v1/image/assets/TEMP/e56003d2e26d34a23f0a057eda0f76ee60d7832636865b090433bac418ab20d1?placeholderIfAbsent=true&apiKey=101831f9da794d2185db89ca983a5462" 
      alt="Empty box" 
      className="w-[96px] h-[77px] mb-4"
    />
    <h3 className="text-base font-medium text-gray-800 mb-1">
      Belum ada Pesanan yang masuk
    </h3>
    <div className="text-sm text-gray-500 text-center whitespace-nowrap">
      Tetap berjuang, rezeki akan datang asalkan kamu tidak putus asa.
    </div>
  </div>
);

// Empty Tab State Component
const EmptyTabState = () => {
  return (
    <div className="flex flex-col justify-center items-center self-stretch px-6 py-20 leading-tight text-center bg-white rounded-xl shadow-sm text-neutral-500 max-md:px-5">
      <div className="flex flex-col items-center">
        <div className="flex flex-col items-center">
          <img
            loading="lazy"
            src="/kelolapesanan/icon-empty-data.svg"
            alt="Tidak ada data"
            className="object-contain w-20 h-20 mb-3"
            onError={(e) => {
              // Fallback jika gambar tidak ditemukan
              e.target.src = "https://cdn.builder.io/api/v1/image/assets/TEMP/e56003d2e26d34a23f0a057eda0f76ee60d7832636865b090433bac418ab20d1?placeholderIfAbsent=true&apiKey=101831f9da794d2185db89ca983a5462";
              e.target.className = "object-contain w-[96px] h-[77px] mb-3";
            }}
          />
          <div className="mt-3 text-base font-semibold" role="heading" aria-level="2">
            Tidak ada data
          </div>
        </div>
      </div>
    </div>
  );
};



function OrdersPage() {
  // Improvement Skeleton Wahyu
  const { t, tOrEmpty, langReady } = useTranslation();
  
  const router = useRouter();
  const { useSWRHook, useSWRMutateHook } = SWRHandler;
  
  // Core state
  const [ordersData, setOrdersData] = useState([]);
  const [filteredOrders, setFilteredOrders] = useState([]);
  // const [activeType, setActiveType] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  const { setShowNavMenu } = toast();
  const { setHeader, setBackIcon, setDataMatrix, dataMatrix } = headerZustand();
  
  // Infinite scroll state
  const observerTarget = useRef(null);
  const [hasMore, setHasMore] = useState(true);
  const [isMobileLoading, setIsMobileLoading] = useState(false);
  
  // Search and filter state
  const [searchQuery, setSearchQuery] = useState({
    isFiltered: false,
    searchInput: "",
    aturMassal: "",
  });
  const [sort, setSort] = useState();
  const [dateFilter, setDateFilter] = useState({
    start_date: undefined,
    end_date: undefined
  });
  const [filterData, setFilterData] = useState({
    pengiriman: [],
    jasa_pengiriman: [], 
    batas_respon: [],
    status: []
  });
  
  // Mobile UI state
  const [openSort, setOpenSort] = useState(false);
  const [openFilter, setOpenFilter] = useState(false);
  
  // Bulk operations state
  const [bulkSettingOrder, setBulkSettingOrder] = useState();
  const [openBulkSetting, setOpenBulkSetting] = useState(false);
  const [isBulkAccept, setIsBulkAccept] = useState();
  const [isBulkLoading, setIsBulkLoading] = useState(false);
  
  // Modal state
  const [modalAturMassal, setModalAturMassal] = useState(false);
  const [activeAturMassal, setActiveAturMassal] = useState({
    label: tOrEmpty("WebKelolaPesananSellerMuatpartsCetakInvoice"),
    value: "1",
  });
  const [modalAction, setModalAction] = useState(false);
  const [isRejectModalOpen, setIsRejectModalOpen] = useState(false);
  const [otherReason, setOtherReason] = useState('');
  const [activeModal, setActiveModal] = useState({
    type: '', // 'invoice', 'download', 'accept', 'reject'
    title: '',
    isOpen: false
  });
  
  // Rejection state
  const [selectedReason, setSelectedReason] = useState(null);
  const [rejectProductId, setRejectProductId] = useState(null);
  const [typeReject, setTypeReject] = useState("firstPopup");
  const [snackbarMessage, setSnackbarMessage] = useState();
  
  // Bulk Rejection State
  const [rejectReasonStep, setRejectReasonStep] = useState("confirmation"); // "confirmation" atau "reasonSelect"
  const [otherReasonDescription, setOtherReasonDescription] = useState("");
  const [reasonValidation, setReasonValidation] = useState({
    reasonRequired: false,
    descriptionRequired: false
  });
  
  // Modal state for new unified modal approach
  const [selectedOrderIds, setSelectedOrderIds] = useState([]);
  
  // Pickup modals state
  const [pickupModalOpen, setPickupModalOpen] = useState(false);
  const [pickupOption, setPickupOption] = useState('siap');
  const [processingAction, setProcessingAction] = useState(false);

  // Device detection - Using window size for mobile detection
  const [isMobile, setIsMobile] = useState(false);

  const searchParams = useSearchParams();
  
  // Ambil parameter tab dari URL saat komponen pertama kali dimuat
  const initialTab = searchParams.get('tab') || 'all';
  
  // Gunakan initialTab untuk inisialisasi activeType
  const [activeType, setActiveType] = useState(initialTab);
  
  // Kode lainnya...

  // Tambahkan useEffect untuk mendeteksi perubahan parameter URL
  useEffect(() => {
    const tabParam = searchParams.get('tab');
    if (tabParam) {
      // Log untuk debugging
      console.log('Tab parameter detected:', tabParam);
      
      // Set activeType langsung dari parameter URL
      setActiveType(tabParam);
      
      // Reset halaman ke 1 untuk memastikan kita memulai dari awal
      setCurrentPage(1);
      
      // Paksa mutate data untuk refresh
      if (ordersMutate) {
        ordersMutate();
      }
    }
  }, [searchParams]);

  useEffect(() => {
    // Function to check if screen size is mobile
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 1024); // 1024px matches lg: breakpoint in Tailwind
    };
    
    // Check on first render
    if (typeof window !== 'undefined') {
      checkMobile();
      
      // Set up listener for window resize
      window.addEventListener('resize', checkMobile);
      
      // Clean up
      return () => window.removeEventListener('resize', checkMobile);
    }
  }, []);

  // API request parameters
  const params = useMemo(() => serializeParam({
    page: currentPage,
    limit: itemsPerPage,
    shipping_method: filterData?.pengiriman?.filter(e => e?.selected)?.map(e => e?.id),
    courier: filterData?.jasa_pengiriman?.filter(e => e?.selected)?.map(e => e?.id),
    response_limit: filterData?.batas_respon?.filter(e => e?.selected)?.map(e => e?.id),
    search: searchQuery?.searchInput,
    status: activeType === 'all' ? undefined : activeType,
    sort,
    start_date: dateFilter?.start_date, // Tambahkan parameter tanggal mulai
    end_date: dateFilter?.end_date // Tambahkan parameter tanggal akhir
  }), [currentPage, itemsPerPage, filterData, searchQuery, activeType, sort, dateFilter]);

  // SWR data fetching hooks
  const {
    data: orders,
    error: orders_error,
    isLoading: orders_loading,
    mutate: ordersMutate
  } = useSWRHook(
    `${baseUrl}muatparts/orders?${params}`,
    null,
    (error) => {
      console.log("Orders fetch error:", error);
    }
  );

  const {
    data: filtersData,
    error: filters_error,
    isLoading: filters_loading,
  } = useSWRHook(
    `${baseUrl}muatparts/seller/orders/filter${activeType ? `?tab=${activeType}` : ''}`,
    null,
    (error) => {
      console.log("Filters fetch error:", error);
    }
  );

  // API mutation hooks
  const { trigger: triggerInvoiceDownload, isMutating: isDownloadingInvoice } = useSWRMutateHook(
    `${baseUrl}muatparts/seller/orders/download-invoices`,
    "POST"
  );
  
  const { trigger: triggerDownloadOrders } = useSWRMutateHook(
    `${baseUrl}muatparts/seller/orders/download-reports`,
    "POST"
  );
  
  const { trigger: triggerAcceptOrders, isMutating: isAcceptingOrders } = useSWRMutateHook(
    `${baseUrl}muatparts/seller/orders/approve`,
    "POST"
  );
  
  const { trigger: triggerRejectOrders, isMutating: isRejectingOrders } = useSWRMutateHook(
    `${baseUrl}muatparts/seller/orders/reject`,
    "POST"
  );
  
  const { trigger: triggerRequestPickup, isMutating: isRequestingPickup } = useSWRMutateHook(
    `${baseUrl}muatparts/seller/orders/request-pickup`,
    "POST"
  );

  const { trigger: triggerReject, isMutating: isRejecting } = useSWRMutateHook(
    `${baseUrl}muatparts/seller/orders/reject`,
    "POST"
  );

  // Tambahkan hook ini untuk membuat key SWR yang dinamis
  const [nextPageKey, setNextPageKey] = useState(null);

  // Tambahkan hook SWR tambahan untuk data halaman berikutnya
  const {
    data: nextPageData,
    error: nextPageError,
    isLoading: nextPageLoading
  } = useSWRHook(
    nextPageKey,
    null,
    (error) => {
      console.log("Next page data fetch error:", error);
      setIsMobileLoading(false);
    }
  );

  // Effect untuk memproses data dari nextPageData
  useEffect(() => {
    if (nextPageData?.Data?.orders && nextPageData.Data.orders.length > 0) {
      // Append data baru ke data yang sudah ada
      setOrdersData(prevData => [...prevData, ...nextPageData.Data.orders]);
      setFilteredOrders(prevData => [...prevData, ...nextPageData.Data.orders]);
      setCurrentPage(prev => prev + 1);
      setIsMobileLoading(false);
    } else if (nextPageData) {
      // Tidak ada data lagi
      setHasMore(false);
      setIsMobileLoading(false);
    }
  }, [nextPageData]);

  // Ubah loadMoreItems untuk menggunakan setNextPageKey daripada langsung memanggil API
  const loadMoreItems = useCallback(() => {
    if (isMobile && !orders_loading && !isMobileLoading && hasMore) {
      setIsMobileLoading(true);
      const nextPage = currentPage + 1;
      
      // Prepare parameters for next request
      const nextParams = serializeParam({
        page: nextPage,
        limit: itemsPerPage,
        shipping_method: filterData?.pengiriman?.filter(e => e?.selected)?.map(e => e?.id),
        courier: filterData?.jasa_pengiriman?.filter(e => e?.selected)?.map(e => e?.id), 
        response_limit: filterData?.batas_respon?.filter(e => e?.selected)?.map(e => e?.id),
        search: searchQuery?.searchInput,
        status: activeType === 'all' ? undefined : activeType,
        sort
      });
      
      // Set nextPageKey untuk memicu fetch data
      setNextPageKey(`${baseUrl}muatparts/orders?${nextParams}`);
    }
  }, [currentPage, isMobile, orders_loading, isMobileLoading, hasMore, itemsPerPage, filterData, searchQuery, activeType, sort]);

  // Setup Intersection Observer for infinite scroll
  useEffect(() => {
    if (!isMobile) return;
    
    const observer = new IntersectionObserver(
      entries => {
        if (entries[0].isIntersecting && hasMore && !isMobileLoading && !orders_loading) {
          loadMoreItems();
        }
      },
      { threshold: 0.5 }
    );
    
    const currentObserver = observerTarget.current;
    if (currentObserver) {
      observer.observe(currentObserver);
    }
    
    return () => {
      if (currentObserver) {
        observer.unobserve(currentObserver);
      }
    };
  }, [loadMoreItems, isMobileLoading, isMobile, hasMore, orders_loading]);

  // Reset infinite scroll when filters change
  useEffect(() => {
    if (isMobile) {
      setHasMore(true);
      setCurrentPage(1);
    }
  }, [activeType, filterData, searchQuery, isMobile]);

  // Improvement fix wording pak Bryan
  const tabList = useMemo(() => {
    if(t("WebKelolaPesananSellerMuatpartsSemua") === "WebKelolaPesananSellerMuatpartsSemua") return null;
    const supporting_data = orders?.Data?.supporting_data;
    const pagination = orders?.Data?.pagination;
    
    const defaultTab = [
      { label: t("WebKelolaPesananSellerMuatpartsSemua"), count: 0, type: "all", active: true },
      { label: t("WebKelolaPesananSellerMuatpartsPesananMasuk"), count: 0, type: "new" },
      { label: t("WebKelolaPesananSellerMuatpartsSiapDikirim"), count: 0, type: "ready" },
      { label: t("WebKelolaPesananSellerMuatpartsDikirim"), count: 0, type: "shipped" },
      { label: t("WebKelolaPesananSellerMuatpartsSelesai"), count: 0, type: "completed" },
      { label: t("WebKelolaPesananSellerMuatpartsBatal"), count: 0, type: "canceled" },
    ];
    if(!supporting_data || !pagination) return defaultTab;
    
    return defaultTab.map(tab => {
      const count = tab.type === "all"
        ? orders.Data.supporting_data?.countSemua || 0
        : tab.type === "new"
        ? orders.Data.supporting_data?.countPesananMasuk || 0
        : tab.type === "ready"
        ? orders.Data.supporting_data?.countSiapDikirim || 0
        : tab.type === "shipped"
        ? orders.Data.supporting_data?.countDikirim || 0
        : tab.type === "canceled"
        ? orders.Data.supporting_data?.countBatal || 0
        : tab.type === "completed"
        ? orders.Data.supporting_data?.countSelesai || 0
        : 0;
      
      return { ...tab, count };
    });
  }, [t, orders?.Data?.supporting_data, orders?.Data?.pagination]);
  // Effects
  // Modifikasi useEffect yang menangani data dari API
  useEffect(() => {
    if (orders?.Data?.orders) {
      // Selalu set data baru dari API saat orders berubah
      setOrdersData(orders.Data.orders);
      setFilteredOrders(orders.Data.orders);
    }
  }, [orders]); // Hapus currentPage dari dependency list

  useEffect(() => {
    if (filtersData?.Data) {
      const newFilters = {
        pengiriman: filtersData.Data.find(f => f.typeFilter === "Pengiriman")?.value.map(item => ({
          id: item.id,
          value: item.value,
          label: item.value,
          selected: false
        })) || [],
        
        jasa_pengiriman: filtersData.Data.find(f => f.typeFilter === "Jasa Pengiriman")?.value.map(item => ({
          id: item.id,
          value: item.value,
          label: item.value,
          selected: false
        })) || [],
        
        batas_respon: filtersData.Data.find(f => f.typeFilter === "Batas Response")?.value.map(item => ({
          id: item.id,
          value: item.value,
          label: item.value,
          selected: false
        })) || [],
        
        status: filtersData.Data.find(f => f.typeFilter === "Status")?.value.map(item => ({
          id: item.id,
          value: item.value,
          label: item.value,
          selected: false
        })) || []
      };
      setFilterData(newFilters);
    }
  }, [filtersData]);

  useEffect(() => {
    if (isMobile) {
      // Reset state for mobile infinite scroll
      setHasMore(true);
      setCurrentPage(1);
    } else {
      // Non-mobile behavior
      setCurrentPage(1);
    }
  }, [itemsPerPage, activeType, isMobile]);

  // Reset penolakan massal ketika modal dibuka/ditutup
  useEffect(() => {
    if (isBulkAccept === false) {
      setSelectedReason(null);
      setOtherReasonDescription("");
      setReasonValidation({
        reasonRequired: false,
        descriptionRequired: false
      });
      setRejectReasonStep("confirmation");
    }
  }, [isBulkAccept]);

  // Event handlers
  const handleTabClick = (type) => {
    setActiveType(type);
    setCurrentPage(1);
    if (isMobile) {
      setOrdersData([]); // Clear existing data when changing tabs on mobile
      setHasMore(true);
    }
  };

  const handlePeriodChange = (periodType, dateRange) => {
    setCurrentPage(1);
    
    // Jika periode custom, simpan tanggal mulai dan akhir
    if (periodType === 'custom' && dateRange) {
      setDateFilter({
        start_date: dateRange.startDate,
        end_date: dateRange.endDate
      });
    } else {
      // Reset filter tanggal jika bukan custom
      setDateFilter({
        start_date: undefined,
        end_date: undefined
      });
    }
    
    if (isMobile) {
      setOrdersData([]); // Clear existing data
      setHasMore(true);
    }
    
    // Refresh data dengan filter baru
    if (ordersMutate) {
      ordersMutate();
    }
  };
  
  // Bulk Reject handlers
  const handleBulkRejectConfirm = () => {
    setRejectReasonStep("reasonSelect");
  };

  // Handler untuk submit penolakan massal
  const handleBulkRejectSubmit = async () => {
    // Validasi form
    if (!selectedReason) {
      setReasonValidation(prev => ({ ...prev, reasonRequired: true }));
      return;
    }

    if (selectedReason === "Lainnya" && otherReasonDescription.trim() === "") {
      setReasonValidation(prev => ({ ...prev, descriptionRequired: true }));
      return;
    }

    // Reset validasi
    setReasonValidation({
      reasonRequired: false,
      descriptionRequired: false
    });

    try {
      setIsBulkLoading(true);
      const success = await handleRejectOrders(
        bulkSettingOrder?.map(e => e?.id) || [], 
        selectedReason,
        selectedReason === "Lainnya" ? otherReasonDescription : ""
      );
      if (success) {
        setBulkSettingOrder(undefined);
        setIsBulkAccept(undefined);
        setSelectedReason(null);
        setOtherReasonDescription("");
        setRejectReasonStep("confirmation");
      }
    } finally {
      setIsBulkLoading(false);
    }
  };
  
  // Modal Action Handlers 
  const handleInvoicePrint = async (selectedIds) => {
    if (!selectedIds || selectedIds.length === 0) return;
    
    setProcessingAction(true);
    
    try {
      const response = await triggerInvoiceDownload({
        transactionIds: selectedIds
      });
      
      if (response?.data?.Data) {
        window.open(response.data.Data, '_blank');
        setSnackbarMessage('Invoice berhasil dicetak');
        await ordersMutate();
        return true;
      } else {
        throw new Error('Gagal mengunduh invoice');
      }
    } catch (error) {
      setSnackbarMessage('Gagal mencetak invoice');
      console.error('Error printing invoices:', error);
      return false;
    } finally {
      setProcessingAction(false);
    }
  };

  const handleDownloadOrders = async (selectedIds) => {
    if (!selectedIds || selectedIds.length === 0) return;
    
    setProcessingAction(true);
    
    try {
      const response = await triggerDownloadOrders({
        transactionIds: selectedIds
      });
      
      if (response?.data?.Data) {
        window.open(response.data.Data, '_blank');
        setSnackbarMessage('Daftar pesanan berhasil diunduh');
        await ordersMutate();
        return true;
      } else {
        throw new Error('Gagal mengunduh daftar pesanan');
      }
    } catch (error) {
      setSnackbarMessage('Gagal mengunduh daftar pesanan');
      console.error('Error downloading orders:', error);
      return false;
    } finally {
      setProcessingAction(false);
    }
  };

  const handleAcceptOrders = async (selectedIds) => {
    if (!selectedIds || selectedIds.length === 0) return;
    
    setProcessingAction(true);
    
    const response = await triggerAcceptOrders({
      transactionIds: selectedIds
    });
    
    if (response?.status === 200) {
      setActiveModal({
        type: '',
        title: '',
        isOpen: false
      });
      setSnackbarMessage(`${selectedIds.length} Pesanan berhasil diterima`);
      setModalAction(false);
      setActiveModal(prev => ({...prev, isOpen: false, needReason: false}));
      setCurrentPage(1);
      refreshData();
      return true;
    } else {
      refreshData();
      throw new Error('Gagal menerima pesanan');
    }
  };
  
  const handleRejectOrders = async (selectedIds, reason, description = "") => {
    if (!selectedIds || selectedIds.length === 0 || !reason) return;
    
    setProcessingAction(true);
    
    // Konversi ID pilihan UI ke nilai yang diharapkan API
    let optionReject = "";
    let descriptionReject = description;
    
    // Set nilai optionReject berdasarkan pilihan
    switch (reason) {
      case 'outOfStock':
      case 'Stok Habis':
        optionReject = "Stok Habis";
        break;
      case 'closed':
      case 'Sedang Tutup':
        optionReject = "Sedang Tutup";
        break;
      case 'shippingIssue':
      case 'Kendala Pengiriman':
        optionReject = "Kendala Pengiriman";
        break;
      case 'Lainnya':
      case 'Lainnya':
        optionReject = "Lainnya";
        // Untuk opsi 'Lainnya', deskripsi wajib diisi
        if (!descriptionReject) {
          setSnackbarMessage('Mohon isi alasan penolakan');
          setProcessingAction(false);
          return false;
        }
        break;
      default:
        optionReject = reason;
    }
    
    const response = await triggerRejectOrders({
      transactionIds: selectedIds,
      optionReject,
      descriptionReject
    });
    
    if (response?.status === 200) {
      setSnackbarMessage(`${selectedIds.length} Pesanan berhasil ditolak`);
      setActiveType(type);
      setModalAction(false);
      setCurrentPage(1);
      refreshData();
      return true;
    } else {
      refreshData();
      throw new Error('Gagal menolak pesanan');
    }
  };

  const handleRequestPickup = async (orderId, pickupType = 'siap') => {
    if (!orderId) return;
    
    setProcessingAction(true);
    
    try {
      const response = await triggerRequestPickup({
        transactionId: orderId,
        pickupType: pickupType // 'siap' for Siap di Pick Up, 'jadwalkan' for Jadwalkan Pick Up
      });
      
      if (response?.status === 200) {
        setSnackbarMessage('Request pickup berhasil');
        setActiveType(type);
        setCurrentPage(1);
        refreshData();
        setPickupModalOpen(false);
        return true;
      } else {
        throw new Error('Gagal request pickup');
      }
    } catch (error) {
      setSnackbarMessage('Gagal request pickup');
      refreshData();
      console.error('Error requesting pickup:', error);
      return false;
    }
  };

  // Handler for unified modal submit
  const handleModalSubmit = async (selectedIds) => {
    if (!selectedIds || selectedIds.length === 0) return;
    
    setProcessingAction(true);
    
    let success = false;
    
    switch (activeModal.type) {
      case 'cetak_label':
        success = await handlePrintLabel(selectedIds);
        break;
      case 'invoice':
        success = await handleInvoicePrint(selectedIds);
        break;
      case 'download':
        success = await handleDownloadOrders(selectedIds);
        break;
      case 'accept':
        success = await handleAcceptOrders(selectedIds);
        break;
      case 'reject':
        // Bersihkan state sebelumnya
        setProcessingAction(false);
        
        // Simpan ID pesanan yang dipilih
        setRejectProductId(selectedIds);
        
        // Reset pilihan alasan dan deskripsi
        setSelectedReason(null);
        setOtherReasonDescription("");
        
        // Penundaan untuk memastikan modal lain tertutup dulu
        setTimeout(() => {
          setIsRejectModalOpen(true);
        }, 100);
        
        // Keluar dari fungsi
        return;
    }
    
    if (success) {
      setActiveModal({
        type: '',
        title: '',
        isOpen: false
      });
      setActiveModal(prev => ({...prev, isOpen: false, needReason: false}));
      setSelectedReason(null);
      setOtherReasonDescription("");
      setSelectedOrderIds([]);
    }
    setActiveModal({
      type: '',
      title: '',
      isOpen: false
    });
  };

  // Bulk operation handlers
  const handleBulkAccept = async () => {
    try {
      setIsBulkLoading(true);
      const success = await handleAcceptOrders(bulkSettingOrder?.map(e => e?.id) || []);
      if (success) {
        setBulkSettingOrder(undefined);
        setIsBulkAccept(undefined);
      }
    } finally {
      setIsBulkLoading(false);
    }
  };

  const reasons = [
    { id: 'outOfStock', label: 'Stok Habis', description: 'Stok produk akan diubah menjadi kosong' },
    { id: 'closed', label: 'Sedang Tutup', description: 'Merchant akan ditutup untuk 3 hari kedepan' },
    { id: 'shippingIssue', label: 'Kendala Pengiriman', description: 'Stok produk akan dikembalikan seperti semula' },
    { id: 'other', label: 'Lainnya', description: '' },
  ];

  const handleReasonChange = (id) => {
    setSelectedReason(id);
  };

  const handleOtherReasonChange = (e) => {
    setOtherReason(e.target.value);
  };

  const handleRejectOrder = async () => {
    // Map the UI selection to the API expected value
    let optionReject = "";
    let descriptionReject = "";
    
    // Set the optionReject value based on selection
    if (selectedReason) {
      // Map the selectedReason to the value properties from your models
      switch (selectedReason) {
        case 'outOfStock':
          optionReject = "Stok Habis";
          break;
        case 'closed':
          optionReject = "Sedang Tutup";
          break;
        case 'shippingIssue':
          optionReject = "Kendala Pengiriman";
          break;
        case 'other':
          optionReject = "Lainnya";
          // For 'other' option, use the text input as description
          descriptionReject = otherReason;
          break;
        default:
          optionReject = "";
      }
    }
  
    const response = await triggerReject({
      transactionIds: rejectProductId,
      optionReject, // Menggunakan nilai yang dipetakan
      descriptionReject // Akan menjadi string kosong kecuali untuk opsi 'Lainnya'
    });
    
    console.log("Response:", response);
    
    if (response?.status === 200) {
      refreshData();
      setSnackbarMessage('Pesanan berhasil ditolak');
      setIsRejectModalOpen(false);
    } else {
      throw new Error('Failed to reject order');
    }
  };

  // Definisikan fungsi refreshOrders sebagai callback
  const refreshOrders = useCallback(() => {
    // Reset halaman ke 1
    setCurrentPage(1);
    
    // Set ulang state tab aktif (opsional, jika ingin tetap di tab yang sama)
    setActiveType(activeType);
    
    // Mutate/refresh data dari API
    ordersMutate();
  }, [ordersMutate, activeType]);

  // Fungsi untuk me-refresh data setelah operasi berhasil
  const refreshData = () => {
    // Reset halaman ke 1
    setCurrentPage(1);
    
    // Set ulang state tab aktif
    setActiveType(activeType);
    
    // Mutate/refresh data dari API - ini penting!
    ordersMutate();
  }

  // Error handling
  if (orders_error || filters_error) {
    return (
      <div className="bg-red-100 p-4 rounded-lg">
        <p className="text-red-600">Error: {orders_error?.message || filters_error?.message}</p>
      </div>
    );
  }


  const { trigger: triggerLabelPrint, isMutating: isPrintingLabel } = useSWRMutateHook(
    `${baseUrl}muatparts/seller/orders/labels`,
    "POST"
  );

  const handlePrintLabel = async (selectedIds) => {
    if (!selectedIds || selectedIds.length === 0) return;
    
    setProcessingAction(true);
    
    try {
      const response = await triggerLabelPrint({
        transactionIds: selectedIds
      });
      
      if (response?.data?.Data) {
        window.open(response.data.Data?.labelUrls?.url, '_blank');
        setSnackbarMessage('Label berhasil dicetak');
        await ordersMutate();
        return true;
      } else {
        throw new Error('Gagal mencetak label');
      }
    } catch (error) {
      setSnackbarMessage('Gagal mencetak label');
      console.error('Error printing labels:', error);
      return false;
    } finally {
      setProcessingAction(false);
    }
  };

  // Membangun daftar opsi aksi massal sesuai tab aktif
  const massActionOptions = useMemo(() => {
    if(!langReady) return [];

    const baseOptions = [
      { 
        label: "Cetak Label", 
        value: "cetak_label",
        action: handlePrintLabel,
        title: "Cetak Label",
        showOnTabs: ['ready']
      },
      { 
        label: tOrEmpty("WebKelolaPesananSellerMuatpartsCetakInvoice"), 
        value: "invoice",
        action: handleInvoicePrint,
        title: "Cetak Invoice",
        showOnTabs: ['all', 'new', 'ready', 'shipped', 'completed', 'canceled']
      },
      { 
        label: tOrEmpty("WebKelolaPesananSellerMuatpartsUnduhDaftarPesanan"), 
        value: "download",
        action: handleDownloadOrders,
        title: "Unduh Daftar Pesanan",
        showOnTabs: ['all', 'new', 'ready', 'shipped', 'completed', 'canceled']
      },
      { 
        label: tOrEmpty("WebKelolaPesananSellerMuatpartsTerimaPesanan"), 
        value: "accept",
        action: handleAcceptOrders,
        title: "Terima Pesanan",
        showOnTabs: ['new']
      },
      { 
        label: tOrEmpty("WebKelolaPesananSellerMuatpartsTolakPesanan"), 
        value: "reject",
        action: handleRejectOrders,
        title: "Tolak Pesanan",
        className: "text-red-500",
        showOnTabs: ['new']
      }
    ];

    return baseOptions.filter(option => 
      option.showOnTabs.includes(activeType)
    );
  }, [activeType, t, langReady]);

  // Check if all tabs are empty
  const isAllTabsEmpty = useMemo(() => {
    return orders?.Data?.supporting_data?.countSemua === 0;
  }, [orders?.Data?.supporting_data?.countSemua]);

  // Check if current tab is empty
  const isCurrentTabEmpty = useMemo(() => {
    // Jika semua tab kosong, gunakan EmptyStateComponent yang ada
    if (isAllTabsEmpty) return false;
    
    // Cek count data pada tab yang aktif
    const tabCount = orders?.Data?.supporting_data 
      ? activeType === 'all' 
        ? orders.Data.supporting_data.countSemua 
        : activeType === 'new' 
          ? orders.Data.supporting_data.countPesananMasuk
          : activeType === 'ready' 
            ? orders.Data.supporting_data.countSiapDikirim
            : activeType === 'shipped' 
              ? orders.Data.supporting_data.countDikirim
            : activeType === 'canceled' 
              ? orders.Data.supporting_data.countBatal
              : activeType === 'completed' 
                ? orders.Data.supporting_data.countSelesai
                : 0
      : 0;
    
    return tabCount === 0;
  }, [activeType, isAllTabsEmpty, orders?.Data?.supporting_data]);

  // Variable untuk menonaktifkan tombol-tombol
  const disableButtons = isCurrentTabEmpty || processingAction || isDownloadingInvoice;

  useEffect(() => {
    setShowNavMenu(false);
    setHeader("");
    setBackIcon(false);
  }, []);

  return (
    <NavbarCover className="lg:pt-0">
      {/* Check if all tabs are empty and show empty state if true */}
      {isAllTabsEmpty ? (
        <div className="flex flex-col gap-[16px]">
          <div className="AvenirBold20px">Daftar Pesanan</div>
          <div className="flex flex-col w-full bg-white lg:rounded-xl shadow-[0px_4px_11px_0px_rgba(65,65,65,0.25)] p-6">
            <EmptyStateComponent />
          </div>
        </div>
        
      ) : (
        <>
          {/* Mobile Header (Tampil di mobile, hidden di desktop) */}
          <div className="lg:hidden">
            <MobileHeader 
              setOpenSort={setOpenSort} 
              setSearch={setSearchQuery} 
              search={searchQuery} 
            />
          </div>
          
          {/* Mobile Filter */}
          <MobileFilter
            isShow={openFilter}
            onHide={() => setOpenFilter(false)}
            filterData={filterData}
            setFilterData={setFilterData}
            onFilter={() => {
              ordersMutate();
            }}
            currentTab={activeType}
          />

          {/* Desktop Header */}
          <div className="lg:flex hidden flex-wrap gap-6 items-center w-full leading-tight min-h-[32px] max-md:max-w-full">
            <OrderHeader 
              onPeriodChange={handlePeriodChange} 
              orders={orders?.Data?.orders}
            />
          </div>

          <div className="bg-white lg:bg-transparent">
            {/* Tabs */}
            <div className="flex flex-col mt-[20px] gap-6 overflow-x-scroll overflow-y-hidden lg:mt-6 mt-0 no-scrollbar">
              {tabList && tabList.length > 0 && (
                <OrderTabs 
                  handleTab={handleTabClick} 
                  initTabs={tabList} 
                  supportingData={orders?.Data?.supporting_data}
                  activeType={activeType} // Pastikan ini diteruskan
                />
              )}
            </div>

            {/* Mobile Controls */}
            <div className="lg:hidden flex justify-between gap-2 items-center p-4">
              {/* Sort Bottom Sheet */}
              <BottomSheet
                isOpen={openSort}
                setOpen={() => setOpenSort(!openSort)}
                snapPoints={[570, 570, 0]}
              >
                <div className="relative w-full h-fit">
                  <ICCross
                    className="text-[#176CF7] cursor-pointer size-6 absolute top-1/2 left-4 translate-y-[-50%]"
                    onClick={() => setOpenSort(false)}
                  />
                  <p className="text-center font-bold text-sm">Urutkan</p>
                </div>
                <div className="p-4 relative h-full flex flex-col">
                  {sortFilter.map((e, i) => (
                    <RadioButton
                      key={e?.value}
                      id={e?.value}
                      className={`${i !== sortFilter?.length - 1 && "border-b"} !flex-row-reverse text-left border-gray-400 py-4 !text-sm !font-semibold`}
                      inputClassName="!size-5"
                      checked={sort === e?.value}
                      onClick={() => setSort(e?.value)}
                    >
                      {e?.label}
                    </RadioButton>
                  ))}
                  <button
                    onClick={() => setOpenSort(false)}
                    className="flex-0 shrink gap-1 font-semibold w-full h-fit self-stretch px-6 py-2.5 text-center text-white bg-blue-600 rounded-3xl min-h-[28px] min-w-[112px]"
                  >
                    Terapkan
                  </button>
                </div>
              </BottomSheet>

              {bulkSettingOrder ? (
                <CheckboxComponents
                  id="select-all"
                  onClick={() => bulkSettingOrder?.length === ordersData?.length
                    ? setBulkSettingOrder([])
                    : setBulkSettingOrder(ordersData)}
                  checked={bulkSettingOrder?.length === ordersData?.length}
                >
                  <p className="text-xs font-medium">Pilih Semua</p>
                </CheckboxComponents>
              ) : (
                <div
                  className={`bg-white flex items-center px-3 py-2 border rounded-3xl cursor-pointer ${
                    Object.values(filterData).some(arr => Array.isArray(arr) && arr.some(item => item.selected))
                    ? "border-[#176CF7] text-[#176CF7]"
                    : "border-[#D9D9D9] text-[#1A1A1A]"
                  }`}
                  onClick={() => setOpenFilter(true)}
                >
                  <div className="text-sm font-medium">Filter</div>
                </div>
              )}
              <p
                className="text-[#176CF7] text-sm font-semibold cursor-pointer"
                onClick={() => 
                  !bulkSettingOrder
                    ? setBulkSettingOrder([])
                    : setBulkSettingOrder(undefined)
                }
              >
                {bulkSettingOrder ? "Batalkan" : "Atur Massal"}
              </p>
            </div>
          </div>

          {/* Main Content Area */}
          <div className="flex overflow-hidden gap-[8px] items-start w-full h-max lg:rounded-xl shadow-[0px_4px_11px_0px_rgba(65,65,65,0.25)] max-md:max-w-full">
            {!isMobile ? (
              
              <div className="flex flex-col flex-1 shrink w-full basis-0 min-w-[240px] max-md:max-w-full bg-[#FFFFFF]">
              {/* Mobile Bulk Settings */}
              <div className="lg:hidden flex flex-col gap-2 mt-2 relative">
                {/* Bulk Settings Bottom Sheet */}
                <BottomSheet
                  isOpen={openBulkSetting}
                  setOpen={() => setOpenBulkSetting(!openBulkSetting)}
                  snapPoints={[300, 300, 0]}
                >
                  <div className="relative w-full h-fit">
                    <ICCross
                      className="text-[#176CF7] cursor-pointer size-6 absolute top-1/2 left-4 translate-y-[-50%]"
                      onClick={() => setOpenBulkSetting(false)}
                    />
                    <p className="text-center font-bold text-sm">Atur Massal</p>
                  </div>
                  <div className="flex flex-col p-4">
                    <p
                      onClick={() => {
                        setOpenBulkSetting(false);
                        setIsBulkAccept(true);
                      }}
                      className="text-sm font-semibold border-b border-b-[#C4C4C4] py-4"
                    >
                      {tOrEmpty("WebKelolaPesananSellerMuatpartsCetakInvoice")}
                    </p>
                    <p
                      onClick={() => {
                        setOpenBulkSetting(false);
                        setIsBulkAccept(false);
                        setRejectReasonStep("confirmation");
                      }}
                      className="text-sm font-semibold text-[#EE4343] py-4"
                    >
                      {tOrEmpty("WebKelolaPesananSellerMuatpartsTolakPesanan")}
                    </p>
                  </div>
                </BottomSheet>

                {/* Dialog Konfirmasi dan Alasan Penolakan */}
                <DialogComponents
                  isOpen={isBulkAccept !== undefined}
                  handleDialog={() => {
                    setIsBulkAccept(undefined);
                    setRejectReasonStep("confirmation");
                    setSelectedReason(null);
                    setOtherReasonDescription("");
                  }}
                  isLoading={isBulkLoading || processingAction}
                  onSubmit={
                    isBulkAccept 
                      ? handleBulkAccept 
                      : (isBulkAccept === false && rejectReasonStep === "confirmation") 
                        ? handleBulkRejectConfirm
                        : handleBulkRejectSubmit
                  }
                  cancel={rejectReasonStep === "reasonSelect" ? "Kembali" : "Tidak"}
                  submit={
                    isBulkAccept 
                      ? "Ya" 
                      : (rejectReasonStep === "confirmation") 
                        ? "Ya" 
                        : "Terapkan"
                  }
                >
                  {isBulkAccept ? (
                    // Tampilan konfirmasi terima pesanan massal
                    <>
                      <h1 className="self-center text-base font-bold text-center text-black lg:hidden block">
                        Terima Pesanan
                      </h1>
                      <div className="text-sm font-medium text-center">
                        <p>Apakah kamu yakin menerima pesanan {bulkSettingOrder?.length} sekaligus?</p>
                      </div>
                    </>
                  ) : (
                    // Tampilan penolakan pesanan massal
                    <>
                      {rejectReasonStep === "confirmation" ? (
                        // Step 1: Konfirmasi penolakan
                        <>
                          <h1 className="self-center text-base font-bold text-center text-black lg:hidden block">
                            Tolak Pesanan
                          </h1>
                          <div className="text-sm font-medium text-center">
                            <p>Apakah kamu yakin menolak pesanan {bulkSettingOrder?.length} sekaligus?</p>
                          </div>
                        </>
                      ) : (
                        // Step 2: Pilih alasan penolakan
                        <>
                          <h1 className="self-center text-base font-bold text-center text-black lg:hidden block">
                            Pilih Alasan Penolakan
                          </h1>
                          
                          <div className="bg-pink-100 p-3 rounded-md mb-4 text-xs text-blue-600 font-medium">
                            Penolakan pesanan dapat dilakukan maks. 3 kali per 30 hari!{" "}
                            <span className="text-blue-600 underline cursor-pointer">
                              Pelajari Batasan
                            </span>
                          </div>

                          {reasonValidation.reasonRequired && (
                            <div className="text-red-500 text-xs mb-2">
                              Silakan pilih alasan penolakan
                            </div>
                          )}

                          <div className="space-y-4 mb-4">
                            <label className="flex items-center gap-2 pb-4 border-b border-gray-300">
                              <input
                                type="radio"
                                name="rejectReason"
                                checked={selectedReason === "Stok Habis"}
                                onChange={() => {
                                  setSelectedReason("Stok Habis");
                                  setReasonValidation(prev => ({ ...prev, reasonRequired: false }));
                                }}
                                className="w-4 h-4 text-blue-600"
                              />
                              <div className="flex flex-col">
                                <span className="font-semibold text-sm">Stok Habis</span>
                                <span className="text-xs text-gray-500">
                                  Stok produk akan diubah menjadi kosong
                                </span>
                              </div>
                            </label>

                            <label className="flex items-center gap-2 pb-4 border-b border-gray-300">
                              <input
                                type="radio"
                                name="rejectReason"
                                checked={selectedReason === "Sedang Tutup"}
                                onChange={() => {
                                  setSelectedReason("Sedang Tutup");
                                  setReasonValidation(prev => ({ ...prev, reasonRequired: false }));
                                }}
                                className="w-4 h-4 text-blue-600"
                              />
                              <div className="flex flex-col">
                                <span className="font-semibold text-sm">Sedang Tutup</span>
                                <span className="text-xs text-gray-500">
                                  Merchant akan ditutup untuk 3 hari kedepan
                                </span>
                              </div>
                            </label>

                            <label className="flex items-center gap-2 pb-4 border-b border-gray-300">
                              <input
                                type="radio"
                                name="rejectReason"
                                checked={selectedReason === "Kendala Pengiriman"}
                                onChange={() => {
                                  setSelectedReason("Kendala Pengiriman");
                                  setReasonValidation(prev => ({ ...prev, reasonRequired: false }));
                                }}
                                className="w-4 h-4 text-blue-600"
                              />
                              <div className="flex flex-col">
                                <span className="font-semibold text-sm">Kendala Pengiriman</span>
                                <span className="text-xs text-gray-500">
                                  Stok produk akan dikembalikan seperti semula
                                </span>
                              </div>
                            </label>

                            <label className="flex items-center gap-2 pb-4">
                              <input
                                type="radio"
                                name="rejectReason"
                                checked={selectedReason === "Lainnya"}
                                onChange={() => {
                                  setSelectedReason("Lainnya");
                                  setReasonValidation(prev => ({ ...prev, reasonRequired: false }));
                                }}
                                className="w-4 h-4 text-blue-600"
                              />
                              <span className="font-semibold text-sm">Lainnya</span>
                            </label>

                            {selectedReason === "Lainnya" && (
                              <div className="ml-6">
                                <textarea
                                  placeholder="Masukkan alasan"
                                  value={otherReasonDescription}
                                  onChange={(e) => {
                                    const value = e.target.value;
                                    if (value.length <= 80) {
                                      setOtherReasonDescription(value);
                                      setReasonValidation(prev => ({ ...prev, descriptionRequired: value.trim() === "" }));
                                    }
                                  }}
                                  className={`w-full p-2 border rounded h-24 text-sm ${
                                    reasonValidation.descriptionRequired ? "border-red-500" : "border-gray-300"
                                  }`}
                                />
                                <div className="flex justify-between">
                                  {reasonValidation.descriptionRequired && (
                                    <span className="text-red-500 text-xs">
                                      Alasan lainnya wajib diisi
                                    </span>
                                  )}
                                  <span className="text-gray-500 text-xs ml-auto">
                                    {otherReasonDescription.length}/80
                                  </span>
                                </div>
                              </div>
                            )}
                          </div>
                        </>
                      )}
                    </>
                  )}
                </DialogComponents>

                {/* Mobile Orders List */}
                {(orders_loading && currentPage === 1) || !langReady ? (
                  <SkeletonDaftarPesanan />
                ) : isCurrentTabEmpty ? (
                  <EmptyTabState />
                ) : !ordersData?.length ? (
                  <EmptyPage />
                ) : (
                  <>
                    {ordersData?.map((order, index) => (
                      <div key={index} className="flex justify-start items-start bg-white">
                        {bulkSettingOrder && (
                          <div className="pt-4 pl-4">
                            <CheckboxComponents
                              id={order?.id}
                              checked={bulkSettingOrder?.find(e => e?.id === order?.id)}
                              onClick={() => {
                                if(bulkSettingOrder?.find(e => e?.id === order?.id)) {
                                  setBulkSettingOrder(bulkSettingOrder?.filter(e => e?.id !== order?.id));
                                } else {
                                  setBulkSettingOrder([...bulkSettingOrder, order]); 
                                }
                              }}
                            />
                          </div>
                        )}
                        <MobileOrderCard 
                          {...order}
                          mutate={ordersMutate}
                          onAccept={() => {
                            handleAcceptOrders([order.id]).then(() => {
                              ordersMutate();
                            });
                          }}
                          onReject={() => {
                            setRejectProductId(order.id);
                            setModalAction(true);
                          }}
                          onRequestPickup={() => {
                            setSelectedOrderIds([order.id]);
                            setPickupModalOpen(true);
                          }}
                        />
                      </div>
                    ))}
                    
                    {/* Observer target for infinite scroll */}
                    <div ref={observerTarget} className="h-10 w-full flex justify-center items-center py-4">
                      {isMobileLoading && hasMore && (
                        <div className="animate-spin rounded-full h-6 w-6 border-2 border-blue-600 border-t-transparent"></div>
                      )}
                    </div>
                  </>
                )}
     
                {bulkSettingOrder?.length ? (
                  <div className="flex flex-col fixed bottom-0 left-0 justify-center px-4 py-3 w-full text-sm font-semibold leading-none whitespace-nowrap bg-white rounded-xl shadow-[0px_-3px_55px_rgba(0,0,0,0.161)]">
                    <button
                      onClick={() => setOpenBulkSetting(true)}
                      className="gap-1 self-stretch px-6 py-4 text-white bg-blue-600 rounded-3xl min-h-[40px] w-full"
                    >
                      Atur {bulkSettingOrder?.length} Produk Sekaligus
                    </button>
                  </div>
                ) : null}
              </div>

              {/* Desktop Orders List */}
              <div className="rounded-xl bg-white lg:block hidden shadow-card pt-[32px] px-[32px]">
                <div className="lg:flex hidden flex-col gap-6">
                <OrderSearch
                    onSearch={setSearchQuery}
                    search={searchQuery}
                    filters={filterData}
                    setFilters={setFilterData}
                    isSelected={Object.values(filterData).some(filters => 
                      filters.some(f => f.selected)
                    )}
                    filtersData={filtersData}
                    isCurrentTabEmpty={isCurrentTabEmpty} // Add this prop
                    setSort={setSort}
                    ordersMutate={ordersMutate}
                  >
                    <Select
                      option={massActionOptions}
                      defaulLabel="Atur Massal"
                      onChange={(value) => {
                        if (isCurrentTabEmpty) return; // Jangan lakukan apa-apa jika tab kosong
                        
                        const selectedAction = massActionOptions.find(opt => opt.value === value);
                        if (selectedAction) {
                          // Jika pilihan adalah 'reject', pastikan selectedOrderIds berisi semua ID pesanan dari tab aktif
                          if (value === 'reject') {
                            setSelectedOrderIds(ordersData.map(order => order.id));
                          }
                          
                          setActiveModal({
                            type: value,
                            title: selectedAction.title,
                            isOpen: true
                          });
                        }
                      }}
                      value={activeModal.type}
                      showIcon={false}
                      disabled={isCurrentTabEmpty} // Tambahkan prop disabled
                    />

                    {/* Tombol untuk cetak invoice */}
                    <Button 
                      variant="cetak_invoice" 
                      onClick={async () => {
                        // Cek apakah ada data pesanan
                        if (!ordersData || ordersData.length === 0) {
                          setSnackbarMessage('Tidak ada pesanan yang dapat dicetak');
                          return;
                        }
                        
                        try {
                          // Ambil semua ID pesanan dari tab yang sedang aktif
                          const orderIds = ordersData.map(order => order.id);
                          
                          // Menampilkan indikator loading (opsional)
                          setSnackbarMessage('Mencetak invoice...');

                          // Langsung panggil API cetak invoice
                          const response = await triggerInvoiceDownload({
                            transactionIds: orderIds
                          });
                          
                          // Handle response
                          if (response?.data?.Data) {
                            window.open(response.data.Data, '_blank');
                            setSnackbarMessage('Invoice berhasil dicetak');
                          } else {
                            throw new Error('Gagal mengunduh invoice');
                          }
                        } catch (error) {
                          setSnackbarMessage('Gagal mencetak invoice');
                          console.error('Error printing invoices:', error);
                        }
                      }}
                      disabled={isCurrentTabEmpty || processingAction || isDownloadingInvoice} // Tambahkan prop disabled
                    >
                      <div className="flex gap-1 justify-center items-center">
                        {isDownloadingInvoice ? (
                          <div className="animate-spin h-4 w-4 border-2 border-white rounded-full border-t-transparent"></div>
                        ) : (
                          <img
                            loading="lazy"
                            src="https://cdn.builder.io/api/v1/image/assets/TEMP/6ac5c6c8b67189490fbb3dccefd5a660f78295232b151e65e35865310667f36d"
                            alt=""
                            className="w-4 h-4"
                          />
                        )}
                        <span className="AvenirDemi14px pt-[2px]">{tOrEmpty("WebKelolaPesananSellerMuatpartsCetakInvoice")}</span>
                      </div>
                    </Button>
                  </OrderSearch>
     
                  {orders_loading || !langReady ? ( 
                    <SkeletonDaftarPesanan />
                  ) : isCurrentTabEmpty ? (
                    <EmptyTabState />
                  ) : !filteredOrders.length ? (
                    <EmptyPage />
                  ) : (
                    <div className="flex flex-col gap-6">
                      {filteredOrders.map((order, index) => (
                        <OrderCard
                          key={index}
                          orderData={order}
                          setActiveType={setActiveType}
                          setCurrentPage={setCurrentPage}
                          activeType={activeType}
                          refreshOrders={refreshOrders}
                          actions={[
                            {
                              label: "Chat Pembeli",
                              variant: "chat_pembeli",
                              availableCategory: ["all"],
                              onClick: () => window.open("/chat/123", "_blank")
                            },
                            {
                              label: "Detail",
                              variant: "detail", 
                              availableCategory: ["all"],
                              onClick: () => window.location.href = `/kelolapesanan/daftarpesananseller/${order?.id}?orderID=${order?.order_id}`
                            },
                            {
                              label: "Tolak Pesanan",
                              variant: "danger",
                              availableCategory: ["new"],
                              type: "reject",
                              onClick: () => {
                                setRejectProductId(order?.id);
                                setModalAction(true);
                              }
                            },
                            {
                              label: "Terima Pesanan", 
                              variant: "primary",
                              availableCategory: ["new"],
                              type: "accept",
                              onClick: () => {
                                setProcessingAction(true);
                                handleAcceptOrders([order?.id])
                                  .finally(() => setProcessingAction(false));
                              },
                              disabled: processingAction || isAcceptingOrders
                            },
                            {
                              label: "Request Pick Up", 
                              variant: "primary",
                              availableCategory: ["ready"],
                              type: "pickup",
                              onClick: () => {
                                setSelectedOrderIds([order?.id]);
                                setPickupModalOpen(true);
                              },
                              disabled: processingAction || isRequestingPickup
                            }
                          ]}
                        />
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Pagination for desktop only */}
              {!isMobile && (
                <div className="flex justify-between items-center mt-[24px] mb-[32px] px-[32px]">
                  {!orders_loading && (
                    <Pagination
                      limit={itemsPerPage}
                      setActive={setCurrentPage}
                      orders={orders}
                      currentPage={currentPage}
                      totalData={orders?.Data?.pagination?.total_items || 1}
                    />
                  )}
                  <div className="flex justify-end items-center gap-2">
                    <label
                      htmlFor="itemsPerPage"
                      className="AvenirDemi12px Color7B7B7B leading-tight"
                    >
                      Tampilkan Jumlah detail
                    </label>
                    <div className="flex gap-2 items-center self-stretch my-auto text-sm font-medium text-center whitespace-nowrap">
                      {[10, 20, 40].map((value) => (
                        <button
                          key={value}
                          onClick={() => setItemsPerPage(value)}
                          className={`flex-1 shrink gap-2.5 self-stretch px-0.5 py-1.5 my-auto w-8 rounded-md min-h-[32px] ${
                            itemsPerPage === value
                              ? "bg-red-700 text-white font-bold"
                              : "font-medium text-[#7B7B7B]"
                          }`}
                          aria-label={`Show ${value} items per page`}
                        >
                          {value}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>


            ) : (
              

              <div className="flex flex-col flex-1 shrink w-full basis-0 min-w-[240px] max-md:max-w-full">
              {/* Mobile Bulk Settings */}
                <div className="lg:hidden flex flex-col gap-2 mt-2 relative">
                  {/* Bulk Settings Bottom Sheet */}
                  <BottomSheet
                    isOpen={openBulkSetting}
                    setOpen={() => setOpenBulkSetting(!openBulkSetting)}
                    snapPoints={[300, 300, 0]}
                  >
                    <div className="relative w-full h-fit">
                      <ICCross
                        className="text-[#176CF7] cursor-pointer size-6 absolute top-1/2 left-4 translate-y-[-50%]"
                        onClick={() => setOpenBulkSetting(false)}
                      />
                      <p className="text-center font-bold text-sm">Atur Massal</p>
                    </div>
                    <div className="flex flex-col p-4">
                      <p
                        onClick={() => {
                          setOpenBulkSetting(false);
                          setIsBulkAccept(true);
                        }}
                        className="text-sm font-semibold border-b border-b-[#C4C4C4] py-4"
                      >
                        {tOrEmpty("WebKelolaPesananSellerMuatpartsCetakInvoice")}
                      </p>
                      <p
                        onClick={() => {
                          setOpenBulkSetting(false);
                          setIsBulkAccept(false);
                          setRejectReasonStep("confirmation");
                        }}
                        className="text-sm font-semibold text-[#EE4343] py-4"
                      >
                        Tolak Pesanan
                      </p>
                    </div>
                  </BottomSheet>

                  {/* Dialog Konfirmasi dan Alasan Penolakan */}
                  <DialogComponents
                    isOpen={isBulkAccept !== undefined}
                    handleDialog={() => {
                      setIsBulkAccept(undefined);
                      setRejectReasonStep("confirmation");
                      setSelectedReason(null);
                      setOtherReasonDescription("");
                    }}
                    isLoading={isBulkLoading || processingAction}
                    onSubmit={
                      isBulkAccept 
                        ? handleBulkAccept 
                        : (isBulkAccept === false && rejectReasonStep === "confirmation") 
                          ? handleBulkRejectConfirm
                          : handleBulkRejectSubmit
                    }
                    cancel={rejectReasonStep === "reasonSelect" ? "Kembali" : "Tidak"}
                    submit={
                      isBulkAccept 
                        ? "Ya" 
                        : (rejectReasonStep === "confirmation") 
                          ? "Ya" 
                          : "Terapkan"
                    }
                  >
                    {isBulkAccept ? (
                      // Tampilan konfirmasi terima pesanan massal
                      <>
                        <h1 className="self-center text-base font-bold text-center text-black lg:hidden block">
                          Terima Pesanan
                        </h1>
                        <div className="text-sm font-medium text-center">
                          <p>Apakah kamu yakin menerima pesanan {bulkSettingOrder?.length} sekaligus?</p>
                        </div>
                      </>
                    ) : (
                      // Tampilan penolakan pesanan massal
                      <>
                        {rejectReasonStep === "confirmation" ? (
                          // Step 1: Konfirmasi penolakan
                          <>
                            <h1 className="self-center text-base font-bold text-center text-black lg:hidden block">
                              Tolak Pesanan
                            </h1>
                            <div className="text-sm font-medium text-center">
                              <p>Apakah kamu yakin menolak pesanan {bulkSettingOrder?.length} sekaligus?</p>
                            </div>
                          </>
                        ) : (
                          // Step 2: Pilih alasan penolakan
                          <>
                            <h1 className="self-center text-base font-bold text-center text-black lg:hidden block">
                              Pilih Alasan Penolakan
                            </h1>
                            
                            <div className="bg-pink-100 p-3 rounded-md mb-4 text-xs text-blue-600 font-medium">
                              Penolakan pesanan dapat dilakukan maks. 3 kali per 30 hari!{" "}
                              <span className="text-blue-600 underline cursor-pointer">
                                Pelajari Batasan
                              </span>
                            </div>

                            {reasonValidation.reasonRequired && (
                              <div className="text-red-500 text-xs mb-2">
                                Silakan pilih alasan penolakan
                              </div>
                            )}

                            <div className="space-y-4 mb-4">
                              <label className="flex items-center gap-2 pb-4 border-b border-gray-300">
                                <input
                                  type="radio"
                                  name="rejectReason"
                                  checked={selectedReason === "Stok Habis"}
                                  onChange={() => {
                                    setSelectedReason("Stok Habis");
                                    setReasonValidation(prev => ({ ...prev, reasonRequired: false }));
                                  }}
                                  className="w-4 h-4 text-blue-600"
                                />
                                <div className="flex flex-col">
                                  <span className="font-semibold text-sm">Stok Habis</span>
                                  <span className="text-xs text-gray-500">
                                    Stok produk akan diubah menjadi kosong
                                  </span>
                                </div>
                              </label>

                              <label className="flex items-center gap-2 pb-4 border-b border-gray-300">
                                <input
                                  type="radio"
                                  name="rejectReason"
                                  checked={selectedReason === "Sedang Tutup"}
                                  onChange={() => {
                                    setSelectedReason("Sedang Tutup");
                                    setReasonValidation(prev => ({ ...prev, reasonRequired: false }));
                                  }}
                                  className="w-4 h-4 text-blue-600"
                                />
                                <div className="flex flex-col">
                                  <span className="font-semibold text-sm">Sedang Tutup</span>
                                  <span className="text-xs text-gray-500">
                                    Merchant akan ditutup untuk 3 hari kedepan
                                  </span>
                                </div>
                              </label>

                              <label className="flex items-center gap-2 pb-4 border-b border-gray-300">
                                <input
                                  type="radio"
                                  name="rejectReason"
                                  checked={selectedReason === "Kendala Pengiriman"}
                                  onChange={() => {
                                    setSelectedReason("Kendala Pengiriman");
                                    setReasonValidation(prev => ({ ...prev, reasonRequired: false }));
                                  }}
                                  className="w-4 h-4 text-blue-600"
                                />
                                <div className="flex flex-col">
                                  <span className="font-semibold text-sm">Kendala Pengiriman</span>
                                  <span className="text-xs text-gray-500">
                                    Stok produk akan dikembalikan seperti semula
                                  </span>
                                </div>
                              </label>

                              <label className="flex items-center gap-2 pb-4">
                                <input
                                  type="radio"
                                  name="rejectReason"
                                  checked={selectedReason === "Lainnya"}
                                  onChange={() => {
                                    setSelectedReason("Lainnya");
                                    setReasonValidation(prev => ({ ...prev, reasonRequired: false }));
                                  }}
                                  className="w-4 h-4 text-blue-600"
                                />
                                <span className="font-semibold text-sm">Lainnya</span>
                              </label>

                              {selectedReason === "Lainnya" && (
                                <div className="ml-6">
                                  <textarea
                                    placeholder="Masukkan alasan"
                                    value={otherReasonDescription}
                                    onChange={(e) => {
                                      const value = e.target.value;
                                      if (value.length <= 80) {
                                        setOtherReasonDescription(value);
                                        setReasonValidation(prev => ({ ...prev, descriptionRequired: value.trim() === "" }));
                                      }
                                    }}
                                    className={`w-full p-2 border rounded h-24 text-sm ${
                                      reasonValidation.descriptionRequired ? "border-red-500" : "border-gray-300"
                                    }`}
                                  />
                                  <div className="flex justify-between">
                                    {reasonValidation.descriptionRequired && (
                                      <span className="text-red-500 text-xs">
                                        Alasan lainnya wajib diisi
                                      </span>
                                    )}
                                    <span className="text-gray-500 text-xs ml-auto">
                                      {otherReasonDescription.length}/80
                                    </span>
                                  </div>
                                </div>
                              )}
                            </div>
                          </>
                        )}
                      </>
                    )}
                  </DialogComponents>

                  {/* Mobile Orders List */}
                  {(orders_loading && currentPage === 1) || !langReady ? (
                    <SkeletonDaftarPesanan />
                  ) : isCurrentTabEmpty ? (
                    <EmptyTabState />
                  ) : !ordersData?.length ? (
                    <EmptyPage />
                  ) : (
                    <>
                      {ordersData?.map((order, index) => (
                        <div key={index} className="flex justify-start items-start bg-white">
                          {bulkSettingOrder && (
                            <div className="pt-4 pl-4">
                              <CheckboxComponents
                                id={order?.id}
                                checked={bulkSettingOrder?.find(e => e?.id === order?.id)}
                                onClick={() => {
                                  if(bulkSettingOrder?.find(e => e?.id === order?.id)) {
                                    setBulkSettingOrder(bulkSettingOrder?.filter(e => e?.id !== order?.id));
                                  } else {
                                    setBulkSettingOrder([...bulkSettingOrder, order]); 
                                  }
                                }}
                              />
                            </div>
                          )}
                          <MobileOrderCard 
                            {...order}
                            mutate={ordersMutate}
                            onAccept={() => {
                              handleAcceptOrders([order.id]).then(() => {
                                ordersMutate();
                              });
                            }}
                            onReject={() => {
                              setRejectProductId(order.id);
                              setModalAction(true);
                            }}
                            onRequestPickup={() => {
                              setSelectedOrderIds([order.id]);
                              setPickupModalOpen(true);
                            }}
                          />
                        </div>
                      ))}
                      
                      {/* Observer target for infinite scroll */}
                      <div ref={observerTarget} className="h-10 w-full flex justify-center items-center py-4">
                        {isMobileLoading && hasMore && (
                          <div className="animate-spin rounded-full h-6 w-6 border-2 border-blue-600 border-t-transparent"></div>
                        )}
                      </div>
                    </>
                  )}
      
                  {bulkSettingOrder?.length ? (
                    <div className="flex flex-col fixed bottom-0 left-0 justify-center px-4 py-3 w-full text-sm font-semibold leading-none whitespace-nowrap bg-white rounded-xl shadow-[0px_-3px_55px_rgba(0,0,0,0.161)]">
                      <button
                        onClick={() => setOpenBulkSetting(true)}
                        className="gap-1 self-stretch px-6 py-4 text-white bg-blue-600 rounded-3xl min-h-[40px] w-full"
                      >
                        Atur {bulkSettingOrder?.length} Produk Sekaligus
                      </button>
                    </div>
                  ) : null}
                </div>

                {/* Desktop Orders List */}
                <div className="rounded-xl bg-white lg:block hidden shadow-card pt-[32px] px-[32px]">
                  <div className="lg:flex hidden flex-col gap-6">
                  <OrderSearch
                      onSearch={setSearchQuery}
                      search={searchQuery}
                      filters={filterData}
                      setFilters={setFilterData}
                      isSelected={Object.values(filterData).some(filters => 
                        filters.some(f => f.selected)
                      )}
                      filtersData={filtersData}
                      isCurrentTabEmpty={isCurrentTabEmpty} // Add this prop
                      setSort={setSort}
                      ordersMutate={ordersMutate}
                    >
                      <Select
                        option={massActionOptions}
                        defaulLabel="Atur Massal"
                        onChange={(value) => {
                          if (isCurrentTabEmpty) return; // Jangan lakukan apa-apa jika tab kosong
                          
                          const selectedAction = massActionOptions.find(opt => opt.value === value);
                          if (selectedAction) {
                            // Jika pilihan adalah 'reject', pastikan selectedOrderIds berisi semua ID pesanan dari tab aktif
                            if (value === 'reject') {
                              setSelectedOrderIds(ordersData.map(order => order.id));
                            }
                            
                            setActiveModal({
                              type: value,
                              title: selectedAction.title,
                              isOpen: true
                            });
                          }
                        }}
                        value={activeModal.type}
                        showIcon={false}
                        disabled={isCurrentTabEmpty} // Tambahkan prop disabled
                      />

                      {/* Tombol untuk cetak invoice */}
                      <Button 
                        variant="cetak_invoice" 
                        onClick={async () => {
                          // Cek apakah ada data pesanan
                          if (!ordersData || ordersData.length === 0) {
                            setSnackbarMessage('Tidak ada pesanan yang dapat dicetak');
                            return;
                          }
                          
                          try {
                            // Ambil semua ID pesanan dari tab yang sedang aktif
                            const orderIds = ordersData.map(order => order.id);
                            
                            // Menampilkan indikator loading (opsional)
                            setSnackbarMessage('Mencetak invoice...');

                            // Langsung panggil API cetak invoice
                            const response = await triggerInvoiceDownload({
                              transactionIds: orderIds
                            });
                            
                            // Handle response
                            if (response?.data?.Data) {
                              window.open(response.data.Data, '_blank');
                              setSnackbarMessage('Invoice berhasil dicetak');
                            } else {
                              throw new Error('Gagal mengunduh invoice');
                            }
                          } catch (error) {
                            setSnackbarMessage('Gagal mencetak invoice');
                            console.error('Error printing invoices:', error);
                          }
                        }}
                        disabled={isCurrentTabEmpty || processingAction || isDownloadingInvoice} // Tambahkan prop disabled
                      >
                        <div className="flex gap-1 justify-center items-center">
                          {isDownloadingInvoice ? (
                            <div className="animate-spin h-4 w-4 border-2 border-white rounded-full border-t-transparent"></div>
                          ) : (
                            <img
                              loading="lazy"
                              src="https://cdn.builder.io/api/v1/image/assets/TEMP/6ac5c6c8b67189490fbb3dccefd5a660f78295232b151e65e35865310667f36d"
                              alt=""
                              className="w-4 h-4"
                            />
                          )}
                          <span className="AvenirDemi14px pt-[2px]">{t("WebKelolaPesananSellerMuatpartsCetakInvoice")}</span>
                        </div>
                      </Button>
                    </OrderSearch>
      
                    {orders_loading || !langReady ? (
                      <SkeletonDaftarPesanan />
                    ) : isCurrentTabEmpty ? (
                      <EmptyTabState />
                    ) : !filteredOrders.length ? (
                      <EmptyPage />
                    ) : (
                      <div className="flex flex-col gap-6">
                        {filteredOrders.map((order, index) => (
                          <OrderCard
                            key={index}
                            orderData={order}
                            setActiveType={setActiveType}
                            setCurrentPage={setCurrentPage}
                            activeType={activeType}
                            refreshOrders={refreshOrders}
                            actions={[
                              {
                                label: "Chat Pembeli",
                                variant: "chat_pembeli",
                                availableCategory: ["all"],
                                onClick: () => window.open("/chat/123", "_blank")
                              },
                              {
                                label: "Detail",
                                variant: "detail", 
                                availableCategory: ["all"],
                                onClick: () => window.location.href = `/kelolapesanan/daftarpesananseller/${order?.id}?orderID=${order?.order_id}`
                              },
                              {
                                label: "Tolak Pesanan",
                                variant: "danger",
                                availableCategory: ["new"],
                                type: "reject",
                                onClick: () => {
                                  setRejectProductId(order?.id);
                                  setModalAction(true);
                                }
                              },
                              {
                                label: "Terima Pesanan", 
                                variant: "primary",
                                availableCategory: ["new"],
                                type: "accept",
                                onClick: () => {
                                  setProcessingAction(true);
                                  handleAcceptOrders([order?.id])
                                    .finally(() => setProcessingAction(false));
                                },
                                disabled: processingAction || isAcceptingOrders
                              },
                              {
                                label: "Request Pick Up", 
                                variant: "primary",
                                availableCategory: ["ready"],
                                type: "pickup",
                                onClick: () => {
                                  setSelectedOrderIds([order?.id]);
                                  setPickupModalOpen(true);
                                },
                                disabled: processingAction || isRequestingPickup
                              }
                            ]}
                          />
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* Pagination for desktop only */}
                {!isMobile && (
                  <div className="flex justify-between items-center mt-[24px] mb-[32px] px-[32px]">
                    {!orders_loading && (
                      <Pagination
                        limit={itemsPerPage}
                        setActive={setCurrentPage}
                        orders={orders}
                        currentPage={currentPage}
                        totalData={orders?.Data?.pagination?.total_items || 1}
                      />
                    )}
                    <div className="flex justify-end items-center gap-2">
                      <label
                        htmlFor="itemsPerPage"
                        className="AvenirDemi12px Color7B7B7B leading-tight"
                      >
                        Tampilkan Jumlah detail
                      </label>
                      <div className="flex gap-2 items-center self-stretch my-auto text-sm font-medium text-center whitespace-nowrap">
                        {[10, 20, 40].map((value) => (
                          <button
                            key={value}
                            onClick={() => setItemsPerPage(value)}
                            className={`flex-1 shrink gap-2.5 self-stretch px-0.5 py-1.5 my-auto w-8 rounded-md min-h-[32px] ${
                              itemsPerPage === value
                                ? "bg-red-700 text-white font-bold"
                                : "font-medium text-[#7B7B7B]"
                            }`}
                            aria-label={`Show ${value} items per page`}
                          >
                            {value}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>



            )}

            
          </div>

          {/* Modals dan Dialogs lainnya */}
          {/* Modal untuk aksi massal */}
          <OrderModal
            isOpen={activeModal.isOpen}
            onClose={() => setActiveModal(prev => ({...prev, isOpen: false}))}
            title={activeModal.title}
            orders={ordersData}
            filtersData={filtersData}
            onSubmit={handleModalSubmit}
            loading={orders_loading || filters_loading || processingAction}
            submitButtonText={
              activeModal.type === 'invoice' ? tOrEmpty("WebKelolaPesananSellerMuatpartsCetakInvoice") :
              activeModal.type === 'download' ? tOrEmpty("WebKelolaPesananSellerMuatpartsUnduh") :
              activeModal.type === 'accept' ? tOrEmpty("WebKelolaPesananSellerMuatpartsTerimaPesanan") :
              activeModal.type === 'reject' ? tOrEmpty("WebKelolaPesananSellerMuatpartsTolakPesanan") : tOrEmpty("WebKelolaPesananSellerMuatpartsTerapkan")
            } 
            modalType={activeModal.type}
            activeTab={activeType} // Pass the active tab from the parent component
          />
          
          {/* Dialog untuk penolakan pesanan individual */}
          <DialogComponents
            isOpen={isRejectModalOpen} // Pastikan ini cocok dengan variabel state
            handleDialog={() => setIsRejectModalOpen(true)}
            cancel="Batal"
            submit="Simpan"
            onSubmit={handleRejectOrder}
            isLoading={isRejecting}
          >
            <div className="flex flex-col text-sm font-medium text-center items-center gap-[24px]">
              <div className="AvenirBold16px Color000000">Pilih Alasan Penolakan</div>
    
              <div className="flex px-2 py-1 bg-pink-100 rounded-md h-fit w-fit">
                <div className="text-left">
                  <div className="text-red-500 AvenirNormal12px">
                    Penolakan pesanan dapat dilakukan maks. 3 kali per 30 hari!
                  </div>
                  <div className="text-blue-600 AvenirDemi12px">Pelajari Batasan</div>
                </div>
              </div>
              <div className="flex flex-col gap-[24px] w-full">
                {reasons.map((reason) => (
                  <div key={reason.id} className="flex gap-2 items-start">
                    <input
                      type="radio"
                      id={reason.id}
                      name="cancelReason"
                      value={reason.id}
                      checked={selectedReason === reason.id}
                      onChange={() => handleReasonChange(reason.id)}
                      className="relative w-4 h-4 rounded-full border border-solid border-neutral-500 appearance-none cursor-pointer checked:border-blue-600 checked:bg-white checked:before:content-[''] checked:before:absolute checked:before:top-1/2 checked:before:left-1/2 checked:before:transform checked:before:-translate-x-1/2 checked:before:-translate-y-1/2 checked:before:w-2 checked:before:h-2 checked:before:bg-blue-600 checked:before:rounded-full"
                    />
                    <div className="flex-1">
                      <div htmlFor={reason.id} className="mb-1 text-xs text-black AvenirDemi12px cursor-pointer text-left">{reason.label}</div>
                      <div className="text-xs text-neutral-500 AvenirNormal12px text-left">{reason.description}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            {selectedReason === 'other' && (
              <div className="mt-1">
                <input
                  type="text"
                  value={otherReason}
                  onChange={handleOtherReasonChange}
                  className="p-3 w-full text-xs h-[32px] rounded-md border border-solid border-neutral-500 AvenirNormal12px"
                  placeholder="Masukan alasan"
                  aria-label="Other reason for cancellation"
                  maxLength={80}
                />
                <div className="flex justify-between mt-2 text-xs text-neutral-500 AvenirNormal10px">
                  <div></div>
                  <div className="AvenirNormal12px">{otherReason.length}/80</div>
                </div>
              </div>
            )}
    
          </DialogComponents>

          <DialogComponents
            isOpen={modalAction}
            handleDialog={() => {
              setModalAction(false);
              // Reset state ketika modal ditutup
              setSelectedReason(null);
              setOtherReasonDescription("");
              setReasonValidation({
                reasonRequired: false,
                descriptionRequired: false
              });
              
              // Juga tutup modal Atur Massal jika terbuka
              setActiveModal(prev => ({...prev, isOpen: false}));
            }}
            isLoading={processingAction || isRejectingOrders}
            cancel="Batal"
            submit="Simpan"
            onSubmit={() => {
              // Validasi form
              if (!selectedReason) {
                setReasonValidation(prev => ({ ...prev, reasonRequired: true }));
                return;
              }
              
              if (selectedReason === "Lainnya" && otherReasonDescription.trim() === "") {
                setReasonValidation(prev => ({ ...prev, descriptionRequired: true }));
                return;
              }
              
              // Cek apakah ini penolakan individual atau massal
              const orderIds = Array.isArray(rejectProductId) ? rejectProductId : [rejectProductId];
              
              // Proses penolakan pesanan
              handleRejectOrders(
                orderIds, 
                selectedReason,
                selectedReason === "Lainnya" ? otherReasonDescription : ""
              ).then(success => {
                if (success) {
                  setModalAction(false);
                  setSelectedReason(null);
                  setOtherReasonDescription("");
                  setReasonValidation({
                    reasonRequired: false,
                    descriptionRequired: false
                  });
                  setActiveModal(prev => ({...prev, isOpen: false})); // Tutup modal Atur Massal juga
                }
              });
            }}
          >
            {/* Konten modal sama seperti sebelumnya */}
          </DialogComponents>
          
          {/* Snackbar notifications */}
          <Snackbar
            open={!!snackbarMessage}
            onClose={() => setSnackbarMessage(undefined)}
          >
            {snackbarMessage}
          </Snackbar>
        </>
      )}
    </NavbarCover>
  );
}

export default OrdersPage;
// LBM - Bahasa - Andrew - 16 April 2025
// 25.03 Web Ronda LB - 0412, MP - 031 LB - 0024, LB - 0036, LB - 0037, LB - 0038, LB - 0066