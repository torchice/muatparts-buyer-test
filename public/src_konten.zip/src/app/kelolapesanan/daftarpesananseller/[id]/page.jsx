"use client";

import OrderDetailView from "@/components/KelolaPesananComponent/packages/order-detail/pages";
import { useSearchParams } from "next/navigation";

const OrderDetailPage = ({ params }) => {
  const { id: transactionID } = params;
  const searchParams = useSearchParams();
  const orderID = searchParams.get('orderID');

  return <OrderDetailView id={transactionID} transactionId={orderID} />;
};

export default OrderDetailPage;
