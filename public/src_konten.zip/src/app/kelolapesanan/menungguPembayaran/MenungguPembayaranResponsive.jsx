import FilterkelolaPesanan from "../screens/FilterkelolaPesanan";
import DetailKelolaPesanan from "../screens/DetailKelolaPesanan";
import { useHeader } from "@/common/ResponsiveContext";
import { useEffect, useState } from "react";
import Checkbox from "@/components/Checkbox/Checkbox";
import IconComponent from "@/components/IconComponent/IconComponent";
import CardManageOrderMobile from "@/components/CardManageOrderMobile/CardManageOrderMobile";
import ModalComponent from "@/components/Modals/ModalComponent";
import RadioButton from "@/components/Radio/RadioButton";
import Button from "@/components/Button/Button";
import style from "./MenungguPembayaran.module.scss";
import TrackOrderMobile from "@/container/TrackOrderMobile/TrackOrderMobile";
import DataNotFound from "@/components/DataNotFound/DataNotFound";
import toast from "@/store/zustand/toast";
import ButtonBottomMobile from "@/components/ButtonBottomMobile/ButtonBottomMobile";
import { useCustomRouter } from "@/libs/CustomRoute";
import InfiniteScrollContainer from "@/container/InfiniteScrollContainer/InfiniteScrollContainer";
import { useTranslation } from "@/context/TranslationProvider";

// Improvement fix wording pak Bryan
const SkeletonLoaderMobile = () => (
  <div className="w-full h-fit flex flex-col bg-white p-4 gap-4">
    {/* Payment deadline */}
    <div className="w-48 h-4 bg-slate-200 rounded-full animate-pulse" />

    {/* Product and Invoice section */}
    <div className="flex gap-3">
      {/* Product image */}
      <div className="w-12 h-12 bg-slate-200 rounded animate-pulse" />
      <div className="flex flex-col gap-1">
        <div className="w-32 h-4 bg-slate-200 rounded animate-pulse" />
        <div className="w-40 h-4 bg-slate-200 rounded animate-pulse" />
      </div>
    </div>

    {/* Courier and Buyer info */}
    <div className="flex justify-between">
      <div className="flex flex-col gap-2">
        <div className="w-20 h-4 bg-slate-200 rounded animate-pulse" />
        <div className="w-24 h-4 bg-slate-200 rounded animate-pulse" />
      </div>
      <div className="flex flex-col gap-2 items-end">
        <div className="w-24 h-4 bg-slate-200 rounded animate-pulse" />
        <div className="w-32 h-4 bg-slate-200 rounded animate-pulse" />
      </div>
    </div>

    {/* Product quantity and total */}
    <div className="flex justify-between items-center">
      <div className="w-24 h-4 bg-slate-200 rounded animate-pulse" />
      <div className="w-32 h-5 bg-slate-200 rounded animate-pulse" />
    </div>

    {/* Detail button */}
    <div className="w-full h-10 bg-slate-200 rounded-full animate-pulse" />
  </div>
);

function MenungguPembayaranResponsive({
  data,
  status_pesanan,
  handleFilter,
  isDownloadingInvoice,
  others,
  isLoading,
  Sort,
  getFilter,
  setFilter,
  dataFilter,
  handleDownloadOrders,
}) {
  const { t, tOrEmpty } = useTranslation();
  const router = useCustomRouter();
  const {
    setAppBar,
    clearScreen, // reset appBar
    setScreen, // set screen
    screen, // get screen,
    search,
    setSearch, // tambahkan payload seperti ini {placeholder:'Pencarian',value:'',type:'text'}
  } = useHeader();

  const [isAturMassal, setAturMassal] = useState(false);
  const [isShowSort, setShowSort] = useState(false);
  const [sortActive, setSortActive] = useState([]);
  const [getChecked, setChecked] = useState([]);

  const { setShowNavMenu } = toast();

  function handleTerapkanSort() {
    handleFilter(sortActive[0], sortActive[1]);
    setShowSort(false);
  }
  useEffect(() => {
    window.scrollTo(0, 0);
    if (screen) setShowNavMenu(false);
    if (!screen) {
      setAppBar({
        appBarType: "header_search",
        renderActionButton: (
          <span
            className="flex flex-col gap-[2px] items-center ml-2 select-none z-10"
            onClick={() => setShowSort(true)}
          >
            <IconComponent
              src={"/icons/sorting.svg"}
              classname={"icon-white"}
              width={24}
              height={24}
            />
            <span className="text-[10px] text-neutral-50 font-semibold">
              Urutkan
            </span>
          </span>
        ),
      });
      // Improvement fix wording pak Bryan
      setSearch({
        placeholder: tOrEmpty(
          "WebKelolaPesananSellerMuatpartspesananMenungguPembayaranCariNo.Invoice/NamaProduk/SKU"
        ),
        onSubmitForm: true,
      });
    }
    if (screen === "detailPesanan") {
      setAppBar({
        appBarType: "header_title",
        title: "Detail Pesanan",
        renderActionButton: (
          <span
            className="flex flex-col gap-[2px] items-center ml-2 select-none z-10 absolute right-4"
            onClick={() => console.log("download")}
          >
            <IconComponent
              src={"/icons/download.svg"}
              classname={"icon-white"}
              width={24}
              height={24}
            />
            <span className="text-[10px] text-neutral-50 font-semibold">
              Unduh
            </span>
          </span>
        ),
        onBack: () => clearScreen(),
      });
    }
    if (screen === "filter") {
      setAppBar({
        appBarType: "header_title_modal_secondary",
        title: "Filter",
        onBack: () => clearScreen(),
        componentBackType: "close",
      });
    }
    if (screen === "lacak_pesanan") {
      setAppBar({
        appBarType: "header_title",
        title: "Lacak Pesanan",
        onBack: () => setScreen("detailPesanan"),
      });
    }
  }, [screen]);

  function handleBatal() {
    clearScreen();
  }
  function handleSimpan(val) {
    setFilter({ ...getFilter, ...val });
    clearScreen();
  }
  if (screen === "filter")
    return (
      <FilterkelolaPesanan
        data={dataFilter}
        getFilterData={getFilter}
        onBatal={handleBatal}
        onSimpan={handleSimpan}
      />
    );
  if (screen === "lacak_pesanan")
    return (
      <TrackOrderMobile
        data={[
          {
            title: "Pengembalian Dana Berhasil",
            date: "26 Jan 2024 11:51 WIB",
            desc: "(Pengembalian Dana berhasil pada Date_pengembalian_dana)",
          },
        ]}
      />
    );
  useEffect(() => {
    if (search.value) handleFilter("search", search.value);
    else handleFilter("search", "");
  }, [search]);
  // main screen
  return (
    <div
      className={`${style.main} flex flex-col gap-2 bg-neutral-200 mt-3 pb-20`}
    >
      <ModalComponent
        isOpen={isShowSort}
        title="Urutkan"
        setClose={() => setShowSort(false)}
        type="BottomSheet"
      >
        <ul className="list-none flex flex-col gap-4 pt-6 px-4">
          {Sort.map((val) => (
            <li key={val?.value}>
              <div className="pb-4 border-b border-neutral-400 flex justify-between items-center">
                <span className="semi-sm text-neutral-900">{val?.name}</span>
                <RadioButton
                  checked={
                    getFilter?.sort === val?.value ||
                    sortActive?.[1] === val?.value
                  }
                  onClick={(a) => setSortActive(["sort", val?.value])}
                />
              </div>
            </li>
          ))}
        </ul>
        <div className="px-4 pb-6">
          <Button Class="!max-w-full !w-full !h-8" onClick={handleTerapkanSort}>
            Terapkan
          </Button>
        </div>
      </ModalComponent>
      <div className="p-4 flex justify-between items-center w-full bg-neutral-50 text-neutral-900">
        {isAturMassal ? (
          <Checkbox
            label="Pilih Semua"
            onChange={(a) => {
              if (a.checked) setChecked(data?.map((a) => a.id));
              else setChecked([]);
            }}
          />
        ) : (
          <div
            className="bg-neutral-200 rounded-3xl py-2 px-3 gap-[10px] select-none flex items-center h-[30px]"
            onClick={() => setScreen("filter")}
          >
            <span className="medium-sm">Filter</span>
            <IconComponent src={"/icons/filter.svg"} width={14} height={14} />
          </div>
        )}
        <span
          className="text-primary-700 semi-sm select-none"
          onClick={() => {
            if (!isAturMassal) setChecked([]);
            setShowNavMenu(isAturMassal);
            setAturMassal(!isAturMassal);
          }}
        >
          {isAturMassal ? "Batalkan" : "Atur Massal"}
        </span>
      </div>
      <InfiniteScrollContainer
        currentPage={1}
        setPageChange={(page) => handleFilter("limit", page * 10)}
        className="list-none flex flex-col gap-2"
      >
        {isLoading
          ? [...Array(2)].map((_, index) => (
              <SkeletonLoaderMobile key={index} />
            ))
          : null}

        {data?.map((val, i) => {
          return (
            <div key={i}>
              <CardManageOrderMobile
                isChecked={getChecked.some((a) => a === val.id)}
                withCheckBox={isAturMassal}
                onClick={(a) =>
                  router.push("/kelolapesanan/menungguPembayaran/" + a)
                }
                {...val}
                onChecked={(a) => {
                  if (a.checked) setChecked((prev) => [...prev, a?.value]);
                  else
                    setChecked(getChecked.filter((terr) => terr !== a?.value));
                }}
              />
            </div>
          );
        })}
        {!data.length && !search?.value && (
          <DataNotFound
            classname={"mt-5"}
            type="data"
            title={t(
              "WebKelolaPesananSellerMuatpartspesananMenungguPembayaranTidakadadaftarpesanan"
            )}
          />
        )}
        {!data.length && search?.value && (
          <DataNotFound
            classname={"mt-5"}
            title={t(
              "WebKelolaPesananSellerMuatpartspesananMenungguPembayaranTidakadapesanan"
            )}
          />
        )}
      </InfiniteScrollContainer>
      {getChecked.length && isAturMassal ? (
        <ButtonBottomMobile
          onClickSingleButton={() => handleDownloadOrders(getChecked)}
          isSingleButton
          textSingleButton={`Unduh Daftar Pesanan`}
        />
      ) : (
        ""
      )}
    </div>
  );
}

export default MenungguPembayaranResponsive;
