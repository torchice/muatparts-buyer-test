
'use client'

import { useContext, useEffect, useState } from "react"
import MenungguPembayaranResponsive from "./MenungguPembayaranResponsive"
import MenungguPembayaranWeb from "./MenungguPembayaranWeb"
import viewport from "@/store/zustand/common"
import SWRHandler from "@/services/useSWRHook"
import { metaSearchParams } from "@/libs/services"
import { useCustomRouter } from "@/libs/CustomRoute"
import { StateContext } from "@/common/StateContext"
import { authZustand } from "@/store/auth/authZustand"
import { capitalizeText } from "@/libs/TypographServices"
export const status_pesanan = [
  {
    id: "Menunggu Pembayaran",
    status: "Menunggu Pembayaran",
    bg: "bg-warning-100",
    text: "warning-900",
    action_button: "Detail Pesanan",
    action_button_detail:[
      {
        buttonText:"Chat Pembeli",
        color:'primary_secondary'
      },
      {
        buttonText:"Detail",
        color:'primary'
      },
    ]
  },
  {
    id: "Menunggu Respon Penjual",
    status: "Menunggu Respon Penjual",
    bg: "bg-warning-100",
    text: "warning-900",
    action_button: "Detail Pesanan",
    action_button_detail:[
      {
        buttonText:"Batalkan Pesanan",
        color:'error_secondary'
      },
      {
        buttonText:"Chat Penjual",
        color:'primary'
      }
    ]
  },
  {
    id: "Dikemas",
    status: "Dikemas",
    bg: "bg-primary-50",
    text: "primary-700",
    action_button: "Detail Pesanan",
    action_button_detail:[
      {
        buttonText:"Chat Penjual",
        color:'primary'
      }
    ]
  },
  {
    id: "Dikirim",
    status: "Dikirim",
    bg: "primary-50",
    text: "primary-700",
    action_button: "Lacak Pesanan",
    action_button_detail:[
      {
        buttonText:"Chat Penjual",
        color:'primary_secondary'
      },
      {
        buttonText:"Selesaikan Pesanan",
        color:'primary'
      }
    ]
  },
  {
    id: "Tiba di Tujuan",
    status: "Tiba di Tujuan",
    bg: "success-50",
    text: "success-400",
    action_button: "Lacak Pesanan",
    action_button_detail:[
      {
        buttonText:"Chat Penjual",
        color:'primary_secondary'
      },
      {
        buttonText:"Selesaikan Pesanan",
        color:'primary'
      }
    ]
  },
  {
    id: "Dibatalkan Penjual",
    status: "Dibatalkan Penjual",
    bg: "error-50",
    text: "error-400",
    action_button: "Detail Pesanan",
    action_button_detail:[
      {
        buttonText:"Chat Penjual",
        color:'primary_secondary'
      },
      {
        buttonText:"Bantuan",
        color:'primary_secondary'
      }
    ]
  },
  {
    id: "Dibatalkan Pembeli",
    status: "Dibatalkan Pembeli",
    bg: "error-50",
    text: "error-400",
    action_button: "Detail Pesanan",
    action_button_detail:[
      {
        buttonText:"Chat Penjual",
        color:'primary_secondary'
      },
      {
        buttonText:"Bantuan",
        color:'primary_secondary'
      }
    ]
  },
  {
    id: "Dibatalkan Sistem",
    status: "Dibatalkan Sistem",
    bg: "error-50",
    text: "error-400",
    action_button: "Detail Pesanan",
    action_button_detail:[
      {
        buttonText:"Chat Penjual",
        color:'primary_secondary'
      },
      {
        buttonText:"Bantuan",
        color:'primary_secondary'
      }
    ]
  },
  {
    id: "Dikomplain",
    status: "Dikomplain",
    bg: "error-400",
    text: "error-50",
    action_button: "Detail Komplain",
    action_button_detail:[
      {
        buttonText:"Chat Penjual",
        color:'primary_secondary'
      },
      {
        buttonText:"Detail Komplain",
        color:'primary'
      }
    ]
  },
  {
    id: "Pengembalian Dana Selesai",
    status: "Pengembalian Dana Selesai",
    bg: "success-400",
    text: "success-50",
    action_button: "Detail Pesanan",
    action_button_detail:[
      {
        buttonText:"Chat Penjual",
        color:'primary_secondary'
      },
      {
        buttonText:"Detail Komplain",
        color:'primary'
      }
    ]
  },
  {
    id: "Selesai",
    status: "Selesai",
    bg: "success-400",
    text: "success-50",
    action_button: {
      left: "Berikan Ulasan",
      right: "Beli Lagi",
    },
    action_button_detail:[
      {
        buttonText:"Chat Penjual",
        color:'primary_secondary'
      },
      {
        buttonText:"Berikan Ulasan",
        color:'primary'
      }
    ]
  },
  {
    id: "Komplain Selesai",
    status: "Komplain Selesai",
    bg: "success-400",
    text: "success-50",
    action_button: {
      left: "Berikan Ulasan",
      right: "Beli Lagi",
    },
    action_button_detail:[
      {
        buttonText:"Chat Penjual",
        color:'primary_secondary'
      },
      {
        buttonText:"Detail Komplain",
        color:'primary'
      }
    ]
  },
];
const OpsiMassal = [
    {name:'Unduh Daftar Pesanan',value:'unduh_daftar_pesanan'},
]
const Sort =[
  {name:'No. Invoice (A-z, 0-9)',value:'invoice'},
  {name:'Tanggal Pembayaran Terbaru',value:'date_desc'},
  {name:'Tanggal Pembayaran Terlama',value:'date_asc'},
  {name:'Batas Respon Terdekat',value:'respon_desc'},
  {name:'Batas Respon Terjauh',value:'respon_asc'},
  {name:'Jumlah Produk Terbesar',value:'product_desc'},
  {name:'Jumlah Produk Terkecil',value:'product_asc'},
  {name:'Total Pesanan Terbesar',value:'total_desc'},
  {name:'Total Pesanan Terkecil',value:'total_asc'},
]
function MenungguPembayaran() {
  const router = useCustomRouter()
  const { handleModal } = useContext(StateContext);
  const [getFilter,setFilter]=useState({
    status: "",
    buyer_status: "Menunggu Pembayaran",
    search: "",
    shipping_method: "",
    courier: "",
    sort: "",
    start_date: "",
    end_date: "",
    page: 1,
    limit: 10,
    payment_status: "",
    batas_respon: "",
    batas_dropoff: "",
    selesai_otomatis: ""
  })
  const {useSWRHook,useSWRMutateHook}=SWRHandler
  const {data,isLoading: order_loading}=useSWRHook(`${process.env.NEXT_PUBLIC_GLOBAL_API}v1/muatparts/orders?${metaSearchParams(getFilter)}`)
  const {data:filter_data}=useSWRHook(`${process.env.NEXT_PUBLIC_GLOBAL_API}/v1/muatparts/orders/filters`)
  const { trigger: triggerInvoiceDownload, isMutating: isDownloadingInvoice } = useSWRMutateHook(
    `${process.env.NEXT_PUBLIC_GLOBAL_API}v1/muatparts/seller/orders/download-invoices`,
    "POST"
  )
  // chat titip
  const { trigger: submitDataRoom } = useSWRMutateHook(
    `${process.env.NEXT_PUBLIC_CHAT_API}api/rooms/muat-muat`,
    "POST",
    null,
    null,
    { loginas: "seller" }
  );
  const directChatRoom = (id) => {
    const body = {
      recipientMuatId: id,
      recipientRole: "buyer",
      menuName: "Muatparts",
      subMenuName: "Muatparts",
      message: "",
      initiatorRole: "seller",
    }
    submitDataRoom(body).then((x) => {
      setTimeout(() => {
        router.push(
          `${
            process.env.NEXT_PUBLIC_CHAT_URL
          }initiate?initiatorId=&initiatorRole=${
            body.initiatorRole
          }&recipientId=${body.recipientMuatId}&recipientRole=${
            body.recipientRole
          }&menuName=${body.menuName}&subMenuName=${
            body.subMenuName
          }&accessToken=${authZustand.getState().accessToken}&refreshToken=${
            authZustand.getState().refreshToken
          }`
        );
      }, 2000);
    });
  };
  // chat titip
  const [dataFilter,setDataFilter]=useState([])
  function handleDownloadOrders(val) {
    triggerInvoiceDownload({
      transactionIds:val?.length?val:data?.Data?.orders?.map(val=>val?.id)
    }).then(a=>{
      if (a?.data?.Data) {
        window.open(a.data.Data, '_blank');
      }
    }).catch(()=> {
      handleModal({
        modalId: "modal_message",
        withHeader: true,
        closeArea: false,
        hideCloseButton: false,
        props: {
          message:<span className="bold-base">Terjadi Kesalahan Server</span>
        },
      })
    })
  }
  function handleFilter(field,value) {
    setFilter(a=>({...a,[field]:value}))
  }
  function handleActionButton(id,value) {
    if(id==='Detail') router.push(`/kelolapesanan/menungguPembayaran/${value?.id}`)
    if(id==='Chat Pembeli')  directChatRoom(value?.user_id)
  }
  useEffect(()=>{
    if(typeof filter_data?.Data==='object'&&Object.keys(filter_data?.Data).length) setDataFilter(Object.entries(filter_data?.Data).map(([key,val])=>({filterable:false,isMultiselect:false,key: key.toLowerCase(),type:capitalizeText(key?.replace('_',' ')),options:val?.map((op,i)=>({name:`Status-${i}`,label:op,value:key!=='response_limits'?op:`Kurang dari ${op} Jam`}))||[]})))
  },[filter_data])

  const {isMobile} = viewport()
  if(typeof isMobile!=='boolean') return <></> //buat skeleton
  if(isMobile) return <MenungguPembayaranResponsive isLoading={order_loading} Sort={Sort} isDownloadingInvoice={isDownloadingInvoice} handleDownloadOrders={handleDownloadOrders} others={data?.Data} data={data?.Data?.orders??[]} getFilter={getFilter} dataFilter={dataFilter||[]} status_pesanan={status_pesanan} handleFilter={handleFilter} setFilter={setFilter} />
  // Improvement fix wording pak Bryan
  return <MenungguPembayaranWeb Sort={Sort} OpsiMassal={OpsiMassal} isDownloadingInvoice={isDownloadingInvoice} handleDownloadOrders={handleDownloadOrders} others={data?.Data} dataFilter={dataFilter||[]} getFilter={getFilter} handleActionButton={handleActionButton} data={data?.Data?.orders??[]} status_pesanan={status_pesanan} handleFilter={handleFilter} isLoading={order_loading}/>
}

export default MenungguPembayaran
  