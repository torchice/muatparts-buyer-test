
import { useHeader } from '@/common/ResponsiveContext'
import React, { useEffect } from 'react'
import style from './IdMenungguPesanan.module.scss'
import DetailKelolaPesanan from '../../screens/DetailKelolaPesanan'
import TrackOrderMobile from '@/container/TrackOrderMobile/TrackOrderMobile'
function IdMenungguPesananResponsive({data,tracking_order,onCLickChat,downloadInvoice}) {
  const {
    appBarType, //pilih salah satu : 'header_title_secondary' || 'header_search_secondary' || 'default_search_navbar_mobile' || 'header_search' || 'header_title'
    appBar, // muncul ini : {onBack:null,title:'',showBackButton:true,appBarType:'',appBar:null,header:null}
    renderAppBarMobile, // untuk render komponen header mobile dengan memasukkanya ke useEffect atau by trigger function / closer
    setAppBar, // tambahkan payload seperti ini setAppBar({onBack:()=>setScreen('namaScreen'),title:'Title header',appBarType:'type'})
    handleBack, // dipanggil di dalam button di luar header, guna untuk kembali ke screen sebelumnya 
    clearScreen,// reset appBar
    setScreen, // set screen
    screen, // get screen,
    search, // {placeholder:'muatparts',value:'',type:'text'}
    setSearch, // tambahkan payload seperti ini {placeholder:'Pencarian',value:'',type:'text'}
  }=useHeader()
  useEffect(()=>{
      
    if(screen==='lacak_pesanan'){
      setAppBar({
        title:'Lacak Pesanan',
        appBarType:'header_title',
        onBack:()=> clearScreen()
      })
    }
  },[screen])
  if (screen==='lacak_pesanan') return <TrackOrderMobile data={tracking_order} />
  // main screen
  return <DetailKelolaPesanan downloadInvoice={downloadInvoice} onCLickChat={onCLickChat} {...data} onCLickTrack={()=>setScreen('lacak_pesanan')} onClickTrack={()=>setScreen('lacak_pesanan')} />
}

export default IdMenungguPesananResponsive
  