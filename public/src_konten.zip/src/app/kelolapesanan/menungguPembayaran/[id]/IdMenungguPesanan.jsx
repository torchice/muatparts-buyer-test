
'use client'
import viewport from '@/store/zustand/common'
import React, { useEffect, useState } from 'react'
import IdMenungguPesananResponsive from './IdMenungguPesananResponsive'
import IdMenungguPesananWeb from './IdMenungguPesananWeb'
import SWRHandler from '@/services/useSWRHook'
import { usePathname } from 'next/navigation'

function IdMenungguPesanan({params}) {
  const [state,setState]=useState()
  const pathname=usePathname()
  const {useSWRHook,useSWRMutateHook}=SWRHandler
  // const {data} = useSWRHook(`${process.env.NEXT_PUBLIC_GLOBAL_API}v1/muatparts/seller/orders/${pathname?.split('/')?.[3]}/invoice`)
  // 25. 11 - QC Plan - Web - Ronda Live Mei - LB - 0085
  const {data} = useSWRHook(`${process.env.NEXT_PUBLIC_GLOBAL_API}v1/muatparts/seller/orders/${params.params.id}/invoice`)
  const {data:tracking_order} = useSWRHook(`${process.env.NEXT_PUBLIC_GLOBAL_API}v1/muatparts/orders/${params.params.id}/tracking`)
  
  const {isMobile} = viewport()
  const { trigger: submitDataRoom } = useSWRMutateHook(
      `${process.env.NEXT_PUBLIC_CHAT_API}api/rooms/muat-muat`,
      "POST",
      null,
      null,
      { loginas: "seller" }
    )
  const { trigger: triggerDownloadInvoice } = useSWRMutateHook(`${process.env.NEXT_PUBLIC_GLOBAL_API}v1/muatparts/seller/orders/download-invoices`,)
  function downloadInvoice() {
    triggerDownloadInvoice({transactionIds:[pathname?.split('/')?.[3]]}).then(a=>{
      if(a?.status==200) window.open(a?.data?.Data,'_blank')
    })
  }
  const directChatRoom = (id) => {
    const body = {
      recipientMuatId: id,
      recipientRole: "buyer",
      menuName: "Muatparts",
      subMenuName: "Muatparts",
      message: "",
      initiatorRole: "seller",
    }
    submitDataRoom(body).then((x) => {
      setTimeout(() => {
        router.push(
          `${
            process.env.NEXT_PUBLIC_CHAT_URL
          }initiate?initiatorId=&initiatorRole=${
            body.initiatorRole
          }&recipientId=${body.recipientMuatId}&recipientRole=${
            body.recipientRole
          }&menuName=${body.menuName}&subMenuName=${
            body.subMenuName
          }&accessToken=${authZustand.getState().accessToken}&refreshToken=${
            authZustand.getState().refreshToken
          }`
        )
      }, 2000)
    })
  }
  useEffect(()=>{
    console.log(params.params.id)
  },[params])
    // chat titip
  if(typeof isMobile!=='boolean') return <></> //buat skeleton
  if(isMobile) return <IdMenungguPesananResponsive downloadInvoice={downloadInvoice} data={data?.Data} tracking_order={tracking_order?.Data?.data} onCLickChat={directChatRoom} />
  return <IdMenungguPesananWeb data={data?.Data} tracking_order={tracking_order?.Data?.data} onCLickChat={directChatRoom} />
}

export default IdMenungguPesanan
  