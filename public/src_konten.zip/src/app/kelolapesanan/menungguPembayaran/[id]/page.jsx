
import IdMenungguPesanan from './IdMenungguPesanan';

function Page(props) {
    return (
        <div className='w-full'>
            {/* 25. 11 - QC Plan - Web - Ronda Live Mei - LB - 0085 */}
            <IdMenungguPesanan params={props} />
        </div>
    );
}

export default Page;
  