
'use client';
import IconComponent from '@/components/IconComponent/IconComponent';
import style from './IdMenungguPesanan.module.scss'
import ImageComponent from '@/components/ImageComponent/ImageComponent';
import { useState } from 'react';
import TrackOrderMobile from '@/container/TrackOrderMobile/TrackOrderMobile';
import Button from '@/components/Button/Button';
import { useCustomRouter } from '@/libs/CustomRoute';
import { formatDate } from '@/libs/DateFormat';
import { numberFormatMoney } from '@/libs/NumberFormat';
function IdMenungguPesananWeb({data,tracking_order,onCLickChat}) {
    const router = useCustomRouter()
    const [getExpanded,setExpanded] = useState(['total_penjualan','total_biaya_layanan'])
    function handleExpand(params) {
        if(getExpanded?.some(a=>a===params)) setExpanded(getExpanded?.filter(a=>a!==params))
        else setExpanded(a=>[...a,params])
    }
    return (
        <div className={`${style.main} flex-col gap-4 text-neutral-900`}>
            <div className='flex gap-3 items-center'>
                <span className='cursor-pointer' onClick={()=>router.back()}><IconComponent src={'/icons/arrowbackblue.svg'} width={24} height={24} /></span>
                <span className='font-bold text-[20px]'>Detail Pesanan</span>
            </div>
            <div className="flex w-full justify-between gap-4 ">
                <div className="rounded-xl flex flex-col py-5 px-8 bg-neutral-50 gap-5 w-[70%]">
                    <div className="pb-3 flex border-b border-neutral-400 gap-3">
                        <div className='flex items-center gap-2 max-w-[228px] border-r border-neutral-400 pr-2'>
                            {data?.buyerInfo?.avatar[0]?<ImageComponent className={'rounded-full'} src={data?.buyerInfo?.avatar[0]} width={24} height={24} alt={'pho'} />:<span className='w-6 h-6 border border-neutral-400 rounded-full'></span>}
                            <span className="semi-sm w-full line-clamp-1">{data?.buyerInfo?.name}</span>
                        </div>
                        <div className='flex items-center gap-2 border-r border-neutral-400 pr-2'>
                            <IconComponent src={'/icons/user-truck.svg'} width={24} height={24} alt={'pho'} />
                            <span className="semi-sm w-full line-clamp-1">{data?.buyerInfo?.shippingName}</span>
                        </div>
                        <div className='flex items-center gap-2 '>
                            <IconComponent src={'/icons/time.svg'} width={24} height={24} alt={'pho'} />
                            <span className="semi-sm w-full line-clamp-1">{formatDate(data?.buyerInfo?.orderTime)}</span>
                        </div>

                    </div>
                    <div className='flex flex-col gap-6 pb-3 border-b border-neutral-400'>
                        <span className='font-semibold text-[18px]'>Rincian Pesanan</span>
                        {data?.orderDetails?.map((val,i)=><div key={i} className='w-full justify-between flex '>
                            <div  className='flex gap-3'>
                                <div className='w-[72px] h-[72px] rounded overflow-hidden'>
                                    {val?.productImage?<ImageComponent src={val?.productImage} width={72} height={72} alt={'pho'} />:<span className='w-[72px] h-[72px] border border-neutral-400'></span>}
                                </div>
                                <div className='flex flex-col gap-2'>
                                    <span className="bold-xs">{val?.name}</span>
                                    {val?.type&&<span className="font-medium text-[10px]">Tipe : {val?.type}</span>}
                                    {val?.sku&&<span className="font-medium text-[10px]">SKU : {val?.sku}</span>}
                                    {val?.notes&&<span className="font-medium text-[10px]">Catatan: {val?.notes}</span>}
                                    {
                                        val?.discountPercentage?<>
                                            <strike className="font-medium text-[10px] text-neutral-600">Rp1.300.000</strike>
                                            <div className='flex text-[10px] items-center'>
                                                <span className='font-bold'>3 x</span>
                                                <span className='font-bold text-error-500'>{numberFormatMoney(val?.discountedPrice)}</span>
                                                <span className='bg-success-50 text-success-400 semi-xs rounded-md p-1 ml-2'>{val?.discountPercentage}%</span>
                                            </div>
                                        </>
                                        :<span className='text-[10px] font-bold'>{numberFormatMoney(val?.basePrice)}</span>
                                    }
                                </div>
                            </div>
                            <span className='bold-sm'>{numberFormatMoney(val?.totalPrice)}</span>
                        </div>)}
                    </div>
                    <div className='flex flex-col gap-5'>
                        <div className='flex flex-col gap-5'>
                            <div className='w-full flex justify-between items-center'>
                                <span className='font-semibold text-[18px]'>Total Penjualan</span>
                                <div className='flex gap-3'>
                                    <span className='bold-sm'>{numberFormatMoney(data?.pricing?.totalSales)}</span>
                                    <span onClick={()=>handleExpand('total_penjualan')}>
                                        <IconComponent src={getExpanded?.includes('total_penjualan')?'/icons/chevron-up.svg':'/icons/chevron-down.svg'} width={20} height={20} />
                                    </span>
                                </div>
                            </div>
                            {getExpanded?.includes('total_penjualan')&&<div className='flex flex-col gap-5'>
                                <div className='w-full flex justify-between items-center'>
                                    <span className='text-neutral-600 medium-xs'>Harga Produk ({data?.orderDetails?.length} item)</span>
                                    <span className='medium-xs'>{numberFormatMoney(data?.pricing?.totalProductsPrice)}</span>
                                </div>
                                <div className='w-full flex justify-between items-center'>
                                    <span className='text-neutral-600 medium-xs'>Biaya Pengiriman ({data?.pricing?.shippingDetails?.name} - {data?.pricing?.shippingDetails?.weight/1000}Kg)</span>
                                    <span className={`medium-xs ${data?.pricing?.shippingDetails?'text-error-400':''}`}>{data?.pricing?.shippingDetails?.cost?`- ${numberFormatMoney(data?.pricing?.shippingDetails?.cost)}`:0}</span>
                                </div>
                                {data?.pricing?.vouchers?.map((val,i)=><div key={i} className='w-full flex justify-between items-center'>
                                    <span className='text-neutral-600 medium-xs'>{val?.title} ({val?.code})</span>
                                    <span className='medium-xs text-error-400'>- {numberFormatMoney(val?.claimedAmount)}</span>
                                </div>)}
                            </div>}
                        </div>
                        {data?.serviceFees?.breakdown?.length?<div className='flex flex-col gap-5'>
                            <div className='w-full flex justify-between items-center'>
                                <span className='font-semibold text-[18px]'>Total Biaya Layanan</span>
                                <div className='flex gap-3'>
                                    <span className='bold-sm'>- {numberFormatMoney(data?.serviceFees?.totalServiceFee)}</span>
                                    <span onClick={()=>handleExpand('total_biaya_layanan')}>
                                        <IconComponent src={getExpanded?.includes('total_biaya_layanan')?'/icons/chevron-up.svg':'/icons/chevron-down.svg'} width={20} height={20} />
                                    </span>
                                </div>
                            </div>
                            {getExpanded?.includes('total_biaya_layanan')&&
                            data?.serviceFees?.breakdown?.map((val,i)=><div key={i} className='flex flex-col gap-5'>
                                <div className='w-full flex justify-between items-center'>
                                    <span className='text-neutral-600 medium-xs'>{val?.description}</span>
                                    <span className='medium-xs text-error-400'>- {numberFormatMoney(val?.serviceFee)}</span>
                                </div>
                            </div>)}
                        </div>:''}
                        <div className="pt-5 border-t border-neutral-400 flex w-full justify-between items-center">
                            <span className='font-semibold text-[18px]'>Total Penghasilan yang Diterima</span>
                            <span className='bold-sm'>{numberFormatMoney(data?.pricing?.grandTotal)}</span>
                        </div>
                    </div>
                </div>
                <div className="flex flex-col gap-4 w-[30%] ">
                    <div className='bg-neutral-50 rounded-xl'>
                        <TrackOrderMobile data={tracking_order?.history} />
                    </div>
                    <Button Class='!max-w-none !w-full' color='primary_secondary' onClick={()=>onCLickChat(data?.buyerInfo?.usersId)} iconLeft={<IconComponent src={'/icons/chat.svg'} classname={'icon-blue'} />} >Chat Pembeli</Button>
                </div>
            </div>
        </div>
    );
}

export default IdMenungguPesananWeb;
  