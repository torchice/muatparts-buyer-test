"use client";
import { useEffect, useState } from "react";
import style from "./MenungguPembayaran.module.scss";
import Dropdown from "@/components/Dropdown/Dropdown";
import Button from "@/components/Button/Button";
import Input from "@/components/Input/Input";
import IconComponent from "@/components/IconComponent/IconComponent";
import CardPesananSeller from "@/components/CardPesananSeller/CardPesananSeller";
import DataNotFound from "@/components/DataNotFound/DataNotFound";
import PaginationContainer from "@/container/PaginationContainer/PaginationContainer";
import { Pagination } from "@/components/AnalisaProdukComponent/Pagination";
import Tooltip from "@/components/Tooltip/Tooltip";
import Filter from "@/components/Filter/Filter";
import { useForm } from "react-hook-form";
import ModalComponent from "@/components/Modals/ModalComponent";
import Checkbox from "@/components/Checkbox/Checkbox";
import Card, { CardContent } from "@/components/Card/Card";
import { ChevronDown } from "lucide-react";
import { formatDate } from "@/libs/DateFormat";
import ImageComponent from "@/components/ImageComponent/ImageComponent";
import { numberFormatMoney } from "@/libs/NumberFormat";
import { useTranslation } from "@/context/TranslationProvider";
import SkeletonLoaderMenungguPembayaran from "@/components/KelolaPesananComponent/SkeletonLoaderMenungguPembayaran";
import TranslationSkeleton from "@/components/Skeleton/TranslationSkeleton";

function MenungguPembayaranWeb({
  OpsiMassal,
  Sort,
  others,
  status_pesanan,
  data,
  getFilter,
  handleFilter,
  handleActionButton,
  dataFilter,
  isDownloadingInvoice,
  handleDownloadOrders,
  isLoading,
}) {
  // Improvement fix wording pak Bryan
  const { t, tOrEmpty } = useTranslation();
  const [getSearch, setSearch] = useState("");
  const [getSelected, setSelected] = useState([]);
  const [getSelectedDownload, setSelectedDownload] = useState([]);
  const [getExpanded, setExpanded] = useState([]);
  const [showFilter, setShowFilter] = useState(false);
  const [showFilterMassal, setShowFilterMassal] = useState(false);

  const { control, getValues, setValue, watch } = useForm();
  const {
    control: controlMassal,
    getValues: getValuesMassal,
    setValue: setValueMassal,
    watch: watchMassal,
  } = useForm();

  function handleExpand(id) {
    if (getExpanded.some((a) => a === id))
      setExpanded(getExpanded.filter((a) => a !== id));
    else setExpanded((a) => [...a, id]);
  }
  return (
    <div
      className={`${style.main} flex flex-col text-neutral-900`}
    >
      <ModalComponent
        isOpen={getSelected?.[0]?.["value"] === "unduh_daftar_pesanan"}
        setClose={() => setSelected([])}
        hideHeader
        full
      >
        <div className="p-4 flex flex-col gap-3 w-[800px]">
          <span className="bold-base self-center">Unduh Daftar Pesanan</span>
          <div className="border border-neutral-400 rounded-xl flex flex-col gap-3 p-3">
            <div className="w-full flex justify-between items-center">
              <div className="flex gap-3 item-center">
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    handleFilter("search", getSearch);
                  }}
                >
                  <Input
                    classname={"!w-[200px]"}
                    icon={{ left: "/icons/search.svg" }}
                    placeholder="Cari No.Invoice/ Nama Produk / SKU"
                    value={getSearch}
                    changeEvent={(e) => setSearch(e.target.value)}
                  />
                </form>
                <Dropdown
                  options={Sort}
                  classname={style.dropdownInvoice}
                  placeholder="No. Invoice"
                  leftIconElement={<IconComponent src={"/icons/sorting.svg"} />}
                />
                <Filter
                  data={dataFilter || []}
                  control={controlMassal}
                  getValues={getValuesMassal}
                  // isActive={selectedFilters.length > 0}
                  isOpen={showFilterMassal}
                  onSelect={(checked, field, value) =>
                    handleFilter(field, checked ? value : "")
                  }
                  setIsOpen={setShowFilterMassal}
                  setValue={setValueMassal}
                  watch={watchMassal}
                  // disabled={
                  //     !product?.Data?.length ||
                  //     !Array.isArray(product?.Data) ||
                  //     !product
                  // }
                />
              </div>
              <Checkbox
                label="Pilih Semua Pesanan"
                onChange={(a) =>
                  a?.checked
                    ? setSelectedDownload(data?.map((val) => val?.id))
                    : setSelectedDownload([])
                }
              />
            </div>

            <span className="h-[1px] w-full bg-neutral-400"></span>
            <div className="pr-2 flex flex-col gap-3 max-h-[256px] overflow-y-auto">
              {
                // my biggest sin, this card generated by AI
                data?.map((val) => (
                  <div
                    key={val?.id}
                    className="py-4 px-6 border rounded-lg shadow-sm border-neutral-400"
                  >
                    <div className="flex items-center justify-between ">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          label=""
                          checked={getSelectedDownload.some(
                            (a) => a === val?.id
                          )}
                          onChange={(a) =>
                            a?.checked
                              ? setSelectedDownload((a) => [...a, val?.id])
                              : setSelectedDownload(
                                  getSelectedDownload.filter(
                                    (a) => a !== val?.id
                                  )
                                )
                          }
                        />
                        <span className="text-primary-700 bg-primary-50 font-medium">
                          {val?.invoice_number}
                        </span>
                        <span className="text-neutral-600 flex items-center">
                          <IconComponent src={"/icons/calendar.svg"} />{" "}
                          <span>{formatDate(val?.order_date)}</span>
                        </span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <ImageComponent
                          alt={"ss"}
                          src={val?.customer?.image_url}
                          width={24}
                          height={24}
                          className={"rounded-full"}
                        />
                        <span className="text-neutral-900 font-medium">
                          {val?.customer?.name}
                        </span>
                      </div>
                    </div>
                    {val?.products
                      ?.slice(
                        0,
                        getExpanded?.some((a) => a === val?.id)
                          ? val.products.length
                          : 1
                      )
                      ?.map((val) => (
                        <CardContent
                          key={val?.id}
                          classname={"flex justify-between items-center"}
                        >
                          <ImageComponent
                            alt={"ss"}
                            src={val?.image_url}
                            width={32}
                            height={32}
                            className={"rounded"}
                          />
                          <div className="flex-1 ml-4">
                            <p className="font-semibold text-sm">{val?.name}</p>
                          </div>
                          {val?.quantity > 1 && (
                            <div className="text-gray-700 font-medium">
                              X {val?.quantity}
                            </div>
                          )}
                        </CardContent>
                      ))}
                    <div
                      className={`flex items-center mt-2 ${
                        val?.products?.length > 1
                          ? "justify-between"
                          : "justify-end"
                      }`}
                    >
                      {val?.products?.length > 1 && (
                        <span
                          onClick={() => handleExpand(val?.id)}
                          className="text-primary-700 flex items-center medium-xs"
                        >
                          Lihat Semua Produk{" "}
                          <ChevronDown size={16} className="ml-1" />
                        </span>
                      )}
                      <div className="medium-xs text-neutral-600 self-end">
                        Total{" "}
                        <span className="text-gray-900 bold-xs">
                          {numberFormatMoney(val?.total_amount)}
                        </span>
                      </div>
                    </div>
                  </div>
                ))
              }
            </div>
          </div>
          <div className="flex w-full justify-between items-center">
            <span className="bold-xs">
              Terpilih : {getSelectedDownload.length} pesanan
            </span>
            <Button
              Class="!h-8"
              disabled={getSelectedDownload.length == 0}
              onClick={() => handleDownloadOrders(getSelectedDownload)}
            >
              Unduh Daftar Pesanan
            </Button>
          </div>
        </div>
      </ModalComponent>
      <div className="py-6 w-full max-w-full flex gap-4 flex-col">
        {/* head */}
        <div className="flex flex-col gap-4">
          <div className="flex w-full gap-2">
            <TranslationSkeleton
              parentClassName="min-w-[200px] min-h-5"
              className="font-bold text-xl"
              label="WebKelolaPesananSellerMuatpartspesananMenungguPembayaranPesananMenungguPembayaran"
            />
            <span className="mt-1 relative group">
              <IconComponent src={"/icons/info.svg"} width={20} height={20} />
              <Tooltip
                title={
                  "Pada halaman ini Anda dapat memantau pesanan baru yang akan masuk dan Anda dapat memanfaatkan informasi ini untuk memperbarui stok produk. Pada produk dengan demand yang tinggi, apabila pembayaran berhasil dilakukan ketika stoknya habis maka pesanan otomatis dibatalkan oleh sistem."
                }
              />
            </span>
          </div>
        </div>
        <div className="bg-neutral-50 p-8 rounded-xl flex flex-col gap-6">
          <div className="flex w-full justify-between">
            <div className="flex gap-3 item-center">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleFilter("search", getSearch);
                }}
              >
                <Input
                  classname={"!w-[262px]"}
                  icon={{ left: "/icons/search.svg" }}
                  placeholder={tOrEmpty(
                    "WebKelolaPesananSellerMuatpartspesananMenungguPembayaranCariNo.Invoice/NamaProduk/SKU"
                  )}
                  value={getSearch}
                  changeEvent={(e) => setSearch(e.target.value)}
                />
              </form>
              <Dropdown
                options={Sort}
                onSelected={(a) => handleFilter("sort", a[0]["value"])}
                classname={style.dropdownInvoice}
                placeholder={tOrEmpty("AppKelolaPesananSellerMuatpartsNoInvoice")}
                leftIconElement={<IconComponent src={"/icons/sorting.svg"} />}
              />
              <Filter
                data={dataFilter || []}
                control={control}
                getValues={getValues}
                // isActive={selectedFilters.length > 0}
                isOpen={showFilter}
                onSelect={(checked, field, value) =>
                  handleFilter(field, checked ? value : "")
                }
                setIsOpen={setShowFilter}
                setValue={setValue}
                watch={watch}
                // disabled={
                //     !product?.Data?.length ||
                //     !Array.isArray(product?.Data) ||
                //     !product
                // }
              />
            </div>
            <div className="flex gap-3 item-center">
              <Dropdown
                defaultValue={getSelected}
                classname={style.dropdownAturMassal}
                placeholder={t(
                  "WebKelolaPesananSellerMuatpartspesananMenungguPembayaranAturMassal"
                )}
                options={OpsiMassal}
                onSelected={(a) => setSelected(a)}
              />
              <Button
                onClick={handleDownloadOrders}
                Class="!h-8"
                iconLeft={
                  <IconComponent
                    src={"/icons/download.svg"}
                    classname={"icon-white"}
                    width={20}
                    height={20}
                  />
                }
              >
                Unduh
              </Button>
            </div>
          </div>
          {isLoading ? (
            <SkeletonLoaderMenungguPembayaran />
          ) : data.length === 0 && !getSearch ? (
            <DataNotFound
              type="data"
              title={t(
                "WebKelolaPesananSellerMuatpartspesananMenungguPembayaranTidakadadaftarpesanan"
              )}
            />
          ) : data.length === 0 && getSearch ? (
            <DataNotFound
              title={t(
                "WebKelolaPesananSellerMuatpartspesananMenungguPembayaranTidakadapesanan"
              )}
            />
          ) : (
            data?.map((val) => (
              <CardPesananSeller
                handleActionButton={handleActionButton}
                key={val?.id}
                status_pesanan={status_pesanan}
                {...val}
                val={val}
              />
            ))
          )}
          <Pagination
            currentPage={getFilter?.page}
            totalPages={others?.pagination?.total_pages}
            itemsPerPage={getFilter?.limit}
            onPageChange={(a) => handleFilter("page", a)}
            onItemsPerPageChange={(a) => handleFilter("limit", a)}
          />
        </div>
      </div>
    </div>
  );
}

export default MenungguPembayaranWeb;
