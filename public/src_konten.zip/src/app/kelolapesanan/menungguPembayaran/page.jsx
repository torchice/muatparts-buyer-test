
import MenungguPembayaran from './MenungguPembayaran';
function Page() {
    return (
        <div className='w-full'>
            <MenungguPembayaran />
        </div>
    );
}

export default Page;
  