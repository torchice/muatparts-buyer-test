"use client";
import { useState, useEffect, useCallback } from "react";
import { addMinutes, addDays, format, differenceInHours, differenceInDays } from "date-fns";
import { TopBar } from "@/components/headersellercomponents/TopBar";
import SidebarWithDropdown from "@/components/headersellercomponents/SidebarWithDropdown";
import PromoProductPopup from "@/components/PromoCreate/PromoProductPopup";
import style from "./promo.module.scss";
import { MockServer_Promo } from "@/services/MockServer_Promo";
import { formatCurrency } from "@/components/PromoCreate/CurrencyUtils";
import ProductTable from "@/components/PromoCreate/ProductTable";
import Input from "@/components/Input/Input";
import DatetimePicker from "@/components/DatetimePicker/DatetimePicker";
import AturMassalPopup from "@/components/PromoForm/AturMassalPopup";
import { useCustomRouter } from '@/libs/CustomRoute';
import DefaultModalConfirmation from "@/ModalComponents/KelolaProduk/DefaultModalConfirmation/DefaultModalConfirmation";
import ImageComponent from '@/components/ImageComponent/ImageComponent';

export default function CreatePromotion() {
  const router = useCustomRouter();

  // Form States
  const [promoName, setPromoName] = useState("");
  const [startDate, setStartDate] = useState(() => addMinutes(new Date(), 15));
  const [endDate, setEndDate] = useState(() => addDays(addMinutes(new Date(), 15), 30));
  const [purchaseLimit, setPurchaseLimit] = useState("no_limit");
  const [selectedProducts, setSelectedProducts] = useState([]);

  // UI States
  const [showProductPopup, setShowProductPopup] = useState(false);
  const [isAturMassalOpen, setIsAturMassalOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [showBackConfirmation, setShowBackConfirmation] = useState(false);
  const [showToast, setShowToast] = useState({ show: false, message: "", type: "" });
  const [searchQuery, setSearchQuery] = useState("");
  const [activeFilters, setActiveFilters] = useState([]);

  // Validation States
  const [errors, setErrors] = useState({
    name: "",
    startDate: "",
    endDate: "",
    products: "",
  });

  // Fetch products function
  const fetchProducts = async (params = {}) => {
    try {
      const response = await MockServer_Promo.getPromotionProducts({
        startDate: format(startDate, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"),
        endDate: format(endDate, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"),
        filters: {
          activeOnly: true,
          categories: params.categories || activeFilters.filter(f => f.type === 'category').map(f => f.id),
          brands: params.brands || activeFilters.filter(f => f.type === 'brand').map(f => f.id),
          ...params.filters
        },
        search: params.search || searchQuery,
        sort: params.sort
      });

      if (response?.Data?.products) {
        return response.Data.products;
      }
      return [];
    } catch (error) {
      console.error("Error fetching products:", error);
      setShowToast({
        show: true,
        message: "Gagal memuat daftar produk",
        type: "error"
      });
      return [];
    }
  };

  // Fetch filter data function
  const fetchFilterData = async () => {
    try {
      const response = await MockServer_Promo.getPromotionFilters({
        startDate: format(startDate, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"),
        endDate: format(endDate, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"),
        currentProducts: selectedProducts.map(p => p.id)
      });

      if (response?.Data) {
        return {
          categories: response.Data.categories || [],
          brands: response.Data.brands || [],
          // Tambahkan filter lain jika diperlukan
        };
      }
      return {};
    } catch (error) {
      console.error("Error fetching filters:", error);
      setShowToast({
        show: true,
        message: "Gagal memuat data filter",
        type: "error"
      });
      return {};
    }
  };

  // Validation Functions
  const validateForm = useCallback(() => {
    const newErrors = {};

    // Validate promo name
    if (!promoName.trim()) {
      newErrors.name = "Nama promosi wajib diisi";
    } else if (promoName.length > 60) {
      newErrors.name = "Nama promosi maksimal 60 karakter";
    }

    // Validate dates
    const hoursDiff = differenceInHours(endDate, startDate);
    const daysDiff = differenceInDays(endDate, startDate);

    if (hoursDiff < 1) {
      newErrors.startDate = "Durasi promosi minimal 1 jam";
    }
    if (daysDiff > 180) {
      newErrors.endDate = "Durasi promosi maksimal 180 hari";
    }

    // Validate products
    if (selectedProducts.length === 0) {
      newErrors.products = "Minimal pilih 1 produk";
    } else if (selectedProducts.length > 30) {
      newErrors.products = "Maksimal 30 produk";
    }

    // Validate product details
    const invalidProducts = selectedProducts.filter(product => {
      if (!product.quota) return true;
      if (purchaseLimit !== 'no_limit' && !product.purchaseLimit) return true;
      if (product.variants?.length > 0) {
        return product.variants.some(variant => {
          if (variant.isActive && !variant.quota) return true;
          if (variant.isActive && purchaseLimit !== 'no_limit' && !variant.purchaseLimit) return true;
          return false;
        });
      }
      return false;
    });

    if (invalidProducts.length > 0) {
      newErrors.products = "Mohon lengkapi data produk yang dipilih";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }, [promoName, startDate, endDate, selectedProducts, purchaseLimit]);

  // Handle back navigation
  const handleBack = () => {
    if (hasUnsavedChanges()) {
      setShowBackConfirmation(true);
    } else {
      router.push("/promotions/listpromo_final");
    }
  };

  // Check for unsaved changes
  const hasUnsavedChanges = () => {
    return promoName !== "" || selectedProducts.length > 0;
  };

  // Handle product selection
  const handleProductSelect = async (products) => {
    try {
      const response = await MockServer_Promo.getPromotionProducts({
        startDate: format(startDate, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"),
        endDate: format(endDate, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"),
        filters: {
          ids: products,
          activeOnly: true,
          categories: activeFilters.filter(f => f.type === 'category').map(f => f.id),
          brands: activeFilters.filter(f => f.type === 'brand').map(f => f.id)
        },
        search: searchQuery
      });

      if (response?.Data?.products) {
        setSelectedProducts(response.Data.products);
      }
    } catch (error) {
      setShowToast({
        show: true,
        message: "Gagal memuat produk",
        type: "error"
      });
    }
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) {
      setShowToast({
        show: true,
        message: "Mohon lengkapi semua field yang wajib",
        type: "error"
      });
      return;
    }

    setIsLoading(true);
    try {
      const formData = {
        promoName,
        startDate: format(startDate, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"),
        endDate: format(endDate, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"),
        purchaseLimit,
        selectedProducts: selectedProducts.map(formatProductData)
      };

      const response = await MockServer_Promo.createPromotion(formData);

      if (response.success) {
        setShowToast({
          show: true,
          message: "Promosi berhasil dibuat",
          type: "success"
        });
        router.push("/promotions/listpromo_final");
      }
    } catch (error) {
      setShowToast({
        show: true,
        message: error.message || "Gagal membuat promosi",
        type: "error"
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Format product data for API
  const formatProductData = (product) => {
    const baseProduct = {
      id: product.id,
      quota: product.quota,
      purchaseLimit: product.purchaseLimit,
    };

    if (product.promoPrice) {
      baseProduct.promoPrice = product.promoPrice;
    } else if (product.discount) {
      baseProduct.discount = product.discount;
    }

    if (product.variants?.length > 0) {
      baseProduct.variants = product.variants.map(formatVariantData);
    }

    return baseProduct;
  };

  // Format variant data for API
  const formatVariantData = (variant) => {
    const variantData = {
      variantId: variant.id,
      isActive: variant.isActive,
    };

    if (variant.isActive) {
      variantData.quota = variant.quota;
      if (purchaseLimit !== 'no_limit') {
        variantData.purchaseLimit = variant.purchaseLimit;
      }
      if (variant.promoPrice) {
        variantData.promoPrice = variant.promoPrice;
      } else if (variant.discount) {
        variantData.discount = variant.discount;
      }
    }

    return variantData;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <TopBar />

      <aside className="fixed top-[56px] left-0 w-[184px] bg-white shadow-sm">
        <SidebarWithDropdown />
      </aside>

      <main className={"ml-[0px] pt-14 " + style.promo}>
        {/* Breadcrumb */}
        <div className="flex items-center px-6 py-4 text-xs">
          <span className="text-gray-500 hover:text-gray-700 cursor-pointer"
            onClick={() => router.push("/dashboard")}>
            Dashboard
          </span>
          <ImageComponent src="/promo/breadcrumb_cevron.svg" alt="/" className="w-4 h-4" />
          <span className="text-gray-500 hover:text-gray-700 cursor-pointer"
            onClick={() => router.push("/promotions/listpromo_final")}>
            Kelola Promosi
          </span>
          <ImageComponent src="/promo/breadcrumb_cevron.svg" alt="/" className="w-4 h-4" />
          <span className="text-blue-600 font-semibold">Buat Promosi</span>
        </div>

        {/* Page Title */}
        <div className={"px-6 py-4 flex items-center gap-3 "}>
          <ImageComponent src="/promo/back_button_header.svg"
            alt="back"
            className="w-6 h-6 cursor-pointer"
          />
          <h1 className="text-xl font-bold">Buat Promosi</h1>
        </div>

        {/* Main Form */}
        <form onSubmit={handleSubmit} className="px-6 pb-6 space-y-6">
          {/* Promotion Info Card */}
          <div className="bg-white rounded-xl shadow-sm p-8">
            <h2 className="text-lg font-bold text-[var(--neutral-900)] mb-8">
              Informasi Promosi
            </h2>

            <div className="flex flex-col gap-6">
              {/* Promo Name */}
              <div className="flex gap-8 items-start">
                <div className="w-[178px] text-xs text-[var(--neutral-700)]">
                  Nama Promosi*
                </div>
                <div className="flex-1 max-w-[514px]">
                  <Input
                    name="promoName"
                    type="text"
                    value={promoName}
                    changeEvent={(e) => setPromoName(e.target.value)}
                    maxLength={60}
                    placeholder="Contoh : Diskon Tahun Baru"
                    supportiveText={{
                      title:
                        "Catatan : Nama promosi tidak tampil di sisi Pembeli",
                      desc: `${promoName.length}/60`,
                    }}
                    width={{ width: "100%" }}
                    classInput="text-[var(--neutral-900)] placeholder:text-[var(--neutral-500)]"
                    status={errors?.name ? "error" : null}
                  />
                </div>
              </div>

              {/* Date Range */}
              <div className="flex gap-8 items-center">
                <div className="w-[178px] text-xs text-[var(--neutral-700)]">
                  Masa Berlaku*
                </div>
                <div className="flex items-center gap-4">
                  <DatetimePicker
                    datetimeValue={startDate}
                    onApply={(e) => setStartDate(e.target.value)}
                  />
                  <span className="text-sm font-semibold text-[var(--neutral-900)]">
                    s/d
                  </span>
                  <DatetimePicker
                    datetimeValue={endDate}
                    onApply={(e) => setEndDate(e.target.value)}
                  />
                </div>
              </div>

              {/* Purchase Limit */}
              <div className="flex gap-8 items-start">
                <div className="w-[178px] text-xs text-[var(--neutral-700)]">
                  Jenis Batas Pembelian*
                </div>
                <div className="flex gap-5">
                  {[
                    {
                      value: "no_limit",
                      label: "Tanpa Batas",
                      description:
                        "Jumlah pemakaian promosi tidak dibatasi, kuota diatur oleh penjual.",
                    },
                    {
                      value: "limit_per_user",
                      label: "Pembatasan Per Pembeli",
                      description:
                        "Jumlah pembelian dibatasi untuk tiap pembeli",
                    },
                    {
                      value: "limit_per_invoice",
                      label: "Pembatasan Per Nota",
                      description:
                        "Jumlah nota pembelian dibatasi untuk tiap pembeli",
                    },
                  ].map((option) => (
                    <label
                      key={option.value}
                      className="flex flex-col w-[220px] cursor-pointer"
                    >
                      <div className="flex items-center gap-2">
                        <input
                          type="radio"
                          name="purchaseLimit"
                          value={option.value}
                          checked={purchaseLimit === option.value}
                          onChange={(e) => setPurchaseLimit(e.target.value)}
                          className="hidden"
                        />
                        <div
                          className={`w-4 h-4 rounded-full border relative
                  ${purchaseLimit === option.value
                              ? "bg-[var(--primary-600)] border-[var(--primary-600)]"
                              : "border-[var(--neutral-300)]"
                            }
                  ${purchaseLimit === option.value &&
                            'after:content-[""] after:absolute after:w-2 after:h-2 after:bg-white after:rounded-full after:top-1/2 after:left-1/2 after:-translate-x-1/2 after:-translate-y-1/2'
                            }
                `}
                        />
                        <span className="text-sm text-[var(--neutral-900)]">
                          {option.label}
                        </span>
                      </div>
                      <p className="ml-6 mt-1 text-xs text-[var(--neutral-500)]">
                        {option.description}
                      </p>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Products Section */}
          <div className="bg-white rounded-xl shadow-sm px-8 pt-8 pb-[100px]">
            <h2 className="text-lg font-bold mb-6">Daftar Produk Promosi</h2>

            {selectedProducts.length === 0 ? (
              <div className="flex flex-col items-center py-12 bg-gray-50 rounded-xl border border-gray-200">
                <ImageComponent src="/promo/no_data_product.png"
                  alt=""
                  className="mb-4 w-[93px] h-[74px]"
                />
                <p className="text-gray-500 mb-2">
                  Kamu belum memilih produk untuk Promo ini
                </p>
                <p className="text-xs text-gray-500 mb-4">
                  Pilih produkmu terlebih dahulu
                </p>
                <button
                  type="button"
                  onClick={() => setShowProductModal(true)}
                  className="px-6 py-2 text-white bg-blue-600 rounded-full"
                >
                  Pilih Produk
                </button>
              </div>
            ) : (
              <ProductTable
                products={selectedProducts}
                onProductUpdate={handleProductUpdate}
                purchaseLimitType={purchaseLimit} // Convert to expected format
              />
            )}
          </div>

          {/* Footer */}
          <div className="fixed bottom-0 left-[184px] right-0 bg-white border-t px-12 py-4 flex justify-between items-center">
            <div className="font-bold">
              Total Produk : {selectedProducts.length}
            </div>
            <button
              type="submit"
              className="px-6 py-2 text-white bg-blue-600 rounded-full"
            >
              Simpan
            </button>
          </div>
        </form>
      </main>

      {/* Modals */}
      {showBackConfirmation && (
        <DefaultModalConfirmation
          title="Konfirmasi"
          message="Perubahan belum tersimpan. Yakin ingin keluar?"
          onConfirm={() => {
            setShowBackConfirmation(false);
            router.push("/promotions/listpromo_final");
          }}
          onCancel={() => setShowBackConfirmation(false)}
        />
      )}

      {/* Product Selection Popup */}
      {showProductPopup && (
        <PromoProductPopup
          isOpen={showProductPopup}
          onClose={() => setShowProductPopup(false)}
          onSave={handleProductSelect}
          maxSelectedProducts={30}
          startDate={startDate}
          endDate={endDate}
          fetchProducts={fetchProducts}
          fetchFilterData={fetchFilterData}
          onSearch={setSearchQuery}
          onFilter={setActiveFilters}
          columns={[
            {
              key: "name",
              title: "Produk",
              sortable: true,
              width: "w-1/3",
              render: (item) => (
                <div className="flex items-center gap-3">
                  <ImageComponent src={item.imageUrl || "/placeholder.png"}
                    alt={item.name}
                    className="w-8 h-8 rounded"
                  />
                  <div>
                    <div className="font-medium">{item.name}</div>
                    <div className="text-sm text-gray-500">
                      SKU: {item.sku} • Brand: {item.brand.name}
                    </div>
                  </div>
                </div>
              ),
            },
            {
              key: "price",
              title: "Harga",
              sortable: true,
              width: "w-1/4",
              render: (item) => formatCurrency(item.price),
            },
            {
              key: "stock",
              title: "Stok",
              sortable: true,
              width: "w-1/6",
            },
          ]}
        />
      )}

      {/* Mass Update Popup */}
      {isAturMassalOpen && (
        <AturMassalPopup
          isOpen={isAturMassalOpen}
          onClose={() => setIsAturMassalOpen(false)}
          onApply={handleMassUpdate}
          products={selectedProducts}
          isLimitedPurchase={purchaseLimit !== 'no_limit'}
        />
      )}
    </div>
  );
}





