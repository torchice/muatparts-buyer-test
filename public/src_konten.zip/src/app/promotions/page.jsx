// src/app/promotions/page.jsx
// 24. THP 2 - MOD001 - MP - 022 - QC Plan - Web - MuatParts - Promo
// LB - 0019
// LB - 0051
// LB - 0093
// LB - 0118
// LB - 0123
// LB - 0130
// LB - 0131
// LB - 0132
// LB - 0146
// LB - 0147
// LB - 0150
// LB - 0152
// LB - 0154
// LB - 0161

'use client';
import React, { useState, useEffect } from 'react';
import promoService from "@/services/MockServer_Promotion";
import Button from '@/components/Button/Button';
import CustomLink from '@/components/CustomLink';
import { EmptyPromotions } from '@/components/Promotions/PromoList/EmptyState';
import PromoTable from '@/components/Promotions/PromoList/PromoTable';
import toast from '@/store/zustand/toast'; // """Keep existing toast store import"""
import { useLanguage } from '@/providers/LanguageProvider';
import { useCustomRouter } from '@/libs/CustomRoute';
import Toast from '@/components/Toast/Toast';

// Add Modal for delete confirmation
import Modal from '@/components/Modals/modal';
import ModalComponent from '@/components/Modals/ModalComponent';

import PaginationContainer from '@/container/PaginationContainer/PaginationContainer';

export default function PromotionList() {
  const router = useCustomRouter();
  const [activeTab, setActiveTab] = useState('active');
  const [promos, setPromos] = useState([]);
  const [promoCountData, setPromoCountData] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [tabCounts, setTabCounts] = useState({ active: 0, history: 0 });
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({
    activeFilters: [],
    status: [],
    dateRange: null
  });
  const { t } = useLanguage();

  // Add states for delete modal
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [selectedPromo, setSelectedPromo] = useState(null);
  const { showToast, setShowToast, setDataToast } = toast();
  const [successModal, setSuccessModal] = useState(false);
  const [isSearching, setIsSearching] = useState(false); // New state for search loading
	const [timezone, setTimezone] = useState('WIB');

  const [showEndModal, setShowEndModal] = useState(false);

  const [pagination, setPagination] = useState({
    currentPage: 1,
    pageSize: 10,
    totalPages: 1
  });

  const isTableLoading = isLoading || isSearching;

  const fetchPromos = async () => {
    try {
      setIsLoading(true);

      // Ensure page and page_size are numbers
      const page = Number(pagination.currentPage);
      const pageSize = Number(pagination.pageSize);

      const params = {
        tab: activeTab,
        search: searchQuery,
        page: page,
        page_size: pageSize,
        filters: {
          status: filters.status.length > 0 ? filters.status : undefined,
          ...(filters.dateRange?.startDate && {
            startDate: filters.dateRange.startDate
          }),
          ...(filters.dateRange?.endDate && {
            endDate: filters.dateRange.endDate
          })
        }
      };

      const response = await promoService.getPromotionList(params);

      if (response?.Data?.promos && Array.isArray(response.Data.promos)) {
        const transformedPromos = response.Data.promos.map(promo => ({
          id: promo.id || '',
          name: promo.name || '',
          status: promo.status || '',
          startDate: promo.startDate || '',
          endDate: promo.endDate || '',
          totalProducts: promo.totalProducts || 0,
          totalVariants: promo.totalVariants || 0,
          products: Array.isArray(promo.products) ? promo.products.map(product => ({
            id: product.id || '',
            name: product.name || '',
            image: product.image || '',
            sku: product.sku || '',
            brand: product.brand || '',
            variant_name: product.variant_name || '',
            variant_value: product.variant_value || '',
          })) : []
        }));

        setPromos(transformedPromos);
        setTabCounts({
          active: response.Data.tabCounts?.active || 0,
          history: response.Data.tabCounts?.history || 0
        });
        setPromoCountData(response.total)
      } else {
        setPromos([]);
        setTabCounts({ active: 0, history: 0 });
      }
    } catch (error) {
      console.error('Error fetching promotions:', error);
      setPromos([]);
      setTabCounts({ active: 0, history: 0 });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    // Use the correct count based on active tab
    const totalItems = activeTab === 'active' ? tabCounts.active : tabCounts.history;
    const newTotalPages = Math.ceil(totalItems / pagination.pageSize);

    console.log('setPagination 1', getTotalPages());
    setPagination(prev => ({
      ...prev,
      totalPages: getTotalPages(),
    }));
  }, [tabCounts, promos.length]);

  useEffect(() => {
    // Use the correct count based on active tab
    const totalItems = activeTab === 'active' ? tabCounts.active : tabCounts.history;
    const newTotalPages = Math.ceil(totalItems / pagination.pageSize);

    console.log('setPagination 99', getTotalPages());
    setPagination(prev => ({
      ...prev,
      totalPages: getTotalPages(),
      currentPage: 1 // Reset to first page when tab changes
    }));
  }, [activeTab, pagination.pageSize])

  useEffect(() => {
    if (!isSearching) {
      console.log('useEffect fetchPromos')
      fetchPromos();
    }
  }, [activeTab, filters, pagination.currentPage, pagination.pageSize]); // Updated dependencies

  useEffect(() => {
    // Check for toast data in sessionStorage
    const storedToast = sessionStorage.getItem('promoToast');

    if (storedToast) {
      try {
        // Parse and display the toast
        const toastData = JSON.parse(storedToast);
        setDataToast(toastData);
        setShowToast(true);

        // Remove the data to prevent showing toast again on refresh
        sessionStorage.removeItem('promoToast');
      } catch (error) {
        console.error('Error parsing toast data:', error);
      }
    }

		const fetchConfig = async () => {
      console.log('45ab');
      try {
        // Fetch timezone from API
        const timezoneRes = await promoService.getUserTimezone();
        setTimezone(timezoneRes.Data.timezone.name);
      } catch (error) {
        console.log(error);
      }
    }

    fetchConfig();
  }, []);

  const getTotalPages = () => {
    const totalItems = promoCountData;
    console.log('totalItems', totalItems)
    const newTotalPages = Math.ceil(totalItems / pagination.pageSize);
    console.log('pagination.pageSize', pagination.pageSize)
    console.log('newTotalPages', newTotalPages)
    return newTotalPages;
  }

  const handleSearch = async (value) => {
    try {
      setIsLoading(true);
      const params = {
        tab: activeTab,
        search: value,
        page: 1, // Reset to first page on search
        page_size: pagination.pageSize,
        filters: {
          status: filters.status.length > 0 ? filters.status : undefined,
          ...(filters.dateRange?.startDate && {
            startDate: filters.dateRange.startDate.toISOString()
          }),
          ...(filters.dateRange?.endDate && {
            endDate: filters.dateRange.endDate.toISOString()
          })
        }
      };

      const response = await promoService.getPromotionList(params);

      if (response?.Data?.promos && Array.isArray(response.Data.promos)) {
        const transformedPromos = response.Data.promos.map(promo => ({
          id: promo.id || '',
          name: promo.name || '',
          status: promo.status || '',
          startDate: promo.startDate || '',
          endDate: promo.endDate || '',
          totalProducts: promo.totalProducts || 0,
          totalVariants: promo.totalVariants || 0,
          products: Array.isArray(promo.products) ? promo.products.map(product => ({
            id: product.id || '',
            name: product.name || '',
            image: product.image || '',
            sku: product.sku || '',
            brand: product.brand || ''
          })) : []
        }));

        setPromos(transformedPromos);
        setTabCounts({
          active: response.Data.tabCounts?.active || 0,
          history: response.Data.tabCounts?.history || 0
        });
        setPromoCountData(response.total)
        setSearchQuery(value);

        console.log('setPagination 2');
        setPagination(prev => ({
          ...prev,
          totalPages: getTotalPages(),
          currentPage: 1
        }));
      } else {
        setPromos([]);
        setTabCounts({ active: 0, history: 0 });
      }
    } catch (error) {
      console.error('Error searching promotions:', error);
      setPromos([]);
      setTabCounts({ active: 0, history: 0 });
    } finally {
      setIsLoading(false);
    }
  };

  const handleFilter = (newActiveFilters) => {
    // Extract status filters
    const statusFilters = newActiveFilters
      .filter(f => f.param === 'status')
      .map(f => f.id);

    // Extract period filter
    const periodFilter = newActiveFilters.find(f => f.param === 'period');

    // Update filters state with proper format for API
    setFilters(prev => ({
      ...prev,
      activeFilters: newActiveFilters,
      status: statusFilters,
      dateRange: periodFilter?.values || null // This will contain {startDate, endDate} from the period filter
    }));

    // Reset to page 1 when applying filters
    console.log('setPagination 3');
    setPagination(prev => ({
      ...prev,
      currentPage: 1
    }));
  };

  // Add delete handlers
  const handleDeleteClick = (promo) => {
    console.log('handleDeleteClick')
    setSelectedPromo(promo);
    setShowDeleteModal(true);
  };
  const handleDeleteConfirm = async () => {
    try {
      setIsLoading(true);
      await promoService.deletePromotion(selectedPromo.id);
      setShowDeleteModal(false);

      // Show success as modal instead of toast
      // setSuccessModal(true);
      setDataToast({
        type: 'success',
        message: `${t('berhasilMenghapusPromo')} ${selectedPromo?.name}`
      });
      setShowToast(true);

      await fetchPromos();
    } catch (error) {
      showToast({
        type: 'error',
        message: t('gagalMenghapusPromo'),
        duration: 3000,
      });
    } finally {
      // setSelectedPromo(null);
      setIsLoading(false);
    }
  };

  const handlePageChange = (newPage) => {
    // Convert to number to ensure correct comparison
    const numericNewPage = Number(newPage);

    console.log('setPagination 4');
    setPagination(prev => ({
      ...prev,
      currentPage: numericNewPage
    }));
  };

  const handlePageSizeChange = (newSize) => {
    // Calculate new total pages based on current tab count
    const totalItems = activeTab === 'active' ? tabCounts.active : tabCounts.history;
    const newTotalPages = Math.ceil(totalItems / newSize);

    console.log('setPagination 5');
    setPagination(prev => ({
      ...prev,
      pageSize: Number(newSize),
      currentPage: 1, // Reset to first page
      totalPages: newTotalPages
    }));
  };

  const handleEndClick = (promo) => {
    setSelectedPromo(promo);
    setShowEndModal(true);
  };

  const handleEndConfirm = async () => {
    try {
      setIsLoading(true);
      await promoService.endPromotion(selectedPromo.id);
      setShowEndModal(false);

      // Set toast data and show it
      setDataToast({
        type: 'success',
        message: `${t('berhasilMengahiriPromo')} ${selectedPromo?.name}`
      });
      setShowToast(true);

      await fetchPromos(); // Refresh data
    } catch (error) {
      // Show error toast
      setDataToast({
        type: 'error',
        message: t('gagalMengakhiriPromo')
      });
      setShowToast(true);
    } finally {
      setSelectedPromo(null);
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-[var(--neutral-100)] min-h-screen">
      {/* Page Header */}
      <div className="mb-6">
        <div className="flex justify-between items-center">
          <h1 className="text-xl font-bold text-[var(--neutral-900)]">
            {t('promosiPenjual')}
          </h1>
        </div>

        {/* Navigation Tabs */}
        <div className="mt-4 border-b border-[var(--neutral-200)]">
          <div className="flex items-center">
            <button
              onClick={() => setActiveTab('active')}
              className={`px-6 py-3 text-base text-[16px] transition-colors ${activeTab === 'active'
                ? 'text-[var(--primary-700)] border-b-2 border-[var(--primary-700)] font-bold'
                : 'text-[var(--neutral-900)] font-medium'
                }`}
            >
              {t('daftarPromosi')} ({tabCounts.active})
            </button>
            <div className="h-[40px] w-px bg-[var(--neutral-300)]" />
            <button
              onClick={() => setActiveTab('history')}
              className={`px-6 py-3 text-base text-[16px] transition-colors ${activeTab === 'history'
                ? 'text-[var(--primary-700)] border-b-2 border-[var(--primary-700)] font-bold'
                : 'text-[var(--neutral-900)] font-medium'
                }`}
            >
              {t('labelRiwayat')} ({tabCounts.history})
            </button>
          </div>
        </div>
      </div>

      {/* Content Area */}
      <div>
        {!isTableLoading && !promos.length && !filters.activeFilters.length && !searchQuery ? (
          <EmptyPromotions activeTab={activeTab} />
        ) : (
          <>
            {/* White container for table only */}
            <div className="bg-white rounded-xl shadow-sm">
              <PromoTable
                promos={promos || []}
                isLoading={isLoading}
                activeTab={activeTab}
                onSearch={handleSearch}
                onFilter={handleFilter}
                filters={filters}
                onDelete={handleDeleteClick}
                onEnd={handleEndClick} // Add this prop
                timezone={timezone}
              />
            </div>

            {/* Pagination controls outside container */}
            {/* MP 22: LB - 0146 */}
            {promos.length > 0 && (
              <div className="flex justify-between items-center px-6 py-4">
                <PaginationContainer
                  currentPage={pagination.currentPage}
                  totalPages={pagination.totalPages||1}
                  onPage={handlePageChange}
                  offsite={0}
                  activeColor="error"
                  clientSide={true}
                />

                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium text-[var(--neutral-600)]">
                    {t('tampilkanJumlahDetail')}
                  </span>

                  <div className="flex gap-1">
                    {[10, 20, 40].map((size) => (
                      <button
                        key={size}
                        onClick={() => handlePageSizeChange(size)}
                        className={`w-8 h-8 flex items-center justify-center rounded text-sm font-medium transition-colors 
                          ${pagination.pageSize === size
                            ? 'bg-[#C22716] text-white'
                            : 'bg-white text-[var(--neutral-600)] hover:bg-[var(--neutral-100)]'
                          }`}
                      >
                        {size}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteModal && (
        <Modal
          isOpen={showDeleteModal}
          setIsOpen={(val) => {
            setShowDeleteModal(val);
            setSelectedPromo(null);
          }}
          closeBtn={true}
          closeArea={true}
          headerColor="red"
        >
          <div className="p-4 flex flex-col items-center">
            <p className="medium-sm text-neutral-900 text-center">
              {t('konfirmasiHapusPromo')} {selectedPromo?.name}?
            </p>
            <div className="flex justify-between gap-2 mt-5">
              <Button
                color="primary_secondary"
                onClick={() => {
                  setShowDeleteModal(false);
                  setSelectedPromo(null);
                }}
                Class="!max-w-full w-[112px]"
              >
                {t('labelBatal')}
              </Button>
              <Button
                color="primary"
                onClick={handleDeleteConfirm}
                Class="!max-w-full w-[112px]"
              >
                {t('labelYa')}
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {showEndModal && (
        <Modal
          isOpen={showEndModal}
          setIsOpen={(val) => {
            setShowEndModal(val);
            setSelectedPromo(null);
          }}
          closeBtn={true}
          closeArea={true}
          headerColor="red"
        >
          <div className="p-4 flex flex-col items-center">
            <p className="medium-sm text-neutral-900 text-center">
              {t('konfirmasiAkhiriPromo')} {selectedPromo?.name}?
            </p>
            <div className="flex justify-between gap-2 mt-5">
              <Button
                color="primary_secondary"
                onClick={() => {
                  setShowEndModal(false);
                  setSelectedPromo(null);
                }}
                Class="!max-w-full w-[112px]"
              >
                {t('labelBatal')}
              </Button>
              <Button
                color="primary"
                onClick={handleEndConfirm}
                Class="!max-w-full w-[112px]"
              >
                {t('labelYa')}
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* Success Modal */}
      {successModal && (
        <Modal
          isOpen={successModal}
          setIsOpen={setSuccessModal}
          closeBtn={true}
          closeArea={true}
          headerColor="red"
        >
          <div className="p-4 flex flex-col items-center">
            <p className="medium-sm text-neutral-900 text-center">
              {t('berhasilMenghapusPromo')} {selectedPromo?.name}
            </p>
          </div>
        </Modal>
      )}

      <Toast classname="promo-toast" />
    </div>
  );
}





