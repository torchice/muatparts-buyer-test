'use client'
import React, { useState, useEffect } from 'react';
import { ChevronLeft } from 'lucide-react';
import { MockServer_Promo } from '@/services/MockServer_Promo';
import { useCustomRouter } from '@/libs/CustomRoute';
import Input from '@/components/Input/Input';
import DatetimePicker from '@/components/DatetimePicker/DatetimePicker';
import ProductTable from '@/components/PromoCreate/ProductTable';
import BulkEditPopup from '../../components/BulkEditPopup';
// import SearchFilterComponent from './SearchFilterComponent';

const EditPromoPage = ({ params }) => {
  const router = useCustomRouter();
  const promoId = params.id;
  const [promoData, setPromoData] = useState(null);
  const [showBulkEdit, setShowBulkEdit] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [errors, setErrors] = useState({});
  
  // Form state
  const [formData, setFormData] = useState({
    name: '', // Initialize with empty string instead of undefined
    startDate: null,
    endDate: null,
    purchaseLimit: 'unlimited',
    products: []
  });

  useEffect(() => {
    fetchPromoData();
  }, [promoId]);

  const fetchPromoData = async () => {
    try {
      setIsLoading(true);
      const response = await MockServer_Promo.getPromotionDetail(promoId);
      
      if (response?.Data) {
        const apiData = response.Data;
        
        // Transform API data to match component structure
        const transformedProducts = apiData.productpromotions.map(pp => ({
          id: pp.productID,
          name: pp.product.name,
          sku: pp.product.skuCode,
          brand: pp.product.brandID, // You might want to show actual brand name
          image: pp.product.imageUrl || '/placeholder-image.jpg', // Add default image
          discountPercentage: pp.discountPercentage,
          quota: pp.quota,
          price: pp.product.price,
          // Add other necessary product fields
        }));

        const transformedData = {
          id: apiData.id,
          name: apiData.promotionName,
          startDate: new Date(apiData.startDate),
          endDate: new Date(apiData.endDate),
          purchaseLimit: apiData.purchaseLimitType === 'limit_per_user' ? 'perBuyer' : 
                        apiData.purchaseLimitType === 'limit_per_note' ? 'perNote' : 'unlimited',
          products: transformedProducts,
          status: apiData.isActive ? 'active' : 'inactive'
        };

        setPromoData(transformedData);
        setFormData({
          name: transformedData.name,
          startDate: transformedData.startDate,
          endDate: transformedData.endDate,
          purchaseLimit: transformedData.purchaseLimit,
          products: transformedData.products
        });
      }
    } catch (error) {
      console.error('Error fetching promotion:', error);
      // Handle error (e.g., show error message)
    } finally {
      setIsLoading(false);
    }
  };

  const validateField = (field, value) => {
    const newErrors = { ...errors };
    
    switch (field) {
      case 'name':
        if (!value?.trim()) {
          newErrors.name = 'Nama promosi wajib diisi';
        } else if (value.length > 60) {
          newErrors.name = 'Maksimal 60 karakter';
        } else {
          delete newErrors.name;
        }
        break;

      case 'startDate':
        if (!value) {
          newErrors.startDate = 'Tanggal mulai wajib diisi';
        } else if (promoData?.status !== 'active' && value < new Date()) {
          newErrors.startDate = 'Waktu mulai masa berlaku harus melebihi waktu saat ini';
        } else {
          delete newErrors.startDate;
        }
        break;

      case 'endDate':
        if (!value) {
          newErrors.endDate = 'Tanggal berakhir wajib diisi';
        } else if (value <= formData.startDate) {
          newErrors.endDate = 'Waktu akhir harus lebih dari waktu awal';
        } else {
          const diffHours = (value - formData.startDate) / (1000 * 60 * 60);
          if (diffHours < 1) {
            newErrors.endDate = 'Masa berlaku minimal 1 jam';
          } else if (diffHours > 4320) { // 180 days * 24 hours
            newErrors.endDate = 'Masa berlaku maksimal 180 hari';
          } else {
            delete newErrors.endDate;
          }
        }
        break;
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleFormChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    validateField(field, value);
  };

  const handleProductUpdate = (productId, updates) => {
    setFormData(prev => ({
      ...prev,
      products: prev.products.map(product => 
        product.id === productId
          ? { ...product, ...updates }
          : product
      )
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validate all fields
    let isValid = true;
    Object.keys(formData).forEach(field => {
      if (!validateField(field, formData[field])) {
        isValid = false;
      }
    });

    if (!isValid) return;

    try {
      const response = await MockServer_Promo.updatePromotion(promoId, {
        name: formData.name,
        startDate: formData.startDate,
        endDate: formData.endDate,
        purchaseLimit: formData.purchaseLimit,
        products: formData.products
      });

      if (response?.Success) {
        // Show success message
        router.push('/promotions/listpromo_final');
      }
    } catch (error) {
      console.error('Error updating promotion:', error);
      // Show error message
    }
  };

  if (isLoading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-[var(--neutral-50)]">
      {/* Header */}
      <div className="px-6 py-4 bg-white border-b border-[var(--neutral-200)]">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-xs mb-4">
          <button className="text-[var(--neutral-500)] hover:text-[var(--neutral-700)]">
            Dashboard
          </button>
          <ChevronLeft className="w-4 h-4 text-[var(--neutral-500)]" />
          <button className="text-[var(--neutral-500)] hover:text-[var(--neutral-700)]">
            Kelola Promosi
          </button>
          <ChevronLeft className="w-4 h-4 text-[var(--neutral-500)]" />
          <span className="text-[var(--primary-500)] font-medium">
            Ubah Promosi
          </span>
        </div>

        <div className="flex items-center gap-3">
          <button className="p-2 hover:bg-[var(--neutral-100)] rounded-full">
            <ChevronLeft className="w-5 h-5" />
          </button>
          <h1 className="text-xl font-bold">Ubah Promosi</h1>
        </div>
      </div>

      {/* Main Form */}
      <form onSubmit={handleSubmit} className="p-6 max-w-[1248px] mx-auto space-y-6">
        {/* Promotion Info Card */}
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h2 className="text-lg font-bold mb-6">Informasi Promosi</h2>

          <div className="space-y-6">
            {/* Promotion Name */}
            <div className="grid grid-cols-[180px_1fr] gap-8 items-start">
              <label className="text-sm text-[var(--neutral-700)]">
                Nama Promosi*
              </label>
              <div className="max-w-[514px]">
                <Input
                  name="promoName"
                  type="text"
                  value={formData.name || ''} // Add fallback empty string
                  changeEvent={(e) => handleFormChange('name', e.target.value)}
                  maxLength={60}
                  placeholder="Contoh : Diskon Tahun Baru"
                  supportiveText={{
                    title: "Catatan : Nama promosi tidak tampil di sisi Pembeli",
                    desc: `${formData.name?.length || 0}/60` // Add null check and fallback
                  }}
                  width={{ width: "100%" }}
                  classInput="text-[var(--neutral-900)] placeholder:text-[var(--neutral-500)]"
                  status={errors?.name ? 'error' : null}
                />
              </div>
            </div>

            {/* Date Range */}
            <div className="grid grid-cols-[180px_1fr] gap-8 items-center">
              <label className="text-sm text-[var(--neutral-700)]">
                Masa Berlaku*
              </label>
              <div className="flex items-center gap-4">
                <DatetimePicker
                  datetimeValue={formData.startDate}
                  onApply={(e) => handleFormChange('startDate', e.target.value)}
                  disabled={promoData?.status === 'active'}
                  error={!!errors?.startDate}
                />
                <span className="text-sm font-semibold text-[var(--neutral-900)]">s/d</span>
                <DatetimePicker
                  datetimeValue={formData.endDate}
                  onApply={(e) => handleFormChange('endDate', e.target.value)}
                  error={!!errors?.endDate}
                />
              </div>
            </div>

            {/* Purchase Limit */}
            <div className="grid grid-cols-[180px_1fr] gap-8 items-start">
              <label className="text-sm text-[var(--neutral-700)]">
                Jenis Batas Pembelian*
              </label>
              <div className="flex gap-5">
                {[
                  {
                    value: 'unlimited',
                    label: 'Tanpa Batas',
                    description: 'Jumlah pemakaian promosi tidak dibatasi, kuota diatur oleh penjual.'
                  },
                  {
                    value: 'perBuyer',
                    label: 'Pembatasan Per Pembeli',
                    description: 'Jumlah pembelian dibatasi untuk tiap pembeli'
                  },
                  {
                    value: 'perNote',
                    label: 'Pembatasan Per Nota',
                    description: 'Jumlah nota pembelian dibatasi untuk tiap pembeli'
                  }
                ].map((option) => (
                  <label key={option.value} className="flex flex-col w-[220px] cursor-pointer">
                    <div className="flex items-center gap-2">
                      <input
                        type="radio"
                        name="purchaseLimit"
                        value={option.value}
                        checked={formData.purchaseLimit === option.value}
                        onChange={(e) => handleFormChange('purchaseLimit', e.target.value)}
                        className="hidden"
                      />
                      <div
                        className={`w-4 h-4 rounded-full border relative
                          ${formData.purchaseLimit === option.value
                            ? 'bg-[var(--primary-600)] border-[var(--primary-600)]'
                            : 'border-[var(--neutral-300)]'
                          }
                          ${formData.purchaseLimit === option.value && 
                            'after:content-[""] after:absolute after:w-2 after:h-2 after:bg-white after:rounded-full after:top-1/2 after:left-1/2 after:-translate-x-1/2 after:-translate-y-1/2'
                          }
                        `}
                      />
                      <span className="text-sm text-[var(--neutral-900)]">{option.label}</span>
                    </div>
                    <p className="ml-6 mt-1 text-xs text-[var(--neutral-500)]">
                      {option.description}
                    </p>
                  </label>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Products Section */}
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-lg font-bold">Daftar Produk Promosi</h2>
            <div className="flex gap-3">
              <button
                type="button"
                onClick={() => setShowBulkEdit(true)}
                className="px-4 py-2 border border-[var(--primary-500)] text-[var(--primary-500)] rounded-full hover:bg-[var(--primary-50)]"
              >
                Atur Massal
              </button>
              <button
                type="button"
                className="px-4 py-2 bg-[var(--primary-500)] text-white rounded-full hover:bg-[var(--primary-600)]"
              >
                Tambah
              </button>
            </div>
          </div>

          {/* Product Table */}
          <ProductTable
            products={formData.products}
            onProductUpdate={handleProductUpdate}
            purchaseLimitType={formData.purchaseLimit}
          />
        </div>

        {/* Footer */}
        <div className="fixed bottom-0 left-[184px] right-0 bg-white border-t p-4 flex justify-between items-center">
          <div className="text-sm font-semibold">
            Total Produk: {formData.products.length}
          </div>
          <div className="flex gap-3">
            <button
              type="button"
              className="px-6 py-2 border border-[var(--neutral-300)] text-[var(--neutral-700)] rounded-lg hover:bg-[var(--neutral-50)]"
              onClick={() => {
                // Handle cancel with confirmation if there are changes
              }}
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-6 py-2 bg-[var(--primary-500)] text-white rounded-lg hover:bg-[var(--primary-600)]"
            >
              Simpan
            </button>
          </div>
        </div>
      </form>

      {/* Bulk Edit Popup */}
      {showBulkEdit && (
        <BulkEditPopup
          isOpen={showBulkEdit}
          onClose={() => setShowBulkEdit(false)}
          products={formData.products}
          purchaseLimitType={formData.purchaseLimit}
          onApply={(selectedProducts, updates) => {
            setFormData(prev => ({
              ...prev,
              products: prev.products.map(product => 
                selectedProducts.includes(product.id)
                  ? { ...product, ...updates }
                  : product
              )
            }));
            setShowBulkEdit(false);
          }}
        />
      )}
    </div>
  );
};

export default EditPromoPage;


