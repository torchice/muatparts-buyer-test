'use client'

import ImageComponent from '@/components/ImageComponent/ImageComponent';
import React, { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import Input from '@/components/Input/Input';
import { formatCurrency } from '@/components/PromoCreate/CurrencyUtils';
import { MockServer_Promo } from '@/services/MockServer_Promo';

const DetailPromoPage = () => {
  const params = useParams();
  const [promoData, setPromoData] = useState(null);
  const [expandedProducts, setExpandedProducts] = useState({});
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  const formatDateTime = (dateString) => {
    try {
      const date = new Date(dateString);
      return new Intl.DateTimeFormat('id-ID', {
        dateStyle: 'long',
        timeStyle: 'short'
      }).format(date);
    } catch (error) {
      console.error('Error formatting date:', error);
      return 'Invalid date';
    }
  };

  // Transform API data to match component structure
  const transformPromoData = (apiData) => {
    if (!apiData) return null;
    
    const products = apiData.productpromotions.map(pp => ({
      id: pp.product.id,
      name: pp.product.name,
      sku: pp.product.skuCode,
      brand: pp.product.brandID,
      imageUrl: '/placeholder.png', // Add default image or get from API
      stock: pp.product.stock,
      price: pp.product.price,
      promoPrice: pp.product.price * (1 - pp.discountPercentage / 100),
      discount: pp.discountPercentage,
      quota: pp.quota,
      purchaseLimit: pp.product.minPurchase,
      variants: pp.product.variants || []
    }));

    return {
      id: apiData.id,
      name: apiData.promotionName,
      status: apiData.isActive ? 'active' : 'upcoming',
      startDate: apiData.startDate,
      endDate: apiData.endDate,
      purchaseLimit: apiData.purchaseLimitType === 'limit_per_user' ? 'perBuyer' : 'unlimited',
      products: products
    };
  };

  useEffect(() => {
    const fetchPromoData = async () => {
      try {
        setIsLoading(true);
        const response = await MockServer_Promo.getPromotionDetail(params.id);
        if (response && response.Data) {
          const transformedData = transformPromoData(response.Data);
          setPromoData(transformedData);
        }
      } catch (error) {
        console.error('Error fetching promotion:', error);
        setError(error.message || 'Failed to fetch promotion details');
      } finally {
        setIsLoading(false);
      }
    };

    if (params.id) {
      fetchPromoData();
    }
  }, [params.id]);

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  if (!promoData) {
    return <div>No promotion data found</div>;
  }

  const toggleProductVariants = (productId) => {
    setExpandedProducts(prev => ({
      ...prev,
      [productId]: !prev[productId]
    }));
  };

  const getTotalProducts = () => {
    if (!promoData?.products) return 0;
    return promoData.products.reduce((acc, product) => 
      acc + (product.variants?.length || 1), 0
    );
  };

  const handleSearch = (value) => {
    setSearchQuery(value);
    setCurrentPage(1); // Reset to first page when searching
  };

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  const getPaginationRange = () => {
    if (!promoData?.products) return [];
    const totalPages = Math.ceil(filteredProducts.length / itemsPerPage);
    let pages = [];

    if (totalPages <= 7) {
      for (let i = 1; i <= totalPages; i++) {
        pages.push(i);
      }
    } else {
      if (currentPage <= 3) {
        pages = [1, 2, 3, 4, '...', totalPages - 1, totalPages];
      } else if (currentPage >= totalPages - 2) {
        pages = [1, 2, '...', totalPages - 3, totalPages - 2, totalPages - 1, totalPages];
      } else {
        pages = [1, '...', currentPage - 1, currentPage, currentPage + 1, '...', totalPages];
      }
    }
    return pages;
  };

  // Filter products based on search
  const filteredProducts = promoData?.products?.filter(product =>
    product.name.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  // Get current page products
  const paginatedProducts = filteredProducts.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  return (
    <div className="min-h-screen bg-[var(--neutral-50)]">
      {/* Header */}
      <div className="px-6 py-4 bg-white border-b border-[var(--neutral-200)]">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-xs mb-4">
          <button className="text-[var(--neutral-500)] hover:text-[var(--neutral-700)]">
            Dashboard
          </button>
          <ImageComponent src="/promo/chevron_left.svg" 
            alt="chevron left" 
            className="w-4 h-4 text-[var(--neutral-500)]" 
          />
          <button className="text-[var(--neutral-500)] hover:text-[var(--neutral-700)]">
            Kelola Promosi
          </button>
          <ImageComponent src="/promo/chevron_left.svg" 
            alt="chevron left" 
            className="w-4 h-4 text-[var(--neutral-500)]" 
          />
          <span className="text-[var(--primary-500)] font-medium">
            Detail Promosi
          </span>
        </div>

        <div className="flex items-center gap-3">
          <button 
            onClick={() => window.history.back()}
            className="p-2 hover:bg-[var(--neutral-100)] rounded-full"
          >
            <ImageComponent src="/promo/chevron_left.svg" 
              alt="back" 
              className="w-5 h-5" 
            />
          </button>
          <h1 className="text-xl font-bold">Detail Promosi</h1>
        </div>
      </div>

      {/* Main Content */}
      <div className="p-6 max-w-[1248px] mx-auto space-y-6">
        {/* Promotion Info Card */}
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h2 className="text-lg font-bold mb-6">{promoData.name}</h2>
          
          <div className="grid grid-cols-2 gap-x-8 gap-y-4">
            <div>
              <div className="text-sm text-[var(--neutral-500)]">Status</div>
              <div className="mt-1">
                <span className={`
                  px-3 py-1 rounded-full text-sm font-medium
                  ${promoData.status === 'active' 
                    ? 'bg-green-100 text-green-600'
                    : 'bg-yellow-100 text-yellow-600'
                  }
                `}>
                  {promoData.status === 'active' ? 'Aktif' : 'Akan Datang'}
                </span>
              </div>
            </div>

            <div>
              <div className="text-sm text-[var(--neutral-500)]">Periode Promosi</div>
              <div className="mt-1 text-sm">
                {formatDateTime(promoData.startDate)} - {formatDateTime(promoData.endDate)} WIB
              </div>
            </div>

            <div>
              <div className="text-sm text-[var(--neutral-500)]">Jenis Batas Pembelian</div>
              <div className="mt-1 text-sm">
                {promoData.purchaseLimit === 'unlimited' 
                  ? 'Tanpa Batas' 
                  : promoData.purchaseLimit === 'perBuyer'
                    ? 'Pembatasan Per Pembeli'
                    : 'Pembatasan Per Nota'}
              </div>
            </div>
          </div>
        </div>

        {/* Products Section */}
        <div className="bg-white rounded-xl shadow-sm">
          <div className="p-6 border-b border-[var(--neutral-200)]">
            <div className="flex justify-between items-center">
              <h2 className="text-lg font-bold">Daftar Produk</h2>
              <div className="text-sm">
                Total: {getTotalProducts()} Produk
              </div>
            </div>

            {/* Search */}
            <div className="mt-4 relative">
              <Input
                type="text"
                placeholder="Cari Nama Produk"
                value={searchQuery}
                changeEvent={(e) => handleSearch(e.target.value)}
                icon={{ left: "search" }}
                width={{ width: "280px" }}
              />
            </div>
          </div>

          {/* Product Table */}
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="text-sm text-[var(--neutral-700)] bg-[var(--neutral-50)]">
                  <th className="text-left px-6 py-4">Produk</th>
                  <th className="text-left px-6 py-4">Stok</th>
                  <th className="text-left px-6 py-4">Harga Setelah Diskon - Harga</th>
                  <th className="text-left px-6 py-4">Promosi (Diskon)</th>
                  <th className="text-left px-6 py-4">Kuota Promosi</th>
                  {promoData.purchaseLimit !== 'unlimited' && (
                    <th className="text-left px-6 py-4">Batas Pembelian</th>
                  )}
                </tr>
              </thead>
              <tbody>
                {paginatedProducts.map((product) => (
                  <React.Fragment key={product.id}>
                    {/* Product Row */}
                    <tr className="border-b border-[var(--neutral-200)]">
                      <td className="px-6 py-4">
                        <div className="flex gap-3">
                          <ImageComponent src={product.imageUrl}
                            alt={product.name}
                            className="w-12 h-12 rounded object-cover"
                          />
                          <div>
                            <div className="font-medium text-sm line-clamp-2">
                              {product.name}
                            </div>
                            <div className="text-xs text-[var(--neutral-600)] mt-1">
                              SKU: {product.sku}
                            </div>
                            <div className="text-xs text-[var(--neutral-600)]">
                              Brand: {product.brand}
                            </div>
                            {product.variants?.length > 0 && (
                              <div className="flex items-center mt-2">
                                <button
                                  onClick={() => toggleProductVariants(product.id)}
                                  className="text-xs text-[var(--primary-500)] hover:text-[var(--primary-600)] flex items-center gap-1"
                                >
                                  Lihat Varian Produk ({product.variants.length})
                                  <ImageComponent src={`/promo/chevron_${expandedProducts[product.id] ? 'up' : 'down'}.svg`}
                                    alt="toggle variants"
                                    className="w-4 h-4"
                                  />
                                </button>
                              </div>
                            )}
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm">
                        {product.stock}
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm line-through text-[var(--neutral-500)]">
                          {formatCurrency(product.price)}
                        </div>
                        <div className="text-sm text-[var(--error-500)] font-medium">
                          {formatCurrency(product.promoPrice)}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm">
                        {product.discount}%
                      </td>
                      <td className="px-6 py-4 text-sm">
                        {product.quota}
                      </td>
                      {promoData.purchaseLimit !== 'unlimited' && (
                        <td className="px-6 py-4 text-sm">
                          {product.purchaseLimit}
                        </td>
                      )}
                    </tr>

                    {/* Variant Rows */}
                    {expandedProducts[product.id] && product.variants?.map((variant) => (
                      <tr 
                        key={variant.id}
                        className="border-b border-[var(--neutral-200)] bg-[var(--neutral-50)]"
                      >
                        <td className="px-6 py-4 pl-16">
                          <div>
                            <div className="font-medium text-sm">
                              {variant.name}
                            </div>
                            <div className="text-xs text-[var(--neutral-600)] mt-1">
                              SKU: {variant.sku}
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-sm">
                          {variant.stock}
                        </td>
                        <td className="px-6 py-4">
                          {variant.isActive ? (
                            <>
                              <div className="text-sm line-through text-[var(--neutral-500)]">
                                {formatCurrency(variant.price)}
                              </div>
                              <div className="text-sm text-[var(--error-500)] font-medium">
                                {formatCurrency(variant.promoPrice)}
                              </div>
                            </>
                          ) : (
                            <span className="text-sm text-[var(--neutral-500)]">-</span>
                          )}
                        </td>
                        <td className="px-6 py-4 text-sm">
                          {variant.isActive ? `${variant.discount}%` : '-'}
                        </td>
                        <td className="px-6 py-4 text-sm">
                          {variant.isActive ? variant.quota : '-'}
                        </td>
                        {promoData.purchaseLimit !== 'unlimited' && (
                          <td className="px-6 py-4 text-sm">
                            {variant.isActive ? variant.purchaseLimit : '-'}
                          </td>
                        )}
                      </tr>
                    ))}
                  </React.Fragment>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          {filteredProducts.length > itemsPerPage && (
            <div className="px-6 py-4 border-t border-[var(--neutral-200)] flex justify-between items-center">
              {/* Records per page selector */}
              <div className="flex items-center gap-2">
                <label className="text-sm text-[var(--neutral-700)]">
                  Tampilkan
                  <select 
                    className="mx-2 px-2 py-1 border border-[var(--neutral-300)] rounded cursor-pointer"
                    value={itemsPerPage}
                    onChange={(e) => {
                      setItemsPerPage(Number(e.target.value));
                      setCurrentPage(1);
                    }}
                  >
                    <option value={10}>10</option>
                    <option value={20}>20</option>
                    <option value={40}>40</option>
                  </select>
                  data
                </label>
              </div>

              {/* Pagination controls */}
              <div className="flex items-center gap-2">
                <button 
                  className="w-8 h-8 flex items-center justify-center rounded border border-[var(--neutral-300)] text-[var(--neutral-500)] disabled:opacity-50 hover:border-[var(--primary-500)] hover:text-[var(--primary-500)]"
                  disabled={currentPage === 1}
                  onClick={() => handlePageChange(1)}
                >
                  <ImageComponent src="/promo/chevron_double_left.svg" 
                    alt="first page" 
                    className="w-4 h-4" 
                  />
                </button>
                <button 
                  className="w-8 h-8 flex items-center justify-center rounded border border-[var(--neutral-300)] text-[var(--neutral-500)] disabled:opacity-50 hover:border-[var(--primary-500)] hover:text-[var(--primary-500)]"
                  disabled={currentPage === 1}
                  onClick={() => handlePageChange(currentPage - 1)}
                >
                  <ImageComponent src="/promo/chevron_left.svg" 
                    alt="previous page" 
                    className="w-4 h-4" 
                  />
                </button>

                {/* Page numbers */}
                <div className="flex items-center gap-2">
                  {getPaginationRange().map((page, index) => (
                    <React.Fragment key={index}>
                      {page === '...' ? (
                        <span className="w-8 h-8 flex items-center justify-center text-[var(--neutral-500)]">
                          ...
                        </span>
                      ) : (
                        <button
                          className={`w-8 h-8 flex items-center justify-center rounded ${
                            currentPage === page
                              ? 'bg-[var(--primary-500)] text-white'
                              : 'border border-[var(--neutral-300)] hover:border-[var(--primary-500)] hover:text-[var(--primary-500)]'
                          }`}
                          onClick={() => handlePageChange(page)}
                        >
                          {page}
                        </button>
                      )}
                    </React.Fragment>
                  ))}
                </div>

                <button 
                  className="w-8 h-8 flex items-center justify-center rounded border border-[var(--neutral-300)] text-[var(--neutral-500)] disabled:opacity-50 hover:border-[var(--primary-500)] hover:text-[var(--primary-500)]"
                  disabled={currentPage === Math.ceil(filteredProducts.length / itemsPerPage)}
                  onClick={() => handlePageChange(currentPage + 1)}
                >
                  <ImageComponent src="/promo/chevron_right.svg" 
                    alt="next page" 
                    className="w-4 h-4" 
                  />
                </button>
                <button 
                  className="w-8 h-8 flex items-center justify-center rounded border border-[var(--neutral-300)] text-[var(--neutral-500)] disabled:opacity-50 hover:border-[var(--primary-500)] hover:text-[var(--primary-500)]"
                  disabled={currentPage === Math.ceil(filteredProducts.length / itemsPerPage)}
                  onClick={() => handlePageChange(Math.ceil(filteredProducts.length / itemsPerPage))}
                >
                  <ImageComponent src="/promo/chevron_double_right.svg" 
                    alt="last page" 
                    className="w-4 h-4" 
                  />
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Info Tooltips */}
        <div className="fixed top-1/2 right-6 flex flex-col gap-2 z-10">
          {/* Kuota Promosi tooltip */}
          <div className="relative group">
            <button className="w-8 h-8 flex items-center justify-center rounded-full bg-[var(--primary-500)] text-white">
              <ImageComponent src="/promo/info.svg" 
                alt="quota info" 
                className="w-4 h-4" 
              />
            </button>
            <div className="absolute right-full top-1/2 -translate-y-1/2 mr-2 w-64 p-3 bg-[var(--neutral-900)] text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity">
              Jumlah maksimum stok produk kamu yang menggunakan harga promosi
            </div>
          </div>

          {/* Batas Pembelian tooltip - only shown if purchase limit exists */}
          {promoData.purchaseLimit !== 'unlimited' && (
            <div className="relative group">
              <button className="w-8 h-8 flex items-center justify-center rounded-full bg-[var(--primary-500)] text-white">
                <ImageComponent src="/promo/info.svg" 
                  alt="purchase limit info" 
                  className="w-4 h-4" 
                />
              </button>
              <div className="absolute right-full top-1/2 -translate-y-1/2 mr-2 w-64 p-3 bg-[var(--neutral-900)] text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity">
                Jumlah maksimum produk kamu yang dapat dibeli. Pembatasan ini berlaku sesuai jenis batas pembelian yang terpilih
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DetailPromoPage;


