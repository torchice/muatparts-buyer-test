import ImageComponent from '@/components/ImageComponent/ImageComponent'
import * as React from "react";
import { products } from "./data/mockData";
import { PromosiField } from "./components/PromosiField";
import { ProductRow } from "./components/ProductRow";

export default function AturMassalPopup() {
  const [selectedProducts, setSelectedProducts] = React.useState(new Set());
  const [allSelected, setAllSelected] = React.useState(false);

  const handleSelectAll = (checked) => {
    setAllSelected(checked);
    if (checked) {
      setSelectedProducts(new Set(products.map((p) => p.id)));
    } else {
      setSelectedProducts(new Set());
    }
  };

  const handleProductSelect = (id, checked) => {
    const newSelected = new Set(selectedProducts);
    if (checked) {
      newSelected.add(id);
    } else {
      newSelected.delete(id);
    }
    setSelectedProducts(newSelected);
    setAllSelected(newSelected.size === products.length);
  };

  return (
    <div className="flex relative flex-col justify-center items-start p-6 bg-white rounded-xl shadow-sm max-w-[800px] max-md:px-5">
      <h1 className="z-0 text-base font-bold leading-tight text-center text-zinc-900 max-md:max-w-full">
        Atur Massal
      </h1>

      <div className="flex z-0 flex-col self-stretch p-3 mt-3 w-full bg-white rounded-xl border border-solid border-stone-300 max-md:max-w-full">
        <div className="flex flex-col justify-center px-6 w-full text-xs leading-tight bg-sky-100 rounded-xl max-md:px-5 max-md:max-w-full">
          <div className="flex gap-3 items-center py-2 w-full max-md:max-w-full">
            <div className="flex flex-wrap gap-4 items-center self-stretch my-auto min-w-[240px] max-md:max-w-full">
              <PromosiField
                label="Kuota Promosi*"
                placeholder="Contoh : 1"
                icon="https://cdn.builder.io/api/v1/image/assets/TEMP/52c1bcd192f547c561a84cea44e64a85782cffb447b4a4c341042aee138141db?placeholderIfAbsent=true&apiKey=60cdcdaf919148d9b5b739827a6f5b2a"
                type="number"
              />
              <PromosiField
                label="Batas Pembelian*"
                placeholder="Contoh : 1"
                icon="https://cdn.builder.io/api/v1/image/assets/TEMP/658e5aa2e18884f9b76b05c05179d93d22cf065294efd4c861ad58ba32476f24?placeholderIfAbsent=true&apiKey=60cdcdaf919148d9b5b739827a6f5b2a"
                type="number"
              />

              <div className="flex flex-col justify-center self-stretch my-auto min-w-[240px]">
                <div className="flex gap-4 items-center self-start font-bold min-h-[16px] text-neutral-500">
                  <div className="self-stretch my-auto w-[216px]">
                    Harga setelah Diskon
                  </div>
                  <div className="self-stretch my-auto">Diskon</div>
                </div>
                <div className="flex gap-4 items-center mt-1 font-medium">
                  <div className="flex overflow-hidden items-start self-stretch my-auto rounded-md border border-blue-600 border-solid w-[180px]">
                    <div className="flex gap-2 items-center py-3 pl-3 text-black whitespace-nowrap bg-white min-h-[32px]">
                      <div className="gap-2.5 self-stretch my-auto">Rp</div>
                    </div>
                    <input
                      type="text"
                      className="flex-1 shrink gap-2 self-stretch p-3 bg-white min-h-[32px] text-neutral-500"
                      placeholder="Contoh : 1.000.000"
                      aria-label="Harga setelah diskon"
                    />
                  </div>
                  <div className="self-stretch my-auto text-xs leading-tight text-black">
                    atau
                  </div>
                  <div className="flex overflow-hidden items-start self-stretch my-auto whitespace-nowrap rounded-md border border-blue-600 border-solid w-[100px]">
                    <input
                      type="text"
                      className="flex-1 shrink gap-2 self-stretch p-3 bg-white min-h-[32px] text-neutral-500"
                      placeholder="Diskon"
                      aria-label="Persentase diskon"
                    />
                    <div className="flex gap-2 items-center py-3 pr-3 text-black bg-white min-h-[32px]">
                      <div className="gap-2.5 self-stretch my-auto">%</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="flex gap-3 justify-center items-start mt-3 w-full max-md:max-w-full">
          <div className="flex flex-col flex-1 shrink justify-center w-full basis-0 min-w-[240px] max-md:max-w-full">
            <div className="flex gap-3 items-center px-6 py-3 w-full bg-white border-t border-b border-solid border-y-stone-300 max-md:px-5 max-md:max-w-full">
              <div className="flex flex-wrap flex-1 shrink gap-5 items-center self-stretch my-auto w-full basis-0 min-w-[240px] max-md:max-w-full">
                <div className="flex flex-col self-stretch my-auto w-4">
                  <input
                    type="checkbox"
                    checked={allSelected}
                    onChange={(e) => handleSelectAll(e.target.checked)}
                    className="shrink-0 w-4 h-4 rounded border border-solid border-neutral-500"
                  />
                </div>
                <div className="flex gap-2 items-center self-stretch my-auto text-xs font-bold leading-tight whitespace-nowrap text-neutral-500">
                  <div className="self-stretch my-auto">Produk</div>
                  <ImageComponent loading="lazy"
                    src="https://cdn.builder.io/api/v1/image/assets/TEMP/c25820b702fc88f506fb47814ec58c30f05dae90466b36b8b073956c6e557ad6?placeholderIfAbsent=true&apiKey=60cdcdaf919148d9b5b739827a6f5b2a"
                    alt=""
                    className="object-contain shrink-0 self-stretch my-auto w-4 aspect-square"
                  />
                </div>
                <div className="flex shrink-0 gap-2 self-stretch my-auto h-2 min-w-[240px] w-[266px]" />
                <div className="flex gap-2 items-center self-stretch my-auto text-xs font-bold leading-tight whitespace-nowrap text-neutral-500 w-[179px]">
                  <div className="flex gap-2 items-center self-stretch my-auto">
                    <div className="self-stretch my-auto">Harga</div>
                    <ImageComponent loading="lazy"
                      src="https://cdn.builder.io/api/v1/image/assets/TEMP/37970c92f91dd27e4162d7856e8e04e0662df75eba3463a994e64054ae2ef110?placeholderIfAbsent=true&apiKey=60cdcdaf919148d9b5b739827a6f5b2a"
                      alt=""
                      className="object-contain shrink-0 self-stretch my-auto w-4 aspect-square"
                    />
                  </div>
                </div>
                <div className="flex flex-1 shrink gap-2 items-center self-stretch my-auto text-xs font-bold leading-tight whitespace-nowrap basis-0 text-neutral-500">
                  <div className="flex gap-2 items-center self-stretch my-auto">
                    <div className="self-stretch my-auto">Stok</div>
                    <ImageComponent loading="lazy"
                      src="https://cdn.builder.io/api/v1/image/assets/TEMP/30da240e217aaf80ec61519998279e256b1e7d298d4eae3dd36121f7dd1d6188?placeholderIfAbsent=true&apiKey=60cdcdaf919148d9b5b739827a6f5b2a"
                      alt=""
                      className="object-contain shrink-0 self-stretch my-auto w-4 aspect-square"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="flex overflow-hidden flex-wrap justify-center w-full max-md:max-w-full">
              <div className="flex overflow-hidden flex-col flex-1 shrink self-start w-full h-48 basis-0 min-w-[240px] max-md:max-w-full">
                {products.map((product) => (
                  <ProductRow
                    key={product.id}
                    product={product}
                    checked={selectedProducts.has(product.id)}
                    onCheckChange={handleProductSelect}
                  />
                ))}
              </div>
              <div className="flex overflow-hidden gap-2.5 px-0.5 pt-1 pb-8 w-2 h-full bg-zinc-100">
                <div className="flex flex-1 shrink w-full rounded-sm basis-0 bg-neutral-400 min-h-[158px]" />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="flex z-0 flex-wrap gap-5 justify-between self-stretch mt-3 w-full leading-tight max-md:max-w-full">
        <div className="my-auto text-xs font-bold text-center text-black">
          Atur Massal : {selectedProducts.size}/3 produk
        </div>
        <button
          className={`gap-1 self-stretch px-6 py-3 text-sm font-semibold whitespace-nowrap rounded-3xl min-h-[32px] min-w-[112px] ${
            selectedProducts.size > 0
              ? "bg-blue-600 text-white"
              : "bg-zinc-100 text-neutral-500"
          } max-md:px-5`}
          disabled={selectedProducts.size === 0}
        >
          Terapkan
        </button>
      </div>
    </div>
  );
}






