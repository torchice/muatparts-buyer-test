import ImageComponent from '@/components/ImageComponent/ImageComponent'
import * as React from "react";

export function PromosiField({ label, placeholder, icon, type = "text" }) {
  return (
    <div className="flex flex-col self-stretch my-auto text-neutral-500 w-[124px]">
      <div className="flex gap-1 items-center self-start font-bold">
        <label className="self-stretch my-auto">{label}</label>
        {icon && (
          <ImageComponent loading="lazy"
            src={icon}
            alt=""
            className="object-contain shrink-0 self-stretch my-auto w-4 aspect-square"
          />
        )}
      </div>
      <div className="flex items-start mt-1 w-full font-medium">
        <input
          type={type}
          className="flex-1 shrink gap-2 self-stretch p-3 w-full bg-white rounded-md border border-blue-600 border-solid min-h-[32px]"
          placeholder={placeholder}
          aria-label={label}
        />
      </div>
    </div>
  );
}






