import ImageComponent from '@/components/ImageComponent/ImageComponent'
import * as React from "react";

export function ProductRow({ product, checked, onCheckChange }) {
  const formatPrice = (prices) => {
    if (prices.length === 1) {
      return `Rp${prices[0].toLocaleString()}`;
    }
    return `Rp${prices[0].toLocaleString()} - Rp${prices[1].toLocaleString()}`;
  };

  return (
    <div className="flex gap-3 px-6 w-full bg-white border-b border-solid border-b-stone-300 max-md:px-5 max-md:max-w-full">
      <div className="flex flex-wrap flex-1 shrink gap-5 items-start py-3 basis-0 min-w-[240px] size-full max-md:max-w-full">
        <div className="flex flex-col w-4">
          <input
            type="checkbox"
            checked={checked}
            onChange={(e) => onCheckChange(product.id, e.target.checked)}
            className="shrink-0 w-4 h-4 rounded border border-solid border-neutral-500"
          />
        </div>
        <ImageComponent loading="lazy"
          src={product.image}
          alt={product.name}
          className="object-contain shrink-0 w-14 rounded aspect-square"
        />
        <div className="flex flex-col justify-center py-1 text-xs font-medium leading-tight text-black min-w-[240px] w-[277px]">
          <div className="text-xs font-bold leading-tight line-clamp-2">
            {product.name}
          </div>
          {product.sku && (
            <div className="mt-3 line-clamp-1">SKU : {product.sku}</div>
          )}
          {product.brand && (
            <div className="mt-3 line-clamp-1">Brand : {product.brand}</div>
          )}
        </div>
        <div className="flex gap-2.5 items-start py-1 text-xs font-medium leading-tight text-black w-[179px]">
          <div className="gap-1 self-stretch w-[171px]">
            {formatPrice(product.price)}
          </div>
        </div>
        <div className="flex-wrap flex-1 shrink gap-2 self-stretch py-1 text-xs font-medium leading-tight text-black whitespace-nowrap min-h-[15px]">
          {product.stock}
        </div>
      </div>
    </div>
  );
}






