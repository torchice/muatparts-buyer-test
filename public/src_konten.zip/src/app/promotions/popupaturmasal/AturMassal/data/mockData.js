export const products = [
  {
    id: 1,
    name: "Adblue (harga perliter)",
    sku: "-",
    brand: "Astra UD Truck",
    image:
      "https://cdn.builder.io/api/v1/image/assets/TEMP/640dba99c4a431814a9274be9aff38ee7815b994cd840249540219f4d31c47a2?placeholderIfAbsent=true&apiKey=60cdcdaf919148d9b5b739827a6f5b2a",
    price: [75000],
    stock: 40,
  },
  {
    id: 2,
    name: "Gear Set Drive Tipe Meritor (5.0 FDR)",
    sku: "X36100-Z0001A",
    brand: "DT Truck",
    image:
      "https://cdn.builder.io/api/v1/image/assets/TEMP/f61379f96a661d4424d47656be284a2e5bd5ed3863ed064bcbcf0403277ef626?placeholderIfAbsent=true&apiKey=60cdcdaf919148d9b5b739827a6f5b2a",
    price: [10000000, 10500000],
    stock: 40,
  },
  {
    id: 3,
    name: "Lampu Depan Besar (Head Lamp RH)",
    sku: "",
    brand: "",
    image:
      "https://cdn.builder.io/api/v1/image/assets/TEMP/5fb1aaa480286cf0429bce57c5c25091e01523ba1a6251ffb75b98443f9501b4?placeholderIfAbsent=true&apiKey=60cdcdaf919148d9b5b739827a6f5b2a",
    price: [3000000],
    stock: 40,
  },
];
