"use client";
import * as React from "react";
import AturMassalPopup from "./AturMassalPopup";

const page = () => {
  return (
    <div className="flex flex-col mx-auto w-full max-w-[480px]">
      <AturMassalPopup />
    </div>
  );
};

export default page;






