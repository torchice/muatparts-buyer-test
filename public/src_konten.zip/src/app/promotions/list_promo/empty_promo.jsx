import ImageComponent from '@/components/ImageComponent/ImageComponent'
import * as React from "react";

function EmptyPromotions() {
  return (
    <div className="flex flex-col justify-center items-center self-stretch px-6 py-14 bg-white rounded-xl shadow-sm max-md:px-5">
      <div className="flex flex-col items-center">
        <div className="flex flex-col items-center w-24">
          <ImageComponent loading="lazy"
            src="https://cdn.builder.io/api/v1/image/assets/TEMP/7432515b2cc9d851a048a94e3735ed94d0b6dc5ebf85ee846325d2e3d6f2f919?placeholderIfAbsent=true&apiKey=60cdcdaf919148d9b5b739827a6f5b2a"
            alt="Empty promotions illustration"
            className="object-contain w-full rounded-none aspect-[1.25]"
          />
        </div>
        {/* Improvement fix wording pak Bryan */}
        <div className="mt-3 text-base font-semibold leading-tight text-center text-neutral-500">
          Belum ada promosi yang aktif
        </div>
      </div>
      <div className="mt-3 text-xs font-medium leading-tight text-center text-neutral-500 max-md:max-w-full">
        Buat promosimu sekarang!
      </div>
      <button
        className="gap-1 self-stretch px-6 py-3 mt-3 text-sm font-semibold leading-tight text-white bg-blue-600 rounded-3xl min-h-[32px] min-w-[112px] max-md:px-5"
        onClick={() => { }}
        aria-label="Create new promotion"
      >
        Buat Promosi
      </button>
    </div>
  );
}

export default EmptyPromotions;





