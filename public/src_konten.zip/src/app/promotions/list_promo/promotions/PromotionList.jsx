import ImageComponent from '@/components/ImageComponent/ImageComponent'
import * as React from "react";
import { PromotionCard } from "./PromotionCard";
import { Promotion } from "./types";

interface PromotionListProps {
  promotions: Promotion[];
  onSearch: (query: string) => void;
  onFilter: () => void;
  onCreatePromotion: () => void;
  onManagePromotion: (id: string) => void;
}

export function PromotionList({
  promotions,
  onSearch,
  onFilter,
  onCreatePromotion,
  onManagePromotion,
}: PromotionListProps) {
  return (
    <div className="flex overflow-hidden flex-col justify-center self-stretch pt-5 bg-white rounded-xl shadow-sm">
      <div className="flex gap-2.5 items-start px-6 pb-5 w-full leading-tight max-md:px-5 max-md:max-w-full">
        <div className="flex flex-wrap flex-1 shrink gap-6 items-center w-full basis-0 min-w-[240px] max-md:max-w-full">
          <div className="flex flex-1 shrink gap-6 items-center self-stretch my-auto text-xs font-medium basis-12 min-w-[240px] text-neutral-500 max-md:max-w-full">
            <div className="flex gap-3 items-center self-stretch my-auto min-w-[240px]">
              <div className="flex gap-2 items-center self-stretch px-3 py-2 my-auto bg-white rounded-md border border-solid border-neutral-500 min-h-[32px] min-w-[240px] w-[262px]">
                <ImageComponent loading="lazy"
                  src="https://cdn.builder.io/api/v1/image/assets/TEMP/872c8b4eb52366a050c54793a558c93057c94595d312988d082a8a4f1018d7d5?placeholderIfAbsent=true&apiKey=60cdcdaf919148d9b5b739827a6f5b2a"
                  alt=""
                  className="object-contain shrink-0 self-stretch my-auto w-4 aspect-square"
                />
                <input
                  type="text"
                  onChange={(e) => onSearch(e.target.value)}
                  placeholder="Cari Nama Promosi"
                  className="flex-1 shrink self-stretch my-auto basis-0 bg-transparent border-none outline-none"
                  aria-label="Search promotions"
                />
              </div>
              <button
                onClick={onFilter}
                className="flex gap-2 items-center self-stretch px-3 py-2 my-auto whitespace-nowrap bg-white rounded-md border border-solid border-neutral-500 min-h-[32px] w-[104px]"
              >
                <span className="flex-1 shrink self-stretch my-auto basis-0">
                  Filter
                </span>
                <ImageComponent loading="lazy"
                  src="https://cdn.builder.io/api/v1/image/assets/TEMP/6e3c49542bbc81e36b445b2bedf7ebba86d6baeddc1b962ef2b8f291f1152901?placeholderIfAbsent=true&apiKey=60cdcdaf919148d9b5b739827a6f5b2a"
                  alt=""
                  className="object-contain shrink-0 self-stretch my-auto w-4 aspect-square"
                />
              </button>
            </div>
          </div>
          <button
            onClick={onCreatePromotion}
            className="gap-1 self-stretch px-6 py-3 my-auto text-sm font-semibold text-white bg-blue-600 rounded-3xl min-h-[32px] min-w-[112px] max-md:px-5"
          >
            Buat Promosi
          </button>
        </div>
      </div>
      <div className="flex gap-3 items-center px-6 py-5 w-full text-xs font-bold leading-tight bg-white border-t border-b border-solid border-y-stone-300 text-neutral-500 max-md:px-5 max-md:max-w-full">
        <div className="flex flex-wrap flex-1 shrink gap-8 items-center self-stretch my-auto w-full basis-0 min-w-[240px] max-md:max-w-full">
          <div className="flex-1 shrink self-stretch my-auto basis-0">
            Nama Promosi
          </div>
          <div className="flex-1 shrink self-stretch my-auto basis-0">
            Produk Promosi
          </div>
          <div className="self-stretch my-auto w-[170px]">
            Status dan Periode
          </div>
          <div className="self-stretch my-auto w-[72px]">..</div>
        </div>
      </div>
      {promotions.map((promotion) => (
        <PromotionCard
          key={promotion.id}
          promotion={promotion}
          onManage={onManagePromotion}
        />
      ))}
    </div>
  );
}






