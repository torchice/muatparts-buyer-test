import ImageComponent from '@/components/ImageComponent/ImageComponent'
import React from 'react';
import { STATUS_STYLES } from './types';

export function PromotionCard({ promotion, onManage }) {
  const { name, product, status, startDate, endDate } = promotion;
  
  return (
    <div className="flex flex-col px-6 w-full font-medium border-b border-solid border-b-stone-300 max-md:px-5 max-md:max-w-full">
      <div className="flex flex-wrap gap-8 items-start py-5 w-full max-md:max-w-full">
        <div className="flex-1 shrink py-1 text-xs leading-4 text-black basis-6 min-w-[240px]">
          <span className="font-bold">{name}</span>
        </div>
        
        <div className="flex flex-col flex-1 shrink basis-6 min-w-[240px]">
          <div className="flex gap-3 items-start w-full text-xs leading-tight text-black">
            <ImageComponent loading="lazy"
              src={product.imageUrl}
              alt={product.name}
              className="object-contain shrink-0 w-8 rounded aspect-square"
            />
            <div className="flex flex-col flex-1 shrink justify-center py-1 basis-0 min-w-[240px]">
              <div className="text-xs font-semibold leading-4">{product.name}</div>
              {product.type && <div className="mt-2">Tipe: {product.type}</div>}
              <div className="mt-2">SKU: {product.sku}</div>
              <div className="mt-2">Brand: {product.brand}</div>
            </div>
          </div>
          
          <div className="flex gap-10 justify-between items-center mt-2 w-full text-xs leading-tight">
            <div className="self-stretch my-auto text-neutral-500">
              {product.productCount} Produk
              {product.variantCount ? ` - ${product.variantCount} Varian` : ''}
            </div>
            <button 
              className="flex gap-2 justify-center items-center self-stretch my-auto text-blue-600"
              onClick={() => onManage(promotion.id)}
            >
              <span>Lihat Semua Produk</span>
              <ImageComponent loading="lazy"
                src="https://cdn.builder.io/api/v1/image/assets/TEMP/5e23b388288c9c4743c0c15da18e459f3f4dd1eda81efa5fa6b2415a0236e4d6?placeholderIfAbsent=true&apiKey=60cdcdaf919148d9b5b739827a6f5b2a"
                alt=""
                className="object-contain shrink-0 self-stretch my-auto w-4 aspect-square"
              />
            </button>
          </div>
        </div>

        <div className="flex flex-col justify-center text-xs leading-tight text-black w-[170px]">
          <div className={`gap-1 self-stretch p-2 text-xs font-semibold leading-tight whitespace-nowrap rounded-md min-h-[24px] w-[90px] ${STATUS_STYLES[status]}`}>
            {status === 'active' ? 'Aktif' : 'Akan Datang'}
          </div>
          <div className="mt-3">
            <span className="text-neutral-500">Mulai: </span>
            {startDate}
          </div>
          <div className="mt-3">
            <span className="text-neutral-500">Akhir: </span>
            {endDate}
          </div>
        </div>

        <button
          onClick={() => onManage(promotion.id)}
          className="flex gap-2 items-center px-3 py-2 text-xs leading-tight text-black whitespace-nowrap bg-white rounded-md border border-solid border-neutral-500 min-h-[32px] w-[72px]"
        >
          <span className="self-stretch my-auto">Atur</span>
          <ImageComponent loading="lazy"
            src="https://cdn.builder.io/api/v1/image/assets/TEMP/451241e18af8ad453a649e2c1acd67f5a2d3f5494fb298c6ae10084a8d3e600b?placeholderIfAbsent=true&apiKey=60cdcdaf919148d9b5b739827a6f5b2a"
            alt=""
            className="object-contain shrink-0 self-stretch my-auto w-4 aspect-square"
          />
        </button>
      </div>
    </div>
  );
}





