"use client"
import React, { useEffect, useState } from "react";
import { MockServer_Promo } from "@/services/MockServer_Promo";

import { TopBar } from "@/components/headersellercomponents/TopBar";
import SidebarWithDropdown from "@/components/headersellercomponents/SidebarWithDropdown";
import { SearchFilter } from "@/components/PromoList/SearchFilter";
import  TabNavigation from "@/components/PromoList/TabNavigation";
import { PromoTable } from "@/components/PromoList/PromoTable";
import style from "./promo.module.scss"

export default function PromosiPenjual() {
  const [activeTab, setActiveTab] = useState("active");
  const [promos, setPromos] = useState([]);
  const [tabCounts, setTabCounts] = useState({ active: 0, history: 0 });

  useEffect(() => {
    fetchPromos();
  }, [activeTab]);

  const fetchPromos = async () => {
    try {
      const response = await MockServer_Promo.getPromotionsList({
        tab: activeTab
      });
      
      // Update to access correct data structure
      if (response && response.Data) {
        setPromos(response.Data.promos || []);
        setTabCounts(response.Data.tabCounts || { active: 0, history: 0 });
      }
    } catch (error) {
      console.error("Error fetching promos:", error);
      setPromos([]);
      setTabCounts({ active: 0, history: 0 });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <TopBar />

      <aside className="fixed top-[56px] left-0 w-[184px] bg-white shadow-sm">
        <SidebarWithDropdown />
      </aside>

      <main className={"ml-[184px] pt-14 " + style.promo}>

        <div className="flex flex-col p-6 max-md:px-5">
          <div className="flex flex-col max-w-full leading-tight w-[1040px]">
            <h1 className="gap-10 self-stretch w-full text-xl font-bold text-black max-md:max-w-full">
              Promosi Penjual
            </h1>
            <TabNavigation
              activeTab={activeTab}
              tabCounts={tabCounts}
              onTabChange={setActiveTab}
            />
          </div>
          <div className="flex overflow-hidden flex-col justify-center pt-5 mt-4 w-full bg-white rounded-xl shadow-sm max-md:max-w-full">
            <SearchFilter />
            <PromoTable promos={promos} />
          </div>
        </div>
      </main>
    </div>
  );
}






