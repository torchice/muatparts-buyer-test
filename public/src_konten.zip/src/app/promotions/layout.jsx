'use client';
import "./promotions.scss"
import { usePathname } from 'next/navigation';
import ResponsiveHandler from '@/providers/ResponsiveHandler/ResponsiveHandler';
import { LanguageProvider } from '@/providers/LanguageProvider';

const Layout = ({ children }) => {
  const pathname = usePathname();
  const isMobilePath = pathname.includes('/mobile');

  return (
    <ResponsiveHandler>
      <LanguageProvider>
        <div className="flex flex-col min-h-screen ">
          {/* Top Bar */}
          {/* {!isMobilePath && <TopBar />} */}

          {/* Main Content */}
          <div className={`flex w-full ${!isMobilePath ? 'pt-[0px]' : ''} max-md:max-w-full`}>
            {/* Sidebar */}
            {/* {!isMobilePath && <SidebarWithDropdown />} */}

            {/* Page Content - Add left margin to account for sidebar */}
            <main className={`flex-1 w-full ${!isMobilePath ? 'ml-[0px]' : ''}`}>
              {/* {!isMobilePath ? <MainApp>{children}</MainApp>:<>{children}</>} */}
              {children}
            </main>
          </div>
        </div>
      </LanguageProvider>
    </ResponsiveHandler>
  );
}

export default Layout;





