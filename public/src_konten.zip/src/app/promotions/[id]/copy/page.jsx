// src/app/promotions/[id]/copy/page.jsx

// all baris file ini fixing untuk:
// 24. THP 2 - MOD001 - MP - 022 - QC Plan - Web - MuatParts - Promo
// LB : 0163, 0165, 0172

"use client";
import { useEffect, useState } from 'react';
import { useCustomRouter } from '@/libs/CustomRoute';
import { useParams } from 'next/navigation';
import { useLanguage } from '@/providers/LanguageProvider';
import CreatePromoPage from '../../create/page';
import promoService from '@/services/MockServer_Promotion';
import Loading from '@/components/Loading/Loading';
import Button from '@/components/Button/Button';
import ModalComponent from '@/components/Modals/ModalComponent';

const CopyPromoPage = () => {
  const router = useCustomRouter();
  const params = useParams();
  const { t } = useLanguage();
  const [initialData, setInitialData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showErrorModal, setShowErrorModal] = useState(false);

  useEffect(() => {
    const fetchPromoData = async () => {
      try {
        const response = await promoService.getPromoById(params.id, 'copy');
        const promoData = response.Data;

        // """Keep existing data transformation logic"""
        const transformedData = {
          promoName: promoData.name,
          startDate: new Date(promoData.startDate),
          endDate: new Date(promoData.endDate),
          purchaseLimit: promoData.purchaseLimit,
          selectedProducts: promoData.products.map(product => ({
            id: product.id,
            name: product.name,
            sku: product.sku,
            brand: product.brand,
            imageUrl: product.imageUrl,
            stock: product.stock,
            price: product.price,
            salesType: product.salesType,
            haveVariant: product.haveVariant,
            promotion: product.promotion ? {
              quota: product.promotion.quota,
              purchaseLimit: product.promotion.purchaseLimit,
              promoPrice: [product.promotion.promoPrice],
              discount: product.promotion.discount,
              isValid: product.promotion.isValid
            } : null,
            quota: product.promotion?.quota,
            purchaseLimit: product.promotion?.purchaseLimit,
            promoPrice: product.promotion ? [product.promotion.promoPrice] : [0],
            discount: product.promotion?.discount || 0,
            variants: product.variants?.map(variant => ({
              id: variant.id,
              name: variant.name,
              sku: variant.sku,
              price: variant.price,
              stock: variant.stock,
              isActive: variant.isActive,
              promotion: variant.promotion ? {
                quota: variant.promotion.quota,
                purchaseLimit: variant.promotion.purchaseLimit,
                promoPrice: [variant.promotion.promoPrice],
                discount: variant.promotion.discount,
                isValid: variant.promotion.isValid
              } : null,
              quota: variant.promotion?.quota,
              purchaseLimit: variant.promotion?.purchaseLimit,
              promoPrice: variant.promotion ? [variant.promotion.promoPrice] : [0],
              discount: variant.promotion?.discount || 0
            }))
          }))
        };

        setInitialData(transformedData);
      } catch (error) {
        console.error('Failed to fetch promo data:', error);
        setError(error.message || 'Failed to load promotion data');
        setShowErrorModal(true);
      } finally {
        setIsLoading(false);
      }
    };

    fetchPromoData();
  }, [params.id]);

  if (isLoading) {
    return <Loading />;
  }

  const handleErrorClose = () => {
    setShowErrorModal(false);
    router.push('/promotions');
  };

  if (error) {
    return (
      <>
        <ModalComponent
          isOpen={showErrorModal}
          setClose={handleErrorClose}
          type="Modal"
          full
          preventAreaClose={false}
        >
          <div className="flex flex-col items-center p-6 gap-6">
            <div className="text-center">
              <p className="text-lg font-semibold mb-2">{t('labelError')}</p>
              <p className="text-sm text-neutral-600">{error}</p>
            </div>
            <Button
              color="primary"
              onClick={handleErrorClose}
              Class="w-full"
            >
              {t('labelKembali')}
            </Button>
          </div>
        </ModalComponent>
      </>
    );
  }

  return <CreatePromoPage
    initialData={initialData}
    mode={'copy'}
    breadcrumbTitle={t('salinPromosi')}
  />;
};

export default CopyPromoPage;