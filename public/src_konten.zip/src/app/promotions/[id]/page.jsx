// """{Keeping same path: src/app/promotions/[id]/page.jsx}"""
"use client";
import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import BreadCrumb from "@/components/BreadCrumb/BreadCrumb";
import PromoInfo from '@/components/Promotions/PromoDetail/PromoInfo';
import ProductList from '@/components/Promotions/PromoDetail/ProductList';
import promoService from '@/services/MockServer_Promotion';
import Loading from '@/components/Loading/Loading';
import ImageComponent from '@/components/ImageComponent/ImageComponent';
import { useCustomRouter } from '@/libs/CustomRoute';

export default function PromotionDetail() {
  const router = useCustomRouter();
  const params = useParams();
  const [promoData, setPromoData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  const breadcrumbData = [
    { value: "Dashboard", path: "/dashboard" },
    { value: "Kelola Promosi", path: "/promotions" },
    { value: "Detail Promosi", path: null }
  ];

  useEffect(() => {
    const fetchPromoData = async () => {
      try {
        const response = await promoService.getPromoById(params.id, 'detail');
        if (response?.Data) {
          // Transform data if needed
          const transformedData = {
            ...response.Data,
            products: response.Data.products?.map(product => ({
              ...product,
              variants: product.variants?.map(variant => ({
                ...variant,
                // Ensure variant has proper price format
                price: Array.isArray(variant.price) ? variant.price[0] : variant.price
              }))
            }))
          };
          setPromoData(transformedData);
        }
      } catch (error) {
        console.error('Failed to fetch promo data:', error);
        setError(error.message || 'Failed to load promotion data');
      } finally {
        setIsLoading(false);
      }
    };

    fetchPromoData();
  }, [params.id]);

  const handleBreadcrumbClick = (item) => {
    if (item.path) {
      router.push(item.path);
    }
  };

  if (isLoading) {
    return <Loading />;
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen">
        <div className="text-red-600 mb-4">Error: {error}</div>
        <button
          onClick={() => router.push('/promotions')}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg"
        >
          Back to Promotions
        </button>
      </div>
    );
  }

  if (!promoData) return null;

  return (
    <div className="bg-transparent min-h-screen">
      {/* Breadcrumb & Header */}
      <div className="mb-5">
        <div className="flex items-center px-6 py-4 bg-transparent">
          <BreadCrumb
            data={breadcrumbData}
            onclick={handleBreadcrumbClick}
            maxWidth={120}
            classname="text-sm"
          />
        </div>

        <div className="px-6 py-1 bg-transparent flex items-center gap-3">
          <ImageComponent src="/promo/back_button_header.svg"
            alt="back"
            className="w-6 h-6 cursor-pointer"
            onClick={() => router.push("/promotions")}
          />
          <h1 className="text-xl font-bold">Detail Promosi</h1>
        </div>
      </div>

      {/* Main Content */}
      <div className="px-6 space-y-6 pb-8">
        {/* Promo Info Section */}
        <PromoInfo promoData={promoData} />

        {/* Products Section */}
        <ProductList 
          products={promoData.products}
          purchaseLimit={promoData.purchaseLimit}
        />
      </div>
    </div>
  );
}


