// src/app/promotions/[id]/edit/page.jsx
"use client";
import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import CreatePromoPage from '../../create/page';
import promoService from '@/services/MockServer_Promotion';
import Loading from '@/components/Loading/Loading';
import Modal from "@/components/Modals/modal";
import { useCustomRouter } from '@/libs/CustomRoute';

export default function EditPromoPage() {
  const router = useCustomRouter();
  const params = useParams();
  const [initialData, setInitialData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showPreventivePopup, setShowPreventivePopup] = useState(false);
  const [preventiveData, setPreventiveData] = useState(null);

  useEffect(() => {
    const fetchPromoData = async () => {
      try {
        const response = await promoService.getPromoById(params.id, 'edit');
        const promoData = response.Data;
        
        // Transform to match create promo data structure
        const transformedData = {
          id: params.id,
          promoName: promoData.name,
          startDate: new Date(promoData.startDate.replace('Z', '')),
          endDate: new Date(promoData.endDate.replace('Z', '')),
          purchaseLimit: promoData.purchaseLimit,
          promoStatus: promoData.status,
          selectedProducts: promoData.products.map(product => ({
            id: product.id,
            name: product.name,
            sku: product.sku,
            brand: product.brand,
            imageUrl: product.imageUrl,
            stock: product.stock,
            price: product.price,
            quota: product.promotion?.quota || 0,
            purchaseLimit: product.promotion?.purchaseLimit || 0,
            promoPrice: product.promotion?.promoPrice ? [product.promotion.promoPrice] : [0],
            discount: product.promotion?.discount || 0,
            variants: product.variants?.map(variant => ({
              id: variant.id,
              name: variant.name,
              sku: variant.sku,
              price: Array.isArray(variant.price) ? variant.price[0] : variant.price,
              stock: variant.stock,
              isActive: variant.promotion?.isActive ?? true,
              quota: variant.promotion?.quota || 0,
              purchaseLimit: variant.promotion?.purchaseLimit || 0,
              promoPrice: variant.promotion?.promoPrice ? [variant.promotion.promoPrice] : [0],
              discount: variant.promotion?.discount || 0
            }))
          }))
        };

        setInitialData(transformedData);
      } catch (error) {
        console.error('Failed to fetch promo data:', error);
        setError(error.message || 'Failed to load promotion data');
      } finally {
        setIsLoading(false);
      }
    };

    fetchPromoData();
  }, [params.id]);

  useEffect(() => {
    if (!initialData?.promoStatus === 'Aktif') return;

    // Set up preventive check interval for active promos
    const checkInterval = setInterval(async () => {
      try {
        const response = await promoService.getPromoById(params.id);
        const currentData = response.Data;

        const hasProductChanges = currentData.products.some(product => {
          const originalProduct = initialData?.selectedProducts.find(p => p.id === product.id);
          if (!originalProduct) return false;

          return (
            product.stock !== originalProduct.stock ||
            product.price[0] !== originalProduct.price[0] ||
            product.status !== originalProduct.status
          );
        });

        if (hasProductChanges) {
          setPreventiveData(currentData);
          setShowPreventivePopup(true);
        }
      } catch (error) {
        console.error('Error checking for product changes:', error);
      }
    }, 30000);

    return () => clearInterval(checkInterval);
  }, [initialData, params.id]);

  const handlePreventiveUpdate = () => {
    if (preventiveData) {
      // Update the initial data with new values
      setInitialData(prev => ({
        ...prev,
        selectedProducts: prev.selectedProducts.map(product => {
          const updatedProduct = preventiveData.products.find(p => p.id === product.id);
          if (!updatedProduct) return product;

          return {
            ...product,
            stock: updatedProduct.stock,
            price: updatedProduct.price,
            status: updatedProduct.status
          };
        })
      }));
    }
    setShowPreventivePopup(false);
    setPreventiveData(null);
  };

  if (isLoading) return <Loading />;

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen">
        <div className="text-red-600 mb-4">Error: {error}</div>
        <button
          onClick={() => router.push('/promotions')}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg"
        >
          Back to Promotions
        </button>
      </div>
    );
  }

  return (
    <>
      <CreatePromoPage 
        initialData={initialData}
        mode="edit"
        pageTitle="Ubah Promosi"
        breadcrumbTitle="Ubah Promosi"
        onSave={async (data) => {
          try {
            // Transform data for update API
            const updateData = {
              id: params.id,
              ...data,
              // Add any edit-specific transformations here
            };
            
            const response = await promoService.savePromotion(updateData);
            // router.push("/promotions");
            return response;
          } catch (error) {
            console.error('Failed to update promotion:', error);
            throw error; // Let CreatePromoPage handle the error
          }
        }}
        validateStartDate={(date) => {
          // Add edit-specific date validation
          if (initialData.promoStatus === 'Aktif') {
            return date >= initialData.startDate && date <= initialData.endDate;
          }
          return date >= new Date();
        }}
        validateEndDate={(date) => {
          // Add edit-specific date validation
          if (initialData.promoStatus === 'Aktif') {
            return date >= initialData.startDate && date <= initialData.endDate;
          }
          return date >= initialData.startDate && date <= addDays(initialData.startDate, 180);
        }}
        disableStartDate={initialData.promoStatus === 'Aktif'}
      />

      {/* Preventive Update Modal */}
      <Modal
        isOpen={showPreventivePopup}
        setIsOpen={setShowPreventivePopup}
        closeBtn={true}
        title="Perubahan Data Produk"
        desc="Terdapat perubahan pada data produk. Sistem akan memperbarui data produk sesuai dengan perubahan terbaru."
        action1={{
          action: handlePreventiveUpdate,
          text: "Mengerti",
          style: "full",
          color: "#176CF7",
        }}
        isBig={false}
        headerColor="blue"
      />
    </>
  );
}


