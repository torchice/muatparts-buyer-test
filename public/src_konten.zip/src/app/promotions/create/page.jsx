// src/app/promotions/create/page.jsx
// 24. THP 2 - MOD001 - MP - 022 - QC Plan - Web - MuatParts - Promo
// LB - 0019
// LB - 0051
// LB - 0093
// LB - 0118
// LB - 0123
// LB - 0130
// LB - 0131
// LB - 0132
// LB - 0138
// LB - 0146
// LB - 0150
// LB - 0152
// LB - 0154
// LB - 0161

"use client";
import { useState, useEffect, useCallback } from "react";
import { addMinutes, addDays, format, differenceInHours, differenceInDays } from "date-fns";
import { useCustomRouter } from '@/libs/CustomRoute';
import { useLanguage } from '@/providers/LanguageProvider';
import BreadCrumb from "@/components/BreadCrumb/BreadCrumb";
import Input from "@/components/Input/Input";
import DatetimePicker from "@/components/DatetimePicker/DatetimePicker";
import PromoProductPopup from "@/components/Promotions/PromoCreate/PromoProductPopup";
import Modal from "@/components/Modals/modal";
import ProductTable from "@/components/Promotions/PromoCreate/ProductTable";
import promoService from "@/services/MockServer_Promotion";
import ToastApp from "@/components/ToastApp/ToastApp";
import Toast from "@/components/Toast/Toast";
import toast from "@/store/zustand/toast";
import ImageComponent from "@/components/ImageComponent/ImageComponent";
import Button from "@/components/Button/Button";

// Add this helper function
const formatCurrency = (value) => {
	return new Intl.NumberFormat('id-ID', {
		style: 'currency',
		currency: 'IDR',
		minimumFractionDigits: 0,
		maximumFractionDigits: 0
	}).format(value);
};

const PromoStatusBadge = ({ status }) => {
	const statusStyles = {
		'Akan Datang': 'bg-[#FFF8E1] text-[#B88217]',
		'Aktif': 'bg-[#E3F5ED] text-[#00AF6C]',
		'Berakhir': 'text-[#555555] bg-[#F5F5F5]'
	};

	return (
		<div className={`inline-flex px-3 py-1 rounded-full text-xs w-fit font-semibold ${statusStyles[status]}`}>
			{status}
		</div>
	);
};

export default function CreatePromoPage({
	initialData = null,
	mode = 'create', // 'create' or 'edit' or 'copy'
	pageTitle = "",
	breadcrumbTitle = "",
	onSave = null, // Optional custom save handler
	validateStartDate = null, // Optional custom start date validator
	validateEndDate = null, // Optional custom end date validator
	disableStartDate = false
}) {
	const router = useCustomRouter();
	const { t } = useLanguage();
	const { showBottomsheet, showSidebar, setShowSidebar, showNavMenu, setShowToast, setDataToast } = toast(); // Get toast store methods
	const [toastMessage, setToastMessage] = useState('');
	const [toastType, setToastType] = useState('success');

	// Form States
	const [promoName, setPromoName] = useState(initialData?.promoName || "");
	const [purchaseLimit, setPurchaseLimit] = useState(initialData?.purchaseLimit || "no_limit");
	const [selectedProducts, setSelectedProducts] = useState(initialData?.selectedProducts || []);
	const [promoStatus, setPromoStatus] = useState(initialData?.promoStatus || null);
	const [maxNameLength, setMaxNameLength] = useState(60);
	const [maxSelectedProducts, setMaxSelectedProducts] = useState(30);
	const [isLoading, setIsLoading] = useState(false);
	const [hasChanges, setHasChanges] = useState(false);
	const [errors, setErrors] = useState({});
	const [maxDiscount, setMaxDiscount] = useState(60); // Default to 60%

	const [showBackConfirm, setShowBackConfirm] = useState(false);
	const [showProductModal, setShowProductModal] = useState(false);
	const [showAddProductModal, setShowAddProductModal] = useState(false);

	const [showSaveConfirm, setShowSaveConfirm] = useState(false);
	const [saveData, setSaveData] = useState(null);

	const [showOverlappingProductsModal, setShowOverlappingProductsModal] = useState(false);
	const [invalidProducts, setInvalidProducts] = useState([]);
	const [showDataChangeModal, setShowDataChangeModal] = useState(false);
	const [timezone, setTimezone] = useState({ id: "Asia/Jakarta", offset: "+07:00" });

	const isSidebarExpanded = () => {
		const element = document.querySelectorAll('body > div > div > div > main.main-container')[0];
		const elemPaddingLeft = parseFloat(window.getComputedStyle(element, null).getPropertyValue("padding-left"))
		return elemPaddingLeft > 60;
	}
	const [hasClass, setHasClass] = useState(null);

	pageTitle = pageTitle == '' ? t('buatPromosi') : pageTitle
	breadcrumbTitle = breadcrumbTitle == '' ? t('buatPromosi') : breadcrumbTitle

	const breadcrumbData = [
		{ value: t('labelDashboard'), path: "/dashboard" },
		{ value: t('promosiPenjual'), path: "/promotions" },
		{ value: breadcrumbTitle, path: null }
	];

	const [clickedBreadcrumbPath, setClickedBreadcrumbPath] = useState("/promotions");


	const getNowTimezone = () => {
		const localNow = new Date();

		// Convert to GMT+0 by subtracting local timezone offset
		const gmtNow = new Date(localNow.getTime() + (localNow.getTimezoneOffset() * 60000));

		// Add desired timezone offset (e.g. +07:00 for Jakarta)
		const targetOffset = parseInt(timezone.offset.slice(1, 3)) * 60;
		const adjustedNow = new Date(gmtNow.getTime() + (targetOffset * 60000));
		return adjustedNow;
	}

	const calculateTimezone = (dateTime = new Date()) => {
		if (initialData?.startDate && mode != 'copy') {
			// Handle initial data if present
			return new Date(initialData.startDate);
		}

		// Add 15 minutes and reset seconds
		const defaultStart = addMinutes(getNowTimezone(), 15);
		defaultStart.setSeconds(0, 0);

		return defaultStart;
	}

	const [startDate, setStartDate] = useState(() => {
		return calculateTimezone();
	});

	const [endDate, setEndDate] = useState(() => {
		console.log('44bx', initialData?.endDate, mode)
		if (initialData?.endDate && mode != 'copy') return new Date(initialData.endDate);

		const defaultEnd = addDays(startDate, 30);
		// defaultEnd.setHours(23, 59, 0, 0);
		console.log('44by', defaultEnd)
		return defaultEnd;
	});

	useEffect(() => {
		const fetchConfig = async () => {
			try {
				const [nameLength, timezoneData, maxProducts, maxDiscountData] = await Promise.all([
					promoService.getPromoNameMaxLength(),
					promoService.getUserTimezone(),
					promoService.getMaxProducts(),
					promoService.getMaxDiscount() // Add this
				]);

				if (nameLength?.Data?.maxLength) {
					setMaxNameLength(nameLength.Data.maxLength);
				}

				if (timezoneData?.Data?.timezone) {
					setTimezone(timezoneData.Data.timezone);
				}

				if (maxProducts?.Data?.maxProducts) {
					setMaxSelectedProducts(maxProducts.Data.maxProducts);
				}

				if (maxDiscountData?.Data?.maxDiscount) {
					setMaxDiscount(maxDiscountData.Data.maxDiscount);
				}
			} catch (error) {
				console.error("Failed to fetch configuration:", error);
			}
		};
		setHasClass(isSidebarExpanded()); // Check sidebar state on mount

		fetchConfig();
	}, []);

	useEffect(() => {
		const targetNode = document.querySelector(".main-container");

		if (!targetNode) return; // Exit if the element is not found

		// Create a MutationObserver instance
		const observer = new MutationObserver(() => {
			setHasClass(isSidebarExpanded()); // Update state based on the class presence
		});

		// Start observing the target node for class changes
		observer.observe(targetNode, {
			attributes: true,
			attributeFilter: ["class"], // Only watch class changes
		});

		// Cleanup on unmount
		return () => observer.disconnect();
	}, []); // Run only once on mount

	useEffect(() => {
		console.log('errorsValidation', errors)
	}, [errors])

	useEffect(() => {
		console.log('45a', showOverlappingProductsModal, showDataChangeModal)
		if (!showOverlappingProductsModal && !showDataChangeModal) {
			handleOverlappingProductsUnderstand();
		}
	}, [showOverlappingProductsModal, showDataChangeModal])

	useEffect(() => {
		if (mode != 'edit') {
			console.log('45g', calculateTimezone());
			setStartDate(calculateTimezone());
			setEndDate(addDays(calculateTimezone(), 30))
		}
	}, [timezone])

	useEffect(() => {
		console.log('45j', startDate);
		// setEndDate(addDays(startDate, 30))
	}, [startDate])

	const handleDateChange = (field, value) => {
		const newDate = new Date(value);
		newDate.setSeconds(0, 0);

		if (field === 'start') {
			// Use custom validation if provided
			// if (validateStartDate && !validateStartDate(newDate)) return;

			setStartDate(newDate);
			// if (newDate > endDate) {
			// 	setEndDate(addDays(newDate, 1));
			// }
		} else {
			// Use custom validation if provided
			// if (validateEndDate && !validateEndDate(newDate)) return;

			setEndDate(newDate);
		}

		// Clear all date-related errors when either date changes
		setErrors(prev => ({
			...prev,
			startDate: null,
			endDate: null
		}));

		setHasChanges(true);
	};

	const validateForm = useCallback(() => {
		const newErrors = {};
		let hasErrors = false;

		// Name validation with toast
		if (!promoName.trim()) {
			setDataToast({
				type: 'error',
				message: t('terdapatFieldYangKosong')
			});
			setShowToast(true);
			newErrors.name = t('fieldWajibDiisi');
			hasErrors = true;
			setErrors(newErrors);
			return false;
		}

		if (promoName.length > maxNameLength) {
			setDataToast({
				type: 'error',
				message: `Nama promosi maksimal ${maxNameLength} karakter`
			});
			setShowToast(true);
			newErrors.name = `Maksimal ${maxNameLength} karakter`;
			hasErrors = true;
			setErrors(newErrors);
			return false;
		}

		// Date validation
		if (!validateDates(startDate, endDate, newErrors)) {
			hasErrors = true;
			setErrors(newErrors);
			return false;
		}

		// Product validation - only show toast if no products selected
		if (selectedProducts.length === 0) {
			setDataToast({
				type: 'error',
				message: t('tambahprodukminimal')
			});
			setShowToast(true);
			hasErrors = true;
			return false;
		}

		// Validate each product and its variants - no toast, only field errors
		selectedProducts.forEach(product => {
			if (!product.variants?.length) {
				// Validate non-variant products
				if (validateProductFields(product, product.id, newErrors)) {
					hasErrors = true;
				}
			} else {
				// For variant products, only validate active variants
				let hasActiveVariant = false;

				product.variants.forEach(variant => {
					if (!variant.isActive) return;
					hasActiveVariant = true;

					if (validateVariantFields(variant, product.id, newErrors)) {
						hasErrors = true;
					}
				});

				if (!hasActiveVariant) {
					newErrors[`variants_${product.id}`] = "Minimal satu varian harus aktif";
					hasErrors = true;
				}
			}
		});

		setErrors(newErrors);
		console.log('45h', startDate)
		return !hasErrors;
	}, [promoName, startDate, endDate, selectedProducts, purchaseLimit, maxNameLength, validateStartDate]);

	const validateProductFields = (product, productId, errors) => {
		let hasError = false;
		const basePrice = Array.isArray(product.price) ? product.price[0] : product.price;
		const minPrice = basePrice * (1 - maxDiscount / 100); // Calculate minimum allowed price

		// Quota validation
		// MP 22: LB - 0134
		if (!product.quota || product.quota < 1) {
			errors[`quota_${productId}`] = "Min. 1";
			hasError = true;
		} else if (product.quota > product.stock) {
			// errors[`quota_${productId}`] = `${t('labelMaks')} ${product.stock}`;
			// hasError = true;
		}

		// Purchase limit validation
		if (purchaseLimit !== 'no_limit') {
			if (!product.purchaseLimit || product.purchaseLimit < 1) {
				errors[`purchaseLimit_${productId}`] = "Min. 1";
				hasError = true;
			} else if (product.purchaseLimit > product.quota) {
				errors[`purchaseLimit_${productId}`] = `${t('labelMaks')} ${product.quota}`;
				hasError = true;
			}
		}

		// Price validation
		if (!product.promoPrice?.[0]) {
			errors[`price_${productId}`] = `Min. ${formatCurrency(minPrice)} atau Maks. ${maxDiscount}%`;
			hasError = true;
		} else {
			const promoPrice = product.promoPrice[0];
			const discountPercent = ((basePrice - promoPrice) / basePrice) * 100;

			if (discountPercent < 1) {
				errors[`price_${productId}`] = `${t('labelMaks')} ${basePrice * 0.99}`;
				hasError = true;
			} else if (discountPercent > 99) {
				errors[`price_${productId}`] = `Min. ${basePrice * 0.01}`;
				hasError = true;
			} else if (promoPrice < minPrice) {
				errors[`price_${productId}`] = `Min. ${formatCurrency(minPrice)} atau ${maxDiscount}%`;
				hasError = true;
			}
		}

		return hasError;
	};

	const validateVariantFields = (variant, productId, errors) => {
		let hasError = false;
		const variantId = variant.id;
		const variantBasePrice = variant.price;
		const minPrice = variantBasePrice * (1 - maxDiscount / 100); // Calculate minimum allowed price

		// Quota validation for variant
		if (!variant.quota || variant.quota < 1) {
			errors[`quota_${productId}_${variantId}`] = "Min. 1";
			hasError = true;
		} else if (variant.quota > variant.stock) {
			// errors[`quota_${productId}_${variantId}`] = `${t('labelMaks')} ${variant.stock}`;
			// hasError = true;
		}

		// Purchase limit validation for variant
		if (purchaseLimit !== 'no_limit') {
			if (!variant.purchaseLimit || variant.purchaseLimit < 1) {
				errors[`purchaseLimit_${productId}_${variantId}`] = "Min. 1";
				hasError = true;
			} else if (variant.purchaseLimit > variant.quota) {
				errors[`purchaseLimit_${productId}_${variantId}`] = `${t('labelMaks')} ${variant.quota}`;
				hasError = true;
			}
		}

		// Price validation for variant
		if (!variant.promoPrice?.[0]) {
			errors[`price_${productId}_${variantId}`] = `Min. ${formatCurrency(minPrice)} atau ${maxDiscount}%`;
			hasError = true;
		} else {
			const variantPromoPrice = variant.promoPrice[0];
			const discountPercent = ((variantBasePrice - variantPromoPrice) / variantBasePrice) * 100;

			if (discountPercent < 1) {
				errors[`price_${productId}_${variantId}`] = `${t('labelMaks')} ${variantBasePrice * 0.99}`;
				hasError = true;
			} else if (discountPercent > 99) {
				errors[`price_${productId}_${variantId}`] = `Min. ${variantBasePrice * 0.01}`;
				hasError = true;
			} else if (variantPromoPrice < minPrice) {
				errors[`price_${productId}_${variantId}`] = `Min. ${formatCurrency(minPrice)} atau ${maxDiscount}%`;
				hasError = true;
			}

			// if (variantPromoPrice < minPrice) {
			// 	errors[`price_${productId}_${variantId}`] = `Min. ${formatCurrency(minPrice)} atau ${maxDiscount}%`;
			// 	hasError = true;
			// } else if (variantPromoPrice > variantBasePrice) {
			// 	errors[`price_${productId}_${variantId}`] = "Tidak boleh melebihi harga normal";
			// 	hasError = true;
			// }

			// if (discountPercent < 1) {
			// 	errors[`discount_${productId}_${variantId}`] = "Min. 1%";
			// 	hasError = true;
			// } else if (discountPercent > 99) {
			// 	errors[`discount_${productId}_${variantId}`] = `${t('labelMaks')} 99%`;
			// 	hasError = true;
			// }
		}

		return hasError;
	};

	const savePromotion = async () => {
		setIsLoading(true);

		try {
			// Transform products data according to API contract
			const transformedProducts = selectedProducts.map(product => {
				// """Keep existing transformation code"""
				const baseProduct = {
					id: product.id
				};

				// Only add promotion fields for non-variant products
				if (!product.variants?.length) {
					return {
						...baseProduct,
						quota: product.quota,
						purchaseLimit: purchaseLimit !== 'no_limit' ? product.purchaseLimit : undefined,
						promoPrice: product.promoPrice?.[0],
						discount: product.discount,
						price: product.price[0], // non-variant always have 1 price
						stock: product.stock
					};
				}

				// For products with variants, only include active variants with their promotion data
				return {
					...baseProduct,
					variants: product.variants
						.filter(variant => variant.isActive)
						.map(variant => ({
							variantId: variant.id,
							isActive: true,
							quota: variant.quota,
							purchaseLimit: purchaseLimit !== 'no_limit' ? variant.purchaseLimit : undefined,
							promoPrice: variant.promoPrice?.[0],
							discount: variant.discount,
							price: variant.price, // integer (not array)
							stock: variant.stock
						}))
				};
			});

			const promoData = {
				promoName: promoName.trim(),
				startDate: format(startDate, "yyyy-MM-dd'T'HH:mm:ss'Z'"),
				endDate: format(endDate, "yyyy-MM-dd'T'HH:mm:ss'Z'"),
				mode: mode,
				purchaseLimit,
				selectedProducts: transformedProducts
			};

			try {
				// Use a nested try-catch to specifically handle API responses
				let response;
				if (onSave) {
					response = await onSave(promoData);
				} else {
					response = await promoService.savePromotion(promoData);
				}
				console.log('response save: ', response)

				// Handle successful API responses
				if (response?.Message?.Code === 200) {
					// Success case

					sessionStorage.setItem('promoToast', JSON.stringify({
						type: 'success',
						message: t('berhasilMenyimpanPromo')
					}));
					// setDataToast({
					// 	type: 'success',
					// 	message: t('berhasilMenyimpanPromo')
					// });
					router.push("/promotions");
					// setShowToast(true);
				} else if (response?.Message?.Code === 400 &&
					response?.Message?.Text === "Cek Produk Kamu" &&
					response?.Data?.invalidProductIds) {
					// Overlapping products case
					const invalidProductIds = response.Data.invalidProductIds;
					const invalidProductsList = selectedProducts.filter(product =>
						invalidProductIds.includes(product.id)
					);

					setInvalidProducts(invalidProductsList);
					setShowOverlappingProductsModal(true);
				} else {					// Other response cases that aren't errors (handled by catch)
					setDataToast({
						type: 'error',
						message: response?.Message?.Text || t('labelGagal')
					});
					setShowToast(true);
				}
			} catch (apiError) {
				// Special handling for the overlapping product error (400 response)
				if (apiError.code === 400 &&
					apiError.message === "Cek Produk Kamu" &&
					apiError.errors?.invalidProductIds) {

					const invalidProductIds = apiError.errors.invalidProductIds;
					const invalidProductsList = selectedProducts.filter(product =>
						invalidProductIds.includes(product.id)
					);

					setInvalidProducts(invalidProductsList);
					setShowOverlappingProductsModal(true);
				} else {
					// Handle other API errors
					console.error('API Error:', apiError);
					setDataToast({
						type: 'error',
						message: apiError.message || t('labelGagal')
					});
					setShowToast(true);
				}
			}
		} catch (error) {
			// Handle other non-API errors
			console.error('Failed to save promotion:', error);
			setDataToast({
				type: 'error',
				message: error.message || t('labelGagal')
			});
			setShowToast(true);
		} finally {
			setIsLoading(false);
			setShowSaveConfirm(false);
		}
	};

	const handleSubmit = async (e) => {
		e.preventDefault();

		if (!validateForm()) {
			return;
		}

		// Show confirmation modal instead of directly saving
		await validatePromoProducts();
		// setShowSaveConfirm(true);
	};

	const handleProductUpdate = (productId, updates) => {
		// Handle error updates for both products and variants
		if (updates.error === null || updates.clearError) {
			setErrors(prevErrors => {
				const newErrors = { ...prevErrors };
				if (updates.variantId) {
					// Clear error for variant field based on the field being updated
					if (updates.clearError) {
						delete newErrors[updates.clearError]; // Use the specific error key to clear
					} else {
						delete newErrors[`quota_${productId}_${updates.variantId}`];
					}
				} else {
					// Clear error for product field
					if (updates.clearError) {
						delete newErrors[updates.clearError]; // Use the specific error key to clear
					} else {
						delete newErrors[`quota_${productId}`];
					}
				}
				return newErrors;
			});
		} else if (updates.error) {
			setErrors(prevErrors => ({
				...prevErrors,
				...updates.error  // Add new errors
			}));
		}

		if (updates.deleted) {
			// Clean up all errors related to this product and its variants
			setErrors(prevErrors => {
				const newErrors = {};
				// Keep only errors that don't belong to the deleted product
				Object.entries(prevErrors).forEach(([key, value]) => {
					if (!key.includes(`_${productId}`) && !key.startsWith(`variants_${productId}`)) {
						newErrors[key] = value;
					}
				});
				return newErrors;
			});

			setSelectedProducts(prev => prev.filter(product => product.id !== productId));
			setHasChanges(true);
			return;
		}

		// Continue with product updates as before
		setSelectedProducts(prev => prev.map(product => {
			if (product.id !== productId) return product;

			if (updates.variantId) {
				// Update variant
				return {
					...product,
					variants: product.variants?.map(variant =>
						variant.id === updates.variantId
							? { ...variant, ...updates }
							: variant
					)
				};
			}

			// Update main product
			return { ...product, ...updates };
		}));
		setHasChanges(true);
	};


	const handleAddProductClick = () => {
		setShowAddProductModal(true);
	};

	const validateDates = (startDate, endDate, errors) => {
		const now = new Date();
		const hoursDuration = differenceInHours(endDate, startDate);
		const daysDuration = differenceInDays(endDate, startDate);

		console.log('ababab')
		console.log(startDate < now)
		console.log(!(mode == 'edit' && promoStatus === 'Aktif'))
		if (startDate < getNowTimezone() && !(mode == 'edit' && promoStatus === 'Aktif')) {
			errors.startDate = t('waktuMulaiHarusLebihdariWaktuSaatIni');
			return false;
		}

		if (startDate >= endDate) {
			errors.endDate = t('waktuAkhirHarusLebihDariWaktuAwal');
			return false;
		}

		if (hoursDuration < 1 || daysDuration > 180) {
			errors.startDate = t('masaBerlakuJamHari');
			return false;
		}

		return true;
	};

	const handleOverlappingProductsUnderstand = () => {
		if (showOverlappingProductsModal) {
			setShowOverlappingProductsModal(false);
		}
		// Remove invalid products from the selection
		console.log('45b', invalidProducts)
		if (invalidProducts.length > 0) {
			const invalidProductIds = invalidProducts.map(p => p.id);
			setSelectedProducts(prev => prev.filter(p => !invalidProductIds.includes(p.id)));
		}
	};

	const validatePromoProducts = async () => {
		setIsLoading(true);
		try {
			// Format the product data as required by the API
			const formattedProducts = selectedProducts.map(product => ({
				id: product.id,
				price: product.variants.length == 0 ? (Array.isArray(product.price) ? product.price[0] : product.price) : undefined,
				stock: product.variants.length == 0 ? product.stock : undefined,
				variants: product.variants ? product.variants.map(variant => ({
					variant_id: variant.id,
					price: variant.price,
					stock: variant.stock
				})) : undefined
			}));

			// Call the validation API
			const response = await promoService.validateProducts({
				start_date: format(startDate, "yyyy-MM-dd'T'HH:mm:ss'Z'"),
				end_date: format(endDate, "yyyy-MM-dd'T'HH:mm:ss'Z'"),
				promo_id: initialData?.id || null,
				selected_products: formattedProducts
			});

			// Check validation result
			if (response.Message.Code === 200 && response.Data.is_valid) {
				// Products are valid, show save confirmation
				setShowSaveConfirm(true);
			} else if (response.Message.Code === 400 &&
				response.Message.Text === "Cek Produk Kamu" &&
				response.Data.overlapProductIds.length > 0) {
				// Handle invalid products case
				const overlapProductIds = response.Data.overlapProductIds;
				const overlapProductsList = selectedProducts.filter(product =>
					overlapProductIds.includes(product.id)
				);

				setInvalidProducts(overlapProductsList);
				setShowOverlappingProductsModal(true);
			} else if (response.Message.Code === 400 &&
				response.Message.Text === "Cek Produk Kamu" &&
				response.Data.invalidProductIds.length > 0) {

				const invalidProductIds = response.Data.invalidProductIds;
				const invalidProductList = selectedProducts.filter(product =>
					invalidProductIds.includes(product.id)
				);
				console.log('45c', selectedProducts)

				setInvalidProducts(invalidProductList);
				setShowDataChangeModal(true);
			} else {
				// Handle other error cases //
				setDataToast({
					type: 'error',
					message: response?.Message?.Text || t('labelGagal')
				});
				setShowToast(true);
			}
		} catch (error) {
			console.error('Product validation failed:', error);

			// Special handling for the overlapping product error
			if (error.code === 400 &&
				error.message === "Cek Produk Kamu" &&
				error.errors?.invalidProductIds) {

				const invalidProductIds = error.errors.invalidProductIds;
				const invalidProductsList = selectedProducts.filter(product =>
					invalidProductIds.includes(product.id)
				);

				setInvalidProducts(invalidProductsList);
				setShowOverlappingProductsModal(true);
			} else {
				setDataToast({
					type: 'error',
					message: error.message || t('labelGagal')
				});
				setShowToast(true);
			}
		} finally {
			setIsLoading(false);
		}
	};

	return (
		<div className="bg-[var(--neutral-100)] min-h-screen">
			{/* Breadcrumb & Header */}
			<div className="">
				<div className="flex items-center px-6">
					<BreadCrumb
						data={breadcrumbData}
						onclick={(item) => {
							if (item.path) {
								if (hasChanges || true) {
									setShowBackConfirm(true);
									setClickedBreadcrumbPath(item.path);
								} else {
									router.push(item.path);
								}
							}
						}}
						maxWidth={'200px'}
						classname="text-sm"
					/>
				</div>

				<div className="px-6 py-4 flex items-center gap-3">
					<ImageComponent
						src="/promo/back_button_header.svg"
						alt="back"
						className="w-6 h-6 cursor-pointer"
						onClick={() => {
							if (hasChanges || true) {
								setShowBackConfirm(true);
							} else {
								router.push("/promotions");
							}
						}}
					/>
					<h1 className="text-xl font-bold">{pageTitle}</h1>
				</div>
			</div>

			{/* Main Content */}
			<div className="px-6 space-y-6 pb-[88px]">
				{/* <form onSubmit={handleSubmit} className="space-y-6"> */}
				{/* Promo Info Card */}
				<div className="bg-white rounded-lg shadow p-6">
					<h2 className="text-lg font-bold mb-6">{t('informasiPromosi')}</h2>

					<div className="space-y-6">
						{/* Promo Name */}
						<div className="grid grid-cols-[178px,1fr] items-start gap-4">
							<label className="text-sm text-gray-600 pt-2">{t('namaPromosi')}*</label>
							<div className="max-w-lg">
								<Input
									name="promoName"
									value={promoName}
									changeEvent={(e) => {
										setPromoName(e.target.value);
										setHasChanges(true);
										if (errors.name) {
											setErrors(prev => ({ ...prev, name: null }));
										}
									}}
									maxLength={maxNameLength}
									placeholder={`${t('labelContoh')} : ${t('diskonTahunBaru')}`}
									status={errors.name ? "error" : null}
								/>
								<div className="flex justify-between items-center text-[12px] text-[var(--neutral-600)] mt-[8px]">
									<div>{`${t('labelCatatan')} : ${t('namaPromosiTidakTampildiPembeli')}`}</div>
									<div>{`${promoName.length}/${maxNameLength}`}</div>
								</div>
							</div>
						</div>

						{/* Date Range - Updated disabled logic */}
						<div className="grid grid-cols-[178px,1fr] items-start gap-4 mb-6">
							<label className="text-sm font-normal text-[#555555] pt-2">{t('masaBerlaku')}*</label>
							<div>
								<div className="flex items-start gap-3">
									<div>
										<DatetimePicker
											datetimeValue={startDate}
											onApply={(date) => {
												handleDateChange('start', date);
											}}
											placeholder="DD/MMM/YYYY HH:mm"
											disabled={mode === 'edit' && promoStatus === 'Aktif'}
											status={errors.startDate ? "error" : null}
											className="w-[160px]"
											minDate={mode === 'edit' ? initialData?.startDate : getNowTimezone()}
										/>
										{errors.startDate && (
											<div className="mt-2 text-[#F22C25] text-xs w-[160px]">
												{errors.startDate}
											</div>
										)}
									</div>
									<span className="text-sm font-medium text-[var(--neutral-900)] mt-2">s/d</span>
									<div>
										<DatetimePicker
											datetimeValue={endDate}
											onApply={(date) => {
												handleDateChange('end', date);
											}}
											placeholder="DD/MMM/YYYY HH:mm"
											status={errors.endDate ? "error" : null}
											className="w-[160px]"
											maxDate={mode === 'edit' ? initialData?.endDate : undefined}
										/>
										{errors.endDate && (
											<div className="mt-2 text-[#F22C25] text-xs w-[160px]">
												{errors.endDate}
											</div>
										)}
									</div>
								</div>
							</div>
						</div>

						{/* Purchase Limit and Status - Adjusted grid layout */}
						<div className={`grid grid-cols-[178px,1fr] items-start gap-4`}>
							<label className="text-sm text-gray-600">{t('jenisBatasPembelian')}*</label>
							<div className="space-y-6">
								{/* Purchase Limit Radio Options */}
								<div className="flex gap-6">
									{[
										{
											value: "no_limit",
											label: t('tanpaBatas'),
											desc: t('jumlahPemakaianPromosiTidakDibatasi')
										},
										{
											value: "limit_per_user",
											label: t('pembatasanPerPembeli'),
											desc: t('jumlahPembeliandibatasi')
										},
										{
											value: "limit_per_invoice",
											label: t('pembatasanPernota'),
											desc: t('jumlahNotaPembelianDibatasi')
										}
									].map(option => (
										<label key={option.value} className="flex flex-col gap-1">
											<div className="flex items-center gap-2">
												<input
													type="radio"
													name="purchaseLimit"
													value={option.value}
													checked={purchaseLimit === option.value}
													onChange={e => {
														setPurchaseLimit(e.target.value);
														setHasChanges(true);
													}}
													className="w-4 h-4 text-blue-600"
												/>
												<span className="text-sm font-medium">{option.label}</span>
											</div>
											<p className="text-xs text-gray-500 ml-6">{option.desc}</p>
										</label>
									))}
								</div>
							</div>
						</div>

						{/* Status - Moved to its own grid row */}
						{mode === 'edit' && promoStatus && (
							<div className="grid grid-cols-[178px,1fr] items-center gap-4">
								<label className="text-sm text-gray-600">{t('labelStatus')}</label>
								<PromoStatusBadge status={promoStatus} />
							</div>
						)}
					</div>
				</div>

				{/* Products Section */}
				<div className="bg-white rounded-xl shadow-sm px-8 py-8">
					<h2 className="text-lg font-bold mb-6">{t('daftarProdukPromosi')}</h2>
					{selectedProducts.length === 0 ? (
						<div className="flex flex-col items-center py-5 bg-gray-50 rounded-xl border border-gray-200">
							<ImageComponent
								src="/promo/no_data_product.png"
								alt=""
								className="mb-3 w-[93px] h-[74px]"
							/>
							<p className="text-gray-500 font-[600]">{t('kamuBelumMemilihProdukUntukPromoIni')}</p>
							<p className="text-xs text-gray-500 my-3">{t('pilihProdukmuTerlebihDahulu')}</p>
							<Button
								type="button" // Explicitly set type to button
								color="primary"
								onClick={() => setShowProductModal(true)}
							>
								{t('pilihProduk')}
							</Button>
						</div>
					) : (
						<ProductTable
							products={selectedProducts}
							onProductUpdate={handleProductUpdate}
							purchaseLimitType={purchaseLimit}
							errors={errors}
							onAddClick={handleAddProductClick}
							maxDiscount={maxDiscount} // Add this prop
							mode={mode}
						/>
					)}
				</div>
				{/* </form> */}
			</div>

			{/* Fixed Footer */}
			{/*24. THP 2 - MOD001 - MP - 022 - QC Plan - Web - MuatParts - Promo LB - 0112 */}
			<div className={`fixed bottom-0 right-0 ${hasClass ? `left-[184px] pl-[120px]` : `left-[32px] pl-[72px]`
				} bg-white border-t px-6 py-4 flex justify-between items-center`}>
				<div className="text-sm font-bold">{selectedProducts.length > 0 && (<>{t('labelTotal')} {t('labelProduk')} : {selectedProducts.length}</>)}</div>
				<Button
					color="primary"
					onClick={handleSubmit}
					disabled={isLoading}
				>
					{t('labelSimpan')}
				</Button>
			</div>

			{/* Modals */}
			{(showProductModal || showAddProductModal) && (
				<PromoProductPopup
					isOpen={showProductModal || showAddProductModal}
					onClose={() => {
						setShowProductModal(false);
						setShowAddProductModal(false);
					}}
					onSave={products => {
						const transformedProducts = products.map(product => ({
							...product,
							quota: 0,
							promoPrice: [0],
							discount: 0,
							purchaseLimit: 0,
							variants: product.variants?.map(variant => ({
								...variant,
								isActive: true,
								quota: 0,
								promoPrice: [0],
								discount: 0,
								purchaseLimit: 0
							}))
						}));

						if (showAddProductModal) {
							// Filter out products that are already in the list
							const newProducts = transformedProducts.filter(
								newProduct => !selectedProducts.some(
									existingProduct => existingProduct.id === newProduct.id
								)
							);
							// Only append new products
							setSelectedProducts(prev => [...newProducts, ...prev]);
						} else {
							// Replace all products
							setSelectedProducts(transformedProducts);
						}

						setShowProductModal(false);
						setShowAddProductModal(false);
						setHasChanges(true);
					}}
					selectedProducts={selectedProducts}
					startDate={startDate}
					endDate={endDate}
					maxSelectedProducts={maxSelectedProducts}
				/>
			)}

			{/* Back Confirmation Modal */}
			<Modal
				isOpen={showBackConfirm}
				setIsOpen={setShowBackConfirm}
			>
				<div className="flex flex-col items-center justify-center text-center">
					<p className="text-base font-medium mb-6">{t('konfirmasiPindahHalaman')}</p>
					<div className="flex gap-3 w-full justify-center">
						<Button
							color="primary_secondary"
							onClick={() => setShowBackConfirm(false)}
							Class="flex-1"
						>
							{t('labelBatal')}
						</Button>
						<Button
							color="primary"
							onClick={() => router.push(clickedBreadcrumbPath)}
							Class="flex-1"
						>
							{t('labelYa')}
						</Button>
					</div>
				</div>
			</Modal>

			{/* Save Confirmation Modal */}
			<Modal
				isOpen={showSaveConfirm}
				setIsOpen={setShowSaveConfirm}
			>
				<div className="flex flex-col items-center justify-center text-center">
					<p className="text-base font-medium mb-6">{t('konfirmasiSimpanPromo')}</p>
					<div className="flex gap-3 w-full justify-center">
						<Button
							color="primary_secondary"
							onClick={() => setShowSaveConfirm(false)}
							Class="flex-1"
						>
							{t('labelBatal')}
						</Button>
						<Button
							color="primary"
							onClick={savePromotion}
							Class="flex-1"
						>
							{t('labelYa')}
						</Button>
					</div>
				</div>
			</Modal>

			{/* Overlapping Products Modal */}
			<Modal
				isOpen={showOverlappingProductsModal}
				setIsOpen={setShowOverlappingProductsModal}
				headerColor="red"
				closeArea={false}
			>
				<div className="flex flex-col items-center justify-center text-center">
					<h2 className="text-lg font-bold mb-4">{t('cekProdukKamu')}</h2>
					<p className="text-sm mb-6">
						{t('terdapatProdukDenganPeriodePromoSama')}
					</p>
					<div className="w-full bg-gray-50 rounded border border-gray-200 p-2 mb-6 max-h-[160px] overflow-y-auto">
						{invalidProducts.map((product) => (
							<div key={product.id} className="py-2 px-2 border-b border-gray-200 last:border-b-0 text-left text-sm truncate">
								{product.name}
							</div>
						))}
					</div>
					<Button
						color="primary"
						onClick={handleOverlappingProductsUnderstand}
					>
						{t('labelMengerti')}
					</Button>
				</div>
			</Modal>

			<Modal
				isOpen={showDataChangeModal}
				setIsOpen={setShowDataChangeModal}
				headerColor="red"
			>
				<div className="flex flex-col items-center justify-center text-center">
					<p className="text-[14px] font-medium">{t('terdapatPerubahanData')}</p>
				</div>
			</Modal>

			<Toast />
		</div>
	);
}





