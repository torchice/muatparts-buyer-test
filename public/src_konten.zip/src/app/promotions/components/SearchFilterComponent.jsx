import ImageComponent from '@/components/ImageComponent/ImageComponent'
import React, { useState, useEffect, useRef } from 'react';
import { X } from 'react-icons/fa';
import { format } from 'date-fns';
import DatetimePicker from '@/components/DatetimePicker/DatetimePicker';

const SearchFilterComponent = ({
  onSearch,
  onFilter,
  filterConfig = {
    showStatus: true,
    showPeriod: true
  },
  placeholder = "Cari Nama Promosi"
}) => {
  // Search state
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  
  // Filter state
  const [showFilterDropdown, setShowFilterDropdown] = useState(false);
  const [selectedFilters, setSelectedFilters] = useState([]);
  const [periodRange, setPeriodRange] = useState({ start: null, end: null });
  const [statusFilters, setStatusFilters] = useState({
    active: false,
    upcoming: false
  });

  // Refs for handling outside clicks
  const filterRef = useRef(null);
  const periodPopupRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (filterRef.current && !filterRef.current.contains(event.target)) {
        setShowFilterDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSearch = (e) => {
    if (e.key === 'Enter' && searchQuery.trim()) {
      onSearch(searchQuery);
    }
  };

  const clearSearch = () => {
    setSearchQuery('');
    onSearch('');
  };

  const handleFilterSelect = (filterType, value) => {
    let newFilters = [...selectedFilters];

    if (filterType === 'status') {
      const statusText = value === 'active' ? 'Aktif' : 'Akan Datang';
      const filterIndex = newFilters.findIndex(f => f.type === 'status' && f.value === value);

      if (filterIndex === -1) {
        newFilters.push({ type: 'status', value, label: `Status: ${statusText}` });
      } else {
        newFilters.splice(filterIndex, 1);
      }

      setStatusFilters(prev => ({
        ...prev,
        [value]: !prev[value]
      }));
    }

    if (filterType === 'period' && periodRange.start && periodRange.end) {
      const periodFilter = {
        type: 'period',
        value: { start: periodRange.start, end: periodRange.end },
        label: `Periode: ${format(periodRange.start, 'dd/MM/yyyy')} - ${format(periodRange.end, 'dd/MM/yyyy')}`
      };

      const existingPeriodIndex = newFilters.findIndex(f => f.type === 'period');
      if (existingPeriodIndex !== -1) {
        newFilters[existingPeriodIndex] = periodFilter;
      } else {
        newFilters.push(periodFilter);
      }
    }

    setSelectedFilters(newFilters);
    onFilter(newFilters);
    setShowFilterDropdown(false);
  };

  const removeFilter = (filterToRemove) => {
    const newFilters = selectedFilters.filter(f => 
      !(f.type === filterToRemove.type && f.value === filterToRemove.value)
    );
    
    if (filterToRemove.type === 'status') {
      setStatusFilters(prev => ({
        ...prev,
        [filterToRemove.value]: false
      }));
    }

    if (filterToRemove.type === 'period') {
      setPeriodRange({ start: null, end: null });
    }

    setSelectedFilters(newFilters);
    onFilter(newFilters);
  };

  const clearAllFilters = () => {
    setSelectedFilters([]);
    setStatusFilters({ active: false, upcoming: false });
    setPeriodRange({ start: null, end: null });
    onFilter([]);
  };

  return (
    <div className="flex flex-col gap-4">
      {/* Search and Filter Bar */}
      <div className="flex gap-3">
        {/* Search Input */}
        <div className="relative flex-1 max-w-md">
          <input
            type="text"
            placeholder={placeholder}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyPress={handleSearch}
            onFocus={() => setIsSearchFocused(true)}
            onBlur={() => setIsSearchFocused(false)}
            className={`
              w-full pl-10 pr-4 py-2 border rounded-lg text-sm text-[var(--neutral-900)]
              placeholder:text-[var(--neutral-500)]
              ${isSearchFocused ? 'border-[var(--primary-500)] ring-2 ring-[var(--primary-100)]' : 'border-[var(--neutral-300)]'}
            `}
          />
          <ImageComponent src="/promo/search.svg"
            alt="search"
            className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" 
          />
          {searchQuery && (
            <button
              onClick={clearSearch}
              className="absolute right-3 top-1/2 -translate-y-1/2"
            >
              <ImageComponent src="/promo/close.svg"
                alt="clear"
                className="w-4 h-4" 
              />
            </button>
          )}
        </div>

        {/* Filter Button */}
        <div className="relative" ref={filterRef}>
          <button
            onClick={() => setShowFilterDropdown(!showFilterDropdown)}
            className={`
              px-4 py-2 border rounded-lg flex items-center gap-2 text-sm
              ${showFilterDropdown 
                ? 'border-[var(--primary-500)] text-[var(--primary-500)]' 
                : 'border-[var(--neutral-300)] text-[var(--neutral-700)]'
              }
              hover:bg-[var(--neutral-50)]
            `}
          >
            <ImageComponent src="/promo/filter.svg"
              alt="filter"
              className="w-4 h-4" 
            />
            Filter
          </button>

          {/* Filter Dropdown */}
          {showFilterDropdown && (
            <div className="absolute top-full right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-[var(--neutral-200)] z-20">
              {filterConfig.showStatus && (
                <div className="p-4 border-b border-[var(--neutral-200)]">
                  <h3 className="text-sm font-semibold mb-2">Status Promo</h3>
                  <div className="space-y-2">
                    <label className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={statusFilters.active}
                        onChange={() => handleFilterSelect('status', 'active')}
                        className="rounded text-[var(--primary-500)]"
                      />
                      <span className="text-sm">Aktif</span>
                    </label>
                    <label className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={statusFilters.upcoming}
                        onChange={() => handleFilterSelect('status', 'upcoming')}
                        className="rounded text-[var(--primary-500)]"
                      />
                      <span className="text-sm">Akan Datang</span>
                    </label>
                  </div>
                </div>
              )}

              {filterConfig.showPeriod && (
                <button
                  onClick={() => {
                    // Show period picker popup
                  }}
                  className="w-full px-4 py-3 text-left text-sm hover:bg-[var(--neutral-50)]"
                >
                  Periode Promo
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Active Filters */}
      {selectedFilters.length > 0 && (
        <div className="flex items-center gap-2 overflow-x-auto py-1">
          <button
            onClick={clearAllFilters}
            className="text-sm text-[var(--primary-500)] whitespace-nowrap"
          >
            Hapus Semua Filter
          </button>

          {selectedFilters.map((filter, index) => (
            <div
              key={`${filter.type}-${index}`}
              className="flex items-center gap-1 px-3 py-1 bg-[var(--primary-50)] text-[var(--primary-500)] rounded-full text-sm whitespace-nowrap"
            >
              <span>{filter.label}</span>
              <button onClick={() => removeFilter(filter)}>
                <X className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default SearchFilterComponent;





