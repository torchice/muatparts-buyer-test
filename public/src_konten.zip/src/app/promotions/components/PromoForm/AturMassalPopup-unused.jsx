import ImageComponent from '@/components/ImageComponent/ImageComponent'
// src/components/PromoForm/AturMassalPopup.jsx
import React, { useState, useEffect } from 'react';
import Input from '@/components/Input/Input';

const formatNumber = (value) => {
  if (!value) return '';
  // Remove non-numeric characters and format with thousand separator
  return value.toString().replace(/\D/g, '')
    .replace(/\B(?=(\d{3})+(?!\d))/g, '.');
};

const AturMassalPopup = ({
  isOpen,
  onClose,
  onApply,
  products,
  isLimitedPurchase = false,
  maxDiscount = 60
}) => {
  const [selectedProducts, setSelectedProducts] = useState(new Set());
  const [allSelected, setAllSelected] = useState(false);
  const [formValues, setFormValues] = useState({
    quota: '',
    purchaseLimit: '',
    promoPrice: '',
    discount: ''
  });
  const [errors, setErrors] = useState({});
  const [disabledFields, setDisabledFields] = useState({
    promoPrice: false,
    discount: false
  });

  useEffect(() => {
    if (isOpen) {
      resetForm();
    }
  }, [isOpen]);

  const resetForm = () => {
    setSelectedProducts(new Set());
    setAllSelected(false);
    setFormValues({
      quota: '',
      purchaseLimit: '',
      promoPrice: '',
      discount: ''
    });
    setErrors({});
    setDisabledFields({
      promoPrice: false,
      discount: false
    });
  };

  const handleSelectAll = (checked) => {
    setAllSelected(checked);
    setSelectedProducts(new Set(checked ? products.map(p => p.id) : []));
  };

  const handleProductSelect = (id) => {
    const newSelected = new Set(selectedProducts);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedProducts(newSelected);
    setAllSelected(newSelected.size === products.length);
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formValues.quota || parseInt(formValues.quota.replace(/\D/g, '')) < 1) {
      newErrors.quota = 'Min. 1';
    }

    if (isLimitedPurchase && (!formValues.purchaseLimit || parseInt(formValues.purchaseLimit.replace(/\D/g, '')) < 1)) {
      newErrors.purchaseLimit = 'Min. 1';
    }

    if (formValues.promoPrice && parseInt(formValues.promoPrice.replace(/\D/g, '')) < 1000) {
      newErrors.promoPrice = 'Min. Rp1.000';
    }

    if (formValues.discount) {
      const discountNum = parseInt(formValues.discount);
      if (discountNum < 1) {
        newErrors.discount = 'Min. 1%';
      } else if (discountNum > maxDiscount) {
        newErrors.discount = `Maks. ${maxDiscount}%`;
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleApply = () => {
    if (!selectedProducts.size) {
      setErrors(prev => ({ ...prev, selection: 'Pilih minimal 1 produk' }));
      return;
    }

    if (!validateForm()) return;

    const data = {
      productIds: Array.from(selectedProducts),
      quota: parseInt(formValues.quota.replace(/\D/g, '')),
      purchaseLimit: isLimitedPurchase ? parseInt(formValues.purchaseLimit.replace(/\D/g, '')) : undefined,
      promoPrice: formValues.promoPrice ? parseInt(formValues.promoPrice.replace(/\D/g, '')) : undefined,
      discount: formValues.discount ? parseInt(formValues.discount) : undefined
    };

    onApply(data);
  };

  const handleInputChange = (field, value) => {
    let formattedValue = value;

    if (['quota', 'purchaseLimit', 'promoPrice'].includes(field)) {
      formattedValue = formatNumber(value);
    }

    if (field === 'promoPrice' && value) {
      setDisabledFields(prev => ({ ...prev, discount: true }));
    } else if (field === 'discount' && value) {
      setDisabledFields(prev => ({ ...prev, promoPrice: true }));
    } else if (!value) {
      setDisabledFields({
        promoPrice: false,
        discount: false
      });
    }

    setFormValues(prev => ({
      ...prev,
      [field]: formattedValue
    }));
  };

  return (
    <div className={`fixed inset-0 z-50 ${isOpen ? 'flex' : 'hidden'} items-center justify-center`}>
      <div className="absolute inset-0 bg-black bg-opacity-50" onClick={onClose} />

      <div className="relative bg-white rounded-xl max-w-[800px] w-full mx-6 my-6">
        {/* Header */}
        <div className="flex justify-between items-center p-6 border-b border-[#D9D9D9]">
          <div className="flex-1" /> {/* Left spacer */}
          <h2 className="flex-1 text-base font-bold text-center">Atur Massall</h2>
          <div className="flex-1 flex justify-end">
            <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full">
              <ImageComponent src="/components/close_popup.svg" alt="close" className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Form Section */}
        <div className="p-3">
          <div className="bg-[#F8FBFF] rounded-xl p-3">
            <div className="grid grid-cols-12 gap-3">
              {/* Kuota Promosi */}
              <div className="col-span-4">
                <label className="flex items-center gap-1 text-xs font-bold text-[#555555] mb-1">
                  Kuota Promosi*
                  <ImageComponent src="/components/info.svg" alt="info" className="w-4 h-4" />
                </label>
                <Input
                  type="text"
                  placeholder="Contoh: 1"
                  value={formValues.quota}
                  changeEvent={(e) => handleInputChange('quota', e.target.value)}
                  status={errors.quota ? 'error' : null}
                  supportiveText={{ title: errors.quota || '' }}
                  width={{ width: "100%" }}
                  classInput="h-8"
                />
              </div>

              {/* Harga setelah Diskon */}
              <div className="col-span-6">
                <label className="text-xs font-bold text-[#555555] mb-1">
                  Harga setelah Diskon
                </label>
                <Input
                  type="text"
                  placeholder="Contoh: 1.000.000"
                  value={formValues.promoPrice}
                  changeEvent={(e) => handleInputChange('promoPrice', e.target.value)}
                  disabled={disabledFields.promoPrice}
                  status={errors.promoPrice ? 'error' : null}
                  supportiveText={{ title: errors.promoPrice || '' }}
                  text={{ left: "Rp" }}
                  width={{ width: "100%" }}
                  classInput="h-8"
                />
              </div>

              {/* Diskon */}
              <div className="col-span-2 flex flex-col justify-end">
                <div className="text-xs text-center mb-2">atau</div>
                <Input
                  type="text"
                  placeholder="0"
                  value={formValues.discount}
                  changeEvent={(e) => handleInputChange('discount', e.target.value)}
                  disabled={disabledFields.discount}
                  status={errors.discount ? 'error' : null}
                  supportiveText={{ title: errors.discount || '' }}
                  text={{ right: "%" }}
                  width={{ width: "100%" }}
                  classInput="h-8"
                />
              </div>
            </div>
          </div>

          {/* Product Table */}
          <div className="mt-3 border border-[#D9D9D9] rounded-xl">
            <div className="flex items-center px-6 py-3 bg-white border-b border-[#D9D9D9]">
              <input
                type="checkbox"
                checked={allSelected}
                onChange={(e) => handleSelectAll(e.target.checked)}
                className="w-4 h-4 rounded border-[#7B7B7B]"
              />
              <div className="ml-5 text-xs font-bold text-[#555555] flex-1">
                <div className="flex items-center gap-2">
                  Produk
                  <ImageComponent src="/components/sorting.svg" alt="sort" className="w-3 h-3" />
                </div>
              </div>
              <div className="w-44 text-xs font-bold text-[#555555]">
                <div className="flex items-center gap-2">
                  Harga
                  <ImageComponent src="/components/sorting.svg" alt="sort" className="w-3 h-3" />
                </div>
              </div>
              <div className="w-24 text-xs font-bold text-[#555555]">
                <div className="flex items-center gap-2">
                  Stok
                  <ImageComponent src="/components/sorting.svg" alt="sort" className="w-3 h-3" />
                </div>
              </div>
            </div>

            <div className="max-h-[calc(100vh-440px)] overflow-y-auto">
              {products.map((product) => (
                <div key={product.id} className="flex items-center px-6 py-3 border-b border-[#D9D9D9] hover:bg-gray-50">
                  <input
                    type="checkbox"
                    checked={selectedProducts.has(product.id)}
                    onChange={() => handleProductSelect(product.id)}
                    className="w-4 h-4 rounded border-[#7B7B7B]"
                  />
                  <div className="ml-5 flex gap-5 flex-1">
                    <ImageComponent src={product.imageUrl || "/api/placeholder/56/56"}
                      alt={product.name}
                      className="w-14 h-14 rounded object-cover"
                    />
                    <div>
                      <div className="text-xs font-bold text-[#171717] line-clamp-2">{product.name}</div>
                      <div className="text-xs text-[#555555] mt-3">SKU: {product.sku || '-'}</div>
                      <div className="text-xs text-[#555555]">Brand: {product.brand?.name || '-'}</div>
                    </div>
                  </div>
                  <div className="w-44 text-xs text-[#171717]">
                    {Array.isArray(product.price) && product.price.length > 1
                      ? `Rp${formatNumber(product.price[0])} - Rp${formatNumber(product.price[1])}`
                      : `Rp${formatNumber(product.price[0])}`}
                  </div>
                  <div className="w-24 text-xs text-[#171717]">{formatNumber(product.stock)}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex justify-between items-center p-6 border-t border-[#D9D9D9]">
          <div className="text-xs font-bold text-[#171717]">
            Atur Massal: {selectedProducts.size}/{products.length} produk
          </div>
          <div className="relative">
            <button
              onClick={handleApply}
              disabled={selectedProducts.size === 0}
              className={`px-6 py-2 rounded-full text-sm font-semibold ${selectedProducts.size === 0
                  ? 'bg-[#F5F5F5] text-[#7B7B7B] cursor-not-allowed'
                  : 'bg-[#176CF7] text-white hover:bg-[#1257C6]'
                }`}
            >
              Terapkan
            </button>
            {errors.selection && (
              <div className="absolute right-0 bottom-full mb-2 bg-[#171717] text-white text-xs rounded px-2 py-1">
                {errors.selection}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AturMassalPopup;





