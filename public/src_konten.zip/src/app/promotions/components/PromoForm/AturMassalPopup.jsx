import React, { useState, useEffect } from 'react';
import { Input } from '@/components/Input/Input';
import { Alert, AlertDescription } from '@/components/ui/alert';

const formatNumber = (number) => {
  return new Intl.NumberFormat('id-ID').format(number);
};

const formatCurrency = (number) => {
  return `Rp${formatNumber(number)}`;
};

const AturMassalPopup = ({
  isOpen,
  onClose,
  onApply,
  products,
  isLimitedPurchase = false,
  maxDiscount = 60
}) => {
  const [selectedProducts, setSelectedProducts] = useState(new Set());
  const [allSelected, setAllSelected] = useState(false);
  const [quota, setQuota] = useState('');
  const [purchaseLimit, setPurchaseLimit] = useState('');
  const [discountedPrice, setDiscountedPrice] = useState('');
  const [discount, setDiscount] = useState('');
  const [errors, setErrors] = useState({});
  const [showTooltip, setShowTooltip] = useState('');

  useEffect(() => {
    if (isOpen) {
      resetForm();
    }
  }, [isOpen]);

  const resetForm = () => {
    setSelectedProducts(new Set());
    setAllSelected(false);
    setQuota('');
    setPurchaseLimit('');
    setDiscountedPrice('');
    setDiscount('');
    setErrors({});
  };

  const handleSelectAll = (checked) => {
    setAllSelected(checked);
    if (checked) {
      setSelectedProducts(new Set(products.map(p => p.id)));
    } else {
      setSelectedProducts(new Set());
    }
  };

  const handleProductSelect = (id, checked) => {
    const newSelected = new Set(selectedProducts);
    if (checked) {
      newSelected.add(id);
    } else {
      newSelected.delete(id);
    }
    setSelectedProducts(newSelected);
    setAllSelected(newSelected.size === products.length);
  };

  const validateInputs = () => {
    const newErrors = {};

    if (!quota || parseInt(quota) < 1) {
      newErrors.quota = 'Min. 1';
    }

    if (isLimitedPurchase && (!purchaseLimit || parseInt(purchaseLimit) < 1)) {
      newErrors.purchaseLimit = 'Min. 1';
    }

    if (discountedPrice) {
      const priceNum = parseInt(discountedPrice.replace(/\D/g, ''));
      if (priceNum < 1000) {
        newErrors.discountedPrice = 'Min. Rp1.000';
      }
    }

    if (discount) {
      const discountNum = parseInt(discount);
      if (discountNum < 1) {
        newErrors.discount = 'Min. 1%';
      } else if (discountNum > maxDiscount) {
        newErrors.discount = `Maks. ${maxDiscount}%`;
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleApply = () => {
    if (!selectedProducts.size) {
      setShowTooltip('Pilih minimal 1 produk');
      return;
    }

    if (!validateInputs()) {
      return;
    }

    const data = {
      productIds: Array.from(selectedProducts),
      quota: parseInt(quota),
      purchaseLimit: isLimitedPurchase ? parseInt(purchaseLimit) : undefined,
      discountedPrice: discountedPrice ? parseInt(discountedPrice.replace(/\D/g, '')) : undefined,
      discount: discount ? parseInt(discount) : undefined
    };

    onApply(data);
    onClose();
  };

  const handleDiscountedPriceChange = (value) => {
    setDiscountedPrice(value);
    setDiscount(''); // Clear discount when discounted price changes
  };

  const handleDiscountChange = (value) => {
    setDiscount(value);
    setDiscountedPrice(''); // Clear discounted price when discount changes
  };

  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center ${isOpen ? '' : 'hidden'}`}>
      <div className="absolute inset-0 bg-black bg-opacity-50" onClick={onClose} />
      
      <div className="relative w-full max-w-4xl mx-4 bg-white rounded-xl shadow-sm">
        {/* Header */}
        <div className="p-6 border-b">
          <h2 className="text-base font-bold">Atur Massal</h2>
        </div>

        {/* Main Content */}
        <div className="p-6">
          {/* Input Fields Section */}
          <div className="p-4 bg-sky-50 rounded-xl">
            <div className="flex flex-wrap gap-4">
              <div className="w-32">
                <div className="flex items-center gap-1 mb-1">
                  <label className="text-xs font-bold text-neutral-500">Kuota Promosi*</label>
                  <img 
                    src="https://cdn.builder.io/api/v1/image/assets/TEMP/52c1bcd192f547c561a84cea44e64a85782cffb447b4a4c341042aee138141db"
                    alt=""
                    className="w-4 h-4"
                  />
                </div>
                <Input
                  type="number"
                  placeholder="Contoh: 1"
                  value={quota}
                  onChange={(e) => setQuota(e.target.value)}
                  className={errors.quota ? 'border-red-500' : ''}
                />
                {errors.quota && (
                  <span className="text-xs text-red-500 mt-1">{errors.quota}</span>
                )}
              </div>

              {isLimitedPurchase && (
                <div className="w-32">
                  <div className="flex items-center gap-1 mb-1">
                    <label className="text-xs font-bold text-neutral-500">Batas Pembelian*</label>
                    <img 
                      src="https://cdn.builder.io/api/v1/image/assets/TEMP/658e5aa2e18884f9b76b05c05179d93d22cf065294efd4c861ad58ba32476f24"
                      alt=""
                      className="w-4 h-4"
                    />
                  </div>
                  <Input
                    type="number"
                    placeholder="Contoh: 1"
                    value={purchaseLimit}
                    onChange={(e) => setPurchaseLimit(e.target.value)}
                    className={errors.purchaseLimit ? 'border-red-500' : ''}
                  />
                  {errors.purchaseLimit && (
                    <span className="text-xs text-red-500 mt-1">{errors.purchaseLimit}</span>
                  )}
                </div>
              )}

              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-neutral-500">Harga setelah Diskon</label>
                  <label className="text-xs font-bold text-neutral-500">Diskon</label>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex-1">
                    <div className="flex">
                      <span className="px-3 py-2 bg-white border border-r-0 border-blue-600 rounded-l-md">
                        Rp
                      </span>
                      <Input
                        placeholder="Contoh: 1.000.000"
                        value={discountedPrice}
                        onChange={(e) => handleDiscountedPriceChange(e.target.value)}
                        className={`rounded-l-none ${errors.discountedPrice ? 'border-red-500' : ''}`}
                        disabled={!!discount}
                      />
                    </div>
                    {errors.discountedPrice && (
                      <span className="text-xs text-red-500 mt-1">{errors.discountedPrice}</span>
                    )}
                  </div>
                  <span className="text-xs">atau</span>
                  <div className="w-32">
                    <div className="flex">
                      <Input
                        type="number"
                        placeholder="0"
                        value={discount}
                        onChange={(e) => handleDiscountChange(e.target.value)}
                        className={`rounded-r-none ${errors.discount ? 'border-red-500' : ''}`}
                        disabled={!!discountedPrice}
                      />
                      <span className="px-3 py-2 bg-white border border-l-0 border-blue-600 rounded-r-md">
                        %
                      </span>
                    </div>
                    {errors.discount && (
                      <span className="text-xs text-red-500 mt-1">{errors.discount}</span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Product Table */}
          <div className="mt-4 border rounded-xl">
            {/* Table Header */}
            <div className="flex items-center p-4 bg-white border-b">
              <div className="w-4">
                <input
                  type="checkbox"
                  checked={allSelected}
                  onChange={(e) => handleSelectAll(e.target.checked)}
                  className="w-4 h-4 rounded border-neutral-500"
                />
              </div>
              <div className="w-14" />
              <div className="flex-1 font-bold text-xs text-neutral-500">Produk</div>
              <div className="w-44 font-bold text-xs text-neutral-500">Harga</div>
              <div className="w-24 font-bold text-xs text-neutral-500">Stok</div>
            </div>

            {/* Table Body */}
            <div className="max-h-[400px] overflow-y-auto">
              {products.map((product) => (
                <div key={product.id} className="flex items-center p-4 border-b">
                  <div className="w-4">
                    <input
                      type="checkbox"
                      checked={selectedProducts.has(product.id)}
                      onChange={(e) => handleProductSelect(product.id, e.target.checked)}
                      className="w-4 h-4 rounded border-neutral-500"
                    />
                  </div>
                  <div className="w-14">
                    <img
                      src={product.imageUrl || "/api/placeholder/56/56"}
                      alt={product.name}
                      className="w-14 h-14 rounded object-cover"
                    />
                  </div>
                  <div className="flex-1 ml-4">
                    <div className="font-bold text-xs line-clamp-2">{product.name}</div>
                    {product.sku && (
                      <div className="text-xs mt-1">SKU: {product.sku}</div>
                    )}
                    {product.brand?.name && (
                      <div className="text-xs mt-1">Brand: {product.brand.name}</div>
                    )}
                  </div>
                  <div className="w-44 text-xs">
                    {Array.isArray(product.price) && product.price.length > 1
                      ? `${formatCurrency(product.price[0])} - ${formatCurrency(product.price[1])}`
                      : formatCurrency(product.price[0])}
                  </div>
                  <div className="w-24 text-xs">{formatNumber(product.stock)}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex justify-between items-center p-6 border-t">
          <div className="text-xs font-bold">
            Atur Massal: {selectedProducts.size}/{products.length} produk
          </div>
          <div className="relative">
            <button
              onClick={handleApply}
              disabled={selectedProducts.size === 0}
              className={`px-6 py-2 rounded-full text-sm font-semibold ${
                selectedProducts.size > 0
                  ? 'bg-blue-600 text-white hover:bg-blue-700'
                  : 'bg-gray-100 text-gray-500 cursor-not-allowed'
              }`}
            >
              Terapkan
            </button>
            {showTooltip && selectedProducts.size === 0 && (
              <div className="absolute bottom-full mb-2 right-0 bg-gray-900 text-white text-xs rounded px-2 py-1">
                {showTooltip}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AturMassalPopup;