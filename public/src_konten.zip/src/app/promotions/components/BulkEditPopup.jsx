import ImageComponent from '@/components/ImageComponent/ImageComponent'
import React, { useState, useEffect } from 'react';
import Input from '@/components/Input/Input';
import { formatCurrency, parseCurrency } from '@/components/PromoCreate/CurrencyUtils';

const BulkEditPopup = ({
  isOpen,
  onClose,
  products,
  purchaseLimitType = 'unlimited',
  onApply
}) => {
  const [selectedProducts, setSelectedProducts] = useState([]);
  // Form state
  const [quota, setQuota] = useState('');
  const [promoPrice, setPromoPrice] = useState('');
  const [discount, setDiscount] = useState('');
  const [purchaseLimit, setPurchaseLimit] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  // Validation state
  const [errors, setErrors] = useState({
    quota: '',
    promoPrice: '',
    discount: '',
    purchaseLimit: ''
  });

  // Sort config
  const [sortConfig, setSortConfig] = useState({ key: null, direction: 'ascending' });

  const handleQuotaChange = (e) => {
    const value = e.target.value;
    setQuota(value);
    validateField('quota', value);
  };

  const handlePromoPriceChange = (e) => {
    const value = e.target.value;
    setPromoPrice(value);
    
    // Calculate and set discount
    if (value) {
      const priceValue = parseCurrency(value);
      const originalPrice = 100000; // Example - should come from product
      const discountPercent = ((originalPrice - priceValue) / originalPrice) * 100;
      setDiscount(discountPercent.toFixed(0));
    }
    
    validateField('promoPrice', value);
  };

  const handleDiscountChange = (e) => {
    const value = e.target.value;
    setDiscount(value);
    
    // Calculate and set promo price
    if (value) {
      const originalPrice = 100000; // Example - should come from product
      const discountValue = parseFloat(value);
      const promoPrice = originalPrice - (originalPrice * (discountValue / 100));
      setPromoPrice(formatCurrency(promoPrice));
    }
    
    validateField('discount', value);
  };

  const handlePurchaseLimitChange = (e) => {
    const value = e.target.value;
    setPurchaseLimit(value);
    validateField('purchaseLimit', value);
  };

  const validateField = (field, value) => {
    let error = '';
    
    switch (field) {
      case 'quota':
        if (!value) error = 'Min. 1';
        else if (parseInt(value) > 99999) error = 'Maks. 99999';
        break;
      case 'promoPrice':
        // Add validation based on original price
        break;
      case 'discount':
        if (parseFloat(value) < 1) error = 'Min. 1%';
        else if (parseFloat(value) > 99) error = 'Maks. 99%';
        break;
      case 'purchaseLimit':
        if (!value) error = 'Min. 1';
        else if (parseInt(value) > parseInt(quota)) error = `Maks. ${quota}`;
        break;
    }

    setErrors(prev => ({ ...prev, [field]: error }));
    return !error;
  };

  const handleSort = (key) => {
    let direction = 'ascending';
    if (sortConfig.key === key && sortConfig.direction === 'ascending') {
      direction = 'descending';
    }
    setSortConfig({ key, direction });
  };

  const handleApply = () => {
    // Validate all fields
    const isValid = Object.keys(errors).every(key => !errors[key]);
    
    if (!isValid || selectedProducts.length === 0) return;

    const updates = {
      quota: parseInt(quota),
      promoPrice: parseCurrency(promoPrice),
      discount: parseFloat(discount),
      ...(purchaseLimitType !== 'unlimited' && { purchaseLimit: parseInt(purchaseLimit) })
    };

    onApply(selectedProducts, updates);
    onClose();
  };

  const filteredProducts = products
    .filter(product => 
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.sku.toLowerCase().includes(searchQuery.toLowerCase())
    );

  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center ${isOpen ? '' : 'hidden'}`}>
      <div className="absolute inset-0 bg-black bg-opacity-50" onClick={onClose} />
      
      <div className="relative bg-white rounded-lg w-full max-w-4xl max-h-[90vh] flex flex-col mx-4">
        {/* Header */}
        <div className="px-6 py-4 border-b border-[var(--neutral-200)]">
          <h2 className="text-lg font-bold text-[var(--neutral-900)]">Atur Massal</h2>
        </div>

        {/* Form Fields */}
        <div className="px-6 py-4 border-b border-[var(--neutral-200)]">
          <div className="grid grid-cols-2 gap-6">
            {/* Left Column */}
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-[var(--neutral-900)] mb-2">
                  Kuota Promosi*
                </label>
                <Input
                  type="text"
                  value={quota}
                  changeEvent={handleQuotaChange}
                  placeholder="Contoh: 1"
                  width={{ width: "100%" }}
                  status={errors.quota ? 'error' : null}
                  supportiveText={{ title: errors.quota }}
                />
              </div>

              {purchaseLimitType !== 'unlimited' && (
                <div>
                  <label className="block text-sm font-medium text-[var(--neutral-900)] mb-2">
                    Batas Pembelian*
                  </label>
                  <Input
                    type="text"
                    value={purchaseLimit}
                    changeEvent={handlePurchaseLimitChange}
                    placeholder="Contoh: 1"
                    width={{ width: "100%" }}
                    status={errors.purchaseLimit ? 'error' : null}
                    supportiveText={{ title: errors.purchaseLimit }}
                  />
                </div>
              )}
            </div>

            {/* Right Column */}
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-[var(--neutral-900)] mb-2">
                  Harga Setelah Diskon
                </label>
                <Input
                  type="text"
                  value={promoPrice}
                  changeEvent={handlePromoPriceChange}
                  placeholder="Contoh: 1.000.000"
                  text={{ left: "Rp" }}
                  width={{ width: "100%" }}
                  status={errors.promoPrice ? 'error' : null}
                  supportiveText={{ title: errors.promoPrice }}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-[var(--neutral-900)] mb-2">
                  Diskon
                </label>
                <Input
                  type="text"
                  value={discount}
                  changeEvent={handleDiscountChange}
                  placeholder="Diskon"
                  text={{ right: "%" }}
                  width={{ width: "100%" }}
                  status={errors.discount ? 'error' : null}
                  supportiveText={{ title: errors.discount }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Product Table */}
        <div className="flex-1 overflow-y-auto px-6 py-4">
          <div className="flex justify-between items-center mb-4">
            <div className="relative w-[280px]">
              <Input
                type="text"
                placeholder="Cari Nama Produk/SKU"
                value={searchQuery}
                changeEvent={(e) => setSearchQuery(e.target.value)}
                width={{ width: "100%" }}
                icon={{ left: "search" }}
              />
            </div>
          </div>

          <div className="border border-[var(--neutral-200)] rounded-xl overflow-hidden">
            {/* Table Header */}
            <div className="grid grid-cols-[auto_1fr_1fr_1fr] gap-4 px-6 py-4 bg-[var(--neutral-100)] text-sm font-bold">
              <div className="w-6">
                <input
                  type="checkbox"
                  checked={selectedProducts.length === filteredProducts.length}
                  onChange={(e) => {
                    setSelectedProducts(
                      e.target.checked 
                        ? filteredProducts.map(p => p.id)
                        : []
                    );
                  }}
                  className="rounded text-[var(--primary-500)]"
                />
              </div>
              <div 
                className="cursor-pointer flex items-center gap-1"
                onClick={() => handleSort('name')}
              >
                Produk
                {sortConfig.key === 'name' && (
                  <span className={`transform ${sortConfig.direction === 'descending' ? 'rotate-180' : ''}`}>
                    ▲
                  </span>
                )}
              </div>
              <div 
                className="cursor-pointer flex items-center gap-1"
                onClick={() => handleSort('price')}
              >
                Harga
                {sortConfig.key === 'price' && (
                  <span className={`transform ${sortConfig.direction === 'descending' ? 'rotate-180' : ''}`}>
                    ▲
                  </span>
                )}
              </div>
              <div 
                className="cursor-pointer flex items-center gap-1"
                onClick={() => handleSort('stock')}
              >
                Stok
                {sortConfig.key === 'stock' && (
                  <span className={`transform ${sortConfig.direction === 'descending' ? 'rotate-180' : ''}`}>
                    ▲
                  </span>
                )}
              </div>
            </div>

            {/* Table Body */}
            <div className="divide-y divide-[var(--neutral-200)]">
              {filteredProducts.map((product) => (
                <div 
                  key={product.id}
                  className="grid grid-cols-[auto_1fr_1fr_1fr] gap-4 px-6 py-4 text-sm"
                >
                  <div className="w-6">
                    <input
                      type="checkbox"
                      checked={selectedProducts.includes(product.id)}
                      onChange={(e) => {
                        setSelectedProducts(prev => 
                          e.target.checked
                            ? [...prev, product.id]
                            : prev.filter(id => id !== product.id)
                        );
                      }}
                      className="rounded text-[var(--primary-500)]"
                    />
                  </div>
                  <div className="flex items-center gap-3">
                    <ImageComponent src={product.imageUrl || '/placeholder.png'}
                      alt={product.name}
                      className="w-10 h-10 rounded"
                    />
                    <div>
                      <div className="font-medium line-clamp-2">{product.name}</div>
                      <div className="text-[var(--neutral-500)]">
                        SKU: {product.sku} • Brand: {product.brand}
                      </div>
                    </div>
                  </div>
                  <div>{formatCurrency(product.price)}</div>
                  <div>{product.stock}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-[var(--neutral-200)] flex justify-between items-center">
          <div>
            Terpilih: {selectedProducts.length}/{filteredProducts.length} produk
          </div>
          <div className="flex gap-3">
            <button
              onClick={onClose}
              className="px-6 py-2 border border-[var(--neutral-300)] text-[var(--neutral-700)] rounded-lg hover:bg-[var(--neutral-50)]"
            >
              Batal
            </button>
            <button
              onClick={handleApply}
              disabled={selectedProducts.length === 0}
              className="px-6 py-2 bg-[var(--primary-500)] text-white rounded-lg hover:bg-[var(--primary-600)] disabled:opacity-50"
            >
              Terapkan
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BulkEditPopup;





