import React, { useState, useRef, useEffect } from 'react';

export const ActionDropdown = ({ status, tab, onDetail, onEdit, onDelete, onEnd, onCopy }) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getMenuItems = () => {
    if (tab === 'history') {
      return [
        { label: 'Detail', onClick: onDetail },
        { label: 'Salin', onClick: onCopy }
      ];
    }
    
    if (status === 'active') {
      return [
        { label: 'Detail', onClick: onDetail },
        { label: 'Ubah', onClick: onEdit },
        { label: 'Akhiri', onClick: onEnd }
      ];
    }
    
    return [
      { label: 'Detail', onClick: onDetail },
      { label: 'Ubah', onClick: onEdit },
      { label: 'Hapus', onClick: onDelete }
    ];
  };

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-2 border border-gray-300 rounded-md text-xs hover:bg-gray-50"
      >
        <span>Atur</span>
        <svg
          xmlns="http://www.w3.org/2000/svg"
          className={`h-4 w-4 transition-transform ${isOpen ? 'rotate-180' : ''}`}
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M19 9l-7 7-7-7"
          />
        </svg>
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-1 w-32 bg-white rounded-md shadow-lg border border-gray-200 z-10">
          <div className="py-1">
            {getMenuItems().map((item, index) => (
              <button
                key={item.label}
                onClick={() => {
                  item.onClick();
                  setIsOpen(false);
                }}
                className="w-full text-left px-4 py-2 text-sm hover:bg-gray-50 text-black"
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default ActionDropdown;





