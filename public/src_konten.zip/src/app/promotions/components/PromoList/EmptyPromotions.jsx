import ImageComponent from '@/components/ImageComponent/ImageComponent'
import React from 'react';

export const EmptyPromotions = ({ tab = 'active' }) => {
  return (
    <div className="flex flex-col items-center justify-center py-14 bg-white rounded-xl shadow-sm w-full">
      <div className="w-24 h-24 mb-3">
        <ImageComponent src="/promo/no_data_product.png"
          alt="Empty promotions illustration"
          className="w-full h-full object-contain"
        />
      </div>
      {/* Improvement fix wording pak Bryan */}
      <p className="text-base font-semibold text-neutral-500">
        {tab === 'active' ? 'Belum ada promosi yang aktif' : 'Belum ada riwayat promosi'}
      </p>
      <p className="mt-3 text-xs font-medium text-neutral-500">
        Buat promosimu sekarang!
      </p>
      <button
        onClick={() => { }}
        className="mt-3 px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-3xl transition-colors"
      >
        Buat Promosi
      </button>
    </div>
  );
};

export default EmptyPromotions;





