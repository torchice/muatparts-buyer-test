import ImageComponent from '@/components/ImageComponent/ImageComponent'
import React from 'react';
import { useCustomRouter } from '@/libs/CustomRoute';
import Input from '@/components/Input/Input';
import EmptyPromotions from './EmptyPromotions';
import ActionDropdown from './ActionDropdown';

export const PromoTable = ({ promos = [], isLoading = false, onSearch, onCreate, activeTab}) => {
  const router = useCustomRouter();

  const handleAction = (action, promo) => {
    switch (action) {
      case 'detail':
        router.push(`/promotions/detailpromo/${promo.id}`);
        break;
      case 'edit':
        router.push(`/promotions/editpromo/${promo.id}`);
        break;
      // ... handle other actions if needed ...
    }
  };

  // Show empty state when there are no promotions
  if (!promos || promos.length === 0) {
    return <EmptyPromotions tab={activeTab} />;
  }

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleString('id-ID', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      timeZoneName: 'short'
    });
  };

  const getStatusStyle = (status) => {
    switch(status) {
      case 'active':
        return 'text-emerald-500 bg-green-100';
      case 'upcoming':
        return 'text-orange-500 bg-yellow-100';
      case 'ended':
        return 'text-gray-600 bg-gray-100';
      default:
        return '';
    }
  };

  const getStatusText = (status) => {
    switch(status) {
      case 'active':
        return 'Aktif';
      case 'upcoming':
        return 'Akan Datang';
      case 'ended':
        return 'Berakhir';
      default:
        return '';
    }
  };

  return (
    <div className="flex flex-col w-full bg-white rounded-xl shadow-sm">
      {/* Search and Actions Bar */}
      <div className="flex justify-between items-center p-6 border-b border-gray-200">
        <div className="flex gap-3 flex-1 max-w-md">
          <div className="flex-1">
            <Input
              placeholder="Cari Nama Promosi"
              className="w-full"
              onChange={(e) => {
                if (onSearch) onSearch(e.target.value);
              }}
              icon={{
                left: (
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-4 w-4 text-gray-400"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                    />
                  </svg>
                )
              }}
            />
          </div>
          <button className="flex items-center gap-2 px-3 py-2 border border-gray-300 rounded-md text-sm">
            <span>Filter</span>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-4 w-4"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"
              />
            </svg>
          </button>
        </div>
        <button
          onClick={onCreate}
          className="px-6 py-2 bg-blue-600 text-white rounded-full text-sm font-semibold hover:bg-blue-700 transition-colors"
        >
          Buat Promosi
        </button>
      </div>

      {/* Table Header */}
      <div className="grid grid-cols-12 gap-4 px-6 py-4 bg-white border-y border-gray-200 text-xs font-bold text-black">
        <div className="col-span-3">Nama Promosi</div>
        <div className="col-span-5">Produk Promosi</div>
        <div className="col-span-3">Status dan Periode</div>
        <div className="col-span-1">Aksi</div>
      </div>

      {/* Table Body */}
      {promos.map((promo) => (
        <div key={promo.id} className="grid grid-cols-12 gap-4 px-6 py-4 border-b border-gray-200">
          {/* Nama Promosi */}
          <div className="col-span-3 text-xs font-bold line-clamp-2 text-black">
            {promo.name}
          </div>

          {/* Produk Promosi */}
          <div className="col-span-5">
            <div className="flex gap-3">
              <ImageComponent src={promo.products[0].image}
                alt={promo.products[0].name}
                className="w-8 h-8 object-cover rounded"
              />
              <div className="flex-1">
                <div className="text-xs font-semibold line-clamp-2 text-black">
                  {promo.products[0].name}
                </div>
                <div className="text-xs mt-1 text-black">
                  SKU: {promo.products[0].sku}
                </div>
                <div className="text-xs text-black">
                  Brand: {promo.products[0].brand}
                </div>
                <div className="flex items-center gap-4 mt-2 text-xs">
                  <span className="text-neutral-500">{promo.totalProducts} Produk</span>
                  {promo.totalProducts > 1 && (
                    <button className="text-blue-600 flex items-center gap-1">
                      Lihat Semua Produk
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-4 w-4"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M9 5l7 7-7 7"
                        />
                      </svg>
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Status dan Periode */}
          <div className="col-span-3">
            <span className={`px-3 py-1 rounded-md text-xs font-semibold ${getStatusStyle(promo.status)}`}>
              {getStatusText(promo.status)}
            </span>
            <div className="mt-3 text-xs">
              <div>
                <span className="text-neutral-500">Mulai: </span>
                <span className="text-black">{formatDate(promo.startDate)}</span>
              </div>
              <div className="mt-1">
                <span className="text-neutral-500">Akhir: </span>
                <span className="text-black">{formatDate(promo.endDate)}</span>
              </div>
            </div>
          </div>

          {/* Aksi */}
          <div className="col-span-1">
            <ActionDropdown 
              status={promo.status}
              tab={activeTab}
              onDetail={() => handleAction('detail', promo)}
              onEdit={() => handleAction('edit', promo)}
              onDelete={() => handleAction('delete', promo)}
              onEnd={() => handleAction('end', promo)}
              onCopy={() => handleAction('copy', promo)}
            />
          </div>
        </div>
      ))}
    </div>
  );
};

export default PromoTable;





