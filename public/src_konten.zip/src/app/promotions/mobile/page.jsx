// src/app/promotions/mobile/page.jsx
// all baris file ini fixing untuk:
// 24. THP 2 - MOD001 - MP - 022 - QC Plan - Web - MuatParts - Promo
// LB : 0163, 0165, 0172

'use client'

import ImageComponent from '@/components/ImageComponent/ImageComponent';
import React, { useState, useEffect } from 'react';
import { useCustomRouter } from '@/libs/CustomRoute';
import { useHeader } from '@/common/ResponsiveContext';
import NavbarCount from '@/components/NavbarCount/NavbarCount';
import PromoCard from '@/components/Promotions/Mobile/PromoCard/PromoCard';
import PromoFilter from '@/components/Promotions/Mobile/PromoFilter/PromoFilter';
import Input from '@/components/Input/Input';
import ToastApp from '@/components/ToastApp/ToastApp';
import promoMockService from '@/services/MockServer_Promotion';
import BottomNavigation from '@/components/Promotions/BottomNavigation';
import ModalComponent from '@/components/Modals/ModalComponent';
import { useTranslation } from '@/context/TranslationProvider';
import toast from '@/store/zustand/toast';
import Bottomsheet from '@/components/Bottomsheet/Bottomsheet';
import { useOnboardingFirstTimer } from '@/store/zustand/produk/useOnboardingFirstTimer';
import { useShallow } from 'zustand/react/shallow';

const PromoListPage = () => {
  const router = useCustomRouter();
  const { setAppBar, clearScreen } = useHeader();
  const { t, langReady } = useTranslation();

  // """Keep existing state declarations"""
  const [activeTab, setActiveTab] = useState('active');
  const [promos, setPromos] = useState([]);
  const [tabCounts, setTabCounts] = useState({ active: 0, history: 0 });
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    status: [],
    date: null,
    dateRange: {
      start: null,
      end: null
    }
  });
  const [showFilter, setShowFilter] = useState(false);
  const [showOptionsModal, setShowOptionsModal] = useState(false);
  const [selectedPromo, setSelectedPromo] = useState(null);
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const [inputValue, setInputValue] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  // """Keep existing filter indicators"""
  const hasActiveFilters =
    (filters.status && filters.status.length > 0) ||
    filters.date !== null;

  const filterButtonStyle = hasActiveFilters ? {
    backgroundColor: 'var(--primary-50)',
    borderColor: 'var(--primary-700)',
    color: 'var(--primary-700)'
  } : {
    backgroundColor: 'var(--neutral-100)',
    borderColor: 'var(--neutral-100)',
    color: 'var(--neutral-700)'
  };

  const filterIconSrc = hasActiveFilters
    ? '/promo/icons/blue/Filter - 2.svg'
    : '/promo/icons/grey/Filter - 2.svg';

  // """Keep existing fetchPromos function"""
  const fetchPromos = async () => {
    setLoading(true);
    try {
      const response = await promoMockService.getPromotionList({
        tab: activeTab,
        search: searchQuery || undefined,
        filters: filters
      });
      setPromos(response.Data.promos);
      setTabCounts(response.Data.tabCounts);
    } catch (error) {
      console.error('Failed to fetch promos:', error);
      // Using direct text since no exact match in common.json
      setToastMessage('Gagal memuat data promosi');
      setShowToast(true);
    } finally {
      setLoading(false);
    }
  };

  // """Keep existing useEffect and handlers"""
  useEffect(() => {
    fetchPromos();
  }, [activeTab, searchQuery, filters]);

  const handleSearch = (e) => {
    setInputValue(e.target.value);
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      setSearchQuery(inputValue);
    }
  };

  const handleFilterApply = (newFilters) => {
    setFilters(newFilters);
    setShowFilter(false);
  };

  const handleActionsClick = (promo) => {
    setSelectedPromo(promo);
    setShowOptionsModal(true);
  };

  const handleEndPromo = async (promoId) => {
    try {
      await promoMockService.endPromotion(promoId);
      setToastMessage(t('berhasilMengahiriPromo'));
      setShowToast(true);
      fetchPromos();
    } catch (error) {
      // Direct text since no exact match
      setToastMessage('Gagal mengakhiri promosi');
      setShowToast(true);
    }
  };

  const handleDeletePromo = async (promoId) => {
    try {
      await promoMockService.deletePromotion(promoId);
      setToastMessage(t('berhasilMenghapusPromo'));
      setShowToast(true);
      fetchPromos();
    } catch (error) {
      // Direct text since no exact match
      setToastMessage('Gagal menghapus promosi');
      setShowToast(true);
    }
  };

  const handleClearSearch = () => {
    setInputValue('');
    setSearchQuery('');
  };

  const renderEmptyState = () => {
    if (loading) {
      return (
        <div className="animate-pulse space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-32 bg-white rounded-lg" />
          ))}
        </div>
      );
    }

    // MP 22: LB - 0179
    if (promos.length === 0) {
      if (searchQuery || hasActiveFilters) {
        return (
          <div className="flex flex-1 flex-col items-center justify-center py-auto">
            <ImageComponent
              src="/promo/img/not_found.png"
              alt="No results found"
              className="w-[92px] h-auto mb-4"
            />
            <p className="text-neutral-700 text-center font-medium mb-2">
              {t('dataTidakDitemukan')}
            </p>
            <p className="text-neutral-600 text-center mb-6">
              {t('mohonHapusBeberapaFilter')}
            </p>
            <p className="text-neutral-600 text-center mb-4">atau</p>
            <button
              onClick={() => setShowFilter(true)}
              className="px-6 py-1 bg-primary-700 text-white rounded-full font-medium"
            >
              {t('aturUlangFilter')}
            </button>
          </div>
        );
      }

      return (
        <div className="flex flex-col flex-1 items-center justify-center py-8 h-full">
          <ImageComponent src="/img/daftarprodukicon.png"
            alt="Empty state"
            className="w-32 mb-4"
          />
          <div className="text-neutral-600 text-center font-demi font-[600] text-[16px]">
            {/* Improvement fix wording pak Bryan */}
            {activeTab === 'active'
              ? t('belumAdaPromosiAktif')
              : t('belumadaRiwayat')
            }
          </div>
          <div className="text-neutral-600 text-center font-medium text-[12px]">
            {t('buatPromosiKamu')}
          </div>
        </div>
      );
    }

    return null;
  };

  return (
    <div className="flex flex-col min-h-screen bg-[var(--neutral-100)] h-full">
      <BottomsheetFirstTimer t={t} langReady={langReady} />
      {/* Header */}
      <div className="flex overflow-hidden relative gap-2.5 items-start px-4 py-3.5 text-base font-bold text-white bg-[#C22716]">
        <div className="flex z-0 gap-2 items-center min-h-[34px] w-full">
          {/* 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0901 */}
          <button
            onClick={() => router.back()}
            className="w-6 h-6 bg-white rounded-full flex items-center justify-center"
          >
            <ImageComponent
              src="/promo/icons/red/Chevron Left.svg"
              alt="Back"
              className="w-5 h-5"
            />
          </button>
          <div>{t('promosiPenjual')}</div>
        </div>
        <ImageComponent src="/img/fallinstartheader.png"
          alt=""
          className="object-contain absolute right-0 bottom-0 z-0 shrink-0 aspect-[2.47] h-[62px] w-[153px]"
        />
      </div>

      {/* Tabs */}
      <div className="flex bg-[#C22716] text-white">
        <button
          className={`flex-1 py-3 px-4 text-sm font-medium relative
      ${activeTab === 'active' ? 'font-bold border-b-2 border-white' : ''}`}
          onClick={() => setActiveTab('active')}
        >
          {t('daftarPromosi')}
        </button>
        <div className="w-px bg-red-800 my-2" />
        <button
          className={`flex-1 py-3 px-4 text-sm font-medium relative
      ${activeTab === 'history' ? 'font-bold border-b-2 border-white' : ''}`}
          onClick={() => setActiveTab('history')}
        >
          {t('labelRiwayat')}
        </button>
      </div>

      <div className="flex-1 overflow-auto pb-20 flex-col flex">
        {/* Search and Filter */}
        <div className="flex flex-col gap-3 p-4 bg-white">
          <Input
            type="text"
            placeholder={t('cariNamaPromosi')}
            value={inputValue}
            changeEvent={handleSearch}
            onKeyPress={handleKeyPress}
            disabled={promos.length === 0 && !hasActiveFilters && !searchQuery}
            icon={{
              left: '/promo/icons/grey/Search.svg',
              right: inputValue ? (
                <div onClick={handleClearSearch}>
                  <ImageComponent
                    src="/promo/icons/grey/silang.svg"
                    alt="Clear"
                    width={16}
                    height={16}
                  />
                </div>
              ) : ''
            }}
          />

          <button
            onClick={() => setShowFilter(true)}
            style={filterButtonStyle}
            className="border flex justify-center items-center gap-2 py-2 px-4 rounded-full text-sm font-medium w-fit transition-colors"
          >
            <span>{t('labelFilter')}</span>
            <ImageComponent
              src={filterIconSrc}
              alt="Filter"
              className="w-4 h-4"
            />
          </button>
        </div>

        {/* Content Area */}
        <div className={"flex-1 p-4 space-y-4 " + (renderEmptyState() ? 'flex' : '')}>
          {renderEmptyState() || (
            // """Keep existing promotion cards mapping"""
            promos.map((promo) => (
              <PromoCard
                key={promo.id}
                promo={promo}
                onOptionsClick={() => handleActionsClick(promo)}
                optionsIcon="/promo/icons/grey/Menu.svg"
              />
            ))
          )}
        </div>
      </div>

      {/* Create Button */}
      <BottomNavigation
        onMessageClick={() => router.push('/pesan')}
        onProfileClick={() => router.push('/profile')}
        onCreateClick={() => router.push('/promotions/mobile/create')}
        createButtonLabel={t('buatPromosi')}
        messageIcon="/promo/icons/grey/Chat.svg"
        plusIcon="/promo/icons/grey/Plus Square.svg"
        profileIcon="/promo/icons/grey/Profile.svg"
      />

      {/* Filter */}
      <PromoFilter
        isOpen={showFilter}
        onClose={() => setShowFilter(false)}
        initialFilters={filters}
        onApplyFilters={handleFilterApply}
        tab={activeTab}
      />


      {/* // MP 22: LB - 0173 */}
      <ModalComponent
        isOpen={showOptionsModal && selectedPromo}
        setClose={() => { }}
        type="BottomSheet"
        title={t('labelAtur')}
      >
        <div className="space-y-[16px] flex flex-col pt-[8px] pb-[24px] px-[16px] font-[600] text-neutral-900">
          <button
            onClick={() => {
              router.push(`/promotions/mobile/${selectedPromo?.id}`);
              setShowOptionsModal(false);
            }}
            className="w-full text-left hover:bg-gray-50 rounded-lg"
          >
            {t('labelDetail')}
          </button>

          {selectedPromo?.status === 'Aktif' && (
            <>
              <div className='border-[var(--neutral-400)] border-b'></div>
              <button
                onClick={() => {
                  handleEndPromo(selectedPromo?.id);
                  setShowOptionsModal(false);
                }}
                className="w-full text-left hover:bg-gray-50 rounded-lg"
              >
                {t('labelAkhiri')}
              </button>
            </>
          )}

          {selectedPromo?.status === 'Akan Datang' && (
            <>
              <div className='border-[var(--neutral-400)] border-b'></div>
              <button
                onClick={() => {
                  handleDeletePromo(selectedPromo?.id);
                  setShowOptionsModal(false);
                }}
                className="w-full text-left hover:bg-gray-50 rounded-lg text-red-600"
              >
                {t('labelHapus')}
              </button>
            </>
          )}

          {selectedPromo?.status === 'Berakhir' && (
            <>
              <div className='border-[var(--neutral-400)] border-b'></div>
              <button
                onClick={() => {
                  router.push(`/promotions/mobile/${selectedPromo?.id}/copy`);
                  setShowOptionsModal(false);
                }}
                className="w-full text-left hover:bg-gray-50 rounded-lg"
              >
                {t('labelSalin')}
              </button>
            </>
          )}
        </div>
      </ModalComponent>


      {/* Options Modal */}


      {/* Toast */}
      <ToastApp
        show={showToast}
        text={toastMessage}
        status="success"
        timer={3000}
        onClose={() => setShowToast(false)}
      />
    </div>
  );
};

// Improvement Konten Marketing by Ce Nola
const BottomsheetFirstTimer = ({ t, langReady }) => {
  const [hasShowBottomsheet, setHasShowBottomsheet] = useState(false);
  const {
    showBottomsheet,
    setShowBottomsheet,
    setTitleBottomsheet,
    setDataBottomsheet,
  } = toast();
  const { hasPopupPromosi, confirmDonePopupPromosi } = useOnboardingFirstTimer(useShallow(state => ({
    hasPopupPromosi: state.hasPopupPromosi,
    confirmDonePopupPromosi: state.confirmDonePopupPromosi
  })));
  
  const handleDonePopupPromosi = () => {
    confirmDonePopupPromosi();
    setShowBottomsheet(false);
  }

  const InnerContent = () => {
    return (
      <div className="flex flex-col items-center justify-center">
        {/* LBM - EKA - Fix gambar konten marketing - 16 Mei 2025 */}
        <img src={process.env.NEXT_PUBLIC_ASSET_REVERSE + "/img/promosi_first_timer.webp"} alt="Info Voucher" className="h-[184px] w-full object-contain" />
        <p className="text-center text-sm text-neutral-600 mt-3 mb-[18px]">
          {t("labelUsePromotionFeatures")}
        </p>

        
        <button
          onClick={handleDonePopupPromosi}
          className="bg-primary-700 hover:bg-blue-700 text-white font-medium rounded-full w-full py-[10px] flex items-center justify-center transition duration-200"
        >
          <span className="text-sm">{t("labelManagePromotionsNow")}</span>
        </button>
      </div>
    );
  };
  // Ini untuk update tampilan kalau link tercopy, karena konten di dalam bottomsheet tidak reactive
  useEffect(() => {
    if (langReady && !hasPopupPromosi) {
      setTitleBottomsheet(t("labelManagePromotions"));
      setDataBottomsheet(<InnerContent />);
      setShowBottomsheet(true);
      setHasShowBottomsheet(true);
    }
  }, [langReady, hasPopupPromosi]);


  useEffect(() => {
    if(hasShowBottomsheet && showBottomsheet === false) {
      confirmDonePopupPromosi();
    }
  }, [hasShowBottomsheet, showBottomsheet]);


  return <Bottomsheet />;
};


export default PromoListPage;