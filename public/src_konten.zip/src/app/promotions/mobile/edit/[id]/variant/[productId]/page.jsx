// app/promotions/edit/[id]/variant/[productId]/page.jsx
'use client'

import ImageComponent from '@/components/ImageComponent/ImageComponent';;

import React, { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import NavbarCount from '@/components/NavbarCount/NavbarCount';
import Input from '@/components/Input/Input';
import ToastApp from '@/components/ToastApp/ToastApp';
import AturMassalPopup from '@/components/Promotions/PromoForm/AturMassalPopup';
import promoMockService from '@/services/MockServer_Promotion';

const formatNumber = (number) => {
  if (!number) return '';
  return new Intl.NumberFormat('id-ID').format(number);
};

const formatCurrency = (value) => {
  if (!value) return '';
  return formatNumber(value);
};

const VariantCard = ({ 
  variant,
  onChange,
  canToggle,
  purchaseLimit,
  errors = {}
}) => {
  const calculatePromoPrice = (discountValue) => {
    return Math.floor(variant.price * (1 - discountValue / 100));
  };

  const calculateDiscountValue = (promoPrice) => {
    return Math.floor((1 - promoPrice / variant.price) * 100);
  };

  const handlePriceChange = (value) => {
    const numericValue = parseInt(value.replace(/\D/g, ''));
    if (!isNaN(numericValue)) {
      const discountValue = calculateDiscountValue(numericValue);
      onChange({
        ...variant,
        promoPrice: numericValue,
        discountValue: discountValue
      });
    }
  };

  const handleDiscountChange = (value) => {
    const numericValue = parseInt(value);
    if (!isNaN(numericValue)) {
      const promoPrice = calculatePromoPrice(numericValue);
      onChange({
        ...variant,
        discountValue: numericValue,
        promoPrice: promoPrice
      });
    }
  };

  return (
    <div className={`p-4 border rounded-lg ${!variant.isActive ? 'bg-gray-50' : 'bg-white'}`}>
      {/* Variant Header */}
      <div className="flex items-center justify-between mb-4">
        <div>
          <h4 className="font-medium">{variant.name}</h4>
          <p className="text-sm text-gray-500">SKU: {variant.sku}</p>
          <p className="text-sm font-medium mt-1">Rp{formatNumber(variant.price)}</p>
          <p className="text-sm text-gray-500">Stok: {variant.stock}</p>
        </div>
        <label className="relative inline-flex items-center cursor-pointer">
          <input
            type="checkbox"
            className="sr-only peer"
            checked={variant.isActive}
            onChange={(e) => onChange({
              ...variant,
              isActive: e.target.checked
            })}
            disabled={!canToggle && variant.isActive}
          />
          <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-700"></div>
        </label>
      </div>

      {variant.isActive && (
        <div className="space-y-4">
          {/* Quota */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Kuota Promosi*
            </label>
            <Input
              type="number"
              placeholder="Contoh: 1"
              value={variant.quota}
              changeEvent={(e) => onChange({
                ...variant,
                quota: e.target.value
              })}
              status={errors.quota ? 'error' : undefined}
              supportiveText={{
                title: errors.quota || '',
                desc: `Min. 1, Maks. ${formatNumber(variant.stock)}`
              }}
            />
          </div>

          {/* Purchase Limit */}
          {purchaseLimit !== 'unlimited' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Batas Pembelian*
              </label>
              <Input
                type="number"
                placeholder="Contoh: 1"
                value={variant.purchaseLimit}
                changeEvent={(e) => onChange({
                  ...variant,
                  purchaseLimit: e.target.value
                })}
                status={errors.purchaseLimit ? 'error' : undefined}
                supportiveText={{
                  title: errors.purchaseLimit || '',
                  desc: `Min. 1, Maks. ${formatNumber(variant.quota || variant.stock)}`
                }}
              />
            </div>
          )}

          {/* Discount Type Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Jenis Diskon*
            </label>
            <div className="flex gap-4">
              <button
                onClick={() => onChange({
                  ...variant,
                  discountType: 'price',
                  discountValue: '',
                  promoPrice: ''
                })}
                className={`flex-1 py-2 px-4 rounded-lg border ${
                  variant.discountType === 'price'
                    ? 'border-primary-700 text-primary-700'
                    : 'border-gray-300'
                }`}
              >
                Harga Promo
              </button>
              <button
                onClick={() => onChange({
                  ...variant,
                  discountType: 'percentage',
                  discountValue: '',
                  promoPrice: ''
                })}
                className={`flex-1 py-2 px-4 rounded-lg border ${
                  variant.discountType === 'percentage'
                    ? 'border-primary-700 text-primary-700'
                    : 'border-gray-300'
                }`}
              >
                Diskon (%)
              </button>
            </div>
          </div>

          {/* Discount Value Input */}
          {variant.discountType === 'price' ? (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Harga Promo*
              </label>
              <Input
                type="text"
                placeholder="Contoh: 100.000"
                value={formatNumber(variant.promoPrice)}
                changeEvent={(e) => handlePriceChange(e.target.value)}
                status={errors.promoPrice ? 'error' : undefined}
                text={{left: 'Rp'}}
                supportiveText={{
                  title: errors.promoPrice || '',
                  desc: `Min. Rp${formatNumber(Math.floor(variant.price * 0.4))}`
                }}
              />
            </div>
          ) : variant.discountType === 'percentage' ? (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Persentase Diskon*
              </label>
              <Input
                type="number"
                placeholder="0"
                value={variant.discountValue}
                changeEvent={(e) => handleDiscountChange(e.target.value)}
                status={errors.discountValue ? 'error' : undefined}
                text={{right: '%'}}
                supportiveText={{
                  title: errors.discountValue || '',
                  desc: variant.promoPrice ? `Rp${formatNumber(variant.promoPrice)}` : ''
                }}
              />
            </div>
          ) : null}

          {/* Error Message */}
          {!variant.isValid && (
            <div className="p-3 bg-red-50 text-red-700 rounded-lg text-sm">
              Harga tidak sesuai ketentuan. Silakan sesuaikan kembali.
            </div>
          )}
        </div>
      )}
    </div>
  );
};

const EditVariantPromoPage = () => {
  const { id, productId } = useParams();
  const router = useCustomRouter();
  const [loading, setLoading] = useState(true);
  const [promoData, setPromoData] = useState(null);
  const [product, setProduct] = useState(null);
  const [variants, setVariants] = useState([]);
  const [showMassEdit, setShowMassEdit] = useState(false);
  const [showExitConfirm, setShowExitConfirm] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const [errors, setErrors] = useState({});

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const response = await promoMockService.getPromoById(id);
        if (!response.Data) {
          throw new Error('Promosi tidak ditemukan');
        }
        
        setPromoData(response.Data);
        const foundProduct = response.Data.products.find(p => p.id.toString() === productId);
        if (!foundProduct) {
          throw new Error('Produk tidak ditemukan');
        }
        
        setProduct(foundProduct);
        
        // Initialize variants with promotion data if exists
        const initialVariants = foundProduct.variants.map(variant => ({
          ...variant,
          isActive: true,
          quota: variant.promotion?.quota || '',
          purchaseLimit: variant.promotion?.purchaseLimit || '',
          discountType: variant.promotion?.discountType || null,
          discountValue: variant.promotion?.discountValue || '',
          promoPrice: variant.promotion?.promoPrice || '',
          isValid: variant.promotion?.isValid || false
        }));
        setVariants(initialVariants);
      } catch (error) {
        console.error('Failed to fetch data:', error);
        setToastMessage(error.message || 'Gagal memuat data');
        setShowToast(true);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [id, productId]);

  const handleBack = () => {
    setShowExitConfirm(true);
  };

  const handleVariantChange = (updatedVariant) => {
    setVariants(currentVariants =>
      currentVariants.map(v =>
        v.id === updatedVariant.id ? updatedVariant : v
      )
    );
  };

  const validateVariants = () => {
    const activeVariants = variants.filter(v => v.isActive);
    if (activeVariants.length === 0) {
      setToastMessage('Minimal satu varian harus aktif');
      setShowToast(true);
      return false;
    }

    const newErrors = {};
    let isValid = true;

    activeVariants.forEach(variant => {
      const variantErrors = {};

      if (!variant.quota || parseInt(variant.quota) < 1) {
        variantErrors.quota = 'Min. 1';
        isValid = false;
      }

      if (promoData.purchaseLimit !== 'unlimited') {
        if (!variant.purchaseLimit || parseInt(variant.purchaseLimit) < 1) {
          variantErrors.purchaseLimit = 'Min. 1';
          isValid = false;
        } else if (parseInt(variant.purchaseLimit) > parseInt(variant.quota)) {
          variantErrors.purchaseLimit = 'Tidak boleh melebihi kuota';
          isValid = false;
        }
      }

      if (!variant.discountType) {
        variantErrors.discountType = 'Pilih jenis diskon';
        isValid = false;
      } else if (variant.discountType === 'price') {
        const minPrice = Math.floor(variant.price * 0.4);
        if (!variant.promoPrice || parseInt(variant.promoPrice) < minPrice) {
          variantErrors.promoPrice = `Min. Rp${formatNumber(minPrice)}`;
          isValid = false;
        }
      } else if (variant.discountType === 'percentage') {
        const value = parseInt(variant.discountValue);
        if (!value || value < 1 || value > 99) {
          variantErrors.discountValue = 'Diskon harus antara 1-99%';
          isValid = false;
        }
      }

      if (Object.keys(variantErrors).length > 0) {
        newErrors[variant.id] = variantErrors;
      }
    });

    setErrors(newErrors);
    return isValid;
  };

  const handleSubmit = async () => {
    if (!validateVariants()) {
      return;
    }

    try {
      const updatedProducts = promoData.products.map(p => {
        if (p.id.toString() === productId) {
          return {
            ...p,
            variants: variants.map(v => ({
              ...v,
              promotion: v.isActive ? {
                quota: v.quota,
                purchaseLimit: v.purchaseLimit,
                discountType: v.discountType,
                discountValue: v.discountValue,
                promoPrice: v.promoPrice,
                isValid: true
              } : null
            }))
          };
        }
        return p;
      });

      const updatedPromo = {
        ...promoData,
        products: updatedProducts
      };

      await promoMockService.savePromotion(updatedPromo);
      
      setToastMessage('Promosi berhasil diperbarui');
      setShowToast(true);
      
      setTimeout(() => {
        router.push(`/promotions/${id}`);
      }, 1500);
    } catch (error) {
      setToastMessage(error.message || 'Gagal memperbarui promosi');
      setShowToast(true);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col min-h-screen">
        <NavbarCount
          title="Atur Diskon"
          subtitle="Loading..."
          backAction={handleBack}
          count={1}
          active={1}
        />
        <div className="animate-pulse p-4 space-y-4">
          <div className="h-20 bg-gray-200 rounded-lg"></div>
          <div className="h-40 bg-gray-200 rounded-lg"></div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="flex flex-col min-h-screen">
        <NavbarCount
          title="Atur Diskon"
          subtitle="Error"
          backAction={handleBack}
          count={1}
          active={1}
        />
        <div className="flex flex-col items-center justify-center p-8">
          <p className="text-gray-500">Produk tidak ditemukan</p>
        </div>
      </div>
    );
  }

  // Count active variants
  const activeVariants = variants.filter(v => v.isActive).length;

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <NavbarCount
        title="Atur Diskon"
        subtitle={product.name}
        backAction={handleBack}
        count={1}
        active={1}
      />

      <div className="p-4 space-y-6">
        {/* Product Info */}
        <div className="bg-white p-4 rounded-lg">
          <div className="flex gap-4">
            <ImageComponent src={product.imageUrl || "/api/placeholder/80/80"}
              alt={product.name}
              className="w-20 h-20 object-cover rounded-lg"
            />
            <div>
              <h3 className="font-medium">{product.name}</h3>
              <p className="text-sm text-gray-500">SKU: {product.sku}</p>
              <div className="mt-1">
                <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                  {variants.length} Varian
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Variant List */}
        <div className="space-y-4">
          {variants.map((variant) => (
            <VariantCard
              key={variant.id}
              variant={variant}
              onChange={handleVariantChange}
              canToggle={activeVariants > 1}
              purchaseLimit={promoData.purchaseLimit}
              errors={errors[variant.id] || {}}
            />
          ))}
        </div>
      </div>

      {/* Bottom Action */}
      <div className="sticky bottom-0 bg-white border-t p-4 mt-auto">
        <button
          onClick={handleSubmit}
          className="w-full py-3 bg-primary-700 text-white rounded-lg font-medium"
        >
          Terapkan
        </button>
      </div>

      {/* Exit Confirmation Modal */}
      {showExitConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-20 flex items-center justify-center">
          <div className="bg-white rounded-lg p-6 m-4 max-w-sm w-full">
            <h3 className="text-lg font-medium text-gray-900 mb-4">
              Batalkan perubahan?
            </h3>
            <p className="text-sm text-gray-500 mb-6">
              Perubahan yang belum disimpan akan hilang
            </p>
            <div className="flex gap-4">
              <button
                onClick={() => setShowExitConfirm(false)}
                className="flex-1 py-2 px-4 border border-gray-300 rounded-lg"
              >
                Tidak
              </button>
              <button
                onClick={() => router.push(`/promotions/${id}`)}
                className="flex-1 py-2 px-4 bg-primary-700 text-white rounded-lg"
              >
                Ya
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Toast */}
      <ToastApp
        show={showToast}
        text={toastMessage}
        status={toastMessage.includes('berhasil') ? 'success' : 'error'}
        timer={3000}
        onClose={() => setShowToast(false)}
      />
    </div>
  );
};

export default EditVariantPromoPage;


