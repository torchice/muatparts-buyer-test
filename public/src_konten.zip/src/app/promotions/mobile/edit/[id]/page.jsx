// app/promotions/edit/[id]/page.jsx
'use client';

import React, { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import NavbarCount from '@/components/NavbarCount/NavbarCount';
import BasicInfoForm from '@/components/Promotions/PromoForm/BasicInfoForm';
import ToastApp from '@/components/ToastApp/ToastApp';
import promoMockService from '@/services/MockServer_Promotion';

const EditPromoPage = () => {
  const { id } = useParams();
  const router = useCustomRouter();
  const [loading, setLoading] = useState(true);
  const [promoData, setPromoData] = useState(null);
  const [showExitConfirm, setShowExitConfirm] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState('');

  useEffect(() => {
    const fetchPromoDetails = async () => {
      setLoading(true);
      try {
        const response = await promoMockService.getPromoById(id);
        if (!response.Data) {
          throw new Error('Promosi tidak ditemukan');
        }
        setPromoData(response.Data);
      } catch (error) {
        console.error('Failed to fetch promo details:', error);
        setToastMessage(error.message || 'Gagal memuat data promosi');
        setShowToast(true);
      } finally {
        setLoading(false);
      }
    };

    fetchPromoDetails();
  }, [id]);

  const handleBack = () => {
    setShowExitConfirm(true);
  };

  const handleSubmit = async (data) => {
    try {
      const updatedPromo = {
        ...promoData,
        name: data.promoName,
        startDate: data.startDate.toISOString(),
        endDate: data.endDate.toISOString(),
        purchaseLimit: data.purchaseLimit
      };

      await promoMockService.savePromotion(updatedPromo);
      
      setToastMessage('Promosi berhasil diperbarui');
      setShowToast(true);
      
      setTimeout(() => {
        router.push(`/promotions/${id}`);
      }, 1500);
    } catch (error) {
      setToastMessage(error.message || 'Gagal memperbarui promosi');
      setShowToast(true);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col min-h-screen">
        <NavbarCount
          title="Ubah Promosi"
          subtitle="Detail Promosi"
          backAction={handleBack}
          count={1}
          active={1}
        />
        <div className="animate-pulse p-4 space-y-4">
          <div className="h-10 bg-gray-200 rounded w-3/4"></div>
          <div className="h-10 bg-gray-200 rounded"></div>
          <div className="h-10 bg-gray-200 rounded w-1/2"></div>
        </div>
      </div>
    );
  }

  if (!promoData) {
    return (
      <div className="flex flex-col min-h-screen">
        <NavbarCount
          title="Ubah Promosi"
          subtitle="Detail Promosi"
          backAction={handleBack}
          count={1}
          active={1}
        />
        <div className="flex flex-col items-center justify-center p-8">
          <p className="text-gray-500">Promosi tidak ditemukan</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <NavbarCount
        title="Ubah Promosi"
        subtitle="Detail Promosi"
        backAction={handleBack}
        count={1}
        active={1}
      />

      <BasicInfoForm
        initialData={{
          promoName: promoData.name,
          startDate: new Date(promoData.startDate),
          endDate: new Date(promoData.endDate),
          purchaseLimit: promoData.purchaseLimit
        }}
        onSubmit={handleSubmit}
        onBack={handleBack}
        disableStartDate={promoData.status === 'Aktif'}
      />

      {/* Exit Confirmation Modal */}
      {showExitConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-20 flex items-center justify-center">
          <div className="bg-white rounded-lg p-6 m-4 max-w-sm w-full">
            <h3 className="text-lg font-medium text-gray-900 mb-4">
              Batalkan perubahan?
            </h3>
            <p className="text-sm text-gray-500 mb-6">
              Perubahan yang belum disimpan akan hilang
            </p>
            <div className="flex gap-4">
              <button
                onClick={() => setShowExitConfirm(false)}
                className="flex-1 py-2 px-4 border border-gray-300 rounded-lg"
              >
                Tidak
              </button>
              <button
                onClick={() => router.push(`/promotions/${id}`)}
                className="flex-1 py-2 px-4 bg-primary-700 text-white rounded-lg"
              >
                Ya
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Toast */}
      <ToastApp
        show={showToast}
        text={toastMessage}
        status={toastMessage.includes('berhasil') ? 'success' : 'error'}
        timer={3000}
        onClose={() => setShowToast(false)}
      />
    </div>
  );
};

export default EditPromoPage;


