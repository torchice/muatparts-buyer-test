// app/promotions/edit/[id]/product/[productId]/page.jsx
'use client'

import ImageComponent from '@/components/ImageComponent/ImageComponent';;

import React, { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import NavbarCount from '@/components/NavbarCount/NavbarCount';
import Input from '@/components/Input/Input';
import ToastApp from '@/components/ToastApp/ToastApp';
import promoMockService from '@/services/MockServer_Promotion';

const formatNumber = (number) => {
  if (!number) return '';
  return new Intl.NumberFormat('id-ID').format(number);
};

const formatCurrency = (value) => {
  if (!value) return '';
  return formatNumber(value);
};

const EditProductPromoPage = () => {
  const { id, productId } = useParams();
  const router = useCustomRouter();
  const [loading, setLoading] = useState(true);
  const [promoData, setPromoData] = useState(null);
  const [product, setProduct] = useState(null);
  const [errors, setErrors] = useState({});
  const [discount, setDiscount] = useState({
    quota: '',
    purchaseLimit: '',
    discountType: null,
    discountValue: '',
    promoPrice: '',
    isValid: false
  });
  const [showExitConfirm, setShowExitConfirm] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const response = await promoMockService.getPromoById(id);
        if (!response.Data) {
          throw new Error('Promosi tidak ditemukan');
        }
        
        setPromoData(response.Data);
        const foundProduct = response.Data.products.find(p => p.id.toString() === productId);
        if (!foundProduct) {
          throw new Error('Produk tidak ditemukan');
        }
        
        setProduct(foundProduct);
        if (foundProduct.promotion) {
          setDiscount(foundProduct.promotion);
        }
      } catch (error) {
        console.error('Failed to fetch data:', error);
        setToastMessage(error.message || 'Gagal memuat data');
        setShowToast(true);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [id, productId]);

  const handleBack = () => {
    setShowExitConfirm(true);
  };

  const handleDiscountTypeChange = (type) => {
    setDiscount({
      ...discount,
      discountType: type,
      discountValue: '',
      promoPrice: ''
    });
    setErrors({});
  };

  const calculatePromoPrice = (discountValue) => {
    if (!product || !discountValue) return '';
    return Math.floor(product.price * (1 - discountValue / 100));
  };

  const calculateDiscountValue = (promoPrice) => {
    if (!product || !promoPrice) return '';
    return Math.floor((1 - promoPrice / product.price) * 100);
  };

  const handlePriceChange = (value) => {
    const numericValue = parseInt(value.replace(/\D/g, ''));
    if (!isNaN(numericValue)) {
      const discountValue = calculateDiscountValue(numericValue);
      setDiscount({
        ...discount,
        promoPrice: numericValue,
        discountValue: discountValue
      });
    }
  };

  const handleDiscountChange = (value) => {
    const numericValue = parseInt(value);
    if (!isNaN(numericValue)) {
      const promoPrice = calculatePromoPrice(numericValue);
      setDiscount({
        ...discount,
        discountValue: numericValue,
        promoPrice: promoPrice
      });
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (!discount.quota || parseInt(discount.quota) < 1) {
      newErrors.quota = 'Min. 1';
    }

    if (promoData.purchaseLimit !== 'unlimited') {
      if (!discount.purchaseLimit || parseInt(discount.purchaseLimit) < 1) {
        newErrors.purchaseLimit = 'Batas pembelian harus diisi';
      } else if (parseInt(discount.purchaseLimit) > parseInt(discount.quota)) {
        newErrors.purchaseLimit = 'Tidak boleh melebihi kuota';
      }
    }

    if (!discount.discountType) {
      newErrors.discountType = 'Pilih jenis diskon';
    } else if (discount.discountType === 'price') {
      const minPrice = Math.floor(product.price * 0.4);
      if (!discount.promoPrice || parseInt(discount.promoPrice) < minPrice) {
        newErrors.promoPrice = `Min. Rp${formatNumber(minPrice)}`;
      }
    } else if (discount.discountType === 'percentage') {
      const value = parseInt(discount.discountValue);
      if (!value || value < 1 || value > 99) {
        newErrors.discountValue = 'Diskon harus antara 1-99%';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validateForm()) {
      setToastMessage('Silakan periksa kembali input Anda');
      setShowToast(true);
      return;
    }

    try {
      const updatedProducts = promoData.products.map(p => {
        if (p.id.toString() === productId) {
          return {
            ...p,
            promotion: {
              ...discount,
              isValid: true
            }
          };
        }
        return p;
      });

      const updatedPromo = {
        ...promoData,
        products: updatedProducts
      };

      await promoMockService.savePromotion(updatedPromo);
      
      setToastMessage('Promosi berhasil diperbarui');
      setShowToast(true);
      
      setTimeout(() => {
        router.push(`/promotions/${id}`);
      }, 1500);
    } catch (error) {
      setToastMessage(error.message || 'Gagal memperbarui promosi');
      setShowToast(true);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col min-h-screen">
        <NavbarCount
          title="Atur Diskon"
          subtitle="Loading..."
          backAction={handleBack}
          count={1}
          active={1}
        />
        <div className="animate-pulse p-4 space-y-4">
          <div className="h-20 bg-gray-200 rounded-lg"></div>
          <div className="h-40 bg-gray-200 rounded-lg"></div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="flex flex-col min-h-screen">
        <NavbarCount
          title="Atur Diskon"
          subtitle="Error"
          backAction={handleBack}
          count={1}
          active={1}
        />
        <div className="flex flex-col items-center justify-center p-8">
          <p className="text-gray-500">Produk tidak ditemukan</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <NavbarCount
        title="Atur Diskon"
        subtitle={product.name}
        backAction={handleBack}
        count={1}
        active={1}
      />

      <div className="p-4 space-y-6">
        {/* Product Info */}
        <div className="bg-white p-4 rounded-lg">
          <div className="flex gap-4">
            <ImageComponent src={product.imageUrl || "/api/placeholder/80/80"}
              alt={product.name}
              className="w-20 h-20 object-cover rounded-lg"
            />
            <div>
              <h3 className="font-medium">{product.name}</h3>
              <p className="text-sm text-gray-500">SKU: {product.sku}</p>
              <p className="text-sm font-medium mt-1">Rp{formatNumber(product.price)}</p>
              <p className="text-sm text-gray-500">Stok: {formatNumber(product.stock)}</p>
            </div>
          </div>
        </div>

        {/* Form Fields */}
        <div className="bg-white p-4 rounded-lg space-y-4">
          {/* Quota */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Kuota Promosi*
            </label>
            <Input
              type="number"
              placeholder="Contoh: 1"
              value={discount.quota}
              changeEvent={(e) => setDiscount({
                ...discount,
                quota: e.target.value
              })}
              status={errors.quota ? 'error' : undefined}
              supportiveText={{
                title: errors.quota || '',
                desc: `Min. 1, Maks. ${formatNumber(product.stock)}`
              }}
            />
          </div>

          {/* Purchase Limit */}
          {promoData.purchaseLimit !== 'unlimited' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Batas Pembelian*
              </label>
              <Input
                type="number"
                placeholder="Contoh: 1"
                value={discount.purchaseLimit}
                changeEvent={(e) => setDiscount({
                  ...discount,
                  purchaseLimit: e.target.value
                })}
                status={errors.purchaseLimit ? 'error' : undefined}
                supportiveText={{
                  title: errors.purchaseLimit || '',
                  desc: `Min. 1, Maks. ${formatNumber(discount.quota || product.stock)}`
                }}
              />
            </div>
          )}

          {/* Discount Type Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Jenis Diskon*
            </label>
            <div className="flex gap-4">
              <button
                onClick={() => handleDiscountTypeChange('price')}
                className={`flex-1 py-2 px-4 rounded-lg border ${
                  discount.discountType === 'price'
                    ? 'border-primary-700 text-primary-700'
                    : 'border-gray-300'
                }`}
              >
                Harga Promo
              </button>
              <button
                onClick={() => handleDiscountTypeChange('percentage')}
                className={`flex-1 py-2 px-4 rounded-lg border ${
                  discount.discountType === 'percentage'
                    ? 'border-primary-700 text-primary-700'
                    : 'border-gray-300'
                }`}
              >
                Diskon (%)
              </button>
            </div>
          </div>

          {/* Discount Value Input */}
          {discount.discountType === 'price' ? (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Harga Promo*
              </label>
              <Input
                type="text"
                placeholder="Contoh: 100.000"
                value={formatNumber(discount.promoPrice)}
                changeEvent={(e) => handlePriceChange(e.target.value)}
                status={errors.promoPrice ? 'error' : undefined}
                text={{ left: 'Rp' }}
                supportiveText={{
                  title: errors.promoPrice || '',
                  desc: `Min. Rp${formatNumber(Math.floor(product.price * 0.4))}`
                }}
              />
            </div>
          ) : discount.discountType === 'percentage' ? (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Persentase Diskon*
              </label>
              <Input
                type="number"
                placeholder="0"
                value={discount.discountValue}
                changeEvent={(e) => handleDiscountChange(e.target.value)}
                status={errors.discountValue ? 'error' : undefined}
                text={{ right: '%' }}
                supportiveText={{
                  title: errors.discountValue || '',
                  desc: discount.promoPrice ? `Rp${formatNumber(discount.promoPrice)}` : ''
                }}
              />
            </div>
          ) : null}
        </div>
      </div>

      {/* Bottom Action */}
      <div className="sticky bottom-0 bg-white border-t p-4 mt-auto">
        <button
          onClick={handleSubmit}
          className="w-full py-3 bg-primary-700 text-white rounded-lg font-medium"
        >
          Terapkan
        </button>
      </div>

      {/* Exit Confirmation Modal */}
      {showExitConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-20 flex items-center justify-center">
          <div className="bg-white rounded-lg p-6 m-4 max-w-sm w-full">
            <h3 className="text-lg font-medium text-gray-900 mb-4">
              Batalkan perubahan?
            </h3>
            <p className="text-sm text-gray-500 mb-6">
              Perubahan yang belum disimpan akan hilang
            </p>
            <div className="flex gap-4">
              <button
                onClick={() => setShowExitConfirm(false)}
                className="flex-1 py-2 px-4 border border-gray-300 rounded-lg"
              >
                Tidak
              </button>
              <button
                onClick={() => router.push(`/promotions/${id}`)}
                className="flex-1 py-2 px-4 bg-primary-700 text-white rounded-lg"
              >
                Ya
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Toast */}
      <ToastApp
        show={showToast}
        text={toastMessage}
        status={toastMessage.includes('berhasil') ? 'success' : 'error'}
        timer={3000}
        onClose={() => setShowToast(false)}
      />
    </div>
  );
};

export default EditProductPromoPage;


