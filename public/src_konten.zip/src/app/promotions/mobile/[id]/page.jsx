// src/app/promotions/mobile/[id]/page.jsx

// Target : semua perubahan di file ini pada commit ini
// 24. THP 2 - MOD001 - MP - 022 - QC Plan - Web - MuatParts - Promo
// LB - 0169
// LB - 0175

'use client'

import ImageComponent from '@/components/ImageComponent/ImageComponent';;

import React, { useState, useEffect } from 'react';
import { useCustomRouter } from '@/libs/CustomRoute';
import NavbarCount from '@/components/NavbarCount/NavbarCount';
import Input from '@/components/Input/Input';
import ToastApp from '@/components/ToastApp/ToastApp';
import promoMockService from '@/services/MockServer_Promotion';
import { PromoBanner } from '@/components/Promotions/Mobile/PromoDetail/PromoBanner';
import { PromoInfo } from '@/components/Promotions/Mobile/PromoDetail/PromoInfo';
import { ProductCard } from '@/components/Promotions/Mobile/PromoDetail/ProductCard';
import { MassEditBottomSheet } from '@/components/Promotions/Mobile/PromoDetail/MassEditBottomSheet';
import usePromoEditStore from '@/store/zustand/promoEditStore';
import PromoPageHeader from '@/components/Promotions/Mobile/PromoPageHeader/PromoPageHeader';
import { useLanguage } from '@/providers/LanguageProvider';
import Toast from '@/components/Toast/Toast';
import toast from '@/store/zustand/toast';
import {
  formatNumber,
  cleanNumber,
  parseNumber,
  handleNumberKeyDown,
  handleNumberPaste
} from '@/components/Promotions/NumberFormatter';

export default function PromoDetailPage({ params }) {
  const router = useCustomRouter();
  const { promoData, setPromoData, setCurrentProduct, clearData } = usePromoEditStore();
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [massEdit, setMassEdit] = useState(false);
  const [selectedProducts, setSelectedProducts] = useState(new Set());
  const [allSelected, setAllSelected] = useState(false);
  const [showMassEditSheet, setShowMassEditSheet] = useState(false);
  // const [showToast, setShowToast] = useState(false);
  const { showToast, setShowToast, setDataToast } = toast();
  const [toastMessage, setToastMessage] = useState('');
  const { t } = useLanguage();
  const [maxDiscount, setMaxDiscount] = useState(60);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const [promoDataResponse, maxDiscountResponse] = await Promise.all([
          promoMockService.getPromoById(params.id),
          promoMockService.getMaxDiscount()
        ]);


        if (maxDiscountResponse?.Data?.maxDiscount) {
          setMaxDiscount(maxDiscountResponse.Data.maxDiscount);
        }

        setPromoData(promoDataResponse.Data);
        // Store data for edit pages
        setPromoData(promoDataResponse.Data);
      } catch (error) {
        console.error('Failed to fetch promo details:', error);
        setToastMessage('Gagal memuat detail promosi');
        setShowToast(true);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [params.id, setPromoData]);

  useEffect(() => {
    console.log('promoData', promoData)
  }, [promoData])

  const handleSelectAll = (checked) => {
    if (checked) {
      // Select all products that match current search filter
      const selectableProducts = promoData.products.filter(product =>
        product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.sku?.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setSelectedProducts(new Set(selectableProducts.map(p => p.id)));
      setAllSelected(true);
    } else {
      // Unselect all products
      setSelectedProducts(new Set());
      setAllSelected(false);
    }
  };

  if (loading || !promoData) {
    return (
      <div className="flex flex-col min-h-screen max-w-[360px]">
        <NavbarCount
          title="Detail Promosi"
          backAction={() => router.push('/promotions')}
          count={1}
          active={1}
        />
        <div className="animate-pulse p-4 space-y-4">
          <div className="h-32 bg-gray-200 rounded-lg" />
          <div className="h-20 bg-gray-200 rounded-lg" />
          <div className="h-20 bg-gray-200 rounded-lg" />
        </div>
      </div>
    );
  }

  const isEditable = ['Aktif', 'Akan Datang'].includes(promoData.status);
  const filteredProducts = promoData.products.filter(product => {
    return product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.sku?.toLowerCase().includes(searchQuery.toLowerCase())
  });

  const formatCurrency = (value) => {
    if (!value) return '';
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(value).replace('IDR', 'Rp');
  };


  const handleProductAction = (product) => {
    // Store current product data in store
    setCurrentProduct(product);

    // Route to appropriate page based on whether product has variants
    if (product.variants?.length > 0) {
      router.push(`/promotions/mobile/${params.id}/variant/${product.id}`);
    } else {
      router.push(`/promotions/mobile/${params.id}/product/${product.id}`);
    }
  };
  const handleMassEdit = () => {
    setMassEdit(true);
    setSelectedProducts(new Set());
  };

  const handleProductSelect = (productId, selected) => {
    const newSelected = new Set(selectedProducts);
    if (selected) {
      newSelected.add(productId);
    } else {
      newSelected.delete(productId);
    }
    setSelectedProducts(newSelected);
  };

  const promoDataIsValid = (promoData, purchaseLimitType, originalPrice) => {
    if (!promoData.quota || parseNumber(promoData.quota) < 1) {
      return false;
    }

    // Validate purchase limit (only if applicable)
    if (purchaseLimitType !== 'no_limit') {
      if (!promoData.purchaseLimit || parseNumber(promoData.purchaseLimit) < 1) {
        return false;
      } else if (parseNumber(promoData.purchaseLimit) > parseNumber(promoData.quota)) {
        return false;
      }
    }

    // For normal (non-mass edit) mode
    const promoPrice = parseNumber(promoData.promoPrice);
    const minAllowedPrice = originalPrice * ((100 - maxDiscount) / 100);

    if ((!promoData.promoPrice && !promoData.discountValue) || promoPrice < minAllowedPrice) {
      return false;
    } else if (promoPrice > originalPrice * 0.99) {
      return false;
    }
    return true;
  }

  const transformPromoPayload = (formData, validate=false) => {
    return promoData.products.map(product => {
      if (product) {
        let productDataPayload = {}
        if (product.variants && product.variants.length > 0) {
          // For variant products
          let variantUpdates = [];
          let isThisProductValid = true;
          product.variants.forEach(variant => {
            const variantPromoData = {
              quota: parseNumber(formData.quota),
              purchaseLimit: parseNumber(formData.purchaseLimit),
              promoPrice: parseNumber(formData.promoPrice) || parseInt(variant.price * ((100 - parseNumber(formData.discountValue)) / 100)),
              discount: parseNumber(formData.discountValue) || parseInt(100 * (1 - (parseNumber(formData.promoPrice) / variant.price))),
            }
            const variantDataIsValid = !validate || promoDataIsValid(variantPromoData, promoData.purchaseLimit, variant.price)
            isThisProductValid = isThisProductValid && variantDataIsValid

            if (!(variant.isActive === false) && (selectedProducts.has(product.id)) && variantDataIsValid) {
              variantUpdates.push({
                variantId: variant.id,
                price: variant.price,
                stock: variant.stock,
                ...variantPromoData,
                isActive: true,
              });
            } else {
              variantUpdates.push({
                variantId: variant.id,
                price: variant.price,
                stock: variant.stock,
                quota: variant.promotion?.quota,
                purchaseLimit: variant.promotion?.purchaseLimit,
                promoPrice: variant.promotion?.promoPrice,
                discount: variant.promotion?.discountValue,
                isActive: variant.isActive,
              });
            }
          });

          productDataPayload = {
            id: product.id,
            variants: variantUpdates
          };

          if (validate) {
            productDataPayload.isValid = isThisProductValid
          }
        } else {
          // For regular products
          const productPromoData = {
            quota: parseNumber(formData.quota),
            purchaseLimit: parseNumber(formData.purchaseLimit),
            discount: formData.discountValue ? parseNumber(formData.discountValue) : parseInt(100 * (1 - (parseNumber(formData.promoPrice) / product.price))),
            promoPrice: formData.promoPrice ? parseNumber(formData.promoPrice) : parseInt(product.price * ((100 - parseNumber(formData.discountValue)) / 100)),
          }

          const productDataIsValid = !validate || promoDataIsValid(productPromoData, promoData.purchaseLimit, product.price[0])

          if (!selectedProducts.has(product.id) && !productDataIsValid) {
            productDataPayload = {
              id: product.id,
              price: product.price[0],
              stock: product.stock,
              quota: product.promotion?.quota,
              purchaseLimit: product.promotion?.purchaseLimit,
              discount: product.promotion?.discount,
              promoPrice: product.promotion?.promoPrice,
            };  
          } else {
            productDataPayload = {
              id: product.id,
              price: product.price[0],
              stock: product.stock,
              ...productPromoData
            };
          }

          if (validate) {
            productDataPayload.isValid = productDataIsValid
          }
        }

        return productDataPayload;
      }
    })
  }

  const handleMassEditSubmit = async (formData) => {
    try {
      console.log('detailmassedit')
      console.log('promoData', promoData)
      console.log('formData', formData)

      // Apply the same pricing data to all selected products
      const originalProductsPayload = transformPromoPayload(formData);
      const updatedProductsPayload = transformPromoPayload(formData);

      const promoDataPayload = {
        id: promoData.id,
        promoName: promoData.name.trim(),
        startDate: promoData.startDate,
        endDate: promoData.endDate,
        purchaseLimit: promoData.purchaseLimit,
        mode: 'edit',
        selectedProducts: updatedProductsPayload
      };

      console.log('promoDataPayload', promoDataPayload)

      // Save to API
      await promoMockService.savePromotion({
        ...promoDataPayload,
      });

      setToastMessage('Berhasil mengubah promosi');
      setShowToast(true);
      setShowMassEditSheet(false);
      setMassEdit(false);
      setSelectedProducts(new Set());

      // Refresh data
      const response = await promoMockService.getPromoById(params.id);
      setPromoData(response.Data);
    } catch (error) {
      console.log(error)
      setToastMessage(error.message || 'Gagal mengubah promosi');
      setShowToast(true);
    }
  };

  const getDisplayPrice = (originalPrice, promoPrice) => {
    // If both prices are arrays (price range)
    if (Array.isArray(originalPrice)) {
      const [minOriginal, maxOriginal] = originalPrice;

      // If min and max are same, show single price
      if (minOriginal === maxOriginal) {
        return {
          original: formatCurrency(minOriginal),
          promo: promoPrice ? formatCurrency(promoPrice) : null
        };
      }

      // Show price range
      if (promoPrice && Array.isArray(promoPrice)) {
        const [minPromo, maxPromo] = promoPrice;
        return {
          original: `${formatCurrency(minOriginal)} - ${formatCurrency(maxOriginal)}`,
          promo: `${formatCurrency(minPromo)} - ${formatCurrency(maxPromo)}`
        };
      }

      return {
        original: `${formatCurrency(minOriginal)} - ${formatCurrency(maxOriginal)}`,
        promo: null
      };
    }

    // Single price
    return {
      original: formatCurrency(originalPrice),
      promo: promoPrice ? formatCurrency(promoPrice) : null
    };
  };

  const handleBack = () => {
    clearData();
    router.push('/promotions/mobile');
  }

  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <PromoPageHeader title={t('detailPromosi')} onBack={handleBack} />

      {/* <div className="flex overflow-hidden relative gap-2.5 items-start px-4 py-3.5 text-base font-bold text-white bg-[#C22716] shadow-sm min-h-[62px]">
        <div className="flex z-0 gap-2 items-center min-h-[34px] w-full">
          <ImageComponent loading="lazy"
            src="https://cdn.builder.io/api/v1/image/assets/60cdcdaf919148d9b5b739827a6f5b2a/647318cf9ecbe7081985e31c8cacc069a16df0dd482ff83876056a17127089c7"
            alt=""
            className="object-contain shrink-0 self-stretch my-auto w-6 aspect-square"
          />
          <div className="self-stretch my-auto">Detail Promosi</div>
        </div>
        <ImageComponent loading="lazy"
          src="https://cdn.builder.io/api/v1/image/assets/60cdcdaf919148d9b5b739827a6f5b2a/43babc38ee2e65f33331fa62ec640e6301b8f368ea3b8442c59cf97c91fe0ed0"
          alt=""
          className="object-contain absolute right-0 bottom-0 z-0 shrink-0 aspect-[2.47] h-[62px] w-[153px]"
        />
      </div> */}

      <div className="flex overflow-auto flex-col">
        {/* Banner Section */}
        <div className="flex relative flex-col items-center px-4 py-6 bg-white">
          {/* Background Header Extension */}
          <div className="flex absolute top-0 left-0 z-0 bg-[#770000] w-full h-[73px]" />

          <div className="z-0 w-[328px]">
            <PromoBanner
              name={promoData.name}
              promoData={promoData}
            />
          </div>

          <div className="w-[328px]">
            <PromoInfo
              promo={promoData}
              isEditable={isEditable}
              onEdit={() => router.push(`/promotions/mobile/${params.id}/edit`)}
            />
          </div>
        </div>

        {/* Search and Actions */}
        <div className="flex flex-col p-4 w-full bg-white border-b border-solid border-b-stone-300">
          {/* Search Field */}
          <Input
            type="text"
            placeholder={t('cariNamaProdukSKU')}
            value={searchQuery}
            changeEvent={(e) => { setSearchQuery(e.target.value) }}
            onKeyPress={(e) => { setSearchQuery(e.target.value) }}
            icon={{
              left: '/promo/icons/grey/Search.svg'
            }}
            width={{ width: '100%' }}
            text={{
              right: searchQuery ? (
                <button
                  onClick={() => { setSearchQuery('') }}
                  className="flex items-center justify-center w-4 h-4"
                >
                  <ImageComponent
                    src="/promo/icons/grey/silang.svg"
                    className="w-4 h-4"
                    alt="Clear search"
                  />
                </button>
              ) : null
            }}
          />

          {/* <div className="flex gap-2 items-center px-3 py-2 w-full bg-white rounded-md border border-solid border-neutral-500 min-h-[32px] text-neutral-500">
            <ImageComponent loading="lazy"
              src="https://cdn.builder.io/api/v1/image/assets/60cdcdaf919148d9b5b739827a6f5b2a/6e6abbc4b9c1f810b3cae54e15abccfd0e44316dc39983af57ad13ea9efb0916"
              alt=""
              className="object-contain shrink-0 self-stretch my-auto w-4 aspect-square"
            />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari nama produk/SKU"
              className="flex-1 shrink self-stretch my-auto basis-0 bg-transparent border-none outline-none"
            />
          </div> */}

          {/* Select All Section - Only show when mass edit is active */}
          {massEdit ? (
            <div className="flex items-center mt-4">
              <label className="flex items-center gap-2 text-black">
                <input
                  type="checkbox"
                  checked={allSelected}
                  onChange={(e) => handleSelectAll(e.target.checked)}
                  className="w-4 h-4 rounded border-neutral-500"
                />
                <span className="text-sm font-normal">Pilih Semua</span>
              </label>
              <button
                onClick={() => setMassEdit(false)}
                className="ml-auto text-sm text-red-500"
              >
                Batal
              </button>
            </div>
          ) : (
            /* Only show Atur Promosi section when not in mass edit mode */
            isEditable && (
              <div className="flex justify-between items-center mt-4">
                <span className="text-sm font-semibold text-black">Atur Promosi</span>
                <button
                  onClick={handleMassEdit}
                  className="text-sm font-semibold text-[var(--primary-700)]"
                >
                  Atur Massal
                </button>
              </div>
            )
          )}
        </div>
        {/* Product List */}
        <div className="flex-1 bg-[var(--neutral-100)]">
          {filteredProducts.length > 0 ? (
            <div className="flex flex-col mt-2">
              {filteredProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={{
                    ...product,
                    displayPrice: getDisplayPrice(product.price, product.promotion?.promoPrice)
                  }}
                  isEditable={isEditable}
                  onAction={() => handleProductAction(product)}
                  massEdit={massEdit}
                  isSelected={selectedProducts.has(product.id)}
                  onSelect={(selected) => handleProductSelect(product.id, selected)}
                />
              ))}
            </div>
          ) : (
            // MP 22: LB - 0178
            <div className="flex flex-col items-center justify-center py-12">
              <ImageComponent
                src="/promo/img/not_found.png"
                alt={t('labelTidakAdaData')}
                className="object-contain max-w-full aspect-[1.16] w-[142px] mb-4"
              />
              <p className="text-gray-500 text-lg font-semibold">
                {searchQuery
                  ? t('keywordTidakDitemukan')
                  : `${t('dataTidakDitemukan')}\n${t('mohonCobaHapusBeberapaFilter')}`}
              </p>
            </div>

            // <div className="flex flex-col items-center justify-center p-16">
            //   <ImageComponent src="https://cdn.builder.io/api/v1/image/assets/TEMP/abcd16345e93117408182b57eb7890ffbf37f54e4d2d4086cb98f8e4fcde7e54"
            //     alt="No results"
            //     className="w-28 h-28 mb-4"
            //   />
            //   <p className="text-center text-[var(--neutral-500)]">
            //     Keyword tidak ditemukan
            //   </p>
            // </div>
          )}
        </div>
      </div>

      {/* Mass Edit Button */}
      {massEdit && selectedProducts.size > 0 && (
        <div className="fixed bottom-0 left-0 right-0 p-4 bg-white border-t">
          <button
            onClick={() => setShowMassEditSheet(true)}
            className="w-full py-3 rounded-full font-medium bg-[var(--primary-700)] text-white"
          >
            Atur {selectedProducts.size} Produk Sekaligus
          </button>
        </div>
      )}

      {/* Mass Edit Sheet */}
      <MassEditBottomSheet
        isOpen={showMassEditSheet}
        onClose={() => setShowMassEditSheet(false)}
        selectedCount={selectedProducts.size}
        purchaseLimit={promoData.purchaseLimit}
        onSubmit={handleMassEditSubmit}
      />

      {/* Toast */}
      {showToast && (
        <Toast />
      )}
      {/* <ToastApp
        show={showToast}
        text={toastMessage}
        status={toastMessage.includes('Berhasil') ? 'success' : 'error'}
        timer={3000}
        onClose={() => setShowToast(false)}
      /> */}
    </div>
  );
}


