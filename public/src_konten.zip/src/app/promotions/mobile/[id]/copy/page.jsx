// src/app/promotions/[id]/copy/page.jsx
// all baris file ini fixing untuk:
// 24. THP 2 - MOD001 - MP - 022 - QC Plan - Web - MuatParts - Promo
// LB - 0163
// LB - 0165
// LB - 0169
// LB - 0172

'use client';

import React, { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import { useCustomRouter } from '@/libs/CustomRoute';
import { useLanguage } from '@/providers/LanguageProvider';
import NavbarCount from '@/components/NavbarCount/NavbarCount';
import PromoFormPage from '@/components/Promotions/Mobile/PromoFormPage/PromoFormPage';
import ToastApp from '@/components/ToastApp/ToastApp';
import Modal from '@/components/Modals/ModalComponent';
import Button from '@/components/Button/Button';
import { usePromoForm } from '@/hooks/usePromoForm';
import ImageComponent from '@/components/ImageComponent/ImageComponent';
import PromoPageHeader from '@/components/Promotions/Mobile/PromoPageHeader/PromoPageHeader';
import Toast from '@/components/Toast/Toast';
import toast from '@/store/zustand/toast';

const PromoCopyPage = () => {
  const { id } = useParams();
  const router = useCustomRouter();
  const { t } = useLanguage();
  const [showExitConfirm, setShowExitConfirm] = useState(false);
  // const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const [toastStatus, setToastStatus] = useState('success');
  const { showToast, setShowToast, setDataToast } = toast();

  // Use the enhanced hook with 'copy' mode
  const { loading, formData, originalPromo, submit } = usePromoForm('basic', 'copy', id);

  // Prepare initial values for the form
  const initialValues = formData?.basicInfo ? {
    name: formData.basicInfo.promoName,
    startDate: formData.basicInfo.startDate,
    endDate: formData.basicInfo.endDate,
    purchaseLimit: formData.basicInfo.purchaseLimit
  } : null;

  const handleBack = () => {
    setShowExitConfirm(true);
  };

  const handleSubmit = async (data) => {
    try {
      const success = await submit(data);
      if (success) {
        setDataToast({
          type: 'success',
          message: t('berhasilMenyimpanPromosi')
        });
        setToastStatus('success');
        setShowToast(true);

        // Short delay before redirecting
        setTimeout(() => {
          router.push('/promotions');
        }, 1500);
      }
    } catch (error) {
      setDataToast({
        type: 'error',
        message: 'Gagal menyimpan promosi'
      });

      // setToastStatus('error');
      setShowToast(true);
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {/* Header */}
      <PromoPageHeader title={t('buatPromosi')} onBack={handleBack} />

      {/* Form */}
      <PromoFormPage
        initialValues={initialValues}
        onSubmit={handleSubmit}
        onBack={handleBack}
        loading={loading}
        mode='copy'
      >
        {/* Additional content - Product preview */}
        {originalPromo && originalPromo.products && originalPromo.products.length > 0 && (
          <div className="mt-6 border-t pt-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold mb-3">{t('labelProduk')}</h3>
              <div className="flex items-center gap-2 mb-3 text-primary-700">
                <ImageComponent
                  src="/promo/icons/blue/Tambah.svg"
                  alt="Back"
                  className="w-5 h-5"
                />
                <h3 className="text-sm font-semibold">{t('labelTambah')}</h3>            
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              {originalPromo.products.slice(0, 5).map((product, index) => (
                <div key={product.id} className="w-[72px] h-[72px] relative rounded-md overflow-hidden border border-gray-200">
                  <ImageComponent
                    src={product.imageUrl || '/api/placeholder/80/80'}
                    width={72}
                    height={72}
                    alt={product.name}
                    className="object-cover h-[72px] w-[72px]"
                  />
                  {index == originalPromo.products.length-1 && (
                    <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
                      <button 
                        onClick={() => router.push(`/promotions/${id}/products`)}
                        className="text-white text-xs font-medium p-3"
                      >
                        {t('lihatSemua') || 'Lihat Semua'}
                      </button>
                    </div>
                  )}
                </div>
              ))}
              {originalPromo.products.length > 5 && (
                <div className="w-12 h-12 bg-gray-100 flex items-center justify-center rounded-md border border-gray-200 text-xs font-medium text-gray-600">
                  +{originalPromo.products.length - 5}
                </div>
              )}
            </div>
          </div>
        )}
      </PromoFormPage>

      {/* Exit Confirmation Modal */}
      <Modal
        isOpen={showExitConfirm}
        setIsOpen={setShowExitConfirm}
        hideHeader={true}
        type="Modal"
      >
        <div className="flex flex-col items-center gap-6 p-4">
          <h3 className="text-lg font-medium text-gray-900">
            {t('batalkanSalinPromosi') || 'Batalkan Salin Promosi?'}
          </h3>
          <p className="text-sm text-gray-500">
            {t('dataPromosiTidakAkanDisimpan') || 'Data promosi yang sudah diisi tidak akan tersimpan'}
          </p>
          <div className="flex gap-4 w-full">
            <Button
              color="primary_secondary"
              onClick={() => setShowExitConfirm(false)}
              Class="flex-1"
            >
              {t('labelBatal') || 'Tidak'}
            </Button>
            <Button
              color="primary"
              onClick={() => router.push(`/promotions/${id}`)}
              Class="flex-1"
            >
              {t('labelYa') || 'Ya'}
            </Button>
          </div>
        </div>
      </Modal>

      {/* Toast */}
      {showToast &&
        <Toast />
      }

      {/* <ToastApp
        show={showToast}
        text={toastMessage}
        status={toastStatus}
        timer={3000}
        onClose={() => setShowToast(false)}
      /> */}
    </div>
  );
};

export default PromoCopyPage;