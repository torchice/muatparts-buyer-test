/*
* page.jsx v1.0.0
* /app/promotions/mobile/[id]/variant/[productId]/page.jsx
*
* Page for managing variant product promotions with VariantDiscountForm component
*/
'use client'

import React, { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import { useCustomRouter } from '@/libs/CustomRoute';
import promoMockService from '@/services/MockServer_Promotion';
import Toast from '@/components/Toast/Toast';
import toast from '@/store/zustand/toast';
import VariantDiscountForm from '@/components/Promotions/Mobile/VariantDiscountForm/VariantDiscountForm';
import {
  formatNumber,
  parseNumber
} from '@/components/Promotions/NumberFormatter';

const VariantPromoPage = () => {
  const { id, productId } = useParams();
  const router = useCustomRouter();
  const [loading, setLoading] = useState(true);
  const [promoData, setPromoData] = useState(null);
  const [product, setProduct] = useState(null);
  const [variants, setVariants] = useState([]);
  const [errors, setErrors] = useState({});
  const [validateTrigger, setValidateTrigger] = useState(false);
  const [showExitConfirm, setShowExitConfirm] = useState(false);
  const { showToast, setShowToast, setDataToast } = toast();

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const response = await promoMockService.getPromoById(id);
        if (!response.Data) {
          throw new Error('Promosi tidak ditemukan');
        }

        setPromoData(response.Data);
        const foundProduct = response.Data.products.find(p => p.id.toString() === productId);
        if (!foundProduct) {
          throw new Error('Produk tidak ditemukan');
        }

        setProduct(foundProduct);

        // Initialize variants with promotion data if exists
        const initialVariants = foundProduct.variants.map(variant => ({
          ...variant,
          isActive: variant.isActive !== false, // Default to true if not explicitly false
          quota: formatNumber(variant.promotion?.quota) || '',
          purchaseLimit: formatNumber(variant.promotion?.purchaseLimit) || '',
          discountValue: formatNumber(variant.promotion?.discount) || '',
          promoPrice: formatNumber(variant.promotion?.promoPrice) || '',
          isValid: variant.promotion?.isValid !== false // Default to true if not explicitly false
        }));
        setVariants(initialVariants);
      } catch (error) {
        console.error('Failed to fetch data:', error);
        setDataToast({
          type: 'error',
          message: error.message || 'Gagal memuat data'
        });
        setShowToast(true);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [id, productId]);

  // Validate variants after errors change
  useEffect(() => {
    if (validateTrigger) {
      const submitAfterValidate = async () => {
        setValidateTrigger(false);

        // Update variant validity based on errors
        setVariants(prev => prev.map(v => ({
          ...v,
          isValid: !Object.values(errors[v.id] || {}).some(a => a != '')
        })));

        // Check if there are any errors
        const hasErrors = Object.keys(errors).some(key =>
          Object.keys(errors[key] || {}).length > 0
        );

        if (!hasErrors) {
          await handleSubmitToApi();
        } else {
          setDataToast({
            type: 'error',
            message: 'Ada yang harus kamu sesuaikan!'
          });
          setShowToast(true);
        }
      };

      submitAfterValidate();
    }
  }, [errors]);

  const handleBack = () => {
    setShowExitConfirm(true);
  };

  const handleSubmitToApi = async () => {
    try {
      // Prepare the payload with the correct structure
      const payload = {
        id: promoData.id,
        promoName: promoData.name,
        startDate: promoData.startDate,
        endDate: promoData.endDate,
        purchaseLimit: promoData.purchaseLimit,
        selectedProducts: promoData.products.map(p => {
          // Base product payload
          const productPayload = {
            id: p.id,
          };

          // Handle variants if this is the current product
          if (p.id.toString() === productId) {
            productPayload.variants = variants.map(v => ({
              variantId: v.id,
              isActive: !(v.isActive === false),
              quota: parseNumber(v.quota),
              purchaseLimit: parseNumber(v.purchaseLimit),
              promoPrice: parseNumber(v.promoPrice),
              discount: parseNumber(v.discountValue),
              price: v.price,
              stock: v.stock,
            }));
          } 
          // Preserve existing variants for other products
          else if (p.variants && p.variants.length > 0) {
            productPayload.variants = p.variants.map(v => ({
              variantId: v.id,
              isActive: v.isActive !== false,
              quota: v.promotion?.quota || null,
              purchaseLimit: v.promotion?.purchaseLimit || null,
              promoPrice: v.promotion?.promoPrice || null,
              discount: v.promotion?.discount || null,
              price: v.price,
              stock: v.stock,
            }));
          }
          // Handle non-variant products
          else if (p.promotion) {
            productPayload.quota = p.promotion.quota;
            productPayload.purchaseLimit = p.promotion.purchaseLimit;
            productPayload.promoPrice = p.promotion.promoPrice;
            productPayload.discount = p.promotion.discount;
            productPayload.price = p.price[0];
            productPayload.stock = p.stock;
          }

          return productPayload;
        })
      };

      const response = await promoMockService.savePromotion(payload);

      setDataToast({
        type: 'success',
        message: 'Promosi berhasil diperbarui'
      });
      setShowToast(true);

      // Redirect back after success
      setTimeout(() => {
        router.back();
      }, 1500);
    } catch (error) {
      console.error('Failed to update promotion:', error);
      setDataToast({
        type: 'error',
        message: 'Gagal memperbarui promosi'
      });
      setShowToast(true);
    }
  };

  const handleSubmit = (updatedVariants) => {
    setVariants(updatedVariants);
    setValidateTrigger(true);
  };

  return (
    <>
      <VariantDiscountForm
        title="Ubah Promosi"
        product={product}
        initialVariants={variants}
        purchaseLimitType={promoData?.purchaseLimit}
        errors={errors}
        setErrors={setErrors}
        validateTrigger={validateTrigger}
        onBack={handleBack}
        onSubmit={handleSubmit}
        showConfirm={showExitConfirm}
        setShowConfirm={setShowExitConfirm}
        isLoading={loading || !product}
      />
      {showToast && <Toast />}
    </>
  );
};

export default VariantPromoPage;