// src/app/promotions/mobile/[id]/product/[productId]/page.jsx
'use client'
import React, { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import { useCustomRouter } from '@/libs/CustomRoute';
import promoMockService from '@/services/MockServer_Promotion';
import ToastApp from '@/components/ToastApp/ToastApp';
import ProductDiscountForm from '@/components/Promotions/Mobile/ProductDiscountForm/ProductDiscountForm';
import Toast from '@/components/Toast/Toast';
import toast from '@/store/zustand/toast';
import {
  formatNumber,
  cleanNumber,
  parseNumber,
  handleNumberKeyDown,
  handleNumberPaste
} from '@/components/Promotions/NumberFormatter';

const ProductPromoPage = () => {
  const { id, productId } = useParams();
  const router = useCustomRouter();
  const [loading, setLoading] = useState(true);
  const [promoData, setPromoData] = useState(null);
  const [product, setProduct] = useState(null);
  const [discountData, setDiscountData] = useState({
    promoPrice: '',
    discountValue: '',
    quota: '',
    purchaseLimit: ''
  });
  const [errors, setErrors] = useState({});
  const [showExitConfirm, setShowExitConfirm] = useState(false);
  // const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const [validateTrigger, setValidateTrigger] = useState(false);
  const [maxDiscount, setMaxDiscount] = useState(60);
  const { showToast, setShowToast, setDataToast } = toast();

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const response = await promoMockService.getPromoById(id);
        if (!response.Data) {
          throw new Error('Promosi tidak ditemukan');
        }

        setPromoData(response.Data);
        const foundProduct = response.Data.products.find(p => p.id.toString() === productId);
        if (!foundProduct) {
          throw new Error('Produk tidak ditemukan');
        }

        setProduct(foundProduct);
        // Pre-fill form if product has existing promotion data
        if (foundProduct.promotion) {
          setDiscountData({
            promoPrice: formatNumber(foundProduct.promotion.promoPrice) || '',
            discountValue: formatNumber(foundProduct.promotion.discount) || '',
            quota: formatNumber(foundProduct.promotion.quota) || '',
            purchaseLimit: formatNumber(foundProduct.promotion.purchaseLimit) || ''
          });
        }
      } catch (error) {
        console.error('Failed to fetch data:', error);
        // setToastMessage(error.message || 'Gagal memuat data');
        // setShowToast(true);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [id, productId]);

  useEffect(() => {
    const submitAfterValidate = async () => {
      setValidateTrigger(false);
      if (Object.keys(errors.productDiscount || {}).length > 0) {
        return;
      }
      try {
        // Prepare the payload with the correct structure
        console.log('promoData', promoData)
        console.log('discountData', discountData)
        const payload = {
          id: promoData.id,
          promoName: promoData.name,
          startDate: promoData.startDate,
          endDate: promoData.endDate,
          purchaseLimit: promoData.purchaseLimit,
          selectedProducts: promoData.products.map(p => {
            const productPayload = {
              id: p.id,
              variants: p.variants.length>0 ? p.variants.map(v => ({
                ...v,
                variantId: v.id,
                isActive: v.isActive ?? true,
                quota: v.promotion?.quota || null,
                purchaseLimit: v.promotion?.purchaseLimit || null,
                promoPrice: v.promotion?.promoPrice || null,
                discount: v.promotion?.discountValue || null
              })) : undefined
            };
            if (p.variants.length == 0) {
              productPayload.price = p.price[0];
              productPayload.stock = p.stock;
            }

            // Only update the current product
            if (p.id.toString() === productId) {
              if (p.variants.length == 0) {
                console.log('aaa')
                productPayload.quota = parseNumber(discountData.quota);
                productPayload.purchaseLimit = parseNumber(discountData.purchaseLimit);
                productPayload.promoPrice = parseNumber(discountData.promoPrice);
                productPayload.discount = parseNumber(discountData.discountValue);
              }
            } else if (p.promotion) {
              // For other products without variants, preserve their existing promotion data
              if (p.variants.length == 0) {
                productPayload.quota = p.promotion.quota;
                productPayload.purchaseLimit = p.promotion.purchaseLimit;
                productPayload.promoPrice = p.promotion.promoPrice;
                productPayload.discount = p.promotion.discountValue;
              }
            }

            return productPayload;
          })
        };

        const response = await promoMockService.savePromotion(payload);

        setDataToast({
          type: 'success',
          message: 'Promosi berhasil diperbarui'
        });
        setShowToast(true);

        // Redirect back after success
        setTimeout(() => {
          router.back();
        }, 1500);
      } catch (error) {
        console.error('Failed to update promotion:', error);
      }
    }

    if (validateTrigger) {
      submitAfterValidate()
    }
  }, [errors]);

  const handleBack = () => {
    setShowExitConfirm(true);
  };

  const handleSubmit = async (submitedDiscountData) => {
    setDiscountData(submitedDiscountData);
    setValidateTrigger(true);

    if (Object.keys(errors.productDiscount || {}).length > 0) {
      return;
    }
  };

  return (
    <>
      <ProductDiscountForm
        title="Ubah Promosi"
        product={product}
        initialDiscount={discountData}
        purchaseLimitType={promoData?.purchaseLimit}
        errors={errors}
        setErrors={setErrors}
        validateTrigger={validateTrigger}
        onBack={handleBack}
        onSubmit={handleSubmit}
        showConfirm={showExitConfirm}
        setShowConfirm={setShowExitConfirm}
        isLoading={loading || !product}
      />
      {showToast && <Toast />}
    </>
  );
};

export default ProductPromoPage;