'use client';

import React, { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import NavbarCount from '@/components/NavbarCount/NavbarCount';
import BasicInfoForm from '@/components/Promotions/PromoForm/BasicInfoForm';
import ProductDiscountForm from '@/components/Promotions/PromoForm/ProductDiscountForm';
import ToastApp from '@/components/ToastApp/ToastApp';
import { promoService } from '@/services/promoService';
import promoMockService from '@/services/MockServer_Promotion';
import { useCustomRouter } from '@/libs/CustomRoute';
import PromoFormPage from '@/components/Promotions/Mobile/PromoFormPage/PromoFormPage';
import { usePromoForm } from '@/hooks/usePromoForm';

const PromoEditPage = () => {
  const { id } = useParams();
  const router = useCustomRouter();
  const [loading, setLoading] = useState(true);
  const [promoData, setPromoData] = useState(null);
  const [currentStep, setCurrentStep] = useState('info'); // 'info' | 'products'
  const [showExitConfirm, setShowExitConfirm] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const [timezone, setTimezone] = useState('WIB');
  const { convertPromoData } = usePromoForm('basic', 'edit', id);

  useEffect(() => {
    const fetchPromoDetails = async () => {
      setLoading(true);
      try {
        const response = await promoMockService.getPromoById(id);
        const timezoneRes = await promoMockService.getUserTimezone();

        setTimezone(timezoneRes.Data.timezone.name);
        setPromoData(response.Data);
      } catch (error) {
        console.error('Failed to fetch promo details:', error);
        setToastMessage('Gagal memuat data promosi');
        setShowToast(true);
      } finally {
        setLoading(false);
      }
    };

    fetchPromoDetails();
  }, [id]);

  const formatDate = (dateString) => {
    try {
      const date = new Date(dateString.replace('Z', ''));
      return format(date, 'dd MMM yyyy HH:mm') + ' ' + timezone;
    } catch (error) {
      return dateString;
    }
  };

  const handleBack = () => {
    setShowExitConfirm(true);
  };

  const handleExit = () => {
    router.push(`/promotions/mobile/${id}`);
  };

  const handleBasicInfoSubmit = async (data) => {
    console.log('handleBasicInfoSubmit', data)
    const promoDataPayload = convertPromoData({
      ...promoData,
      ...data
    }, 'promoGetData', 'promoSaveData');
    console.log('aaa')
    try {
      // Update only basic info
      console.log('promoDataPayload', promoDataPayload)
      await promoMockService.savePromotion({
        id: id,
        ...promoDataPayload
      });

      setToastMessage('Informasi promosi berhasil diperbarui');
      setShowToast(true);

      setTimeout(() => {
        router.push(`/promotions/mobile/${id}`);
      }, 1500);
    } catch (error) {
      console.log('errorrrr')
      console.log(error)
      // setToastMessage(error.message || 'Gagal memperbarui promosi');
      // setShowToast(true);
    }
    console.log('tesss a33')
  };

  const handleDiscountSubmit = async (productsData) => {
    try {
      // Update products data
      await promoMockService.updatePromotion(id, {
        ...promoData,
        products: productsData
      });

      setToastMessage('Promosi berhasil diperbarui');
      setShowToast(true);

      setTimeout(() => {
        router.push(`/promotions/mobile/${id}`);
      }, 1500);
    } catch (error) {
      setToastMessage(error.message || 'Gagal memperbarui promosi');
      setShowToast(true);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col min-h-screen">
        <NavbarCount
          title="Ubah Promosi"
          subtitle={currentStep === 'info' ? "Informasi Promosi" : "Daftar Produk"}
          backAction={handleBack}
          count={1}
          active={1}
        />
        <div className="flex-1 p-4">
          <div className="animate-pulse space-y-4">
            <div className="h-10 bg-gray-200 rounded w-3/4"></div>
            <div className="h-10 bg-gray-200 rounded"></div>
            <div className="h-10 bg-gray-200 rounded w-1/2"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!promoData) {
    return (
      <div className="flex flex-col min-h-screen">
        <NavbarCount
          title="Ubah Promosi"
          subtitle="Error"
          backAction={handleBack}
          count={1}
          active={1}
        />
        <div className="flex flex-col items-center justify-center p-8">
          <p className="text-gray-500">Promosi tidak ditemukan</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {/* Header */}
      <NavbarCount
        title="Ubah Promosi"
        subtitle={currentStep === 'info' ? "Informasi Promosi" : "Daftar Produk"}
        backAction={handleBack}
        count={1}
        active={1}
      />

      {/* Form Content */}
      {/* // MP 22: LB - 0184 */}
      {currentStep === 'info' ? (
        <PromoFormPage
          initialValues={{
            name: promoData.name,
            startDate: new Date(promoData.startDate.replace('Z', '')),
            endDate: new Date(promoData.endDate.replace('Z', '')),
            purchaseLimit: promoData.purchaseLimit
          }}
          onSubmit={handleBasicInfoSubmit}
          onBack={handleBack}
          loading={loading}
        />
      ) : (
        <ProductDiscountForm
          products={promoData.products}
          purchaseLimit={promoData.purchaseLimit}
          onSubmit={handleDiscountSubmit}
          onBack={handleBack}
        />
      )}

      {/* Exit Confirmation Modal */}
      {showExitConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-20 flex items-center justify-center">
          <div className="bg-white rounded-lg p-6 m-4 max-w-sm w-full">
            <h3 className="text-lg font-medium text-gray-900 mb-4">
              Batalkan perubahan?
            </h3>
            <p className="text-sm text-gray-500 mb-6">
              Perubahan yang belum disimpan akan hilang
            </p>
            <div className="flex gap-4">
              <button
                onClick={() => setShowExitConfirm(false)}
                className="flex-1 py-2 px-4 border border-gray-300 rounded-lg"
              >
                Tidak
              </button>
              <button
                onClick={handleExit}
                className="flex-1 py-2 px-4 bg-primary-700 text-white rounded-lg"
              >
                Ya
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Toast */}
      <ToastApp
        show={showToast}
        text={toastMessage}
        status="success"
        timer={3000}
        onClose={() => setShowToast(false)}
      />
    </div>
  );
};

export default PromoEditPage;


