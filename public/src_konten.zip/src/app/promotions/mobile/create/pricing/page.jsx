// src/app/promotions/mobile/create/pricing/page.jsx
// all baris file ini fixing untuk:
// 24. THP 2 - MOD001 - MP - 022 - QC Plan - Web - MuatParts - Promo
// LB - 0163
// LB - 0165
// LB - 0169
// LB - 0172

'use client'

import React, { useEffect, useState } from 'react';
import { useLanguage } from '@/providers/LanguageProvider';
import { useCustomRouter } from '@/libs/CustomRoute';
import NavbarCount from '@/components/NavbarCount/NavbarCount';
import Input from '@/components/Input/Input';
import ImageComponent from '@/components/ImageComponent/ImageComponent';
import ToastApp from '@/components/ToastApp/ToastApp';
import AturMassalPopup from '@/components/Promotions/PromoForm/AturMassalPopup';
import { usePromoForm } from '@/hooks/usePromoForm';
import Button from '@/components/Button/Button';
import promoService from '@/services/MockServer_Promotion';
import ModalComponent from '@/components/Modals/ModalComponent';
import { MassEditBottomSheet } from '@/components/Promotions/Mobile/PromoDetail/MassEditBottomSheet';
import Toast from '@/components/Toast/Toast';
import toast from '@/store/zustand/toast';
import usePromoCreateStore from '@/store/zustand/promoCreateStore';

const formatNumber = (value) => {
  if (!value) return '';
  return new Intl.NumberFormat('id-ID').format(value);
};

const ProductCard = ({
  product,
  onEditClick,
  massEdit,
  selected,
  onSelect,
  onDelete,
  maxDiscount = 60
}) => {
  const { t } = useLanguage();
  const { formData: formDataFromHook, isProductValid, isAnyPromoFieldEmpty, convertPromoData } = usePromoForm('pricing');
  const [formData, setFormData] = useState(formDataFromHook);

  const hasVariants = product.variants && product.variants.length > 0;
  const priceDisplay = hasVariants ?
    `Rp${formatNumber(product.price[0])}-Rp${formatNumber(product.price[1])}` :
    `Rp${formatNumber(product.price[0])}`;

  useEffect(() => {
    if (formDataFromHook) {
      setFormData(formDataFromHook);
    }
  }, [formDataFromHook]);


  // Check if variant has valid promotions set
  const hasValidPromotion = () => {
    return isProductValid(product.id);
    // return validatePromoValues([product.id], { maxDiscount: maxDiscount, purchaseLimit: formData.basicInfo?.purchaseLimit })
    // const productDiscount = formData.productDiscounts[product.id];

    // if (hasVariants) {
    //   // For variant products, check if variants have promotions set
    //   return productDiscount?.variants &&
    //     Object.values(productDiscount.variants).some(v => v.isValid === true);
    // } else {
    //   // For regular products
    //   return productDiscount?.isValid === true;
    // }
  };

  return (
    <div className="flex overflow-hidden flex-col bg-white border-b border-solid border-neutral-200">
      <div className="flex p-4 w-full">
        {massEdit && (
          <div className="pr-3 pt-2">
            <input
              type="checkbox"
              checked={selected}
              onChange={(e) => onSelect(e.target.checked)}
              className="h-5 w-5 rounded border-gray-300"
            />
          </div>
        )}

        <div className="flex flex-col flex-1">
          <div className="flex gap-3 w-full">
            <ImageComponent
              src={product.imageUrl || "/api/placeholder/68/68"}
              alt={product.name}
              className="object-contain shrink-0 rounded aspect-square w-[68px] h-[68px]"
            />

            <div className="flex flex-col flex-1 min-w-0">
              <div className="text-sm font-bold leading-4 text-black line-clamp-2">
                {product.name}
              </div>

              <div className="mt-3 text-xs font-medium text-black">
                {t('labelSKU')}: {product.sku || '-'}
              </div>

              <div className="mt-3 text-xs font-medium text-black">
                {priceDisplay}
              </div>

              <div className="flex gap-3 items-center mt-3">
                <div className="text-xs font-medium text-black">
                  {t('labelStok')}: {product.stock}
                </div>
                {hasVariants && (
                  <div className="px-2 py-2 text-sm font-semibold text-primary-700 bg-blue-50 rounded-md">
                    {product.variants.length} {t('labelVarian')}
                  </div>
                )}
              </div>

              {!massEdit && (
                <div className="flex gap-3 items-center mt-3">
                  <button
                    onClick={() => onEditClick(product)}
                    className="flex-1 px-6 py-2.5 text-xs font-semibold text-primary-700 bg-white rounded-3xl border border-primary-700"
                  >
                    {!isAnyPromoFieldEmpty(product.id) ? t('labelUbah') : t('aturDiskon')}
                  </button>
                  <button
                    className="p-2"
                    onClick={(e) => {
                      e.stopPropagation();
                      onDelete(product.id);;
                    }}
                  >
                    <ImageComponent
                      src="/promo/icons/red/Delete.svg"
                      alt={t('labelHapus')}
                      width={24}
                      height={24}
                    />
                  </button>
                </div>
              )}

            </div>
          </div>
          {!hasValidPromotion() && (
            <div className="flex items-center gap-[4px] px-[8px] py-[4px] bg-[#FFF9C1] rounded-md w-fit mt-2">
              <ImageComponent
                src="/promo/icons/orange/invalid_warning.svg"
                width={16}
                height={16}
                alt="Warning"
              />
              <span className="text-[#FF7A00] font-semibold text-sm">
                {t('adaYangHarusKamuSesuaikan')}
              </span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const PricingPage = () => {
  const { t } = useLanguage();
  const router = useCustomRouter();

  // State management
  const { formData: formDataFromHook, resetForm, validatePromoValues, convertPromoData } = usePromoForm('pricing');
  const { submit } = usePromoForm('bulk-pricing');
  const [formData, setFormData] = useState(formDataFromHook);
  const { submit: submitProducts } = usePromoForm('products');
  const {
    submitBasicInfo,
    submitProductSelection,
    submitPricing,
    updateProductPricing,
    bulkUpdatePricing,
    getFormData,
    reset
  } = usePromoCreateStore();

  const [searchQuery, setSearchQuery] = useState('');
  const [massEdit, setMassEdit] = useState(false);
  const [selectedProducts, setSelectedProducts] = useState(new Set());
  const [showMassEditPopup, setShowMassEditPopup] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [maxDiscount, setMaxDiscount] = useState(60);

  // Change from derived value to proper state
  const [filteredProducts, setFilteredProducts] = useState([]);

  useEffect(() => {
    const fetchConfig = async () => {
      try {
        const maxDiscountData = await promoService.getMaxDiscount();
        if (maxDiscountData?.Data?.maxDiscount) {
          setMaxDiscount(maxDiscountData.Data.maxDiscount);
        }
      } catch (error) {
        console.error("Failed to fetch configuration:", error);
      }
    };

    fetchConfig();
  }, []);

  // Update filtered products whenever formData or searchQuery changes
  useEffect(() => {
    if (formData && formData.products) {
      const filtered = formData.products.filter(product =>
        product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.sku.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setFilteredProducts(filtered);
    }
  }, [formData, searchQuery]);

  const { showToast, setShowToast, setDataToast } = toast();

  // Update local formData when hook data changes
  useEffect(() => {
    if (formDataFromHook) {
      setFormData(formDataFromHook);
    }
  }, [formDataFromHook]);

  useEffect(() => {
    console.log('Selected products:', selectedProducts);
  }, [selectedProducts])

  // useEffect(() => {
  //   console.log('Form data:', formData);

  //   if (formData) {
  //     // Check for variant data when loading product
  //     const productsWithVariants = formData.products.map(product => {
  //       if (product.variants && formData.productDiscounts[product.id]?.variants) {
  //         return {
  //           ...product,
  //           variants: product.variants.map(variant => ({
  //             ...variant,
  //             promotion: formData.productDiscounts[product.id].variants[variant.id]
  //           }))
  //         };
  //       }
  //       return product;
  //     });

  //     console.log('Products with variants:', productsWithVariants);
  //   }
  // }, [formData]); //// unused

  const handleProductSelect = (productId, selected) => {
    const newSelected = new Set(selectedProducts);
    if (selected) {
      newSelected.add(productId);
    } else {
      newSelected.delete(productId);
    }
    setSelectedProducts(newSelected);
  };

  const handleMassEdit = (data) => {
    console.log('Mass edit data:', data);

    // Format data for bulk update
    const bulkUpdateData = {
      productIds: Array.from(selectedProducts),
      discount: {
        promoPrice: data.promoPrice,
        discountValue: data.discountValue,
        quota: data.quota,
        purchaseLimit: data.purchaseLimit,
        isValid: true,
        applyToVariants: true
      }
    };

    // Use the bulk-pricing handler to update products without final submission
    submit(bulkUpdateData);

    // Close popup and reset selection
    setShowMassEditPopup(false);
    setMassEdit(false);
    setSelectedProducts(new Set());

    const isValidAll = validatePromoValues(Array.from(selectedProducts), { maxDiscount: maxDiscount, purchaseLimit: formData.basicInfo?.purchaseLimit })

    // Show success toast
    // setDataToast({
    //   type: 'success',
    //   message: `Berhasil menerapkan perubahan ke ${selectedProducts.size} produk`
    // });
    // setShowToast(true);
  };

  // MP 22: LB - 0170
  const handleDeleteProduct = async (productId) => {
    // Filter out the selected product
    const updatedProducts = formData.products.filter(product => product.id !== productId);

    // If only one product would remain, redirect to product selection page
    if (updatedProducts.length < 1) {
      // Update localStorage before redirecting
      const currentFormData = JSON.parse(localStorage.getItem('promoFormData'));
      const newFormData = {
        ...currentFormData,
        products: updatedProducts,
        productDiscounts: { ...currentFormData.productDiscounts }
      };

      // Remove the deleted product's discount data
      delete newFormData.productDiscounts[productId];

      localStorage.setItem('promoFormData', JSON.stringify(newFormData));

      // Redirect to product selection page
      router.push('/promotions/mobile/create/products');
      return;
    }

    // Update Zustand store and localStorage via hook
    const updatedFormData = await submitProducts(updatedProducts, false);

    // Manually update local formData state to trigger re-renders
    setFormData(updatedFormData);

    // Update filtered products directly to ensure immediate UI update
    const filteredUpdated = updatedProducts.filter(product =>
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.sku.toLowerCase().includes(searchQuery.toLowerCase())
    );
    setFilteredProducts(filteredUpdated);
  };

  const handleSave = () => {
    console.log('formDataa', formData)
    // Check if all products have valid discounts
    const invalidProducts = formData.products.filter(product => {
      const productDiscount = formData.productDiscounts[product.id];

      if (!productDiscount) return true; // Invalid if no discount data

      if (product.variants && product.variants.length > 0) {
        // For products with variants
        if (!productDiscount.variants) return true;

        // Check if at least one variant is active and valid
        const hasValidVariant = Object.values(productDiscount.variants)
          .some(variant => variant.isActive && variant.isValid);

        return !hasValidVariant;
      } else {
        // For products without variants
        return !productDiscount.isValid;
      }
    });

    if (invalidProducts.length > 0) {
      console.log('Invalid products details:', invalidProducts.map(p => ({
        id: p.id,
        name: p.name,
        hasVariants: p.variants && p.variants.length > 0,
        discountData: formData.productDiscounts[p.id]
      })));

      setDataToast({
        type: 'success',
        message: `${invalidProducts.length} produk perlu disesuaikan`
      });
      setShowToast(true);
      return;
    }

    setShowConfirm(true);
  };

  const handleEditClick = (product) => {
    // Check if product has variants
    if (product.variants && product.variants.length > 0) {
      const hasPromotions = formData.productDiscounts[product.id]?.variants &&
        Object.values(formData.productDiscounts[product.id].variants).some(v => v.isValid);

      const buttonText = hasPromotions ? 'Ubah' : 'Atur diskon';      // Route to variant form (page 14)
      router.push(`/promotions/mobile/create/pricing/variant/${product.id}`);
    } else {
      // Route to regular product form (page 13)
      router.push(`/promotions/mobile/create/pricing/product/${product.id}`);
    }
  };

  const handleSaveConfirmed = async () => {
    try {
      setIsSaving(true);

      // Format data according to API contract
      // const promoData = {
      //   promoName: formData.basicInfo.promoName,
      //   startDate: formData.basicInfo.startDate,
      //   endDate: formData.basicInfo.endDate,
      //   purchaseLimit: formData.basicInfo.purchaseLimit,
      //   selectedProducts: formData.products.map(product => {
      //     const discount = formData.productDiscounts[product.id];

      //     if (product.variants && product.variants.length > 0) {
      //       // Format variant products
      //       return {
      //         id: product.id,
      //         variants: Object.entries(discount.variants).map(([variantId, variantDiscount]) => {
      //           let variantObj = product.variants.filter(variant => variantId == variant.id)[0];
      //           return {
      //             variantId,
      //             isActive: variantDiscount.isActive,
      //             quota: parseInt(variantDiscount.quota),
      //             purchaseLimit: parseInt(variantDiscount.purchaseLimit),
      //             promoPrice: parseInt(variantDiscount.promoPrice),
      //             discount: parseInt(variantDiscount.discountValue),
      //             price: variantObj.price,
      //             stock: variantObj.stock
      //           }
      //         })
      //       };
      //     } else {
      //       // Format regular products
      //       return {
      //         id: product.id,
      //         quota: parseInt(discount.quota),
      //         purchaseLimit: parseInt(discount.purchaseLimit),
      //         promoPrice: parseInt(discount.promoPrice),
      //         discount: parseInt(discount.discountValue),
      //         price: product.price[0],
      //         stock: product.stock
      //       };
      //     }
      //   })
      // };

      const promoData = convertPromoData(formData)
      console.log('promoData', promoData)
      // Call mockserver save function
      const response = await promoService.savePromotion(promoData);

      if (response.Message.Code === 200) {
        // Show success toast
        setDataToast({
          type: 'success',
          message: t('berhasilMenyimpanPromo')
        });
        setShowToast(true);

        // Clear form data using the hook's submit
        await resetForm();

        // Wait for toast before redirecting
        setTimeout(() => {
          router.push('/promotions/mobile');
        }, 1500);
      } else {
        throw new Error('Failed to save promotion');
      }
    } catch (error) {
      console.error('Error saving promotion:', error);
      setDataToast({
        type: 'success',
        message: 'Gagal menyimpan promo'
      });
      setShowToast(true);
    } finally {
      setIsSaving(false);
      setShowConfirm(false);
    }
  };

  return (
    <div className="flex overflow-hidden flex-col w-full min-h-screen bg-slate-50">
      <div className="fixed top-0 left-0 right-0 z-10 w-full bg-[var(--muat-parts-non-900)]">
        <NavbarCount
          title={t('buatPromosi')}
          subtitle={t('daftarProdukPromosi')}
          backAction={() => router.push('/promotions/mobile/create/products')}
          count={2}
          active={2}
          classname={'!w-full'}
        />
      </div>

      <div className="flex flex-col flex-1 overflow-auto pt-[96px] pb-[72px] bg-zinc-100">
        <div className="flex flex-col p-4 bg-white border-b border-stone-300">
          <Input
            type="text"
            placeholder={t('cariNamaProdukSKU')}
            value={searchQuery}
            changeEvent={(e) => setSearchQuery(e.target.value)}
            icon={{
              left: '/promo/icons/grey/Search.svg',
              right: searchQuery ? '/promo/icons/grey/Circle Cross.svg' : ''
            }}
            rightIconClick={() => setSearchQuery('')}
            classInput="bg-transparent"
          />

          {filteredProducts.length > 1 && (
            <div className="flex justify-between items-center mt-4">
              <div className="text-sm font-semibold text-black">
                {t('aturPromosi')}
              </div>
              <button
                onClick={() => {
                  setMassEdit(!massEdit);
                  setSelectedProducts(new Set());
                }}
                className="text-sm font-semibold text-primary-700"
              >
                {massEdit ? t('labelBatal') : t('aturMassal')}
              </button>
            </div>
          )}
        </div>

        <div className="flex flex-col w-full">
          {filteredProducts.map(product => (
            <ProductCard
              key={product.id}
              product={product}
              discount={formData.productDiscounts[product.id]}
              onEditClick={() => handleEditClick(product)}
              massEdit={massEdit}
              selected={selectedProducts.has(product.id)}
              onSelect={(selected) => handleProductSelect(product.id, selected)}
              onDelete={handleDeleteProduct}  // Pass the delete handler
              maxDiscount={maxDiscount}  // Pass max discount to ProductCard
            />
          ))}
        </div>
      </div>

      {!massEdit && (
        <div className="fixed bottom-0 left-0 right-0 z-10">
          <div className="flex flex-col px-4 py-3 bg-white shadow-[0px_-3px_55px_rgba(0,0,0,0.161)]">
            <div className="flex gap-2 w-full">
              <Button
                onClick={() => router.push('/promotions/mobile/create/products')}
                color="primary_secondary"
                Class="flex-1 !max-w-none w-1/2"
              >
                {t('labelSebelumnya')}
              </Button>
              <Button
                onClick={handleSave}
                color="primary"
                Class="flex-1 !max-w-none w-1/2"
              >
                {t('labelSimpan')}
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Mass Edit Button */}
      {massEdit && selectedProducts.size > 0 && (
        <div className="fixed bottom-0 left-0 right-0 z-10 px-4 py-3 bg-white">
          <Button
            onClick={() => setShowMassEditPopup(true)}
            color="primary"
            Class="w-full !max-w-none"
          >
            {t('labelAtur')}({selectedProducts.size}) {t('produkSekaligus')}
          </Button>
        </div>
      )}

      {/* Popups and Modals */}
      {showMassEditPopup && (
        <MassEditBottomSheet
          isOpen={showMassEditPopup}
          onClose={() => setShowMassEditPopup(false)}
          onSubmit={handleMassEdit}
          purchaseLimit={formData.basicInfo.purchaseLimit}
          selectedCount={selectedProducts.size}
        />
      )}

      {/* Save Confirmation */}
      {/* MP 22: LB - 0171 */}
      <ModalComponent
        isOpen={showConfirm}
        onClose={() => setShowConfirm(false)}
        hideHeader={true}
        type="Modal"
      >
        <div className="py-[16px] px-[8px]">
          <div className="mb-[20px] text-center">
            <div className="text-[16px] font-bold text-nautral-900 mb-[16px] leading-[11px]">
              {t('konfirmasiSimpan')}
            </div>
            <div className="text-[14px] font-medium text-nautral-900 leading-[12px]">
              {t('konfirmasiSimpanPromo')}
            </div>
          </div>
          <div className="flex gap-2 justify-center">
            <Button
              onClick={() => setShowConfirm(false)}
              disabled={isSaving}
              color="primary_secondary"
            >
              {t('labelBatal')}
            </Button>
            <Button
              onClick={handleSaveConfirmed}
              disabled={isSaving}
              color='primary'
            >
              {isSaving ? (
                <span className="inline-block animate-spin mr-2">⌛</span>
              ) : null}
              Ya
            </Button>
          </div>
        </div>
      </ModalComponent>

      {/* Toast */}
      <Toast />
    </div>
  );
};

export default PricingPage;