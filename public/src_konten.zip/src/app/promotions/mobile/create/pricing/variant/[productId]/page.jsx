// app/promotions/mobile/create/pricing/variant/[productId]/page.jsx
"use client"

import React, { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import { usePromoForm } from '@/hooks/usePromoForm';
import { useCustomRouter } from '@/libs/CustomRoute';
import { useLanguage } from '@/providers/LanguageProvider';
import VariantDiscountForm from '@/components/Promotions/Mobile/VariantDiscountForm/VariantDiscountForm';
import Toast from "@/components/Toast/Toast";
import toast from "@/store/zustand/toast";
import promoService from "@/services/MockServer_Promotion";

const VariantPromoPage = () => {
  const { productId } = useParams();
  const router = useCustomRouter();
  const { formData, submit, loading, getPromoFieldErrors } = usePromoForm('product-pricing');
  const { t } = useLanguage();

  const [product, setProduct] = useState(null);
  const [variants, setVariants] = useState([]);
  const [errors, setErrors] = useState(getPromoFieldErrors(productId));
  const [validateTrigger, setValidateTrigger] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const { showToast, setShowToast, setDataToast } = toast();

  // Load product data from form state
  useEffect(() => {
    if (!loading && formData) {
      const foundProduct = formData.products.find(p => p.id.toString() === productId);
      if (!foundProduct) {
        router.back();
        return;
      }
      setProduct(foundProduct);

      // Get existing variant promotions from localStorage
      const existingVariants = formData.productDiscounts[productId]?.variants || {};

      // Initialize variants with existing promotion data if available
      const initialVariants = foundProduct.variants.map(variant => ({
        ...variant,
        isActive: existingVariants[variant.id]?.isActive,
        quota: existingVariants[variant.id]?.quota || '',
        purchaseLimit: existingVariants[variant.id]?.purchaseLimit || '',
        discountValue: existingVariants[variant.id]?.discountValue || '',
        promoPrice: existingVariants[variant.id]?.promoPrice || '',
        isValid: existingVariants[variant.id]?.isValid || true
      }));

      setVariants(initialVariants);
    }
  }, [loading, formData, productId]);

  // Validate variants after errors change
  useEffect(() => {
    console.log('Errors:', errors);
    if (validateTrigger) {
      const submitAfterValidate = async () => {
        setValidateTrigger(false);

        // Update variant validity based on errors
        setVariants(prev => prev.map(v => ({
          ...v,
          isValid: !Object.values(errors[v.id] || {}).some(a => a != '')
        })));

        // Check if there are any errors
        const hasErrors = Object.keys(errors).some(key =>
          Object.keys(errors[key] || {}).length > 0
        );

        if (!hasErrors) {
          handleFormSubmit();
        } else {
          setDataToast({
            type: 'error',
            message: t('adaYangHarusKamuSesuaikan')
          });
          setShowToast(true);
        }
      };

      submitAfterValidate();
    }
  }, [errors]);

  const handleBack = () => {
    setShowConfirm(true);
  };

  const handleFormSubmit = async () => {
    // Create variant promotions map
    const variantPromotions = variants.reduce((acc, variant) => ({
      ...acc,
      [variant.id]: {
        isActive: variant.isActive,
        quota: variant.quota,
        purchaseLimit: variant.purchaseLimit,
        promoPrice: variant.promoPrice,
        discountValue: variant.discountValue,
        isValid: true
      }
    }), {});

    // Submit using the hook
    const success = await submit({
      productId,
      discount: {
        variants: variantPromotions
      }
    });

    if (success) {
      setDataToast({
        type: 'success',
        message: 'Berhasil menyimpan pengaturan varian'
      });
      setShowToast(true);

      setTimeout(() => {
        router.push('/promotions/mobile/create/pricing');
      }, 1500);
    } else {
      setDataToast({
        type: 'error',
        message: 'Gagal menyimpan pengaturan varian'
      });
      setShowToast(true);
    }
  };

  const handleSubmit = (updatedVariants) => {
    setVariants(updatedVariants);
    setValidateTrigger(true);
  };

  return (
    <>
      <VariantDiscountForm
        title={variants.length > 0 ? t('ubahPromosi') : t('aturDiskon')}
        product={product}
        initialVariants={variants}
        purchaseLimitType={formData?.basicInfo?.purchaseLimit}
        errors={errors}
        setErrors={setErrors}
        validateTrigger={validateTrigger}
        onBack={handleBack}
        onSubmit={handleSubmit}
        showConfirm={showConfirm}
        setShowConfirm={setShowConfirm}
        isLoading={loading || !product}
      />
      {showToast && <Toast />}
    </>
  );
};

export default VariantPromoPage;