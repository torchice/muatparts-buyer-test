// app/promotions/mobile/create/pricing/product/[productId]/page.jsx
"use client"
import React, { useState, useEffect, useRef } from "react";
import { useParams } from 'next/navigation';
import { usePromoForm } from '@/hooks/usePromoForm';
import { useCustomRouter } from '@/libs/CustomRoute';
import Toast from '@/components/Toast/Toast';
import toast from '@/store/zustand/toast';
import promoService from "@/services/MockServer_Promotion";
import ProductDiscountForm from '@/components/Promotions/Mobile/ProductDiscountForm/ProductDiscountForm';

const ProductDiscountPage = () => {
  const { productId } = useParams();
  const router = useCustomRouter();
  const { formData, submit, loading, getPromoFieldErrors } = usePromoForm('product-pricing');

  const [product, setProduct] = useState(null);
  const [discount, setDiscount] = useState({
    quota: '',
    purchaseLimit: '',
    promoPrice: '',
    discountValue: '',
    isValid: false
  });

  const [showConfirm, setShowConfirm] = useState(false);
  const { showToast, setShowToast, setDataToast } = toast();
  const [maxDiscount, setMaxDiscount] = useState(60);
  const [errors, setErrors] = useState(getPromoFieldErrors(productId));
  const [validateTrigger, setValidateTrigger] = useState(false);

  // Load product data and existing discount if available
  useEffect(() => {
    if (!loading && formData) {
      const foundProduct = formData.products.find(p => p.id.toString() === productId);
      if (!foundProduct) {
        router.back();
        return;
      }
      setProduct(foundProduct);

      const existingDiscount = formData.productDiscounts[productId];
      if (existingDiscount) {
        setDiscount(existingDiscount);
      }
    }
  }, [loading, formData, productId]);

  // Fetch max discount configuration
  useEffect(() => {
    const fetchConfig = async () => {
      try {
        const maxDiscountData = await promoService.getMaxDiscount();
        if (maxDiscountData?.Data?.maxDiscount) {
          setMaxDiscount(maxDiscountData.Data.maxDiscount);
        }
      } catch (error) {
        console.error("Failed to fetch configuration:", error);
      }
    };

    fetchConfig();
  }, []);

  useEffect(() => {
    // MP 22: LB - 0171
    console.log('Errors:', errors);
    const submitAfterValidate = async () => {
      console.log('submitAfterValidate', {
        productId,
        discount: {
          ...discount,
          isValid: true
        }
      });
      setValidateTrigger(false);
      if (Object.keys(errors.productDiscount || {}).length > 0) {
        return;
      }
      // Submit the discount data
      const success = await submit({
        productId,
        discount: {
          ...discount,
          isValid: true
        }
      });

      if (success) {
        router.back();
      } else {
        setDataToast({
          type: 'error',
          message: 'Gagal menyimpan data'
        });
        setShowToast(true);
      }
    }

    if (validateTrigger) {
      submitAfterValidate()
    }
  }, [errors]);

  const handleBack = () => {
    if (JSON.stringify(discount) !== JSON.stringify(formData.productDiscounts[productId])) {
      setShowConfirm(true);
    } else {
      router.back();
    }
  };

  const handleDiscountChange = (newValues) => {
    setDiscount(prev => ({
      ...prev,
      ...newValues,
      isValid: true
    }));
  };
  const handleSubmit = async (discountData) => {
    // Trigger validation in the PromoInputFields component
    setDiscount(discountData)
    setValidateTrigger(true);

    // Check if there are any errors
    if (Object.keys(errors.productDiscount || {}).length > 0) {
      return;
    }
  };

  return (
    <>
      <ProductDiscountForm
        title="Atur Diskon"
        product={product}
        initialDiscount={formData?.productDiscounts?.[productId]}
        purchaseLimitType={formData?.basicInfo?.purchaseLimit}
        maxDiscount={maxDiscount}
        errors={errors}
        setErrors={setErrors}
        validateTrigger={validateTrigger}
        onBack={handleBack}
        onSubmit={handleSubmit}
        showConfirm={showConfirm}
        setShowConfirm={setShowConfirm}
        isLoading={loading || !product}
      />
      {showToast && <Toast />}
    </>
  );
};

export default ProductDiscountPage;