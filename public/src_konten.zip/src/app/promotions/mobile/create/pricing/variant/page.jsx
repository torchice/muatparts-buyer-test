"use client"
import React, { useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import NavbarCount from '@/components/NavbarCount/NavbarCount';
import Input from '@/components/Input/Input';
import ToastApp from '@/components/ToastApp/ToastApp';
import { usePromoForm } from '@/hooks/usePromoForm';
import ImageComponent from '@/components/ImageComponent/ImageComponent'

const formatCurrency = (value) => {
  if (!value) return '';
  return new Intl.NumberFormat('id-ID').format(value);
};

const VariantCard = ({ 
  variant, 
  onChange,
  canToggle,
  purchaseLimit,
  errors = {} 
}) => {
  const calculatePromoPrice = (discountValue) => {
    return Math.floor(variant.price * (1 - discountValue / 100));
  };

  const calculateDiscountValue = (promoPrice) => {
    return Math.floor((1 - promoPrice / variant.price) * 100);
  };

  return (
    <div className={`p-4 border rounded-lg ${!variant.isActive ? 'bg-gray-50' : 'bg-white'}`}>
      {/* Variant Header */}
      <div className="flex items-center justify-between mb-4">
        <div>
          <h4 className="font-medium">{variant.name}</h4>
          <p className="text-sm text-gray-500">SKU: {variant.sku}</p>
          <p className="text-sm font-medium mt-1">Rp{formatCurrency(variant.price)}</p>
          <p className="text-sm text-gray-500">Stok: {variant.stock}</p>
        </div>
        <label className="relative inline-flex items-center cursor-pointer">
          <input
            type="checkbox"
            className="sr-only peer"
            checked={variant.isActive}
            onChange={(e) => onChange({
              ...variant,
              isActive: e.target.checked
            })}
            disabled={!canToggle && variant.isActive}
          />
          <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-700"></div>
        </label>
      </div>

      {variant.isActive && (
        <div className="space-y-4">
          {/* Quota */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Kuota Promosi*
            </label>
            <Input
              type="number"
              placeholder="Contoh: 1"
              value={variant.quota}
              changeEvent={(e) => onChange({
                ...variant,
                quota: e.target.value
              })}
              status={errors.quota ? 'error' : undefined}
              supportiveText={{
                title: errors.quota || '',
                desc: `Min. 1, Maks. ${variant.stock}`
              }}
            />
          </div>

          {/* Purchase Limit */}
          {purchaseLimit !== 'unlimited' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Batas Pembelian*
              </label>
              <Input
                type="number"
                placeholder="Contoh: 1"
                value={variant.purchaseLimit}
                changeEvent={(e) => onChange({
                  ...variant,
                  purchaseLimit: e.target.value
                })}
                status={errors.purchaseLimit ? 'error' : undefined}
                supportiveText={{
                  title: errors.purchaseLimit || '',
                  desc: `Min. 1, Maks. ${variant.quota || variant.stock}`
                }}
              />
            </div>
          )}

          {/* Discount Type Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Jenis Diskon*
            </label>
            <div className="flex gap-4">
              <button
                onClick={() => onChange({
                  ...variant,
                  discountType: 'price',
                  discountValue: '',
                  promoPrice: ''
                })}
                className={`flex-1 py-2 px-4 rounded-lg border ${
                  variant.discountType === 'price'
                    ? 'border-primary-700 text-primary-700'
                    : 'border-gray-300'
                }`}
              >
                Harga Promo
              </button>
              <button
                onClick={() => onChange({
                  ...variant,
                  discountType: 'percentage',
                  discountValue: '',
                  promoPrice: ''
                })}
                className={`flex-1 py-2 px-4 rounded-lg border ${
                  variant.discountType === 'percentage'
                    ? 'border-primary-700 text-primary-700'
                    : 'border-gray-300'
                }`}
              >
                Diskon (%)
              </button>
            </div>
          </div>

          {/* Discount Value Input */}
          {variant.discountType === 'price' ? (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Harga Promo*
              </label>
              <Input
                type="text"
                placeholder="Contoh: 100.000"
                value={formatCurrency(variant.promoPrice)}
                changeEvent={(e) => {
                  const value = parseInt(e.target.value.replace(/\D/g, ''));
                  onChange({
                    ...variant,
                    promoPrice: value,
                    discountValue: calculateDiscountValue(value)
                  });
                }}
                status={errors.promoPrice ? 'error' : undefined}
                text={{left: 'Rp'}}
                supportiveText={{
                  title: errors.promoPrice || '',
                  desc: `Min. Rp${formatCurrency(Math.floor(variant.price * 0.4))}`
                }}
              />
            </div>
          ) : variant.discountType === 'percentage' ? (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Persentase Diskon*
              </label>
              <Input
                type="number"
                placeholder="0"
                value={variant.discountValue}
                changeEvent={(e) => {
                  const value = parseInt(e.target.value);
                  onChange({
                    ...variant,
                    discountValue: value,
                    promoPrice: calculatePromoPrice(value)
                  });
                }}
                status={errors.discountValue ? 'error' : undefined}
                text={{right: '%'}}
                supportiveText={{
                  title: errors.discountValue || '',
                  desc: variant.promoPrice ? `Rp${formatCurrency(variant.promoPrice)}` : ''
                }}
              />
            </div>
          ) : null}

          {/* Error Message */}
          {!variant.isValid && (
            <div className="p-3 bg-red-50 text-red-700 rounded-lg text-sm">
              Harga tidak sesuai ketentuan. Silakan sesuaikan kembali.
            </div>
          )}
        </div>
      )}
    </div>
  );
};

const VariantDiscountPage = () => {
  const { productId } = useParams();
  const router = useRouter();
  const { formData, submit } = usePromoForm('pricing');
  
  // Find product and its current discount data
  const product = formData.products.find(p => p.id.toString() === productId);
  const initialDiscount = formData.productDiscounts[productId] || {
    variants: product?.variants?.map(v => ({
      ...v,
      isActive: true,
      quota: '',
      purchaseLimit: '',
      discountType: null,
      discountValue: '',
      promoPrice: '',
      isValid: false
    })) || []
  };

  const [discount, setDiscount] = useState(initialDiscount);
  const [showConfirm, setShowConfirm] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState('');

  const handleVariantChange = (updatedVariant) => {
    const variants = discount.variants.map(v => 
      v.id === updatedVariant.id ? updatedVariant : v
    );
    setDiscount({ ...discount, variants });
  };

  // Count active variants
  const activeVariants = discount.variants.filter(v => v.isActive).length;
  
  const handleSave = () => {
    // Validate at least one variant is active
    if (activeVariants === 0) {
      setToastMessage('Minimal satu varian harus aktif');
      setShowToast(true);
      return;
    }

    // Save variant discounts
    const updatedDiscounts = {
      ...formData.productDiscounts,
      [productId]: {
        ...discount,
        isValid: true
      }
    };

    submit({
      ...formData,
      productDiscounts: updatedDiscounts
    });

    router.back();
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <NavbarCount
        title="Atur Diskon"
        subtitle={product?.name}
        backAction={() => setShowConfirm(true)}
        count={3}
        active={3}
      />

      <div className="p-4 space-y-4">
        {/* Product Card */}
        <div className="bg-white p-4 rounded-lg">
          <div className="flex gap-4">
            <ImageComponent src={product?.imageUrl || "/placeholder.png"} 
              alt={product?.name}
              className="w-20 h-20 object-cover rounded-lg"
            />
            <div>
              <h3 className="font-medium">{product?.name}</h3>
              <p className="text-sm text-gray-500">SKU: {product?.sku}</p>
              <div className="mt-1">
                <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                  {product?.variants?.length} Varian
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Variant List */}
        <div className="space-y-4">
          {product?.variants?.map((variant) => (
            <VariantCard
              key={variant.id}
              variant={discount.variants.find(v => v.id === variant.id)}
              onChange={handleVariantChange}
              canToggle={activeVariants > 1}
              purchaseLimit={formData.basicInfo.purchaseLimit}
            />
          ))}
        </div>
      </div>

      {/* Bottom Actions */}
      <div className="sticky bottom-0 bg-white border-t p-4 mt-auto">
        <button
          onClick={handleSave}
          className="w-full py-3 bg-primary-700 text-white rounded-lg font-medium"
        >
          Terapkan
        </button>
      </div>

      {/* Confirmation Modal */}
      {showConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-20 flex items-center justify-center">
          <div className="bg-white rounded-lg p-6 m-4 max-w-sm w-full">
            <h3 className="text-lg font-medium text-gray-900 mb-4">
              Batalkan perubahan?
            </h3>
            <p className="text-sm text-gray-500 mb-6">
              Perubahan yang belum disimpan akan hilang
            </p>
            <div className="flex gap-4">
              <button
                onClick={() => setShowConfirm(false)}
                className="flex-1 py-2 px-4 border border-gray-300 rounded-lg"
              >
                Tidak
              </button>
              <button
                onClick={() => router.back()}
                className="flex-1 py-2 px-4 bg-primary-700 text-white rounded-lg"
              >
                Ya
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Toast */}
      <ToastApp
        show={showToast}
        text={toastMessage}
        status="error"
        timer={3000}
        onClose={() => setShowToast(false)}
      />
    </div>
  );
};

export default VariantDiscountPage;
