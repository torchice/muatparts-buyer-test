// src/app/promotions/mobile/create/products/page.jsx
'use client';

import React, { useEffect, useState } from 'react';
import { useCustomRouter } from '@/libs/CustomRoute';
import { useLanguage } from '@/providers/LanguageProvider';
import ProductSelectionForm from '@/components/Promotions/PromoForm/ProductSelectionForm';
import ToastApp from '@/components/ToastApp/ToastApp';
import usePromoCreateStore from '@/store/zustand/promoCreateStore';
import { usePromoForm } from '@/hooks/usePromoForm';
import PromoPageHeader from '@/components/Promotions/Mobile/PromoPageHeader/PromoPageHeader';
import ModalComponent from '@/components/Modals/ModalComponent';

const SelectProductsPage = () => {
  const router = useCustomRouter();
  const { t } = useLanguage();

  // Store state
  const { submitProductSelection, formData: storeFormData, loading: storeLoading, error: storeError } = usePromoCreateStore();

  // Form state with localStorage
  const { loading: formLoading, formData, submit } = usePromoForm('products');

  // UI state
  const [showExitConfirm, setShowExitConfirm] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const basicInfo = formData?.basicInfo || {};
  const startDate = basicInfo.startDate ? new Date(basicInfo.startDate) : null;
  const endDate = basicInfo.endDate ? new Date(basicInfo.endDate) : null;

  const handleBack = () => {
    setShowExitConfirm(true);
  };

  const handleSubmit = async (selectedProducts) => {
    try {
      const success = await submitProductSelection(selectedProducts);
      if (success) {
        await submit(selectedProducts);
        router.push('/promotions/mobile/create/pricing');
      }
    } catch (error) {
      setToastMessage(error?.message || storeError || t('gagalMenyimpanProduk'));
      setShowToast(true);
    }
  };

  // Show loading state if either store or form is loading
  if (formLoading || storeLoading) {
    return (
      <div className="flex flex-col min-h-screen">
        {/* Header */}
        <PromoPageHeader
          title={t('pilihProduk')}
          onBack={handleBack}
        />

        <div className="flex-1 p-4">
          <div className="animate-pulse space-y-4">
            <div className="h-32 bg-gray-200 rounded-lg"></div>
            <div className="h-32 bg-gray-200 rounded-lg"></div>
            <div className="h-32 bg-gray-200 rounded-lg"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {/* Header */}
      <PromoPageHeader
        title={t('pilihProduk')}
        onBack={handleBack}
      />

      <ProductSelectionForm
        startDate={startDate}
        endDate={endDate}
        onSubmit={handleSubmit}
        onBack={handleBack}
        loading={storeLoading}
        error={storeError}
      />

      {/* Exit Confirmation Modal */}
      {showExitConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-20 flex items-center justify-center">
          <div className="bg-white rounded-lg p-6 m-4 max-w-sm w-full">
            <h3 className="text-lg font-medium text-gray-900 mb-4">
              Batalkan Pilih Produk?
            </h3>
            <p className="text-sm text-gray-500 mb-6">
              Perubahan yang belum disimpan akan hilang
            </p>
            <div className="flex gap-4">
              <button
                onClick={() => setShowExitConfirm(false)}
                className="flex-1 py-2 px-4 border border-gray-300 rounded-lg"
              >
                Tidak
              </button>
              <button
                onClick={() => router.push('/promotions/mobile/create')}
                className="flex-1 py-2 px-4 bg-primary-700 text-white rounded-lg"
              >
                Ya
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Toast */}
      <ToastApp
        show={showToast}
        text={toastMessage}
        status="error"
        timer={3000}
        onClose={() => setShowToast(false)}
      />
    </div>
  );
};

export default SelectProductsPage;





