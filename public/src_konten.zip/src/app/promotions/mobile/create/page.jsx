// src/app/promotions/mobile/create/page.jsx
// all baris file ini fixing untuk:
// 24. THP 2 - MOD001 - MP - 022 - QC Plan - Web - MuatParts - Promo
// LB : 0163, 0165, 0172

'use client';

import React, { useState } from 'react';
import { useCustomRouter } from '@/libs/CustomRoute';
import { useLanguage } from '@/providers/LanguageProvider';
import NavbarCount from '@/components/NavbarCount/NavbarCount';
import PromoFormPage from '@/components/Promotions/Mobile/PromoFormPage/PromoFormPage';
import usePromoCreateStore from '@/store/zustand/promoCreateStore';
import { usePromoForm } from '@/hooks/usePromoForm';
import ToastApp from '@/components/ToastApp/ToastApp';
import Toast from '@/components/Toast/Toast';
import toast from '@/store/zustand/toast';

const CreatePromoPage = () => {
  const { t } = useLanguage();
  const router = useCustomRouter();
  const { submitBasicInfo, loading: storeLoading, error: storeError } = usePromoCreateStore();
  const { loading: formLoading, formData, submit } = usePromoForm('basic', 'create');
  
  const [showExitConfirm, setShowExitConfirm] = useState(false);
  // const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const { showToast, setShowToast, setDataToast } = toast();

  // Prepare initial values from form data if available
  const initialValues = formData?.basicInfo ? {
    name: formData.basicInfo.promoName,
    startDate: formData.basicInfo.startDate,
    endDate: formData.basicInfo.endDate,
    purchaseLimit: formData.basicInfo.purchaseLimit
  } : null;

  const handleBack = () => setShowExitConfirm(true);

  const handleSubmit = async (data) => {
    try {
      // First update the store
      const storeSuccess = await submitBasicInfo({
        promoName: data.name,
        startDate: data.startDate,
        endDate: data.endDate,
        purchaseLimit: data.purchaseLimit
      });
      
      if (!storeSuccess) {
        throw new Error(storeError || t('gagalMenyimpanData'));
      }
      
      // Then use the form hook to handle localStorage and navigation
      const formSuccess = await submit(data);
      
      if (!formSuccess) {
        throw new Error(t('gagalMenyimpanData'));
      }

      // Navigation is handled by the hook
    } catch (error) {
      setToastMessage(error.message || t('gagalMenyimpanData'));
      setShowToast(true);
    }
  };

  const loading = formLoading || storeLoading;

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <div className="fixed top-0 left-0 right-0 z-10 bg-white">
        <NavbarCount
          title={t('buatPromosi')}
          subtitle={t('informasiPromosi')}
          backAction={handleBack}
          count={2}
          active={1}
          classname="w-full"
        />
      </div>

      <div className="mt-[100px]">
        <PromoFormPage
          initialValues={initialValues}
          onSubmit={handleSubmit}
          onBack={handleBack}
          loading={loading}
        />
      </div>

      {/* Exit Confirmation */}
      {showExitConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-20 flex items-center justify-center">
          <div className="bg-white rounded-lg p-6 m-4 max-w-sm w-full">
            <h3 className="text-lg font-medium text-gray-900 mb-4">
              {t('konfirmasiKamuPindahHalaman')}
            </h3>
            <p className="text-sm text-gray-500 mb-6">
              {t('dataPromosiTidakAkanDisimpan')}
            </p>
            <div className="flex gap-4">
              <button
                onClick={() => setShowExitConfirm(false)}
                className="flex-1 py-2 px-4 border border-gray-300 rounded-lg"
              >
                {t('labelNo')}
              </button>
              <button
                onClick={() => router.push('/promotions')}
                className="flex-1 py-2 px-4 bg-primary-700 text-white rounded-lg"
              >
                {t('labelYa')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Toast */}
      {showToast && 
        <Toast />
      }
      
      {/* <ToastApp
        show={showToast}
        text={toastMessage}
        status="error"
        timer={3000}
        onClose={() => setShowToast(false)}
      /> */}
    </div>
  );
};

export default CreatePromoPage;