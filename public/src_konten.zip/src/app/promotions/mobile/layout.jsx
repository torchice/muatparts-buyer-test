// app/daftaretalase/detail/[id]/layout.jsx
// app/daftaretalase/edit/[id]/layout.jsx
// app/daftaretalase/susunproduk/layout.jsx

// all baris file ini fixing untuk:
// 24. THP 2 - MOD001 - MP - 022 - QC Plan - Web - MuatParts - Promo
// LB : 0163, 0165, 0172

'use client';
import { LanguageProvider } from "@/providers/LanguageProvider";
import React, { useEffect } from 'react';
import headerZustand from "@/store/zustand/header";
import toast from "@/store/zustand/toast";


export default function Layout({ children }) {
  const { setShowNavMenu } = toast()
  const { setHeader } = headerZustand()

  useEffect(() => {
    setShowNavMenu(false)
    setHeader('false')
  }, [])

  return (
    <>
      {/* //24. THP 2 - MOD001 - MP - 008 - QC Plan - Web - MuatParts - Paket 012 A - Seller - Daftar Etalase - LB - 0207 */}
      <div className="fixed top-0 w-full h-[100vh] overflow-auto layout-mobile">
        {children}
      </div>
    </>
  );
}