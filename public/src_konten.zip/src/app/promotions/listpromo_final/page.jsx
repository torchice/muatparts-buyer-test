"use client"
import React, { useState, useEffect } from 'react';
import { TopBar } from '@/components/headersellercomponents/TopBar';
import SidebarWithDropdown from '@/components/headersellercomponents/SidebarWithDropdown';
import { PromoTable } from '../components/PromoList/PromoTable';
import { MockServer_Promo } from '@/services/MockServer_Promo';

export default function PromosiPenjual() {
  const [activeTab, setActiveTab] = useState('active');
  const [promos, setPromos] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [tabCounts, setTabCounts] = useState({ active: 0, history: 0 });
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    fetchPromos();
  }, [activeTab]);

  const fetchPromos = async () => {
    try {
      setIsLoading(true);
      const response = await MockServer_Promo.getPromotionsList({
        tab: activeTab,
        search: searchQuery,
      });
      if (response && response.Data) {
        setPromos(response.Data.promos || []);
        setTabCounts(response.Data.tabCounts || { active: 0, history: 0 });
      }
    } catch (error) {
      console.error('Error fetching promos:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <TopBar />
      
      <aside className="fixed top-[56px] left-0 w-[184px] bg-white shadow-sm">
        <SidebarWithDropdown />
      </aside>

      <main className="ml-[184px] pt-14">
        <div className="p-6">
          <div className="max-w-[1040px]">
            <h1 className="text-xl font-bold text-black">
              Promosi Penjual
            </h1>

            {/* Tabs */}
            <div className="mt-4 border-b border-gray-200">
              <div className="flex gap-4">
                <button
                  onClick={() => setActiveTab('active')}
                  className={`px-4 py-2 -mb-px text-sm font-medium ${
                    activeTab === 'active'
                      ? 'text-blue-600 border-b-2 border-blue-600'
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                >
                  Daftar Promosi ({tabCounts?.active || 0})
                </button>
                <button
                  onClick={() => setActiveTab('history')}
                  className={`px-4 py-2 -mb-px text-sm font-medium ${
                    activeTab === 'history'
                      ? 'text-blue-600 border-b-2 border-blue-600'
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                >
                  Riwayat ({tabCounts?.history || 0})
                </button>
              </div>
            </div>

            {/* Table or Empty State */}
            <div className="mt-6">
              <PromoTable
                promos={promos}
                isLoading={isLoading}
                activeTab={activeTab}
                onSearch={setSearchQuery}
                onCreate={() => {
                  // Handle create promotion
                  console.log('Create promotion clicked');
                }}
              />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}





