
import Notifikasi from './Notifikasi';

function Page() {
    return (
        <div className='w-full'>
            <Notifikasi />
        </div>
    );
}

export default Page;
  