"use client";
import { useEffect, useRef, useState } from "react";
import style from "./Notifikasi.module.scss";
import { MoreVertical, CircleCheck } from "lucide-react";
import Button from "@/components/Button/Button";
import IconComponent from "@/components/IconComponent/IconComponent";
import DataNotFound from "@/components/DataNotFound/DataNotFound";
import ConfigUrl from "@/services/baseConfig";

function NotifikasiWeb(sharedProps) {
  const {
    menuItems,
    subCategories,
    selectedSubCategory,
    notificationData,
    onMenuClick,
    onSubCategoryClick,
    onPageChange,
    onMarkAllRead,
    onMarkAsRead,
    onToggleUnread,
    t,
  } = sharedProps;
  const { get, put } = ConfigUrl();

  const [selectedMenu, setSelectedMenu] = useState(0);
  const [activePopover, setActivePopover] = useState(null);
  const [activeFilter, setActiveFilter] = useState("all");

  const headerPopoverRef = useRef(null);
  const headerButtonRef = useRef(null);
  const notificationPopoverRefs = useRef({});
  const notificationButtonRefs = useRef({});

  const generatePaginationNumbers = (currentPage, totalPages) => {
    let pages = [1];
    if (currentPage > 3) pages.push("...");
    for (
      let i = Math.max(2, currentPage - 1);
      i <= Math.min(totalPages - 1, currentPage + 1);
      i++
    ) {
      if (!pages.includes(i)) pages.push(i);
    }
    if (currentPage < totalPages - 2) pages.push("...");
    if (totalPages > 1 && !pages.includes(totalPages)) pages.push(totalPages);
    return pages;
  };

  const handleNotificationClick = async (notification, e) => {
    // Jika click berasal dari popover menu, abaikan
    if (e.target.closest(".notification-popover")) {
      return;
    }

    try {
      // Cek jika notifikasi belum dibaca
      if (notification.isNew) {
        // Hit API read notification
        const result = await put({
          path: `v1/muatparts/notifications/${notification.id}/read`,
        });

        // Jika berhasil mark as read
        if (result?.data?.Message?.Code === 200) {
          // Refresh data notifikasi
          await get({
            path: `v1/muatparts/notifications${notificationParams}`,
          });
        }
      }

      // Setelah proses mark as read selesai atau jika sudah read, lakukan redirect
      if (notification?.additional_information?.deeplink) {
        const decodedUrl = decodeURIComponent(
          notification.additional_information.deeplink
        );
        window.location.href = decodedUrl;
      }
    } catch (error) {
      console.error("Error handling notification click:", error);
      // Jika gagal mark as read, tetap redirect
      if (notification?.additional_information?.deeplink) {
        const decodedUrl = decodeURIComponent(
          notification.additional_information.deeplink
        );
        window.location.href = decodedUrl;
      }
    }
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (activePopover === "header") {
        if (
          !headerPopoverRef.current?.contains(event.target) &&
          !headerButtonRef.current?.contains(event.target)
        ) {
          setActivePopover(null);
        }
        return;
      }

      if (typeof activePopover === "number") {
        const popoverRef = notificationPopoverRefs.current[activePopover];
        const buttonRef = notificationButtonRefs.current[activePopover];
        if (
          !popoverRef?.contains(event.target) &&
          !buttonRef?.contains(event.target)
        ) {
          setActivePopover(null);
        }
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [activePopover]);

  return (
    <div className="flex min-h-screen bg-gray-100 px-[72px] py-[34px]">
      <div className="sticky top-[34px] h-fit">
        <div className="w-64 bg-white shadow-muat h-fit p-3 rounded-lg">
          {menuItems?.map((item, idx) => (
            <div
              key={item.id}
              onClick={() => {
                setSelectedMenu(item.id);
                onMenuClick(item);
              }}
              className={`flex justify-between items-center px-4 py-3 cursor-pointer text-sm ${
                selectedMenu === item.id
                  ? "text-[#CF2E1D] font-bold bg-[#FFEAEC] !border-none"
                  : "text-[#868686] font-semibold"
              } ${idx !== menuItems.length - 1 ? "border-b" : ""}`}
            >
              <span>{item.title || item.categoryName}</span>
              {item.count > 0 && (
                <span className="bg-[#CF2E1D] text-white text-xs px-2 py-1 rounded-full">
                  {item.count}
                </span>
              )}
            </div>
          ))}
        </div>
      </div>

      <div className="flex-1 pl-8 overflow-y-auto">
        <div className="bg-white rounded-lg shadow px-3">
          <div className="flex justify-between items-center pt-3 pb-6 relative">
            <h2 className="text-base font-bold">{t("titleNotifications")}</h2>
            <div className="flex items-center gap-3">
              <Button
                Class="flex items-center gap-1 !text-xs !font-semibold !h-6 !w-fit"
                color="primary_secondary"
                onClick={onMarkAllRead}
              >
                <IconComponent src="/icons/crosscheck.svg" />
                {t("buttonMarkAllRead")}
              </Button>

              <button
                ref={headerButtonRef}
                onClick={() =>
                  setActivePopover((prev) =>
                    prev === "header" ? null : "header"
                  )
                }
              >
                <MoreVertical color={"#1b1b1b"} className="w-5 h-5" />
              </button>
              {activePopover === "header" && (
                <div
                  ref={headerPopoverRef}
                  className="absolute right-0 top-12 w-[225px] bg-white rounded-md shadow-lg z-20 border"
                >
                  <div
                    className="flex items-center justify-between hover:bg-gray-50 py-3 px-[10px] rounded cursor-pointer"
                    onClick={() => {
                      setActiveFilter("all");
                      onToggleUnread(false);
                      setActivePopover(null);
                    }}
                  >
                    <span className="font-medium text-xs text-neutral-900">
                      {t("buttonShowNotification")}
                    </span>
                    {activeFilter === "all" && (
                      <CircleCheck size={16} color="#176cf7" />
                    )}
                  </div>
                  <div
                    className="flex items-center justify-between hover:bg-gray-50 py-3 px-2 rounded cursor-pointer"
                    onClick={() => {
                      setActiveFilter("unread");
                      onToggleUnread(true);
                      setActivePopover(null);
                    }}
                  >
                    <span className="font-medium text-xs text-neutral-900">
                      {t("buttonShowUnread")}
                    </span>
                    {activeFilter === "unread" && (
                      <CircleCheck size={16} color="#176cf7" />
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>

          {subCategories?.length > 0 ? (
            <div className="border-b">
              <div className="overflow-x-auto no-scrollbar">
                <div className="flex items-center h-12 gap-8 psx-6">
                  {subCategories.map((subCat) => (
                    <button
                      key={subCat.id}
                      onClick={() => onSubCategoryClick(subCat)}
                      className={`h-full text-xs flex items-center px-2 cursor-pointer relative whitespace-nowrap
              ${
                selectedSubCategory?.id === subCat.id
                  ? "text-[#CF2E1D] border-b-2 border-[#CF2E1D] font-bold"
                  : "text-[#868686] hover:text-[#CF2E1D] font-medium"
              }`}
                    >
                      {subCat.name}
                      {subCat.count > 0 && (
                        <span className="ml-2 bg-[#CF2E1D] text-white text-xs px-1.5 py-0.5 rounded-full">
                          {subCat.count}
                        </span>
                      )}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <hr className="m-0" />
          )}

          <div className="pt-6">
            {notificationData.list.length > 0 ? (
              notificationData.list.map((notification) => (
                <div key={notification.id}>
                  <div
                    className={`p-4 relative ${
                      notification.isNew
                        ? "bg-red-50 border-l-2 border-[#CF2E1D]"
                        : "bg-white"
                    } cursor-pointer`}
                    onClick={(e) => handleNotificationClick(notification, e)}
                  >
                    <div className="flex justify-between">
                      <h3 className="font-semibold text-sm text-neutral-900">
                        {notification.title}
                      </h3>
                      <div className="relative notification-popover">
                        {" "}
                        {/* Tambah class untuk identifier */}
                        <button
                          ref={(el) =>
                            (notificationButtonRefs.current[notification.id] =
                              el)
                          }
                          onClick={(e) => {
                            e.stopPropagation(); // Prevent card click
                            setActivePopover((prev) =>
                              prev === notification.id ? null : notification.id
                            );
                          }}
                        >
                          <MoreVertical
                            // color={notification.isNew ? "#1b1b1b" : "#d7d7d7"}
                            color={"#1b1b1b"}
                            className="w-5 h-5"
                          />
                        </button>
                        {activePopover === notification.id && (
                          <div
                            ref={(el) =>
                              (notificationPopoverRefs.current[
                                notification.id
                              ] = el)
                            }
                            className="absolute right-0 mt-2 bg-white rounded-md shadow-lg z-10 border w-[140px]"
                          >
                            <div className="py-3 px-[10px]">
                              <button
                                className="block w-full text-left text-xs text-neutral-900 font-medium"
                                onClick={(e) => {
                                  e.stopPropagation(); // Prevent card click
                                  onMarkAsRead(notification.id);
                                  setActivePopover(null);
                                }}
                              >
                                {t(
                                  "LelangMuatanTransporterIndexTombolTandaiSudahDibaca"
                                )}
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                    {/* 25. 09 - QC Plan - Web - Imp BO Broadcast, Promo Terkini, View Aktivitas Buyer - LB - 0071 */}
                    <p className="text-[#868686] font-medium text-xs -mt-[2px]" dangerouslySetInnerHTML={{__html: notification.content}}/>
                    <p className="text-[#868686] text-xs font-semibold mt-2">
                      {notification.date}
                    </p>
                  </div>
                  {!notification.isNew && <hr className="m-0" />}
                </div>
              ))
            ) : (
              <div className="text-center py-8">
                <DataNotFound />
              </div>
            )}
          </div>

          {notificationData?.list?.length > 0 && (
            <div className="flex justify-center items-center gap-2 py-4">
              {generatePaginationNumbers(
                notificationData.pagination.currentPage,
                notificationData.pagination.totalPages
              ).map((item, index) =>
                item === "..." ? (
                  <span key={`dot-${index}`} className="text-[#868686] px-1">
                    ...
                  </span>
                ) : (
                  <button
                    key={item}
                    onClick={() => onPageChange(item)}
                    className={`w-8 h-8 rounded-lg text-xs ${
                      notificationData.pagination.currentPage === item
                        ? "bg-[#CF2E1D] text-white font-bold"
                        : "text-[#868686] hover:bg-gray-100 font-semibold"
                    }`}
                  >
                    {item}
                  </button>
                )
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default NotifikasiWeb;
