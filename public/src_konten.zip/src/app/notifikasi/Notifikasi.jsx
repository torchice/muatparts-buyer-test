"use client";
import { viewport } from "@/store/zustand/viewport";
import { useEffect, useState, useMemo } from "react";
import NotifikasiResponsive from "./NotifikasiResponsive";
import NotifikasiWeb from "./NotifikasiWeb";
import SWRHandler from "@/services/useSWRHook";
import toast from "@/store/zustand/toast";
import ConfigUrl from "@/services/baseConfig";
import { useTranslation } from "@/context/TranslationProvider";

const api = process.env.NEXT_PUBLIC_GLOBAL_API;


function Notifikasi() {
  const { t, langReady } = useTranslation();
  const { setShowSidebar } = toast();
  const { isMobile } = viewport();
  const { useSWRHook } = SWRHandler;
  const { get, put, post } = ConfigUrl();

  const [menuItems, setMenuItems] = useState([]);
  const [selectedMenu, setSelectedMenu] = useState(null);
  const [selectedSubCategory, setSelectedSubCategory] = useState(null);
  const [notificationParams, setNotificationParams] = useState("");
  const [notificationData, setNotificationData] = useState({
    list: [],
    pagination: {
      currentPage: 1,
      totalPages: 1,
      totalItems: 0,
      itemsPerPage: 10,
    },
    supportingData: { notReadCount: 0, realCountData: 0, countData: 0 },
  });

  const { data: categoryNotif, mutate: mutateCategoryNotif } = useSWRHook(
    `${api}v1/muatparts/notifications/categories`
  );

  const { data: listNotif } = useSWRHook(
    `${api}v1/muatparts/notifications${
      notificationParams || "?page=1&limit=10"
    }`
  );

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };

  const updateNotificationParams = ({
    categoryId,
    subCategoryId = null,
    page = 1,
    status = null,
  }) => {
    const params = {
      page,
      limit: 10,
      sort: "newest",
    };

    if (categoryId && categoryId !== 0) params.category_id = categoryId;
    if (subCategoryId) params.sub_category_id = subCategoryId;
    if (status) params.status = status && "unread";

    setNotificationParams(`?${new URLSearchParams(params)}`);
  };

  const handleMenuClick = (item) => {
    setSelectedMenu(item);
    setSelectedSubCategory(null);
    scrollToTop();
  };

  const handleSubCategoryClick = (subCategory) => {
    setSelectedSubCategory(subCategory);
    updateNotificationParams({
      categoryId: selectedMenu?.id,
      subCategoryId: subCategory.id,
    });
    scrollToTop();
  };

  const handlePageChange = (page) => {
    updateNotificationParams({
      categoryId: selectedMenu?.id,
      subCategoryId: selectedSubCategory?.id,
      page,
    });
    scrollToTop();
  };

  const handleMarkAllAsRead = async () => {
    try {
      const body = {
        category_id: selectedMenu?.id !== 0 ? selectedMenu?.id : undefined,
        sub_category_id: selectedSubCategory?.id,
      };

      post({
        path: `v1/muatparts/notifications/read-all`,
        data: body,
      }).then((lo) => {
        if (lo?.data?.Message?.Code === 200) {
          get({
            path: `v1/muatparts/notifications${notificationParams}`,
          });
        }
      });
    } catch (error) {
      console.error("Error marking all as read:", error);
    }
  };

  const handleMarkAsRead = async (notificationId) => {
    try {
      put({
        path: `v1/muatparts/notifications/${notificationId}/read`,
      }).then((lo) => {
        if (lo?.data?.Message?.Code === 200) {
          get({
            path: `v1/muatparts/notifications${notificationParams}`,
          }).then((y) => {
            const freshNotifications = y.data.Data;

            setNotificationData({
              list: freshNotifications.notifications.map((notif) => ({
                id: notif.ID,
                title: notif.Judul,
                content: notif.Deskripsi,
                date: notif.time_notif,
                isNew: notif.status_read === 0,
                tipe_action: notif.tipe_action,
                additional_information: notif.additional_information,
              })),
              pagination: {
                currentPage: freshNotifications.pagination.currentPage,
                totalPages: freshNotifications.pagination.totalPages,
                totalItems: freshNotifications.pagination.totalItems,
                itemsPerPage: freshNotifications.pagination.itemsPerPage,
              },
              supportingData: {
                notReadCount: freshNotifications.SupportingData.NotReadCount,
                realCountData: freshNotifications.SupportingData.RealCountData,
                countData: freshNotifications.SupportingData.CountData,
              },
            });

            mutateCategoryNotif();
          });
        }
      });
    } catch (error) {
      console.error("Error marking notification as read:", error);
    }
  };

  const handleToggleUnread = (showUnreadOnly) => {
    setNotificationParams("");

    setTimeout(() => {
      updateNotificationParams({
        categoryId: selectedMenu?.id,
        subCategoryId: selectedSubCategory?.id,
        status: showUnreadOnly,
      });
    }, 0);
  };

  useEffect(() => {
    setShowSidebar(false);
  }, []);

  // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0802
  const transformedCategory = useMemo(() => {
    if (!categoryNotif?.Data || !langReady) return [];
    const translate = (str) => {
      if (!str) return "";
      return t(`titleNotifikasiKategori_${str.replace(/\s+/g, "_")}`);
    };
    const categories = Array.isArray(categoryNotif.Data)
      ? categoryNotif.Data
      : categoryNotif.Data.Data || [];
    
    const totalCount = categories.reduce((sum, category) => sum + (category?.CountKategori || 0), 0);
    const allMenuItem = {
      id: 0,
      title: t("titleAllNotifications"),
      count: totalCount,
      orderNumber: 0,
      subCategories: [],
    };

    const transformed = categories.map((category) => ({
      id: category?.Identifier || 0,
      title: translate(category?.CategoryName),
      count: category?.CountKategori || 0,
      orderNumber: category?.Identifier || 0,
      subCategories:
        category?.SubCategory?.map((sub) => ({
          id: sub?.Identifier || 0,
          name: translate(sub?.SubCategoryName),
          count: sub?.CountSubCategory || 0,
        })) || [],
    }));
    
    return [allMenuItem, ...transformed].sort((a, b) => a.orderNumber - b.orderNumber);
  }, [categoryNotif, t, selectedMenu, langReady]);

  useEffect(() => {
    if (transformedCategory.length > 0) setMenuItems(transformedCategory);
  }, [transformedCategory]);

  useEffect(() => {
    if (selectedMenu) {
      if (selectedMenu.subCategories?.length > 0) {
        const firstSubCat = selectedMenu.subCategories[0];
        setSelectedSubCategory(firstSubCat);
        updateNotificationParams({
          categoryId: selectedMenu.id,
          subCategoryId: firstSubCat.id,
        });
      } else {
        setSelectedSubCategory(null);
        updateNotificationParams({
          categoryId: selectedMenu?.id,
        });
      }
    }
  }, [selectedMenu]);

  useEffect(() => {
    if (listNotif?.Data) {
      setNotificationData({
        list: listNotif.Data.notifications.map((notif) => ({
          id: notif.ID,
          title: notif.Judul,
          content: notif.Deskripsi,
          date: notif.time_notif,
          isNew: notif.status_read === 0,
          tipe_action: notif.tipe_action,
          additional_information: notif.additional_information,
        })),
        pagination: {
          currentPage: listNotif.Data.pagination.currentPage,
          totalPages: listNotif.Data.pagination.totalPages,
          totalItems: listNotif.Data.pagination.totalItems,
          itemsPerPage: listNotif.Data.pagination.itemsPerPage,
        },
        supportingData: {
          notReadCount: listNotif.Data.SupportingData.NotReadCount,
          realCountData: listNotif.Data.SupportingData.RealCountData,
          countData: listNotif.Data.SupportingData.CountData,
        },
      });
    }
  }, [listNotif]);

  const sharedProps = {
    menuItems,
    subCategories: selectedMenu?.subCategories || [],
    categoryNotif,
    selectedSubCategory,
    notificationData,
    onMenuClick: handleMenuClick,
    onSubCategoryClick: handleSubCategoryClick,
    onPageChange: handlePageChange,
    onMarkAllRead: handleMarkAllAsRead,
    onMarkAsRead: handleMarkAsRead,
    onToggleUnread: handleToggleUnread,
  };

  // if (typeof isMobile !== "boolean") return <></>;
  return isMobile ? (
    <NotifikasiResponsive t={t} {...sharedProps} />
  ) : (
    <NotifikasiWeb t={t} {...sharedProps} />
  );
}

export default Notifikasi;
