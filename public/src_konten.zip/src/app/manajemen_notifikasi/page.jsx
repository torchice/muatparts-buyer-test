
import Manajemen_notifikasi from './Manajemen_notifikasi';

function Page() {
    return (
        <div className='w-full'>
            <Manajemen_notifikasi />
        </div>
    );
}

export default Page;
  