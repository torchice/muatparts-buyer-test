"use client";

import MockServer_Dashboard from "@/services/MockServer_Dashboard";
import headerZustand from "@/store/zustand/header";
import useLoadingStore from "@/store/zustand/loading";
import toast from "@/store/zustand/toast";
import { Suspense, useEffect, useState } from "react";
import DashboardRegister from "./components/DashboardRegister";
import DashboardRegisterMobile from "./components/DashboardRegisterMobile";
import DashboardSeller from "./components/DashboardSeller";
import DashboardSellerMobile from "./components/DashboardSellerMobile";
import { useHeader } from "@/common/ResponsiveContext";
import viewport from "@/store/zustand/common";
import { useCustomRouter } from "@/libs/CustomRoute";
import Modal from "@/components/Modals/modal";
import otpRegisterZustand from "@/store/zustand/otpRegister";
import { useTranslation } from "@/context/TranslationProvider";

const page = () => {
  const [data, setData] = useState(null);
  const { updateShow } = useLoadingStore();
  const { setTitle, setBackIcon, setHeader } = headerZustand();
  // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0487
  const { clearPersistData, successVerifyOtp, setSuccessVerifyOtp, isModalOpen, setIsModalOpen } = otpRegisterZustand();
  const {isMobile} = viewport();
  const { setShowNavMenu } = toast();
  const {setAppBar} = useHeader();
  const router = useCustomRouter();
  // LBM - OLIVER - KURANG IMP MULTIBAHASA - MP - 012
  const { t } = useTranslation();

  const fetchData = async () => {
    try {
      updateShow(true);
      setData((await MockServer_Dashboard.getDashboardStatus()).Data);
    } catch (error) {
    } finally {
      updateShow(false);
    }
  };

  useEffect(() => {
    fetchData();
    setTitle("");
    setBackIcon(false);
    setShowNavMenu(true);
  }, []);

  useEffect(() => {
    if(successVerifyOtp) {
      setAppBar({
        appBarType: null,
      });

      setHeader(false);
      setSuccessVerifyOtp(false);
      clearPersistData();
      setIsModalOpen(true);
    }
  }, [successVerifyOtp])

  return (
    <>
      <Modal 
        isOpen={isModalOpen}
        setIsOpen={setIsModalOpen}
        closeArea={false}
        closeBtn={true}
        // LBM - OLIVER - KURANG IMP MULTIBAHASA - MP - 012
        title={t("titleOneStep")}
        desc={t("messageUpload")}
        action1={{
          action: () => setIsModalOpen(false),
          // LBM - OLIVER - KURANG IMP MULTIBAHASA - MP - 012
          text: isMobile ? t("buttonLaterResponsive") : t("buttonLater"),
          style: "outline",
          color: "#176CF7",
          customStyle: {
            width: isMobile? "84px": "116px"
          }
        }}
        action2={{
          action: () => router.push("/kelolaproduk/tambahproduk"),
          // LBM - OLIVER - KURANG IMP MULTIBAHASA - MP - 012
          text: t("buttonAddProduct"),
          style: "full",
          color: "#176CF7",
          customStyle: {
            width: "149px",
            color: "#ffffff"
          }
        }}
      />
      {/* LBM - padding - Andrew */}
      <Suspense fallback={<></>}>
        <div className="flex flex-col items-center w-full max-md:ml-0 mb-32 sm:mb-0 min-h-screen pb-[80px]">
          <div className="flex flex-col grow max-md:max-w-full w-full">
            {data === null ? (
              <></>
            ) : data?.canAccessDashboard === false ? (
              <>
                <DashboardRegister status={data?.setupStatus} />
                <DashboardRegisterMobile status={data?.setupStatus} />
              </>
            ) : (
              <>
                <DashboardSeller />
                <DashboardSellerMobile />
              </>
            )}
          </div>
        </div>
      </Suspense>
    </>
  );
};

export default page;
