"use client";

import PaginationStepper from "@/components/PaginationStepper/PaginationStepper";
import PaginationContainer from "@/container/PaginationContainer/PaginationContainer";
import MockServer_Disbursement from "@/services/MockServer_Disbursement";
import useLoadingStore from "@/store/zustand/loading";
import { useEffect, useState } from "react";
import { DisbursementReportDetailHeader } from "./components/DisbursementReportDetailHeader";
import DisbursementReportDetailMobile from "./components/DisbursementReportDetailMobile";
import { DisbursementReportDetailOrderList } from "./components/DisbursementReportDetailOrderList";
import { DisbursementReportDetailSummary } from "./components/DisbursementReportDetailSummary";

const Page = ({ params }) => {
  const { id } = params;
  const { updateShow } = useLoadingStore();

  const [pagination, setPagination] = useState({
    page: 1,
    limit: 10,
    totalItems: 0,
    totalPages: 0,
  });
  const [account, setAccount] = useState(null);

  const fetchData = async () => {
    try {
      updateShow(true);
      const acc = (await MockServer_Disbursement.getDisbursementDetail({
        id,
        page,
        limit: pagination.limit,})
      ).Data;
      setPagination((prev) => {
        return {
          ...prev,
          totalItems: acc.pagination.totalItems,
          totalPages: acc.pagination.totalPages,
        };
      });
      setAccount(acc);
    } catch (error) {
    } finally {
      updateShow(false);
    }
  };

  const fetchPagination = async (page) => {
    try {
      updateShow(true);

      const his = (
        await MockServer_Disbursement.getDisbursementDetail({
          id,
          page,
          limit: pagination.limit,
        })
      ).Data;
      setPagination({
        page: his?.pagination?.currentPage??0,
        limit: pagination?.limit??0,
        totalItems: his?.pagination?.totalItems??0,
        totalPages: his?.pagination?.totalPages??0,
      });
      setHistory(his);
    } catch (error) {
    } finally {
      updateShow(false);
    }
  };

  const handleDownloadDisbursementDetailReport = async () => {
    try {
      updateShow(true);
      await MockServer_Disbursement.downloadReport();
    } catch (error) {
    } finally {
      updateShow(false);
    }
  };

  const fetchLimit = async (limit) => {
    try {
      updateShow(true);

      const his = (
        await MockServer_Disbursement.getDisbursementDetail({
          id,
          page: 1,
          limit,
        })
      ).Data;
      setPagination({
        page: 1,
        limit,
        totalItems: his?.pagination?.totalItems??0,
        totalPages: his?.pagination?.totalPages??0,
      });
      setHistory(his);
    } catch (error) {
    } finally {
      updateShow(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <>
      <DisbursementReportDetailMobile
        data={account}
        handleDownloadDisbursementDetailReport={
          handleDownloadDisbursementDetailReport
        }
      />

      <div className="flex sm:hidden flex-col min-h-screen">
        <DisbursementReportDetailHeader
          handleDownload={handleDownloadDisbursementDetailReport}
        />
        <div className="flex flex-wrap gap-4 mt-4 w-full max-md:max-w-full">
          <DisbursementReportDetailSummary data={account} />
          <div className="flex gap-4 flex-col grow shrink max-md:max-w-full">
            <DisbursementReportDetailOrderList data={account} />

            <div className="flex justify-between">
              <PaginationContainer
                activeColor="error"
                currentPage={pagination.page}
                totalPages={pagination.totalPages}
                onPage={fetchPagination}
              />

              <PaginationStepper
                pagination={pagination}
                onChange={fetchLimit}
              />
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Page;
