import moment from "moment";
import ImageComponent from '@/components/ImageComponent/ImageComponent';

export function DisbursementReportDetailSummary({ data }) {
  const date = moment.utc(data?.disbursementInfo?.date);
  const jakartaDate = date.clone().add(7, "hours");
  const formattedDate = jakartaDate.format("D MMM YYYY HH:mm [WIB]");

  return (
    <div
      className="flex flex-col justify-center self-start leading-tight max-md:px-5"
      style={{ width: "400px" }}
    >
      <div className="flex overflow-hidden flex-col justify-center px-6 py-5 w-full max-w-full bg-white rounded-xl shadow-lg max-md:px-5">
        <div className="flex flex-col w-full">
          <div className="flex gap-10 justify-between items-center w-full text-xs font-medium">
            <div className="self-stretch my-auto text-black">
              Dana yang dicairkan
            </div>
            <div className="self-stretch my-auto text-neutral-500">
              {formattedDate}
            </div>
          </div>
          <div className="mt-6 text-2xl font-bold text-black">
            {new Intl.NumberFormat("id-ID", {
              style: "currency",
              currency: "IDR",
              maximumFractionDigits: 0,
            }).format(data?.disbursementInfo?.amount ?? 0)}
          </div>
        </div>
        <div className="flex flex-col mt-7 w-full text-xs">
          <div className="flex gap-10 justify-between items-start w-full font-medium">
            <div className="text-neutral-500">Dicairkan ke</div>
          </div>
          <div className="flex overflow-hidden gap-3 items-center p-3 mt-3 w-full bg-sky-100 rounded-md">
            <ImageComponent loading="lazy"
              src="/img/BCA.svg"
              alt="Bank Logo"
              className="object-contain shrink-0 self-stretch my-auto w-10 rounded-lg aspect-square"
            />
            <div className="flex flex-col flex-1 shrink self-stretch my-auto basis-0">
              <div className="flex-1 shrink gap-2 w-full font-semibold text-black">
                {data?.disbursementInfo?.account?.bankName}
              </div>
              <div className="flex-1 mt-3 font-medium text-neutral-600">
                {data?.disbursementInfo?.account?.accountNumber} -{" "}
                {data?.disbursementInfo?.account?.accountHolder}
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="flex overflow-hidden flex-col justify-center px-6 py-5 mt-4 max-w-full text-xs font-medium bg-white rounded-xl shadow-lg w-full max-md:px-5">
        <div className="flex flex-col w-full">
          <div className="gap-2 self-stretch w-full text-black whitespace-nowrap">
            Ringkasan
          </div>
          <div className="flex flex-col mt-6 w-full">
            <div className="flex gap-10 justify-between items-start w-full">
              <div className="text-neutral-500 w-[180px]">Pendapatan Kotor</div>
              <div className="text-right text-black">
                {new Intl.NumberFormat("id-ID", {
                  style: "currency",
                  currency: "IDR",
                  maximumFractionDigits: 0,
                }).format(data?.summary?.grossIncome ?? 0)}
              </div>
            </div>
            <div className="flex gap-10 justify-between items-start mt-4 w-full">
              <div className="text-neutral-500 w-[180px]">Biaya Layanan</div>
              <div className="text-right text-red-500 w-full ">
                {new Intl.NumberFormat("id-ID", {
                  maximumFractionDigits: 0,
                }).format(data?.summary?.serviceFee ?? 0)}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

