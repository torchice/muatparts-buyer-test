import { url } from "@/services/url";
import headerZustand from "@/store/zustand/header";
import moment from "moment";
import { useEffect } from "react";
import DisbursementReportBankCard from "../../components/DisbursementReportBankCard";
import DisbursementReportDetailOrderItem from "./DisbursementReportDetailOrderItem";
import { useCustomRouter } from '@/libs/CustomRoute';

const DisbursementReportDetailMobile = ({
  data,
  handleDownloadDisbursementDetailReport,
}) => {
  const router = useCustomRouter();
  const { setBackIconAction, setTitle, setIconList } = headerZustand();

  const date = moment.utc(data?.disbursementInfo?.date);
  const jakartaDate = date.clone().add(7, "hours");
  const formattedDate = jakartaDate.format("D MMM YYYY HH:mm [WIB]");

  const resetToastState = () => {
    setTitle("Rincian Pencairan");
    setBackIconAction(() => router.replace(`${url.laporanPencarian}`));
    setIconList([
      {
        icon: "/icons/downloadwhite.svg",
        label: "Unduh",
        onclick: handleDownloadDisbursementDetailReport,
      },
    ]);
  };

  useEffect(() => {
    resetToastState();
  }, []);

  return (
    <div className="hidden sm:flex flex-col w-full">
      <div className="flex overflow-hidden flex-col self-center px-4 pb-5 w-full bg-white">
        <DisbursementReportBankCard account={data?.disbursementInfo?.account} />

        <div className="flex flex-col mt-5 w-full">
          <div className="text-center self-stretch pb-5 w-full text-2xl font-bold leading-tight text-black whitespace-nowrap border-b border-solid border-b-stone-300">
            {new Intl.NumberFormat("id-ID", {
              style: "currency",
              currency: "IDR",
              maximumFractionDigits: 0,
            }).format(data?.summary?.netAmount ?? 0)}
          </div>
          <div className="flex gap-10 justify-between items-start mt-4 w-full text-xs leading-none">
            <div className="font-medium text-neutral-500 w-[107px]">
              Tanggal Pencairan
            </div>
            <div className="font-semibold text-right text-black w-[150px]">
              {formattedDate}
            </div>
          </div>
        </div>
      </div>
      <div className="flex overflow-hidden flex-col justify-center px-4 py-5 mt-2 w-full leading-none bg-white">
        <div className="flex flex-col w-full">
          <div className="flex gap-7 justify-between items-center w-full text-sm text-black whitespace-nowrap">
            <div className="self-stretch my-auto font-semibold w-[200px]">
              Ringkasan
            </div>
          </div>
          <div className="flex flex-col mt-6 w-full text-xs">
            <div className="flex justify-between items-start pb-4 w-full border-b border-solid border-b-stone-300">
              <div className="font-medium text-neutral-500 w-[200px]">
                Pendapatan Kotor
              </div>
              <div className="font-semibold text-right text-black w-[150px]">
                {new Intl.NumberFormat("id-ID", {
                  style: "currency",
                  currency: "IDR",
                  maximumFractionDigits: 0,
                }).format(data?.summary?.grossIncome ?? 0)}
              </div>
            </div>
            <div className="flex gap-10 justify-between items-center mt-4 w-full">
              <div className="self-stretch my-auto font-medium text-neutral-500 w-[200px]">
                Biaya Layanan
              </div>
              <div className="self-stretch my-auto font-semibold text-red-500">
                {new Intl.NumberFormat("id-ID", {
                  maximumFractionDigits: 0,
                }).format(data?.summary?.serviceFee ?? 0)}
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="flex flex-col self-center mt-2 w-full leading-none text-black">
        <div className="flex justify-between items-center p-4 w-full text-sm font-semibold bg-white">
          <div className="flex-1 shrink gap-2 self-stretch my-auto w-full min-w-[240px]">
            Daftar Pesanan dan Komplain
          </div>
        </div>
        <div className="flex overflow-hidden gap-2.5 items-start px-4 pb-3 w-full text-xs font-medium bg-white border-b border-solid border-b-stone-300">
          <div className="flex flex-1 shrink gap-3 items-start w-full basis-0 min-w-[240px]">
            <div className="flex-1 shrink basis-0 text-ellipsis">Invoice</div>
            <div className="text-right w-[100px]">Total Pendapatan</div>
          </div>
        </div>
      </div>
      {data?.orders.map((order, index) => (
        <DisbursementReportDetailOrderItem
          key={index}
          invoiceNumber={order.invoiceNumber}
          amount={order.amount}
          status={order.status}
        />
      ))}
    </div>
  );
};

export default DisbursementReportDetailMobile;

