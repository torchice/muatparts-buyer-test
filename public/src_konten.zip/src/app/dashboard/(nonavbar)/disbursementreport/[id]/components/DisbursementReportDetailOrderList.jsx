export function DisbursementReportDetailOrderList({ data }) {
  return (
    <div className="flex overflow-hidden flex-col pt-5 w-full leading-tight bg-white rounded-xl shadow-lg max-md:max-w-full">
      <div className="flex flex-wrap gap-10 items-start px-6 pb-5 w-full border-b border-solid border-b-stone-300 max-md:px-5 max-md:max-w-full">
        <div className="text-xl font-bold text-black">
          Daftar Pesanan dan Komplain
        </div>
      </div>
      <div className="flex gap-3 items-center px-6 py-5 w-full text-xs font-bold bg-white border-b border-solid border-b-stone-300 text-neutral-500 max-md:px-5 max-md:max-w-full">
        <div className="flex flex-wrap flex-1 shrink gap-10 items-center self-stretch my-auto w-full basis-0 min-w-[240px] max-md:max-w-full">
          <div className="flex-[1.5] gap-2 self-stretch my-auto w-[175px]">
            No. Invoice
          </div>
          <div className="flex-1 gap-2 self-stretch my-auto whitespace-nowrap w-[140px]">
            Status
          </div>
          <div className="flex-1 gap-2 self-stretch my-auto w-[180px]">
            Total Pendapatan
          </div>
        </div>
      </div>
      {data?.orders.map((order, index) => (
        <div
          key={index}
          className={`flex gap-3 items-center px-6 py-5 w-full text-xs font-medium bg-white ${
            index > 0 ? "border-t border-solid border-t-stone-300" : ""
          } max-md:px-5 max-md:max-w-full`}
        >
          <div className="flex flex-wrap flex-1 shrink gap-10 items-center self-stretch my-auto w-full basis-0 min-w-[240px] max-md:max-w-full">
            <div className="flex-[1.5] gap-2 self-stretch my-auto whitespace-nowrap text-neutral-500 w-[175px]">
              {order.invoiceNumber}
            </div>
            <div className="flex-1 text-center gap-2 self-stretch my-auto font-semibold min-h-[24px] w-[140px]">
              <div className="text-emerald-500 bg-green-100 rounded-md p-2 w-[140px]">
                {order.status}
              </div>
            </div>
            <div className="flex-1 gap-2 self-stretch my-auto text-black whitespace-nowrap w-[180px]">
              {new Intl.NumberFormat("id-ID", {
                style: "currency",
                currency: "IDR",
                maximumFractionDigits: 0,
              }).format(order?.amount ?? 0)}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
