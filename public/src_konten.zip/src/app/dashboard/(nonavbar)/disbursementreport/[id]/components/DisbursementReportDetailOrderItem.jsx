import { url } from "@/services/url";
import { useCustomRouter } from '@/libs/CustomRoute';

const DisbursementReportDetailOrderItem = ({
  invoiceNumber,
  amount,
  status,
}) => {
  const router = useCustomRouter();

  return (
    <div
      onClick={() => router.push(`${url.pesanan}/${invoiceNumber}`)}
      className="flex overflow-hidden gap-2.5 p-4 mt-2 w-full bg-white hover:bg-slate-100"
    >
      <div className="flex flex-col self-start leading-none w-[166px]">
        <div className="text-xs font-medium text-black text-ellipsis">
          {invoiceNumber}
        </div>
        <div className="flex text-center mt-2 w-full text-sm font-semibold text-emerald-500 max-w-[158px]">
          <div className="flex-1 shrink gap-1 self-stretch px-2 py-1 w-full bg-green-100 rounded-md min-h-[24px]">
            {status}
          </div>
        </div>
      </div>
      <div className="flex-1 shrink text-xs font-bold leading-3 justify-end text-black basis-0 items-center flex">
        {new Intl.NumberFormat("id-ID", {
          style: "currency",
          currency: "IDR",
          maximumFractionDigits: 0,
        }).format(amount ?? 0)}
      </div>
    </div>
  );
};

export default DisbursementReportDetailOrderItem;

