import ImageComponent from '@/components/ImageComponent/ImageComponent';

function DisbursementReportCard({ data, setIsBankAccountSelectorOpen }) {
  return (
    <div
      className="flex overflow-hidden flex-col justify-center self-start px-6 py-5 leading-tight bg-white rounded-xl shadow-lg max-md:px-5"
      style={{
        width: "400px",
      }}
    >
      <div className="flex flex-col w-full text-black">
        <div className="gap-2 self-stretch w-full text-xs font-medium">
          Pencairan Dalam Proses
        </div>
        <div className="mt-6 text-2xl font-bold">
          {new Intl.NumberFormat("id-ID", {
            style: "currency",
            currency: "IDR",
            maximumFractionDigits: 0,
          }).format(data?.amount ?? 0)}
        </div>
      </div>
      <div className="flex flex-col mt-7 w-full text-xs">
        <div className="flex gap-10 justify-between items-start w-full font-medium">
          <div className="text-neutral-500">Dicairkan ke</div>
          <button
            onClick={() => {
              setIsBankAccountSelectorOpen(true);
            }}
            className="gap-2.5 self-stretch text-blue-600"
          >
            Ubah Rekening Tujuan
          </button>
        </div>
        <div className="flex overflow-hidden gap-3 items-center p-3 mt-3 w-full bg-sky-100 rounded-md">
          <ImageComponent loading="lazy"
            src="/img/BCA.svg"
            alt="Bank Logo"
            className="object-contain shrink-0 self-stretch my-auto w-10 rounded-lg aspect-square"
          />
          <div className="flex flex-col flex-1 shrink self-stretch my-auto basis-0">
            <div className="flex-1 shrink gap-2 w-full font-semibold text-black">
              {data?.bankName}
            </div>
            <div className="flex-1 mt-3 font-medium text-neutral-600">
              {data?.accountNumber} - {data?.accountHolder}
            </div>
          </div>
        </div>
        <div className="mt-3 font-medium leading-4 text-neutral-500">
          Proses pencairan dilakukan setiap hari kerja maks. pukul 12.00 WIB.
          Penghasilan yang dicairkan adalah yang didapat pada hari sebelumnya.
        </div>
      </div>
    </div>
  );
}

export default DisbursementReportCard;

