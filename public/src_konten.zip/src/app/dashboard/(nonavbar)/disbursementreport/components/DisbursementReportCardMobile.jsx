import Bottomsheet from "@/components/Bottomsheet/Bottomsheet";
import toast from "@/store/zustand/toast";
import DisbursementReportBankCard from "./DisbursementReportBankCard";
import ImageComponent from '@/components/ImageComponent/ImageComponent';

function DisbursementReportCardMobile({ account, accountChangeToastState }) {
  const { setShowBottomsheet, setTitleBottomsheet, setDataBottomsheet } =
    toast();

  const handleDisbursementInfo = () => {
    setTitleBottomsheet("Penghasilan Dalam Proses");
    setDataBottomsheet(
      <div className="py-3 px-1 font-normal">
        Proses pencairan dilakukan setiap hari kerja maks. pukul 12.00 WIB.
        Penghasilan yang dicarikan adalah yang didapat pada hari sebelumnya.
      </div>
    );
    setShowBottomsheet(true);
  };

  return (
    <div className="flex overflow-hidden relative flex-col px-4 py-6 w-full bg-white">
      <div className="flex absolute top-0 left-2/4 z-0 bg-red-900 -translate-x-2/4 h-[111px] min-h-[111px] translate-y-[0%] w-full" />
      <div className="flex z-0 flex-col px-4 pt-3 pb-4 w-full bg-white rounded-md border border-blue-400 border-solid shadow-lg">
        <div className="flex flex-col w-full text-black">
          <div className="flex gap-1 justify-center items-center w-full text-xs font-medium leading-none text-right">
            <div className="self-stretch my-auto">Pencairan Dalam Proses</div>
            <ImageComponent src="/icons/info_mark.svg"
              loading="lazy"
              alt=""
              width={16}
              height={16}
              className="object-contain shrink-0 self-stretch my-auto w-4 aspect-square cursor-pointer"
              onClick={handleDisbursementInfo}
            />
          </div>
          <div className="self-start mt-3 text-2xl font-bold leading-tight text-center w-full">
            {new Intl.NumberFormat("id-ID", {
              style: "currency",
              currency: "IDR",
              maximumFractionDigits: 0,
            }).format(account?.amount ?? 0)}
          </div>
        </div>

        <DisbursementReportBankCard
          account={account}
          onClick={accountChangeToastState}
        />
      </div>

      <Bottomsheet />
    </div>
  );
}

export default DisbursementReportCardMobile;

