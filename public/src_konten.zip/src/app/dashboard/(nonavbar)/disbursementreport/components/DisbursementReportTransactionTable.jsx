import Button from "@/components/Button/Button";
import { url } from "@/services/url";
import moment from "moment";
import { useCustomRouter } from '@/libs/CustomRoute';
import ImageComponent from '@/components/ImageComponent/ImageComponent';

const DisbursementReportTransactionTable = ({ data }) => {
  const router = useCustomRouter();

  return (
    <div className="flex overflow-hidden flex-col pt-5 w-full leading-tight bg-white rounded-xl shadow-lg max-md:max-w-full">
      <div className="flex flex-wrap gap-10 items-start px-6 pb-5 w-full border-b border-solid border-b-stone-300 max-md:px-5 max-md:max-w-full">
        <div className="text-xl font-bold text-black">Riwayat Pencairan</div>
      </div>
      <div className="flex gap-3 items-center px-6 py-5 w-full text-xs font-bold bg-white border-b border-solid border-b-stone-300 text-neutral-500 max-md:px-5 max-md:max-w-full">
        <div className="flex flex-wrap flex-1 shrink gap-5 items-center self-stretch my-auto w-full basis-0 min-w-[240px] max-md:max-w-full">
          <div className="flex-1 w-[130px]">Tanggal</div>
          <div className="flex-1 w-[100px]">Jumlah</div>
          <div className="flex-[1.5] shrink">Rekening Pencairan</div>
          <div className="w-[120px]">Aksi</div>
        </div>
      </div>
      {data?.disbursements?.map((disbursement) => {
        const date = moment.utc(disbursement.date);
        const jakartaDate = date.clone().add(7, "hours");
        const formattedDate = jakartaDate.format("D MMM YYYY HH:mm [WIB]");

        return (
          <div
            key={disbursement.id}
            className="flex gap-3 items-center px-6 py-3 w-full text-xs font-medium bg-white border-t border-solid border-t-stone-300 text-neutral-500 max-md:px-5 max-md:max-w-full"
          >
            <div className="flex flex-wrap flex-1 shrink gap-5 items-center self-stretch my-auto w-full basis-0 min-w-[240px] max-md:max-w-full">
              <div className="flex-1 w-[130px]">{formattedDate}</div>
              <div className="flex-1 w-[100px]">
                {new Intl.NumberFormat("id-ID", {
                  style: "currency",
                  currency: "IDR",
                  maximumFractionDigits: 0,
                }).format(disbursement?.amount ?? 0)}
              </div>
              <div className="flex flex-[1.5] shrink gap-2 items-center self-stretch my-auto basis-0">
                <ImageComponent loading="lazy"
                  src="/img/BCA.svg"
                  alt="Bank Logo"
                  className="object-contain shrink-0 self-stretch my-auto w-6 rounded aspect-square"
                />
                <div className="self-stretch my-auto">
                  {disbursement.account.bankCode}{" "}
                  {disbursement.account.accountNumber}
                </div>
              </div>
              <div className="gap-2">
                <Button
                  color="primary_secondary"
                  onClick={() =>
                    router.push(`${url.laporanPencarian}/${disbursement.id}`)
                  }
                >
                  Detail
                </Button>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default DisbursementReportTransactionTable;

