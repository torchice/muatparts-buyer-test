"use client";

import DisbursementReportTransactionItem from "./DisbursementReportTransactionItem";

const DisbursementReportTransactionList = ({ history }) => {
  return (
    <div className="flex flex-col mt-2 w-full leading-none">
      {history?.disbursements?.map((transaction, index) => (
        <DisbursementReportTransactionItem key={index} {...transaction} />
      ))}
    </div>
  );
};

export default DisbursementReportTransactionList;
