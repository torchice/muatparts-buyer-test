import { url } from "@/services/url";
import { useCustomRouter } from '@/libs/CustomRoute';
import ImageComponent from '@/components/ImageComponent/ImageComponent';

function DisbursementReportHeader({ handleDownload }) {
  const router = useCustomRouter();

  return (
    <>
      <div className="flex gap-1.5 items-center w-full text-xs leading-tight min-h-[16px] max-md:max-w-full">
        <div className="flex flex-wrap gap-1.5 items-center self-stretch my-auto min-w-[240px] w-full">
          <div
            onClick={() => router.replace(url.dashboard)}
            className="cursor-pointer self-stretch my-auto font-medium text-neutral-500 hover:text-neutral-700"
          >
            Dashboard
          </div>
          <ImageComponent loading="lazy"
            src="/icons/chevron-right.svg"
            alt=""
            className="object-contain shrink-0 self-stretch my-auto w-4 aspect-square"
          />
          <div className="self-stretch my-auto font-semibold text-blue-600">
            Laporan Pencairan
          </div>
        </div>
      </div>
      <div className="flex justify-between items-center mt-4 w-full leading-tight max-md:max-w-full">
        <div className="flex flex-wrap gap-3 items-center self-stretch my-auto text-xl font-bold text-black min-w-[240px] w-[515px] max-md:max-w-full">
          <img
            onClick={() => router.replace(url.dashboard)}
            loading="lazy"
            src="/icons/arrowbackblue.svg"
            alt=""
            className="cursor-pointer object-contain shrink-0 self-stretch my-auto w-6 aspect-square"
          />
          <div
            onClick={() => router.replace(url.dashboard)}
            className="self-stretch my-auto cursor-pointer"
          >
            Laporan Pencairan
          </div>
        </div>
        <button
          onClick={handleDownload}
          className="flex gap-1 justify-center items-center px-6 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-800 duration-300 rounded-3xl"
        >
          <ImageComponent loading="lazy"
            src="/icons/downloadwhite.svg"
            alt=""
            className="w-6 aspect-square"
          />
          <span>Unduh</span>
        </button>
      </div>
    </>
  );
}

export default DisbursementReportHeader;

