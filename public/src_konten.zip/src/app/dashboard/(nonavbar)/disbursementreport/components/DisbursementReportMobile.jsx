import { url } from "@/services/url";
import headerZustand from "@/store/zustand/header";
import { useEffect, useState } from "react";
import DisbursementAccountChange from "./DisbursementAccountChange";
import DisbursementReportCardMobile from "./DisbursementReportCardMobile";
import DisbursementReportTransactionList from "./DisbursementReportTransactionList";
import { useCustomRouter } from '@/libs/CustomRoute';

const DisbursementReportMobile = ({
  account,
  fetchAccount,
  history,
  handleDownloadDisbursementReport,
}) => {
  const router = useCustomRouter();
  const { setBackIconAction, setTitle, setIconList } = headerZustand();

  const [isBankAccountSelectorMobileOpen, setIsBankAccountSelectorMobileOpen] =
    useState(false);

  const resetToastState = () => {
    setTitle("Laporan Pencairan");
    setBackIconAction(() => router.replace(`${url.dashboard}?detail=true`));
    setIconList([
      {
        icon: "/icons/downloadwhite.svg",
        label: "Unduh",
        onclick: handleDownloadDisbursementReport,
      },
    ]);
    setIsBankAccountSelectorMobileOpen(false);
  };

  const accountChangeToastState = () => {
    setTitle("Rekening Pencairan");
    setBackIconAction(() => resetToastState());
    setIconList([]);
    setIsBankAccountSelectorMobileOpen(true);
  };

  useEffect(() => {
    resetToastState();
  }, []);

  useEffect(() => {
    fetchAccount();
  }, [isBankAccountSelectorMobileOpen]);

  return (
    <>
      {isBankAccountSelectorMobileOpen ? (
        <DisbursementAccountChange resetToastState={resetToastState} />
      ) : (
        <div className="hidden sm:flex flex-col mx-auto w-full">
          <div className="flex overflow-hidden flex-col bg-zinc-100 w-full">
            <DisbursementReportCardMobile
              account={account}
              accountChangeToastState={accountChangeToastState}
            />
            <DisbursementReportTransactionList history={history} />
          </div>
        </div>
      )}
    </>
  );
};

export default DisbursementReportMobile;

