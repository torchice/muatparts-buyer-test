import BankAccountCard from "@/components/BankAccountCard/BankAccountCard";
import MockServer_BankAccount from "@/services/MockServer_BankAccounts";
import useLoadingStore from "@/store/zustand/loading";
import { useEffect, useState } from "react";

const DisbursementAccountChange = ({ resetToastState }) => {
  const { updateShow } = useLoadingStore();
  const [accounts, setAccounts] = useState([]);
  const [selectedAccount, setSelectedAccount] = useState(null);

  const handleAddAccount = () => {
    console.log("handleAddAccount");
  };

  const handleAccountSelect = async (id) => {
    setSelectedAccount(id);
  };

  const handleSaveAccount = async () => {
    try {
      updateShow(true);
      await MockServer_BankAccount.setMainAccount(selectedAccount);
      resetToastState();
    } catch (error) {
    } finally {
      updateShow(false);
    }
  };

  const fetchData = async () => {
    try {
      updateShow(true);

      const res = (await MockServer_BankAccount.getBankAccounts()).Data;
      const selected = res.accounts.find((acc) => acc.isFund === true).id;

      setAccounts(res.accounts);
      setSelectedAccount(selected);
    } catch (error) {
    } finally {
      updateShow(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <div className="flex flex-col mx-auto w-full">
      <div className="flex overflow-hidden flex-col bg-slate-50">
        <div className="flex flex-col px-4 mt-5 w-full">
          <div className="flex flex-col self-start w-full">
            {accounts.map((account) => (
              <BankAccountCard
                key={account.id}
                account={account}
                isSelected={selectedAccount === account.id}
                onSelect={handleAccountSelect}
              />
            ))}
          </div>
        </div>

        <div className="fixed bottom-0 flex flex-col mt-2 w-full">
          <div className="flex flex-col justify-center px-4 py-3 w-full text-sm font-semibold leading-none text-white whitespace-nowrap bg-white rounded-xl shadow-[0px_-3px_55px_rgba(0,0,0,0.161)]">
            <button
              onClick={handleSaveAccount}
              className="flex-1 shrink gap-1 self-stretch px-6 py-4 w-full bg-blue-600 rounded-3xl min-h-[40px] min-w-[160px]"
            >
              Simpan
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DisbursementAccountChange;
