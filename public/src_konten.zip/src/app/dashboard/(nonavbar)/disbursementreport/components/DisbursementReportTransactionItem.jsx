import { url } from "@/services/url";
import moment from "moment";
import { useCustomRouter } from '@/libs/CustomRoute';
import ImageComponent from '@/components/ImageComponent/ImageComponent';

function DisbursementReportTransactionItem({ id, amount, date, account }) {
  const router = useCustomRouter();

  const momentDate = moment.utc(date);
  const jakartaDate = momentDate.clone().add(7, "hours");
  const formattedDate = jakartaDate.format("D MMM YYYY HH:mm [WIB]");

  return (
    <div
      role="button"
      onClick={() => router.push(`${url.laporanPencarian}/${id}`)}
      className="flex gap-4 items-center p-4 mt-2 w-full text-xs font-medium bg-white text-neutral-600 hover:bg-slate-100"
    >
      <div className="flex flex-1 shrink gap-3 items-center self-stretch my-auto basis-0 min-w-[240px]">
        <ImageComponent loading="lazy"
          src="/img/BCA.svg"
          alt="Transaction Icon"
          className="object-contain shrink-0 self-stretch my-auto w-9 rounded-md aspect-square"
        />
        <div className="flex flex-col flex-1 shrink self-stretch basis-0 gap-1">
          <div className="text-sm font-bold text-black">
            {new Intl.NumberFormat("id-ID", {
              style: "currency",
              currency: "IDR",
              maximumFractionDigits: 0,
            }).format(amount ?? 0)}
          </div>
          <div className="">{formattedDate}</div>
          <div className="">
            {account?.bankCode} {account?.accountNumber}
          </div>
        </div>
      </div>
      <ImageComponent loading="lazy"
        src={"/icons/chevron-right.svg"}
        alt=""
        className="object-contain shrink-0 self-stretch my-auto w-5 aspect-square"
      />
    </div>
  );
}

export default DisbursementReportTransactionItem;

