import ImageComponent from '@/components/ImageComponent/ImageComponent';

const DisbursementReportBankCard = ({ account, onClick }) => {
  return (
    <div className="flex flex-col mt-6 w-full">
      <div className="flex gap-10 justify-between items-center w-full text-xs leading-none">
        <div className="self-stretch my-auto font-medium text-black">
          Dicairkan ke
        </div>
      </div>
      <div className="flex relative flex-col p-3 mt-2 w-full bg-sky-100 rounded-md">
        <div className="flex z-0 gap-2 items-center w-full">
          <ImageComponent loading="lazy"
            src="/img/BCA.svg"
            alt="Bank Logo"
            className="object-contain shrink-0 self-stretch my-auto w-6 rounded aspect-square"
          />
          <div className="flex flex-col justify-center self-stretch my-auto">
            <div className="text-xs font-semibold leading-none text-black">
              {account?.bankName}
            </div>
            <div className="mt-2 text-xs font-medium leading-none text-neutral-600">
              {account?.accountNumber} - {account?.accountHolder}
            </div>
          </div>
        </div>

        {onClick && (
          <ImageComponent onClick={onClick}
            role="button"
            loading="lazy"
            src="/icons/edit.svg"
            alt=""
            className="object-contain absolute top-2 right-3 z-0 w-4 h-4 aspect-square"
          />
        )}
      </div>
    </div>
  );
};

export default DisbursementReportBankCard;

