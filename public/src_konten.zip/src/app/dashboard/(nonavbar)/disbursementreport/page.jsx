"use client";

import { BankAccountSelector } from "@/components/BankAccountSelector/BankAccountSelector";
import PaginationStepper from "@/components/PaginationStepper/PaginationStepper";
import PaginationContainer from "@/container/PaginationContainer/PaginationContainer";
import MockServer_BankAccount from "@/services/MockServer_BankAccounts";
import MockServer_Disbursement from "@/services/MockServer_Disbursement";
import useLoadingStore from "@/store/zustand/loading";
import { Suspense, useEffect, useState } from "react";
import DisbursementReportCard from "./components/DisbursementReportCard";
import DisbursementReportHeader from "./components/DisbursementReportHeader";
import DisbursementReportMobile from "./components/DisbursementReportMobile";
import DisbursementReportTransactionTable from "./components/DisbursementReportTransactionTable";

const Page = () => {
  const { updateShow } = useLoadingStore();
  const [account, setAccount] = useState(null);
  const [history, setHistory] = useState(null);
  const [isBankAccountSelectorOpen, setIsBankAccountSelectorOpen] =
    useState(false);
  const [pagination, setPagination] = useState({
    page: 1,
    limit: 10,
    totalItems: 0,
    totalPages: 0,
  });

  const fetchAccount = async () => {
    try {
      updateShow(true);

      const acc = (await MockServer_BankAccount.getBankAccounts()).Data;
      setAccount(acc.find((e) => e.isFund === true));
    } catch (error) {
    } finally {
      updateShow(false);
    }
  };

  const fetchData = async () => {
    try {
      updateShow(true);

      const acc = (await MockServer_BankAccount.getBankAccounts()).Data;
      setAccount(acc.accounts.find((e) => e.isFund === true));

      const his = (
        await MockServer_Disbursement.getDisbursementHistory(pagination)
      ).Data;
      setPagination((prev) => {
        return {
          ...prev,
          totalItems: his.pagination.totalItems,
          totalPages: his.pagination.totalPages,
        };
      });
      setHistory(his);
    } catch (error) {
    } finally {
      updateShow(false);
    }
  };

  const fetchPagination = async (page) => {
    try {
      updateShow(true);

      const his = (
        await MockServer_Disbursement.getDisbursementHistory({
          page,
          limit: pagination.limit,
        })
      ).Data;
      setPagination({
        page: his.pagination.currentPage,
        limit: pagination.limit,
        totalItems: his.pagination.totalItems,
        totalPages: his.pagination.totalPages,
      });
      setHistory(his);
    } catch (error) {
    } finally {
      updateShow(false);
    }
  };

  const fetchLimit = async (limit) => {
    try {
      updateShow(true);

      const his = (
        await MockServer_Disbursement.getDisbursementHistory({
          page: 1,
          limit,
        })
      ).Data;
      setPagination({
        page: 1,
        limit,
        totalItems: his.pagination.totalItems,
        totalPages: his.pagination.totalPages,
      });
      setHistory(his);
    } catch (error) {
    } finally {
      updateShow(false);
    }
  };

  const handleDownloadDisbursementReport = async () => {
    try {
      updateShow(true);
      await MockServer_Disbursement.downloadReport();
    } catch (error) {
    } finally {
      updateShow(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    fetchAccount();
  }, [isBankAccountSelectorOpen]);

  return (
    <Suspense fallback={<></>}>
      <DisbursementReportMobile
        account={account}
        fetchAccount={fetchAccount}
        history={history}
        handleDownloadDisbursementReport={handleDownloadDisbursementReport}
      />

      <div className="flex sm:hidden flex-col mb-24 min-h-screen">
        <DisbursementReportHeader
          handleDownload={handleDownloadDisbursementReport}
        />
        <div className="flex flex-wrap gap-4 mt-4 w-full max-md:max-w-full">
          <DisbursementReportCard
            data={account}
            setIsBankAccountSelectorOpen={setIsBankAccountSelectorOpen}
          />
          <div className="flex gap-4 flex-col grow shrink max-md:max-w-full">
            <DisbursementReportTransactionTable
              data={history}
              pagination={pagination}
            />

            <div className="flex justify-between">
              <PaginationContainer
                currentPage={pagination.page}
                totalPages={pagination.totalPages}
                onPage={fetchPagination}
                activeColor="error"
              />

              <PaginationStepper
                pagination={pagination}
                onChange={fetchLimit}
              />
            </div>
          </div>
        </div>

        <BankAccountSelector
          isOpen={isBankAccountSelectorOpen}
          setIsOpen={setIsBankAccountSelectorOpen}
          fetchAccount={fetchAccount}
        />
      </div>
    </Suspense>
  );
};

export default Page;
