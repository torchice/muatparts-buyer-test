"use client";

import MockServer_Review from "@/services/MockServer_Reviews";
import headerZustand from "@/store/zustand/header";
import useLoadingStore from "@/store/zustand/loading";
import { useEffect, useState } from "react";
import ProductList from "../../components/ProductList";
import { useCustomRouter } from '@/libs/CustomRoute';

const page = () => {
  const router = useCustomRouter();
  const { setBackIconAction, setTitle, setBackIcon } = headerZustand();
  const { updateShow } = useLoadingStore();

  const [reviewProducts, setReviewProducts] = useState([]);

  const fetchData = async () => {
    try {
      updateShow(true);
      setReviewProducts((await MockServer_Review.getUnreadReviews(1, 50)).Data);
    } catch (error) {
    } finally {
      updateShow(false);
    }
  };

  useEffect(() => {
    setTitle("Ulasan Baru");
    setBackIcon(true);
    setBackIconAction(() => router.back());
    fetchData();
  }, []);

  return (
    <div>
      <div className="flex overflow-hidden gap-2.5 justify-center items-center px-6 py-4 w-full text-xs leading-tight bg-yellow-100 rounded-md max-md:px-5 max-md:max-w-full">
        <div className="flex flex-wrap flex-1 shrink gap-2 items-center self-stretch my-auto w-full basis-0 min-w-[240px] max-md:max-w-full">
          <div className="self-stretch my-auto font-medium text-black max-md:max-w-full">
            Jumlah ulasan dari pembeli yang belum kamu baca. Pastikan untuk
            mengeceknya agar tidak ada masukan yang terlewat.
          </div>
        </div>
      </div>

      <ProductList products={reviewProducts?.products ?? []} />
    </div>
  );
};

export default page;

