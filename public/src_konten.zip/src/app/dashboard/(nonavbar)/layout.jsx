"use client";

import toast from "@/store/zustand/toast";
import { useEffect } from "react";

const layout = ({ children }) => {
  const { setShowNavMenu } = toast();

  useEffect(() => {
    setShowNavMenu(false);
  }, []);

  return <div>{children}</div>;
};

export default layout;
