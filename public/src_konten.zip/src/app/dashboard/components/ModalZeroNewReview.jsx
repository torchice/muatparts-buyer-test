import Modal from "@/components/Modals/modal";
import { t } from "i18next";

// Improvement fix wording pak Bryan

const ModalZeroNewReview = ({ isOpen, setIsOpen, t = () => { } }) => {
  return (
    <Modal
      isOpen={isOpen}
      setIsOpen={setIsOpen}
      closeArea={true}
      closeBtn={true}
      title={t("dashboardBelumAdaUlasan")}
      desc={
        t("dashboardKamuAkanMenerima")
      }
    >
      <div className={"flex flex-col gap-[16px] items-center"}>
        {/* <Image src={modalImg}/> */}
      </div>
    </Modal >
  );
};

export default ModalZeroNewReview;
