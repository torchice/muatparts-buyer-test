"use client";

import { SetupCard } from "@/components/SetupCard/SetupCard";
import { url } from "@/services/url";
import { useEffect, useMemo, useState } from "react";
import ImageComponent from '@/components/ImageComponent/ImageComponent';
import { useTranslation } from "@/context/TranslationProvider";

const DashboardRegister = ({ status }) => {
  // 25. 11 - QC Plan - Web - Ronda Live Mei - LB - 0083
  const { tOrEmpty, langReady } = useTranslation();

  const [setupItems, setSetupItems] = useState([
    {
      icon: "/img/address-location.svg",
      title: "dashboardLengkapiAlamatToko",
      description: "dashboardKamuHarusMelengkapiAlamat",
      buttonText: "dashboardSelesai",
      isComplete: true,
      isHidden: false,
      redirect: "",
    },
    {
      icon: "/img/credit-card.svg",
      title: "dashboardLengkapiRekeningPencairan",
      description: "dashboardKamuWajibMenyimpanRekening",
      buttonText: "dashboardTambahRekening",
      isComplete: false,
      isHidden: false,
      redirect: url.tambahRekening,
    },
    {
      icon: "/img/send.svg",
      title: "dashboardPublishProduk",
      description: "dashboardUntukBerjualanMakaKamu",
      buttonText: "dashboardTambah",
      isComplete: false,
      isHidden: true,
      redirect: url.tambahProduk,
    },
  ]);

  const translatedSetupItems = useMemo(() => {
    return setupItems.map((item) => ({
      ...item,
      title: langReady ? tOrEmpty(item.title) : "",
      description: langReady ? tOrEmpty(item.description) : "",
      buttonText: langReady ? tOrEmpty(item.buttonText) : "",
    }));
  }, [langReady, tOrEmpty])

  const handleComplete = (index) => {
    setSetupItems((prev) => {
      return prev.map((step, i) => {
        if (i === index) {
          return { ...step, isComplete: true };
        }

        if (i === 2) {
          return { ...step, isHidden: false };
        }

        return step;
      });
    });
  };

  useEffect(() => {
    setSetupItems((prev) => {
      return prev.map((step, i) => {
        if (i === 0) {
          return { ...step, isComplete: status.address.isComplete };
        }

        if (i === 1) {
          return { ...step, isComplete: status.bankAccount.isComplete };
        }

        if (i === 2) {
          return {
            ...step,
            isComplete: status.product.isComplete,
            isHidden: !status.bankAccount.isComplete,
          };
        }

        return step;
      });
    });
  }, [status]);

  return (
    <div className="sm:hidden flex flex-col p-6 w-full leading-tight max-md:px-5 max-md:max-w-full">
      <div className="flex flex-wrap gap-10 justify-between items-center w-full min-h-[32px] max-md:max-w-full">
        <div className="self-stretch my-auto text-xl font-bold text-black">
          {tOrEmpty("dashboardPage")}
        </div>
      </div>

      <div className="flex flex-wrap gap-6 items-center mt-4 w-full font-semibold max-md:max-w-full">
        {setupItems.map((item, index) => (
          <div
            key={index}
            className="flex flex-1 shrink gap-3 items-center self-stretch my-auto text-base text-black basis-0 min-w-[240px]"
          >
            {item.isComplete ? (
              <ImageComponent src={"/img/success_mark.svg"}
                alt="success_mark"
                width={20}
                height={20}
                priority
              />
            ) : (
              <div className="flex flex-col self-stretch my-auto w-6 text-xs text-white whitespace-nowrap">
                <div className="px-0.5 pt-1 w-6 h-6 bg-blue-600 text-center rounded-full border border-blue-600 border-solid fill-blue-600 stroke-[1px] stroke-blue-600">
                  {index + 1}
                </div>
              </div>
            )}
            <div className="self-stretch my-auto">{tOrEmpty(item.title)}</div>
          </div>
        ))}
      </div>

      <div className="flex overflow-hidden items-start px-6 py-5 mt-4 w-full bg-white rounded-xl shadow-lg max-md:px-5 max-md:max-w-full">
        <div className="flex flex-col flex-1 shrink w-full basis-0 min-w-[240px] max-md:max-w-full">
          <div className="flex flex-col justify-center w-full max-md:max-w-full">
            <div className="flex gap-3 items-center w-full max-md:max-w-full">
              <div className="flex flex-col flex-1 shrink self-stretch my-auto w-full basis-0 min-w-[240px] max-md:max-w-full">
                <div className="flex-1 shrink gap-1 self-stretch w-full text-lg font-bold text-black max-md:max-w-full">
                  {tOrEmpty("dashboardLangkahMudahUntukMulaiBerjualan")}
                </div>
                <div className="mt-3 text-xs font-medium text-neutral-500 max-md:max-w-full">
                  {tOrEmpty("dashboardAyoInfomasiToko")}
                </div>
              </div>
            </div>
          </div>

          {translatedSetupItems.map((item, index) => (
            <div
              key={index}
              className="flex flex-col mt-6 w-full max-md:max-w-full"
            >
              <SetupCard {...item} />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DashboardRegister;

