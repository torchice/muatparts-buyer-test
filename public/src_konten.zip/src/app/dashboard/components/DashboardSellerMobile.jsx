import BottomBar from "@/components/BottomBar/BottomBar";
import { StatCard } from "@/components/StatCard/StatCard";
import MockServer_Dashboard from "@/services/MockServer_Dashboard";
import { url } from "@/services/url";
import headerZustand from "@/store/zustand/header";
import useLoadingStore from "@/store/zustand/loading";
import toast from "@/store/zustand/toast";
import { useSearchParams } from 'next/navigation';
import { useEffect, useState } from "react";
import DashboardSellerFullMobile from "./DashboardSellerFullMobile";
import ModalZeroNewReview from "./ModalZeroNewReview";
import { useCustomRouter } from '@/libs/CustomRoute';
import ImageComponent from '@/components/ImageComponent/ImageComponent';
import { authZustand } from "@/store/auth/authZustand";
import { useTranslation } from "@/context/TranslationProvider";

// Improvement fix wording pak Bryan

const DashboardSellerMobile = () => {
  // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0853
  const { t } = useTranslation();
  const router = useCustomRouter();
  const { updateShow } = useLoadingStore();
  const searchParams = useSearchParams();
  const { setBackIcon, setBackIconAction, setTitle, title } = headerZustand();
  const { setShowNavMenu } = toast();

  const [dashboardSummary, setDashboardSummary] = useState(null);
  const [fullDetail, setFullDetail] = useState(false);
  const [isModalZeroNewReview, setIsModalZeroNewReview] = useState(false);

  const fetchData = async () => {
    try {
      updateShow(true);
      setDashboardSummary(
        (await MockServer_Dashboard.getDashboardStats()).Data
      );
    } catch (error) {
    } finally {
      updateShow(false);
    }
  };

  const handleOpenFullDetail = () => {
    setTitle("Dashboard");
    setBackIcon(true);
    setFullDetail(true);
    router.push("/dashboard?detail=true");
    setBackIconAction(() => router.replace(`/dashboard`));
  };

  const handleCloseFullDetail = () => {
    setFullDetail(false);
    setTitle("");
    setShowNavMenu(true);
    setBackIcon(false);
  };

  useEffect(() => {
    fetchData();

    if (searchParams.get("detail") === "true") {
      handleOpenFullDetail();
    } else {
      handleCloseFullDetail();
    }
  }, [searchParams.get("detail")]);

  return fullDetail ? (
    <DashboardSellerFullMobile />
  ) : (
    <div className="hidden sm:flex sm:justify-start sm:items-start flex-col gap-3">
      <div className="h-full bg-white w-screen p-6">
        <div className="self-stretch my-auto text-xl font-bold text-black mb-5">
          {t("dashboardPage")}
        </div>

        <div className="grid grid-cols-2 gap-3 mb-5">
          <StatCard
            onClick={() => {
              router.push(url.pesananMasuk);
            }}
            title={t("dashboardPesananMasuk")}
            value={dashboardSummary?.incomingOrders ?? 0}
          />
          <StatCard
            onClick={() => {
              router.push(url.pesananSiapDikirim);
            }}
            title={t("dashboardPesananSiapDikirim")}
            value={dashboardSummary?.readyToShipOrders ?? 0}
          />
          <StatCard
            onClick={() => {
              // Imp Redirect Chat Dashboard - Airlangga - 0077/HW/PROG/III/2025 & LB - 0005, 24. THP 2 - MOD001 - MP - 026 - QC Plan - Web - MuatParts - Dashboard Seller
              router.push(
                `${process.env.NEXT_PUBLIC_CHAT_URL}initiate?accessToken=${authZustand.getState().accessToken
                }&refreshToken=${authZustand.getState().refreshToken
                }&initiatorRole=seller`
              );
            }}
            title={t("dashboardChatBaru")}
            value={dashboardSummary?.newChats ?? 0}
          />
          <StatCard
            onClick={async () => {
              try {
                if (dashboardSummary?.newReviews <= 0) {
                  setIsModalZeroNewReview(true);
                } else {
                  router.push(`${url.ulasanBaru}`);
                }
              } catch (error) { }
            }}
            title={t("dashboardUlasanBaru")}
            value={dashboardSummary?.newReviews ?? 0}
          />
        </div>
        <div
          role="button"
          onClick={handleOpenFullDetail}
          className="flex text-blue-700 fill-blue-500 hover:text-blue-800 font-semibold text-xs gap-2 items-center justify-end"
        >
          {t("dashboardLihatSelengkapnya")}
          <ImageComponent src="/icons/chevron-right-blue.svg"
            alt=""
            width={6}
            height={6}
          />
        </div>
      </div>

      <BottomBar />

      <ModalZeroNewReview
        isOpen={isModalZeroNewReview}
        setIsOpen={setIsModalZeroNewReview}
      />
    </div>
  );
};

export default DashboardSellerMobile;

