"use client";

import BottomBar from "@/components/BottomBar/BottomBar";
import Bottomsheet from "@/components/Bottomsheet/Bottomsheet";
import { url } from "@/services/url";
import toast from "@/store/zustand/toast";
import { useEffect, useState } from "react";
import { OnboardingSteps } from "./OnboardingSteps";
import { useCustomRouter } from '@/libs/CustomRoute';
import ImageComponent from '@/components/ImageComponent/ImageComponent';
import { useTranslation } from "@/context/TranslationProvider";

const DashboardRegisterMobile = ({ status }) => {
  // 25. 11 - QC Plan - Web - Ronda Live Mei - LB - 0083
  const { tOrEmpty } = useTranslation();
  const router = useCustomRouter();
  const { setShowBottomsheet, setTitleBottomsheet, setDataBottomsheet } =
    toast();

  const [setupItems, setSetupItems] = useState([
    {
      id: 1,
      icon: "/img/address-location.svg",
      title: "dashboardLengkapiAlamatToko",
      description: "dashboardKamuHarusMelengkapiAlamat",      
      buttonText: "dashboardSelesai",
      isComplete: true,
      isHidden: false,
      redirect: "",
      hasBorder: true,
    },
    {
      id: 2,
      icon: "/img/credit-card.svg",
      title: "dashboardLengkapiRekeningPencairan",
      description: "dashboardKamuWajibMenyimpanRekening",
      buttonText: "dashboardTambahRekening",
      isComplete: false,
      isHidden: false,
      redirect: url.tambahRekening,
      hasBorder: true,
    },
    {
      id: 3,
      icon: "/img/send.svg",
      title: "dashboardPublishProduk",
      description: "dashboardUntukBerjualanMakaKamu",
      buttonText: "dashboardTambahProduk",
      isComplete: false,
      isHidden: true,
      redirect: url.tambahProduk,
      hasBorder: false,
    },
  ]);

  const handleComplete = (index) => {
    setSetupItems((prev) => {
      return prev.map((step, i) => {
        if (i === index) {
          return { ...step, isComplete: true };
        }

        if (i === 2) {
          return { ...step, isHidden: false };
        }

        return step;
      });
    });
  };

  const handleDetail = () => {
    setTitleBottomsheet("Dashboard");
    setDataBottomsheet(<OnboardingSteps setupItems={setupItems} />);
    setShowBottomsheet(true);
  };

  useEffect(() => {
    setSetupItems((prev) => {
      return prev.map((step, i) => {
        if (i === 0) {
          return { ...step, isComplete: status.address.isComplete };
        }

        if (i === 1) {
          return { ...step, isComplete: status.bankAccount.isComplete };
        }

        if (i === 2) {
          return {
            ...step,
            isComplete: status.product.isComplete,
            isHidden: status.bankAccount.isComplete === false ? true : false,
          };
        }

        return step;
      });
    });
  }, [status]);

  return (
    <div className="hidden sm:flex flex-col w-full leading-tight max-md:px-5 max-md:max-w-full">
      <div className="p-6">
        <div className="flex flex-wrap gap-10 justify-between items-center w-full min-h-[32px] max-md:max-w-full">
          <div className="self-stretch my-auto text-xl font-bold text-black flex gap-2">
            {tOrEmpty("dashboardPage")}
            <ImageComponent src="/icons/info_mark.svg"
              alt=""
              width={16}
              height={16}
              className="cursor-pointer"
              onClick={handleDetail}
            />
          </div>
        </div>

        <div className="flex flex-wrap gap-6 items-center mt-4 w-full font-semibold max-md:max-w-full">
          {setupItems.map((item, index) => (
            <div
              key={index}
              className="flex justify-between flex-1 shrink items-center self-stretch my-auto text-base text-black basis-0 min-w-[240px]"
            >
              <div className="flex flex-row gap-3">
                {item.isComplete ? (
                  <ImageComponent src={"/img/success_mark.svg"}
                    alt="success_mark"
                    width={20}
                    height={20}
                    priority
                  />
                ) : (
                  <div className="flex flex-col self-stretch my-auto w-6 text-xs text-white whitespace-nowrap">
                    <div className="px-0.5 pt-1 w-6 h-6 bg-blue-600 text-center rounded-full border border-blue-600 border-solid fill-blue-600 stroke-[1px] stroke-blue-600">
                      {index + 1}
                    </div>
                  </div>
                )}
                <div className="self-stretch my-auto text-xs">{tOrEmpty(item.title)}</div>
              </div>

              {item.isComplete ? (
                <></>
              ) : item.isHidden == false ? (
                <div
                  className="text-blue-600 text-end text-xs cursor-pointer hover:text-blue-800 duration-200"
                  onClick={() => router.push(item.redirect)}
                >
                  {tOrEmpty(item.buttonText)}
                </div>
              ) : (
                <></>
              )}
            </div>
          ))}
        </div>
      </div>

      <BottomBar />
      <Bottomsheet />
    </div>
  );
};

export default DashboardRegisterMobile;

