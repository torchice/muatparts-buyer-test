import Button from "@/components/Button/Button";
import Modal from "@/components/Modals/modal";
import ProductList from "./ProductList";

// Improvement fix wording pak Bryan

const ModalNewReview = ({ isOpen, setIsOpen, reviewProducts, t = () => { } }) => {
  const handleUnderstand = () => {
    setIsOpen(false);
  };

  return (
    <Modal
      isOpen={isOpen}
      setIsOpen={setIsOpen}
      closeArea={true}
      closeBtn={true}
    >
      <div className={"flex flex-col gap-[16px] w-full items-center"}>
        <span
          className={
            "font-[700] text-[16px] leading-[19.2px] text-[#000000] text-center"
          }
        >
          {t("dashboardUlasanBaru")}
        </span>

        <span
          className={
            "font-[500] text-[14px] leading-[16.8px] text-[#000000] text-center"
          }
        >
          {t("messageUnreadBuyerReviewsCheckPrompt")}
        </span>

        <ProductList products={reviewProducts?.products} />
        <Button onClick={handleUnderstand}>{t("dashboardMengerti")}</Button>
      </div>
    </Modal>
  );
};
export default ModalNewReview;
