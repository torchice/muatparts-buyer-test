// 24. THP 2 - MOD001 - MP - 026 - QC Plan - Web - MuatParts - Dashboard Seller
// LB -0020, LB -0021, LB -0015, LB -0016, LB -0099, LB -0019, LB -0023, LB -0024, LB -0031, LB -0032, LB -0049, LB -0013, LB -0014, LB -0007
"use client";

import { MetricCard } from "@/components/MetricCard/MetricCard";
import PeriodPicker from "@/components/PeriodePicker/PeriodPicker";
import { PromotionCard } from "@/components/PromotionCard/PromotionCard";
import { StatCard } from "@/components/StatCard/StatCard";
import MockServer_Dashboard from "@/services/MockServer_Dashboard";
import MockServer_Review from "@/services/MockServer_Reviews";
import { url } from "@/services/url";
import useLoadingStore from "@/store/zustand/loading";
import { useEffect, useState } from "react";
import ModalNewReview from "./ModalNewReview";
import ModalZeroDisbursement from "./ModalZeroDisbursement ";
import ModalZeroEarnings from "./ModalZeroEarnings";
import ModalZeroNewReview from "./ModalZeroNewReview";
import { useCustomRouter } from '@/libs/CustomRoute';
import ImageComponent from '@/components/ImageComponent/ImageComponent';
import { authZustand } from "@/store/auth/authZustand";
import { useTranslation } from "@/context/TranslationProvider";

const DashboardSeller = () => {
  const router = useCustomRouter();
  const { updateShow } = useLoadingStore();
  // Improvement fix wording pak Bryan
  // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0853
  const { t } = useTranslation();

  const [activePromotions, setActivePromotions] = useState(null);
  const [dashboardStatus, setDashboardStatus] = useState(null);
  const [dashboardSummary, setDashboardSummary] = useState(null);
  const [selectedPeriod, setSelectedPeriod] = useState("all");
  const [isModalZeroDisbursementOpen, setIsModalZeroDisbursementOpen] =
    useState(false);
  const [isModalZeroEarningsOpen, setIsModalZeroEarningsOpen] = useState(false);
  const [isModalZeroNewReview, setIsModalZeroNewReview] = useState(false);
  const [isModalNewReviewOpen, setIsModalNewReviewOpen] = useState(false);
  const [reviewProducts, setReviewProducts] = useState([]);
  const [storePerformance, setStorePerformance] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [startDate, setStartDate] = useState(null);

  const fetchData = async () => {
    try {
      updateShow(true);

      setDashboardStatus(
        (await MockServer_Dashboard.getDashboardStatus()).Data
      );
      setDashboardSummary(
        (await MockServer_Dashboard.getDashboardStats()).Data
      );
      setStorePerformance(
        (
          await MockServer_Dashboard.getStorePerformance(
            selectedPeriod,
            startDate,
            endDate
          )
        ).Data
      );
      setActivePromotions(
        (await MockServer_Dashboard.getActivePromotions()).Data
      );
    } catch (error) {
    } finally {
      updateShow(false);
    }
  };

  const fetchStorePerformance = async () => {
    try {
      updateShow(true);
      console.log("startDate", startDate);
      setStorePerformance(
        (
          await MockServer_Dashboard.getStorePerformance(
            selectedPeriod,
            startDate,
            endDate
          )
        ).Data
      );
    } catch (error) {
    } finally {
      updateShow(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    fetchStorePerformance();
  }, [startDate, endDate]);

  return (
    <>
      <div className="sm:hidden flex flex-col w-full">
        <div className="flex flex-wrap gap-10 justify-between items-center w-full leading-tight min-h-[32px] max-md:max-w-full">
          <div className="self-stretch my-auto text-xl font-bold text-black">
            {t("dashboardPage")}
          </div>
        </div>

        {/* {dashboardStatus?.npwpStatus?.isValid == false && (
          <div className="flex overflow-hidden gap-2.5 justify-center items-center px-6 py-4 mt-4 w-full text-xs leading-tight bg-yellow-100 rounded-md max-md:px-5 max-md:max-w-full">
            <div className="flex flex-wrap flex-1 shrink gap-2 items-center self-stretch my-auto w-full basis-0 min-w-[240px] max-md:max-w-full">
              <ImageComponent loading="lazy"
                src="/img/warning.svg"
                alt=""
                className="object-contain shrink-0 self-stretch my-auto w-6 aspect-square"
              />
              <div className="self-stretch my-auto font-medium text-black max-md:max-w-full">
                Pastikan NPWP kamu telah terverifikasi untuk memperoleh Faktur
                Pajak atas pengenaan Biaya Layanan
              </div>
              <button onClick={() => router.push(url.npwp)} className="flex-1 shrink self-stretch my-auto font-semibold text-right text-blue-600 basis-0">
                Input NPWP
              </button>
            </div>
          </div>
        )} */}

        <div className="flex overflow-hidden items-start px-6 py-5 mt-4 leading-tight bg-white rounded-xl shadow-lg max-md:px-5 max-md:max-w-full w-full">
          <div className="flex flex-col flex-1 shrink w-full basis-0 min-w-[240px] max-md:max-w-full">
            <div className="flex flex-col justify-center w-full max-md:max-w-full">
              <div className="flex gap-3 items-center w-full max-md:max-w-full">
                <div className="flex flex-col flex-1 shrink self-stretch my-auto w-full basis-0 min-w-[240px] max-md:max-w-full">
                  <div className="flex-1 shrink gap-1 self-stretch w-full text-lg font-bold text-black max-md:max-w-full">
                    {t("dashboardYangPerluDiperhatikan")}
                  </div>
                  <div className="mt-3 text-xs font-medium text-neutral-500 max-md:max-w-full">
                    {t("dashboardAktivitasYangPerlu")}
                  </div>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-4 gap-3 md:grid-cols-2 items-start mt-6 w-full text-black max-md:max-w-full">
              <StatCard
                onClick={() => {
                  router.push(url.pesananMasuk);
                }}
                title={t("dashboardPesananMasuk")}
                value={dashboardSummary?.incomingOrders ?? 0}
              />
              <StatCard
                onClick={() => {
                  router.push(url.pesananSiapDikirim);
                }}
                title={t("dashboardPesananSiapDikirim")}
                value={dashboardSummary?.readyToShipOrders ?? 0}
              />
              <StatCard
                onClick={() => {
                  // Imp Redirect Chat Dashboard - Airlangga - 0077/HW/PROG/III/2025 & LB - 0005, 24. THP 2 - MOD001 - MP - 026 - QC Plan - Web - MuatParts - Dashboard Seller
                  router.push(
                    `${process.env.NEXT_PUBLIC_CHAT_URL}initiate?accessToken=${authZustand.getState().accessToken
                    }&refreshToken=${authZustand.getState().refreshToken
                    }&initiatorRole=seller`
                  );
                }}
                title={t("dashboardChatBaru")}
                value={dashboardSummary?.newChats ?? 0}
              />
              <StatCard
                onClick={async () => {
                  try {
                    if (dashboardSummary?.newReviews <= 0) {
                      setIsModalZeroNewReview(true);
                    } else {
                      const res = (
                        await MockServer_Review.getUnreadReviews(1, 10)
                      ).Data;

                      setReviewProducts(res);
                      setIsModalNewReviewOpen(true);
                    }
                  } catch (error) { }
                }}
                title={t("dashboardUlasanBaru")}
                value={dashboardSummary?.newReviews ?? 0}
              />
              <StatCard
                className={"hidden"}
                onClick={() => {
                  router.push(url.diskusi);
                }}
                title={t("dashboardNewDiscussion")}
                value={0}
              />
              <StatCard
                className={"hidden"}
                onClick={() => {
                  router.push(url.komplain);
                }}
                title={t("AppMuatpartsDashboardSellerKomplainBaru")}
                value={dashboardSummary?.newComplaints ?? 0}
              />
              <StatCard
                className={"hidden"}
                onClick={() => {
                  router.push(url.komplain);
                }}
                title={t("AppMuatpartsDashboardSellerResponPengembalian")}
                value={dashboardSummary?.returnResponses ?? 0}
              />
              <StatCard
                className={"hidden"}
                onClick={() => {
                  router.push(url.komplain);
                }}
                title={t("AppMuatpartsDashboardSellerResponPengirimanRetur")}
                value={dashboardSummary?.returnShippingResponses ?? 0}
              />
              <StatCard
                onClick={() => {
                  router.push(url.stokHabis);
                }}
                title={t("AppMuatpartsDashboardSellerProdukHabis")}
                value={dashboardSummary?.outOfStockProducts ?? 0}
              />
            </div>
          </div>
        </div>

        <div className="flex overflow-hidden items-start px-6 py-5 mt-4 max-w-full bg-white rounded-xl shadow-lg w-full max-md:px-5">
          <div className="flex flex-col flex-1 shrink w-full basis-0 min-w-[240px] max-md:max-w-full">
            <div className="flex flex-wrap gap-1 items-center w-full leading-tight text-black max-md:max-w-full">
              <div className="flex-1 shrink self-stretch my-auto text-lg font-bold basis-0 max-md:max-w-full">
                {t('dashboardPenghasilanDanPerformaToko')}
              </div>
              <PeriodPicker
                onPeriodChange={(e) => {
                  setSelectedPeriod(e.type);
                  setEndDate(e.endDate);
                  setStartDate(e.startDate);
                }}
              />
            </div>

            <div className="flex flex-wrap gap-3 items-start mt-6 w-full leading-none max-md:max-w-full">
              <div className="flex flex-col flex-1 shrink text-black basis-0 min-w-[240px] max-md:max-w-full gap-3">
                <MetricCard
                  onClick={() => {
                    if (storePerformance?.revenue !== null) {
                      if (storePerformance?.revenue === 0) {
                        setIsModalZeroEarningsOpen(true);
                      } else {
                        router.push(url.totalPenghasilan);
                      }
                    }
                  }}
                  icon="/img/total-earnings.svg"
                  title={t("dashboardTotalPenghasilan")}
                  value={
                    // (startDate !== null || endDate !== null) &&
                    // storePerformance?.revenue === 0 ? (
                    //   <p className="text-neutral-600 font-semibold">
                    //     Tidak ada data
                    //   </p>

                    // ) : (
                    new Intl.NumberFormat("id-ID", {
                      style: "currency",
                      currency: "IDR",
                      maximumFractionDigits: 0,
                    }).format(storePerformance?.revenue ?? 0)
                    // )
                  }
                />
                <MetricCard
                  onClick={() => {
                    // if (storePerformance?.disbursement !== null) {
                    //   if (storePerformance?.disbursement === 0) {
                    //     setIsModalZeroDisbursementOpen(true);
                    //   } else {
                    //     router.push(url.laporanPencarian);
                    //   }
                    // }
                    //LBM - fixing Rules card pencairan dalam proses : 20/04/2025 - brian 
                    if (storePerformance?.isHistoryFund !== null) {
                      if (storePerformance?.isHistoryFund !== true) {
                        setIsModalZeroDisbursementOpen(true);
                      } else {
                        router.push(url.laporanPencarian);
                      }
                    }
                  }}
                  icon="/img/pending-earnings.svg"
                  title={t("dashboardPencairanDalamProses")}
                  value={
                    // (startDate !== null || endDate !== null) &&
                    // storePerformance?.disbursement === 0 ? (
                    //   <p className="text-neutral-600 font-semibold">
                    //     Tidak ada data
                    //   </p>
                    // ) : (
                    new Intl.NumberFormat("id-ID", {
                      style: "currency",
                      currency: "IDR",
                      maximumFractionDigits: 0,
                    }).format(storePerformance?.disbursement ?? 0)
                    // )
                  }
                />
              </div>
              <div className="flex flex-col flex-1 shrink text-black basis-0 min-h-[152px] min-w-[240px] max-md:max-w-full gap-3">
                <MetricCard
                  onClick={() => {
                    // Dikomen karena tidak ada ulasan seller
                    // router.push(url.rating);
                  }}
                  icon="/img/performance-rating.svg"
                  title={t("dashboardUlasan")}
                  value={
                    // (startDate !== null || endDate !== null) &&
                    // storePerformance?.rating === 0 ? (
                    //   <p className="text-neutral-600 font-semibold">
                    //     Tidak ada data
                    //   </p>
                    // ) : (
                    <span className="flex justify-end gap-2 items-center">
                      <ImageComponent src="/img/star.svg"
                        height={15}
                        width={15}
                        alt="star-icon"
                      />
                      <span>
                        {storePerformance?.rating ?? 0}
                        <span className="text-neutral-600 text-sm font-semibold">
                          /5
                        </span>
                      </span>
                    </span>
                    // )
                  }
                />
                <MetricCard
                  onClick={() => {
                    router.push(url.totalPesanan);
                  }}
                  icon="/img/performance-sales.svg"
                  title={t("dashboardTotalPesanan")}
                  value={
                    // (startDate !== null || endDate !== null) &&
                    // storePerformance?.totalOrder === 0 ? (
                    //   <p className="text-neutral-600 font-semibold">
                    //     Tidak ada data
                    //   </p>
                    // ) : (
                    storePerformance?.totalOrder ?? 0
                    // )
                  }
                />
              </div>
            </div>
          </div>
        </div>

        <div className="flex overflow-hidden items-start px-6 py-5 mt-4 max-w-full bg-white rounded-xl shadow-lg w-full max-md:px-5">
          <div className="flex flex-col flex-1 shrink w-full basis-0 min-w-[240px] max-md:max-w-full">
            <div className="flex flex-wrap gap-1 items-center w-full max-md:max-w-full">
              <div className="flex-1 shrink self-stretch my-auto text-lg font-bold leading-tight text-black basis-0 max-md:max-w-full">
                {t("dashboardKegiatanPromosiSaatIni")}
              </div>
            </div>
            <div className="flex flex-wrap gap-3 items-start mt-6 w-full text-sm max-md:max-w-full">
              <div className="text-black flex flex-col flex-1 shrink justify-between basis-0 min-h-[70px] min-w-[240px] max-md:max-w-full">
                <PromotionCard
                  onClick={() => {
                    if (activePromotions?.voucher === 0) {
                      router.push(url.buatVoucher);
                    } else {
                      router.push(url.aktifVoucher);
                    }
                  }}
                  value={activePromotions?.voucher ?? 0}
                  unit={"Voucher"}
                  icon={"/img/active-voucher.svg"}
                  title={t("dashboardVoucherAktif")}
                  actionButton={t("dashboardBuatVoucher")}
                />
              </div>
              <div className="text-black flex flex-col flex-1 shrink basis-0 min-h-[70px] min-w-[240px] max-md:max-w-full">
                <PromotionCard
                  onClick={() => {
                    if (activePromotions?.promo === 0) {
                      router.push(url.buatPromo);
                    } else {
                      router.push(url.aktifPromo);
                    }
                  }}
                  value={activePromotions?.promo ?? 0}
                  // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0853
                  unit={t("labelProduk")}
                  icon={"/img/active-promotion.svg"}
                  title={t("dashboardPromosiAktif")}
                  actionButton={t("dashboardBuatPromosi")}
                />
              </div>
            </div>
          </div>
        </div>

        <ModalZeroEarnings
          isOpen={isModalZeroEarningsOpen}
          setIsOpen={setIsModalZeroEarningsOpen}
          t={t}
        />

        <ModalZeroDisbursement
          isOpen={isModalZeroDisbursementOpen}
          setIsOpen={setIsModalZeroDisbursementOpen}
          t={t}
        />

        <ModalNewReview
          isOpen={isModalNewReviewOpen}
          setIsOpen={setIsModalNewReviewOpen}
          reviewProducts={reviewProducts}
          t={t}
        />

        <ModalZeroNewReview
          isOpen={isModalZeroNewReview}
          setIsOpen={setIsModalZeroNewReview}
          t={t}
        />
      </div>
    </>
  );
};

export default DashboardSeller;

