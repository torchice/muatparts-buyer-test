import Modal from "@/components/Modals/modal";

// Improvement fix wording pak Bryan

const ModalZeroDisbursement = ({ isOpen, setIsOpen, t = () => { } }) => {
  return (
    <Modal
      isOpen={isOpen}
      setIsOpen={setIsOpen}
      closeArea={true}
      closeBtn={true}
      title={t("dashboardBelumAdaPencairan")}
      desc={
        t("messageWithdrawalProcessedEveryWorkingDayWithEarnings")
      }
    >
      <div className={"flex flex-col gap-[16px] items-center"}>
        {/* <Image src={modalImg}/> */}
      </div>
    </Modal>
  );
};

export default ModalZeroDisbursement;
