import { OnboardingStep } from "./OnboardingStep";

export function OnboardingSteps({ setupItems }) {
  return (
    <div className="flex flex-col mx-auto w-full max-w-[480px]">
      <div className="flex flex-col text-xs max-w-[328px]">
        {setupItems.map((step, index) => (
          <div key={step.id} className={index > 0 ? "mt-4" : ""}>
            <OnboardingStep setupItems={step} />
          </div>
        ))}
      </div>
    </div>
  );
}
