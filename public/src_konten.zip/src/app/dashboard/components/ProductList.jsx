import { url } from "@/services/url";
import { useCustomRouter } from '@/libs/CustomRoute';
import ImageComponent from '@/components/ImageComponent/ImageComponent';

function ProductList({ products }) {
  const router = useCustomRouter();

  return (
    <div className="flex self-stretch w-full bg-white rounded-md border border-solid border-stone-300 sm:px-2">
      <div className="flex overflow-auto flex-col flex-1 shrink px-2 my-auto w-full text-xs font-medium leading-tight text-black basis-0 min-w-[240px] max-h-[205px] sm:max-h-full">
        {products.map((product) => (
          <div
            key={product.id}
            className="flex flex-row justify-between hover:bg-slate-100 flex-1 shrink gap-2.5 self-stretch py-3 w-full border-b border-solid border-b-stone-300"
            tabIndex={0}
            role="button"
            onClick={() => {
              router.push(`${url.produk}/${product.id}`);
            }}
          >
            <div>{product.name}</div>
            <ImageComponent src="/icons/chevron-right.svg"
              alt=""
              width={15}
              height={15}
              className="sm:flex hidden"
            />
          </div>
        ))}
      </div>
    </div>
  );
}

export default ProductList;

