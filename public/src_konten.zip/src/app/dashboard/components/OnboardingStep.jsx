import { useCustomRouter } from '@/libs/CustomRoute';

export function OnboardingStep({ setupItems }) {
  const router = useCustomRouter();

  return (
    <div
      className={`flex flex-col justify-center w-full ${
        setupItems.hasBorder
          ? "pb-4 border-b border-solid border-b-stone-300"
          : ""
      }`}
    >
      <div className="font-semibold leading-none text-black">
        {setupItems.title}
      </div>
      <div className="mt-3 font-medium leading-3 text-neutral-500">
        {setupItems.description}
      </div>

      {setupItems.isComplete ? (
        <></>
      ) : setupItems.isHidden == false ? (
        <div
          className="mt-3 text-blue-600 hover:text-blue-800 duration-200"
          role="button"
          tabIndex={0}
          onClick={() => router.push(setupItems.redirect)}
        >
          {setupItems.buttonText}
        </div>
      ) : (
        <></>
      )}
    </div>
  );
}

