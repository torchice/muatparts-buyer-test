import Modal from "@/components/Modals/modal";
import { url } from "@/services/url";
import { useCustomRouter } from '@/libs/CustomRoute';

// Improvement fix wording pak Bryan
// 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0853
const ModalZeroEarnings = ({ isOpen, setIsOpen, t = () => { } }) => {
  const router = useCustomRouter();

  return (
    <Modal
      isOpen={isOpen}
      setIsOpen={setIsOpen}
      closeArea={true}
      closeBtn={true}
      title={t("dashboardBelumAdaTotalPenghasilan")}
      desc={
        t("dashboardAyoPromosikanProduk")
      }
      action1={{
        action: () => {
          router.push(url.buatPromo);
        },
        text: t("dashboardBuatPromo"),
        style: "outline",
        color: "#176CF7",
        class: "sm:w-[120px] w-[140px]",
      }}
      action2={{
        action: () => {
          router.push(url.buatVoucher);
        },
        text: t("dashboardBuatVoucher"),
        style: "outline",
        color: "#176CF7",
        class: "sm:w-[120px] w-[140px]",
      }}
    >
      <div className={"flex flex-col gap-[16px] items-center"}>
        {/* <Image src={modalImg}/> */}
      </div>
    </Modal>
  );
};

export default ModalZeroEarnings;

