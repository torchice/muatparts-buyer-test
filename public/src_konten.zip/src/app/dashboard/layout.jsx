"use client";

import NavigationMenu from "@/components/Bottomsheet/NavigationMenu";
import DashboardBottomNavbar from "@/components/DashboardBottomNavbar/DashboardBottomNavbar";
import FAB from "@/components/FAB/FAB";
import toast from "@/store/zustand/toast";
import { useEffect } from "react";

const layout = ({ children }) => {
  const { showNavMenu, setDataNavMenu } = toast();
  // LB - 0389, 25.03
  useEffect(() => {
    let url = typeof window !== 'undefined' ? window.location.href : null
    
    setDataNavMenu({
      title: "Home",
      action: url.includes("/muatparts") ? "/muatparts/dashboard" : "/dashboard",
      type: 0,
    });
  }, [])
  

  return (
    <div>
      {children}
      {/* {showNavMenu && <DashboardBottomNavbar />} */}
      {showNavMenu && <NavigationMenu />}
      {/* <FAB /> */}
    </div>
  );
};

export default layout;
