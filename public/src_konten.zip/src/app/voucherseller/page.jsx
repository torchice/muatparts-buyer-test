"use client";

import { useEffect, useState, useRef } from "react";
import Kenapa from "@/container/LandingContainer/Kenapa";
import Hero from "@/container/LandingContainer/Hero";
import Kenali from "@/container/LandingContainer/Kenali";
import Transaksi from "@/container/LandingContainer/Transaksi";
import Step from "@/container/LandingContainer/Step";
import Penjual from "@/container/LandingContainer/Penjual";
import Faq from "@/container/LandingContainer/Faq";
import Join from "@/container/LandingContainer/Join";
import Footer from "@/container/LandingContainer/Footer";
import toast from "@/store/zustand/toast";
import headerZustand from "@/store/zustand/header";
import SWRHandler from "@/services/useSWRHook";
import { useMatrixCheck } from "@/container/LandingContainer/useMatrixCheck";
import { authZustand as useToken } from "@/store/auth/authZustand";
import Modal from "@/components/AI/Modal";
import { userZustand } from "@/store/auth/userZustand";

const api = process.env.NEXT_PUBLIC_GLOBAL_API + "v1/";

export default function LandingMuatParts() {
  const { setShowNavMenu } = toast();
  const { setHeader, setBackIcon, setDataMatrix, dataMatrix } = headerZustand();
  const { setDataUser,setDataMatrixLS } = userZustand();
  const { checkMatrixVerification } = useMatrixCheck();
  const { useSWRHook, useSWRMutateHook } = SWRHandler;
  const [dataLogin, setDataLogin] = useState();
  const isLogin = useToken?.getState()?.accessToken;

  // Gunakan ref untuk mencegah infinite loop
  const apiCallRef = useRef(false);

  // Panggil API checkMatrix hanya jika user login
  const { data: dataCheckMatrix } = useSWRHook(
    isLogin && !apiCallRef.current ? `${api}register/checkmatrix` : null
  );

  const { data: dataLoginUser, trigger: triggerDataLoginUser } =
    useSWRMutateHook(`${api}user/getUserStatusV3`);

  // Handle dataCheckMatrix
  useEffect(() => {
    if (dataCheckMatrix?.Data) {
      setDataMatrixLS(dataCheckMatrix.Data);
      apiCallRef.current = true; // Set flag setelah data diterima
    }
  }, [dataCheckMatrix]);

  // Handle dataLoginUser
  useEffect(() => {
    if (dataLoginUser?.data?.Data) {
      setDataUser(dataLoginUser.data.Data);
      setDataLogin(dataLoginUser.data.Data);
    }
  }, [dataLoginUser]);

  // Trigger getUserStatus saat login
  useEffect(() => {
    if (isLogin && !apiCallRef.current) {
      triggerDataLoginUser();
    }
  }, [isLogin]);

  // Reset state saat unmount
  // useEffect(() => {
  //   return () => {
  //     setDataLogin(null);
  //     setDataMatrixLS(null);
  //     apiCallRef.current = false;
  //   };
  // }, []);

  useEffect(() => {
    setShowNavMenu(false);
    setHeader("");
    setBackIcon(false);
  }, []);

  const handleCheckMatrix = () => {
    checkMatrixVerification(dataMatrix);
  };

  return (
    <div className="flex flex-col rounded-none w-[1280px] sm:w-auto m-[-25px_auto_-20px_auto] sm:!-mt-[56px]">
      <Modal />
      <Hero />
      <Kenapa dataLogin={dataLogin} handleAuthLanding={handleCheckMatrix} />
      <Kenali />
      <Transaksi />
      <Step dataLogin={dataLogin} handleAuthLanding={handleCheckMatrix} />
      <Penjual />
      <Faq />
      <Join dataLogin={dataLogin} handleAuthLanding={handleCheckMatrix} />
      <Footer />
    </div>
  );
}
