import { useState, useEffect } from "react";
import { Button } from "../../../../components/MobileCom/button";
import { Badge } from "../../../../components/MobileCom/badge";
import { id } from 'date-fns/locale'
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Calendar } from "lucide-react";
import { format } from "date-fns";
import { useHeader } from '../../../../common/ResponsiveContext';
import { getOrderVoucher } from '../../../../services/voucher';
import VoucherCardLists from "./VoucherCardLists";
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
  
} from "../../../../components/MobileCom/drawer";
import DrawerMore from "./DrawerMore";

import {
  RadioGroup,
  RadioGroupItem,
} from "../../../../components/MobileCom/radio-group";
import { Label } from "../../../../components/MobileCom/label";
import CustomDatePicker from "../../../../components/MobileCom/custom-datepicker";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "../../../../components/MobileCom/card";
import { formatDate,formatCurrency } from "../../../../libs/formaters";

export default function DaftarPesanan({ prev }) {
  const pathname = usePathname();
  const voucherId = pathname.split('voucherseller/')[1];
  const { setAppBar } = useHeader();
  
  const [transactions, setTransactions] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  
  // Period filter states
  const [selectedPeriod, setSelectedPeriod] = useState("all");
  const [dateRange, setDateRange] = useState({
    from: null,
    to: null
  });

  const periods = [
    { id: "all", label: "Semua Daftar Pesanan" },
    { id: "today", label: "Hari Ini" },
    { id: "week", label: "1 Minggu Terakhir" },
    { id: "custom", label: "Pilih Periode" }
  ];

  const fetchTransactions = async () => {
    try {
      setIsLoading(true);
      
      // Prepare date filters based on selected period
      let startDate, endDate;
      
      switch (selectedPeriod) {
        case "today":
          startDate = new Date();
          endDate = new Date();
          break;
        case "week":
          endDate = new Date();
          startDate = new Date();
          startDate.setDate(startDate.getDate() - 7);
          break;
        case "custom":
          startDate = dateRange.from;
          endDate = dateRange.to;
          break;
        default:
          startDate = null;
          endDate = null;
      }

      const body = {
        page: 1,
        page_size: 100,
        start_date: startDate ? format(startDate, "yyyy-MM-dd") : null,
        end_date: endDate ? format(endDate, "yyyy-MM-dd") : null
      };

      const response = await getOrderVoucher(`/voucher/order-voucher/${voucherId}`, body, process.env.NEXT_PUBLIC_AUTH_TOKEN);
      setTransactions(response.Data.transactions || []);
      setError(null);
    } catch (err) {
      setError(err.message);
      setTransactions([]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleApplyFilter = () => {
    setIsDrawerOpen(false);
    fetchTransactions();
  };

  useEffect(() => {
    setAppBar({
      title: 'Detail Voucher',
      appBarType: 'header_title',
      rightContent: (
        <Drawer open={isDrawerOpen} onOpenChange={setIsDrawerOpen}>
          <DrawerTrigger asChild>
            <Button variant="ghost" className="flex items-center gap-2">
              {/* <Calendar className="h-5 w-5" />
              <span>Periode</span> */}
            </Button>
          </DrawerTrigger>
          <DrawerContent>
            <DrawerHeader>
              <DrawerTitle>Filter Periode</DrawerTitle>
            </DrawerHeader>
            <div className="p-4">
              <RadioGroup value={selectedPeriod} onValueChange={setSelectedPeriod}>
                {periods.map((period) => (
                  <div key={period.id} className="flex items-center space-x-2 mb-2">
                    <RadioGroupItem value={period.id} id={period.id} />
                    <Label htmlFor={period.id}>{period.label}</Label>
                  </div>
                ))}
              </RadioGroup>

              {selectedPeriod === "custom" && (
                <div className="mt-4">
                  <Label>Pilih Periode</Label>
                  <div className="mt-2">
                    <CalendarPicker
                      mode="range"
                      selected={{ from: dateRange.from, to: dateRange.to }}
                      onSelect={(range) => setDateRange(range || { from: null, to: null })}
                      className="rounded-md border"
                    />
                  </div>
                </div>
              )}

              <Button
                className="w-full mt-4 rounded-full bg-blue-500 text-white"
                onClick={handleApplyFilter}
              >
                Terapkan
              </Button>
            </div>
          </DrawerContent>
        </Drawer>
      )
    });
    
    fetchTransactions();
  }, []);
  // Function to format numbers with thousand separator
  const formatNumber = (number) => {
    return new Intl.NumberFormat('id-ID').format(number);
  };

  // Alternative custom function if you prefer
  const formatNumberCustom = (number) => {
    return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  };

  // Function to format date to Indonesian format
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return format(date, 'dd MMM yyyy HH:mm', { locale: id }); // Make sure to import 'id' locale
  };


  const TransactionCard = ({ transaction }) => (
    
    <Card className="w-full border border-gray-200 bg-white p-4 shadow-md relative">
    {/* Header */}
    <div className="absolute top-4 right-2">
      <DrawerMore voucher={transaction} />
    </div>
    <CardHeader className="p-0 flex flex-row items-top space-x-4">
      <div className="flex-shrink-0 rounded-lg items-center justify-center">
        <img src="/img/voucher.png" alt="ticket" className="w-18 h-18" />

      </div>
      <div className="space-y-2 w-[85%]">
        <CardTitle className="text-[14px] leading-4 capitalize">{transaction.products[0]?.name}</CardTitle>
        <CardDescription className="capitalize text-[12px]">
          SKU : {transaction.products[0]?.skuCode}
        </CardDescription>
        <Badge
          className={`mt-2 min-w-6 justify-center py-1 capitalize bg-${transaction.status?.bg} text-${transaction.status?.textColor}`} 
        >
          {transaction.status?.text}
        </Badge>
      </div>
    </CardHeader>
   

    <CardContent className="flex justify-between items-center py-2 px-0 pt-6">
      <div>
        <p className="text-[12px] leading-3.5 font-medium text-muted-foreground">Pembayaran</p>
        <p className="text-[12px] m-0 leading-3.5 text-primary font-bold">
          {formatDate(transaction.paymentInfo?.date)}
        </p>
      </div>
      <div>
        <p className="text-[12px] leading-3.5 font-medium text-muted-foreground">
          Jumlah
        </p>
        <p className="text-[12px] m-0 leading-3.5 text-primary font-bold">
          {transaction.products[0]?.quantity}
        </p>
      </div>
      <div>
        <p className="text-[12px] leading-3.5 font-medium text-muted-foreground">
          Dana Diterima Penjual
        </p>
        <p className="text-[12px] m-0 leading-3.5 text-primary font-bold">
          Rp {formatNumber(transaction.products[0]?.price)}
        </p>
      </div>
    </CardContent>
  </Card>
  );

  if (isLoading) {
    return <div className="flex justify-center items-center min-h-screen">Loading...</div>;
  }

  return (
    <div>
      <div className="min-h-[600px] bg-gray-100 flex flex-col p-4">
        {transactions.length > 0 ? (
          <div className="space-y-4">
            {transactions.map((transaction, index) => (
              <TransactionCard key={transaction.invoiceNumber || index} transaction={transaction} />
            ))}
          </div>
        ) : (
          <div className="text-center min-h-screen flex flex-col items-center justify-center">
            <p className="font-semibold text-[14px] text-muted-foreground">
              Data tidak Ditemukan.
            </p>
          </div>
        )}
      </div>
      
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white border-t">
        <div className="flex gap-x-2">
          <Button
            onClick={prev}
            className="bg-white text-blue-500 w-full border-blue-500 border hover:bg-slate-200 rounded-full"
          >
            Sebelumnya
          </Button>
          <Button
            className="rounded-full bg-blue-500 text-white w-full hover:bg-blue-700"
            asChild
          >
            <Link href="/voucherPenjual/aktif">Kembali ke List</Link>
          </Button>
        </div>
      </div>
    </div>
  );
}