import { Separator } from "@radix-ui/react-separator";
import { ChevronLeft } from "lucide-react";
import StepIndicator from "./StepperIndicator";
import Link from "next/link";

export default function Nav({ step }) {
  return (
    <nav className="py-2 px-4 flex flex-col justify-between items-start bg-red-700 text-white space-y-4">
     
      <Separator />
      <div className="flex justify-between w-full items-center">
        <p className="font-semibold text-md">
          {step === 1 ? "Informasi Voucher" : "Daftar Pesanan"}
        </p>
        <StepIndicator step={step} />
      </div>
    </nav>
  );
}