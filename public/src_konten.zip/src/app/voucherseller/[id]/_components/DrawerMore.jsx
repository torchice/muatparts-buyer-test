"use client";
import {
  Drawer,
  DrawerClose,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from "../../../../components/MobileCom/drawer";
import { Separator } from "../../../../components/MobileCom/separator";
import { EllipsisVertical, X } from "lucide-react";
import { useState } from "react";
import DrawerMenuUbahKuota from "./DrawerMenuUbahKuota";
import Link from "next/link";

export default function DrawerMore({ voucher }) {
  const [isModalAkhiriOpen, setIsModalAkhiriOpen] = useState(false);
  const [isModalKuotaOpen, setIsModalKuotaOpen] = useState(false);
  const [isModalHapusOpen, setIsModalHapusOpen] = useState(false);
  const [selectedVoucherId, setSelectedVoucherId] = useState(null);
  const [voucherName, setVoucherName] = useState("");

  const handleSuccess = () => {
    // This will be called after successful voucher end
    window.location.reload();
  };

  return (
    <>
      <Drawer>
        <DrawerTrigger>
          <EllipsisVertical className="h-6 w-6" />
        </DrawerTrigger>
        <DrawerContent className="max-w-screen-sm mx-auto min-h-3.5">
          <DrawerHeader className="text-center relative">
            <DrawerTitle className="text-center text-[14px] leading-4">Opsi</DrawerTitle>
            <DrawerClose asChild className="absolute left-4">
              {/* <Button variant="ghost" className="p-0"> */}
              <X className="h-8 w-8 text-blue-500 cursor-pointer" />
              {/* </Button> */}
            </DrawerClose>
          </DrawerHeader>
          <div className="p-4 space-y-4">
            <div>
              <DrawerClose asChild>
              <Link href={`/orderdetail/${voucher.uuid}`} className=" hover:no-underline">
                <h3 className="capitalize text-[#343434] font-semibold text-[14px] leading-4 cursor-pointer">
                  Detail
                </h3>
              </Link>
              </DrawerClose>
              <Separator className="" />
            </div>
            <div>
              <DrawerClose>
                <h3
                  className="capitalize font-semibold text-[14px] leading-4"
                  onClick={() => {
                    setSelectedVoucherId(voucher.uuid); // Store the selected voucher ID
                    setIsModalKuotaOpen(true); // Membuka modal
                  }}
                >
                  Chat Pembeli
                </h3>
                <Separator className="" />
              </DrawerClose>
            </div>
          </div>
        </DrawerContent>
      </Drawer>
      <DrawerMenuUbahKuota
        open={isModalKuotaOpen}
        onOpenChange={setIsModalKuotaOpen}
        voucherId={selectedVoucherId} // Pass the ID to modal
        onSuccess={handleSuccess}
      />
    
    
    </>
  );
}
