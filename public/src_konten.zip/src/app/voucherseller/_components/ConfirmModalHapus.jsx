"use client";
import { Button } from "@/components/MobileCom/button";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/MobileCom/dialog";
import { Check, X } from "lucide-react";
import toast from '@/store/zustand/toast'; // Import the zustand store


export default function ConfirmModalHapus({ open, onOpenChange, voucherId, voucherName, onSuccess }) {
  const { setShowToast, setDataToast } = toast(); // Destructure methods from zustand store

  const submitHandler = async () => {
    try {
      const response = await fetch(`http://192.168.7.77:3019/v1/muatparts/voucher/${voucherId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': 'Bearer YOUR_TOKEN',
          'Content-Type': 'application/json',
        }
      });

      if (!response.ok) {
        throw new Error('Failed to end voucher');
      }

       // Close modal first
       onOpenChange(false);
      
       // Show success toast
       setDataToast({ 
         type: 'success', 
         message: "Berhasil Menghapus Voucher" 
       });
       setShowToast(true);
 
       // Trigger parent component to update list
       if (onSuccess) {
         onSuccess(voucherId);
       }
    
    } catch (error) {
      // Show error toast
      setDataToast({ 
        type: 'error', 
        message: "Gagal menghapus voucher" 
      });
      setShowToast(true);
    }
  };


  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader className="items-center">
          <DialogTitle>Hapus Voucher</DialogTitle>
        </DialogHeader>
        <p className="font-medium text-sm text-center">
          Apakah kamu yakin mengapus Voucher {voucherName} ?
        </p>
        <DialogFooter className="flex gap-x-2 flex-row">
          <DialogClose className="w-1/2" asChild>
            <Button className="bg-white text-blue-500  border-blue-500 border rounded-full">
              Batal
            </Button>
          </DialogClose>
          <DialogClose className="w-1/2" asChild>
            <Button
              className="rounded-full bg-blue-500 text-white"
              onClick={submitHandler}
            >
              Ya
            </Button>
          </DialogClose>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
