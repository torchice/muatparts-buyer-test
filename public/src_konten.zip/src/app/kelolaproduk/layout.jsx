import React from "react";

const LayoutDashboard = ({ children }) => {
  return <>{children}</>;
};

export default LayoutDashboard;
