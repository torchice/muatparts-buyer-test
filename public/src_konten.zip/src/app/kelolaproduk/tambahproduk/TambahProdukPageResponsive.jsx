"use client";

import { useState, useEffect, useContext } from "react";
import { useSearchParams } from "next/navigation";
import toast from "@/store/zustand/toast";
import { StateContext } from "@/common/StateContext";
import Button from "@/components/Button/Button";
import NavSelectedMobile from "@/components/Bottomsheet/NavSelectedMobile";
import InformasiProduk from "@/container/FormContainer/TambahProdukContainer/InformasiProduk";
import PengirimanProdukResponsive from "@/container/FormContainer/TambahProdukContainer/PengirimanProdukContainer/PengirimanProdukResponsive";
import IconComponent from "@/components/IconComponent/IconComponent";
import InformasiPenjualanProduk from "@/container/FormContainer/TambahProdukContainer/InformasiPenjualan";
import Bottomsheet from "@/components/Bottomsheet/Bottomsheet";
import Toast from "@/components/Toast/Toast";
import DetailProduk from "@/container/FormContainer/TambahProdukContainer/DetailProduk";
import headerZustand from "@/store/zustand/header";
import addProductState from "@/store/zustand/produk/tambahProduk";
import SWRHandler from "@/services/useSWRHook";
import { useCustomRouter } from "@/libs/CustomRoute";
import NavbarCount from "@/components/NavbarCount/NavbarCount";
// 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0475
import { useHeader } from "@/common/ResponsiveContext";

const pages = [
  { page: 1, title: "informasi produk" },
  { page: 2, title: "detail produk" },
  { page: 3, title: "informasi penjualan" },
  { page: 4, title: "pengiriman produk" },
];

const baseUrl = `${process.env.NEXT_PUBLIC_GLOBAL_API}v1/`;

const TambahProdukPageResponsive = () => {
  const screenLink = useSearchParams().get("screen");
  const [nextStep, setNextStep] = useState(false);
  const [pageList, setPageList] = useState(pages[0]);
  const pageLink = useSearchParams().get("page");
  const share = useSearchParams().get("share");
  const productId = useSearchParams().get("id");
  const isEdit = useSearchParams().get("type");
  const router = useCustomRouter();
  const { handleModal, handleHeader, modalId } = useContext(StateContext);
  const {
    showToast,
    dataToast,
    setShowToast,
    setDataToast,
    setShowBottomsheet,
    dataBottomsheet,
  } = toast();

  const { setShowNavMenu } = toast();
  const { header } = headerZustand();
  const {
    informasiProduk,
    detailProduk,
    informasiPenjualan,
    pengirimanProduk,
    validation,
    setValidation,
    setProducts,
  } = addProductState();
  const { clearScreen } = useHeader()

  // api create dan update
  const { useSWRMutateHook } = SWRHandler;
  const { data, error, trigger } = useSWRMutateHook(
    `${baseUrl}muatparts/product/create`,
    "POST"
  );
  const { trigger: trigger_updated } = useSWRMutateHook(
    `${baseUrl}muatparts/product/update`,
    "PUT"
  );

  // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0475
  useEffect(() => {
    clearScreen()
  }, [])

  //LB - 0248, 25.03
  const handleSave = (isDraft) => {
    const formatSpecifications = () => {
      if (!detailProduk?.Specifications) {
        return {
          CompatibilityValues: [],
          OEMValues: [],
          OEValues: [],
        };
      }

      const {
        CompatibilityValues = [],
        OEMValues = [],
        OEValues = [],
      } = detailProduk.Specifications;

      return {
        CompatibilityValues,
        OEMValues,
        OEValues,
      };
    };

    let validationErrors = {};

    // Untuk draft, validasi minimal di halaman 1
    if (isDraft) {
      if (!informasiProduk.ProductName) {
        setValidation("ProductName", "Nama produk wajib diisi");
        validationErrors.ProductName = true;
      }

      if (!informasiProduk.Categories.GroupcategoryID) {
        setValidation("Categories", "Kategori wajib dipilih");
        validationErrors.Categories = true;
      }

      if (!informasiProduk.GradeID) {
        setValidation("GradeID", "Grade produk wajib dipilih");
        validationErrors.GradeID = true;
      }

      if (!informasiProduk.ProductPhotos.some((item) => item.value !== null)) {
        setValidation("ProductPhotos", "Produk harus memiliki minimal 1 foto");
        validationErrors.ProductPhotos = true;
      }

      if (Object.keys(validationErrors).length > 0) {
        setDataToast({
          type: "error",
          message: "Lengkapi data minimal untuk menyimpan draft",
        });
        setShowToast(true);
        return;
      }
    }

    if (
      informasiPenjualan.SaleType === "Satuan/Ecer" &&
      informasiPenjualan.Variants?.length
    )
      setProducts("informasiPenjualan", "HaveVariant", true);
    else setProducts("informasiPenjualan", "HaveVariant", false);

    const theTrigger = isEdit === "edit" ? trigger_updated : trigger;

    theTrigger({
      IsDraft: isDraft,
      ID: informasiProduk?.ID || "",
      Status: informasiProduk?.Status || "",
      ProductName: informasiProduk.ProductName,
      ProductDescription: detailProduk.ProductDescription,
      SaleType: informasiPenjualan.SaleType,
      Weight: informasiPenjualan?.Variants?.length
        ? 0
        : pengirimanProduk.berat_pengiriman,
      DimensionLength:
        pengirimanProduk.dimensi[0].value == ""
          ? 0
          : pengirimanProduk.dimensi[0].value,
      DimensionWidth:
        pengirimanProduk.dimensi[1].value == ""
          ? 0
          : pengirimanProduk.dimensi[1].value,
      DimensionHeight:
        pengirimanProduk.dimensi[2].value == ""
          ? 0
          : pengirimanProduk.dimensi[2].value,
      UrlVideo: informasiProduk.UrlVideo,
      ShippingCostBy: pengirimanProduk.biaya_pengiriman,
      ShippingType: pengirimanProduk.opsi_pengiriman,
      AssuranceType: pengirimanProduk.asuransi_pengiriman,
      ShippingIDs: pengirimanProduk.ShippingIDs,
      Stock:
        informasiPenjualan?.Variants.length &&
        informasiPenjualan.SaleType === "Satuan/Ecer"
          ? null
          : informasiPenjualan.Stock,
      Price:
        informasiPenjualan?.Variants.length &&
        informasiPenjualan.SaleType === "Satuan/Ecer"
          ? null
          : informasiPenjualan.Price,
      SKUCode: informasiPenjualan.SKUCode,
      MinPurchase: informasiPenjualan.MinPurchase,
      // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB-0294
      HaveVariant:
        informasiPenjualan?.Variants.length &&
        informasiPenjualan.SaleType === "Satuan/Ecer"
          ? true
          : false,
      GradeID: informasiProduk.GradeID,
      ConditionID: detailProduk.ConditionID,
      EtalaseID: informasiProduk.EtalaseID,
      Condition: detailProduk.conditionID,
      Grade: informasiProduk.GradeID,
      Brand: detailProduk.Brand,
      Categories: informasiProduk.Categories,
      ProductPhotos: informasiProduk.ProductPhotos.filter(
        (item) => item.value !== null
      ),
      TypeVariants: informasiPenjualan.varian,
      Variants: informasiPenjualan.Variants,
      Wholesales: informasiPenjualan.Wholesales,
      Bonus: informasiPenjualan.Bonus,
      Specifications: formatSpecifications(),
    })
      .then(() => {
        addProductState.getState().resetProductStates();

        setDataToast({
          type: "success",
          message: isDraft
            ? "Produk berhasil disimpan ke draft"
            : isEdit == "edit"
            ? "Berhasil memperbarui product"
            : "Produk berhasil ditambahkan",
        });
        setShowToast(true);
        router.push("/kelolaproduk/daftarproduk?tab=1");
      })
      .catch((error) => {
        console.log("Error saat menyimpan produk:", error);
        if (error.status == 402) {
          return handleModal({
            modalId: "modal_tambah_rekening",
            withHeader: true,
            closeArea: false,
            hideCloseButton: false,
          });
        }
        if (error.status === 400) {
          setShowToast(true);
          setDataToast({
            type: "error",
            message:
              error.response.data.Data.Message ||
              error.response.data.Message.Text,
          });
        }
      });
  };

  const ValidationPage = (id) => {
    let isError = true;
    // validasi page 1 informasiproduk
    if (pageList.page === 1) {
      if (!informasiProduk.ProductName) {
        setValidation("ProductName", "Nama produk wajib diisi");
        isError = true;
      } else {
        setValidation("ProductName", "");
        isError = false;
      }
      // FIX BUG DAFTAR PRODUK LB-0175
      if (!informasiProduk.Categories.GroupcategoryID) {
        setValidation("Categories", "Kategori wajib dipilih");
        isError = true;
      } else {
        setValidation("Categories", "");
        isError = false;
      }
      // FIX BUG DAFTAR PRODUK LB-0175
      if (!informasiProduk.GradeID) {
        setValidation("GradeID", "Grade produk wajib dipilih");
        isError = true;
      } else {
        setValidation("GradeID", "");
        isError = false;
      }

      if (informasiProduk.UrlVideo && informasiProduk.UrlVideo.length > 1000) {
        setValidation("UrlVideo", "Link tidak valid");
        isError = true;
      } else {
        setValidation("UrlVideo", "");
        isError = false;
      }

      if (!informasiProduk.ProductPhotos.some((item) => item.value !== null)) {
        setValidation("ProductPhotos", "Produk harus memiliki minimal 1 foto");
        isError = true;
      } else {
        setValidation("ProductPhotos", "");
        isError = false;
      }

      // untuk draft, karena validasi hanya di step 1
      if (!isError && id === true) {
        handleSave(true); // Simpan sebagai draft
        return;
      }
    }

    // validasi page 2 detailproduk
    if (pageList.page === 2) {
      // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB-0294
      // 25. 11 - QC Plan - Web - Ronda Live Mei - LB - 0110
      if (id === true) return handleSave(true);
      // detail produk
      if (!detailProduk.ConditionID)
        setValidation("ConditionID", "Kondisi produk wajib dipilih");
      else setValidation("ConditionID", "");

      // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0584
      if (!detailProduk.Brand.BrandName)
        setValidation("Brand", "Brand wajib dipilih");
      else setValidation("Brand", "");

      if (!detailProduk.ProductDescription)
        setValidation("ProductDescription", "Deskripsi produk wajib diisi");
      else setValidation("ProductDescription", "");
      // detail produk
    }

    // validasi page 3 informasipenjualan
    if (pageList.page === 3) {
      if (id === true) {
        handleSave(true); // Simpan sebagai draft
        return;
      }

      // LB - 0242, 25.03
      if (
        (informasiPenjualan.Price === 0 || !informasiPenjualan.Price) &&
        !informasiPenjualan?.Variants?.length &&
        informasiPenjualan.SaleType !== "Grosir"
      ) {
        setValidation("Price", "Harga wajib diisi");
        isError = true;
      } else if (informasiPenjualan.Price > 999999999) {
        setValidation("Price", "Maksimal Rp999.999.999");
        isError = true;
      } else {
        setValidation("Price", "");
        isError = false;
      }

      if (
        (informasiPenjualan.Stock === 0 || !informasiPenjualan.Stock) &&
        !informasiPenjualan?.Variants?.length
      ) {
        setValidation("Stock", "Stok wajib diisi");
        isError = true;
      } else if (
        informasiPenjualan.Stock > 99999 &&
        !informasiPenjualan?.Variants?.length
      ) {
        setValidation("Stock", "Maksimal 99999");
        isError = true;
      } else {
        setValidation("Stock", "");
        isError = false;
      }

      if (informasiPenjualan.SaleType === "Grosir") {
        if (informasiPenjualan.Wholesales.length === 0) {
          setValidation("Wholesales", "Harga Grosir wajib diisi");
          isError = true;
        } else {
          setValidation("Wholesales", "");
          isError = false;
        }
      }
    } 

    // validasi page 4 pengirimanproduk
    if (pageList.page === 4) {
      if (id === true) {
        handleSave(true); // Simpan sebagai draft
        return;
      }
      // 
      const validationsToSet = [];
      if (
        // 25. 11 - QC Plan - Web - Ronda Live Mei - LB - 0062
        // 25. 11 - QC Plan - Web - Ronda Live Mei - LB - 0075
        (pengirimanProduk.berat_pengiriman == 0 ||
        !pengirimanProduk.berat_pengiriman) && informasiPenjualan.Variants.length===0
      ) {
        // setValidation("berat_pengiriman", "Berat Minimal 1 gram");
        validationsToSet.push({
          field: "berat_pengiriman",
          msg: "Berat Minimal 1 gram",
        });
        isError = true;
      } else {
        setValidation("berat_pengiriman", "");
        isError = false;
      }

      // LB - 0189 - PRIO : 8 - 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - Prio 8
      if (pengirimanProduk.berat_pengiriman > 99999) {
        // setValidation("berat_pengiriman", "Berat maksimal 99.999 gram");
        validationsToSet.push({
          field: "berat_pengiriman",
          msg: "Berat Minimal 1 gram",
        });
        isError = true;
      } else {
        setValidation("berat_pengiriman", "");
        isError = false;
      }

      // Validasi dimensi produk
      const validateDimensi = () => {
        const dimensi = pengirimanProduk.dimensi;
        const dimensiErrors = {
          panjang: "",
          lebar: "",
          tinggi: "",
        }

        if(!dimensi[0].value || dimensi[0].value === 0) {
          dimensiErrors.panjang = "Panjang harus diisi";
        }else if(dimensi[0].value > 1000) {
          dimensiErrors.panjang = "Panjang maksimal 1000 cm";
        }
        if(!dimensi[1].value || dimensi[1].value === 0) {
          dimensiErrors.lebar = "Lebar harus diisi";
        }else if(dimensi[1].value > 1000) {
          dimensiErrors.lebar = "Lebar maksimal 1000 cm";
        }
        if(!dimensi[2].value || dimensi[2].value === 0) {
          dimensiErrors.tinggi = "Tinggi harus diisi";
        }else if(dimensi[2].value > 1000) {
          dimensiErrors.tinggi = "Tinggi maksimal 1000 cm";
        }

        return dimensiErrors;
      };

      // Jalankan validasi dimensi
      const dimensiErrors = validateDimensi();
      if(Object.values(dimensiErrors).some(error => error !== "")) {
        // setValidation("dimensi", dimensiErrors);
        validationsToSet.push({
          field: "dimensi",
          msg: dimensiErrors,
        });
        isError = true;
      }else{
        // setValidation("dimensi", "");
        validationsToSet.push({ field: "dimensi", msg: "" });
        isError = false;
      }
      if (validationsToSet.length > 0) {
        validationsToSet.forEach(({ field, msg }) => {
          setValidation(field, msg);
        });
      }
      isError = validationsToSet.length>0 || validationsToSet.every((validations)=>validations.msg==="")
      // Jika berada di halaman terakhir dan tombol Simpan ditekan (bukan Save Draft)
      if (!isError && pageList.page === 4 && id !== true) {
        handleSave(false); // Submit produk
        setValidation(null, null);
        return;
      }
    }
    console.log(validation)
    console.log(informasiPenjualan)
    setNextStep(true);
  };

  useEffect(() => {

    if (!nextStep) return setNextStep(false);
    setNextStep(false);

    if (validation.length === 0 && pageList.page < 4) {
      let url = `/kelolaproduk/tambahproduk?page=${pageList.page + 1}`;
      // if (share && productId) {
      //   url = `/kelolaproduk/tambahproduk?share=${share}&id=${productId}&page=${
      //     pageList.page + 1
      //   }`;
      // }
      setPageList(pages.find((item) => item.page === pageList.page + 1));
      // router.push(url, {
      //   scroll: false,
      // });
      return;
    } else {
      setDataToast({
        type: "error",
        message: "Terdapat field yang kosong",
      });
      if (!showToast) setShowToast(true);
    }
    if (validation.length === 0 && pageList.page === 4) handleSave(false);
  }, [validation, nextStep]);

  useEffect(()=>{
    console.log(pengirimanProduk)
  },[pengirimanProduk])
  const CheckFilledData = () => {
    if (pageList.page)
      return handleModal({
        modalId: "ConfirmationFormAdd",
        withHeader: false,
        closeArea: false,
        hideCloseButton: true,
      });
    else router.back();
  };

  useEffect(() => {
    setShowNavMenu(false);
    // let url = `/kelolaproduk/tambahproduk?page=1&screen=${
    //   screenLink ?? "default"
    // }`;
    // if (share && productId) {
    //   url = `/kelolaproduk/tambahproduk?share=${share}&id=${productId}&page=1&screen=${
    //     screenLink ?? "default"
    //   }`;
    // }

    // router.push(url, { scroll: false });
  }, [share, productId]);

  return (
    <>
      <Bottomsheet>{dataBottomsheet}</Bottomsheet>
      <Toast type={dataToast.type}>{dataToast.message}</Toast>

      {!header && (
        // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0381
        isEdit == "edit" ? 
        <NavbarCount
          classname="w-full fixed top-0 z-[51]"
          title="Edit Produk"
          subtitle={pageList?.title}
          count="4"
          active={pageLink}
          backAction={() => CheckFilledData()}
        />
        :
        <NavbarCount
          classname="w-full fixed top-0 z-[51]"
          title="Tambah Produk"
          subtitle={pageList?.title}
          count="4"
          active={pageLink}
          backAction={() => CheckFilledData()}
        />
      )}
      {/* FIX BUG Pengecekan Ronda Muatparts LB-0294 */}
      <div className={`bg-neutral-50 pt-[45px] pb-[120px] flex flex-col gap-6 ${pageList.page === 1 ? "mb-[60px]" : ""}`}>
        {pageList.page === 1 && <InformasiProduk />}
        {pageList.page === 2 && <DetailProduk />}
        {pageList.page === 3 && <InformasiPenjualanProduk />}
        {pageList.page === 4 && <PengirimanProdukResponsive />}
      </div>

      {/* nav step, header itu variabel untuk intent di harga grosir responsive, dll */}
      {!header && (
        <NavSelectedMobile classname={`flex flex-col gap-[10px] w-full !z-[9]`}>
          {pageList.page > 1 && (
            <button
              className="flex justify-between items-center bg-primary-50 py-2 px-4 rounded-md"
              onClick={() => ValidationPage(true)}
            >
              <span className="text-neutral-900 text-sm font-semibold">
                Belum yakin?
              </span>
              <div className="flex gap-4 items-center">
                <span className="text-primary-700 text-sm font-semibold">
                  Simpan Draft
                </span>
                <IconComponent
                  classname="-rotate-90 -mt-[2px]"
                  size="medium"
                  src="/icons/arrow-blue-down.svg"
                />
              </div>
            </button>
          )}

          <div className="flex w-full justify-between gap-2">
            {pageList.page !== 1 && (
              <Button
                Class="w-full min-w-[49%]"
                color="primary_secondary"
                onClick={() => {
                  // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0294
                  setValidation(null, null)
                  setNextStep(false);
                  setPageList(
                    pages.find((item) => item.page == pageList.page - 1)
                  );
                  let url = `/kelolaproduk/tambahproduk?page=${
                    pageList.page - 1
                  }`;
                  if (share && productId) {
                    url = `/kelolaproduk/tambahproduk?share=${share}&id=${productId}&page=${
                      pageList.page - 1
                    }`;
                  }
                  router.push(url, {
                    scroll: false,
                  });
                  return;
                }}
              >
                Sebelumnya
              </Button>
            )}
            <Button
              Class={`w-full ${
                pageList.page !== 1 ? "min-w-[49%]" : "min-w-full"
              }`}
              onClick={() => ValidationPage(false)}
            >
              {pageList.page === 4 ? "Simpan" : "Selanjutnya"}
            </Button>
          </div>
        </NavSelectedMobile>
      )}
    </>
  );
};

export default TambahProdukPageResponsive;

export const ConfirmationFormAddModal = () => {
  const { closeModal } = useContext(StateContext);
  const router = useCustomRouter();
  const {
    informasiProduk,
    detailProduk,
    informasiPenjualan,
    pengirimanProduk,
  } = addProductState();
  const { setDataToast, setShowToast } = toast();
  const checkUrl = useSearchParams()?.get("type");

  // api create
  const { useSWRMutateHook } = SWRHandler;
  const { trigger } = useSWRMutateHook(
    `${process.env.NEXT_PUBLIC_GLOBAL_API}v1/muatparts/product/create`,
    "POST"
  );

  const handleSave = (isDraft) => {
    const formatSpecifications = () => {
      if (!detailProduk?.Specifications) {
        return {
          CompatibilityValues: [],
          OEMValues: [],
          OEValues: [],
        };
      }

      const {
        CompatibilityValues = [],
        OEMValues = [],
        OEValues = [],
      } = detailProduk.Specifications;

      return {
        CompatibilityValues,
        OEMValues,
        OEValues,
      };
    };

    // Untuk draft hanya validasi halaman 1
    if (
      !informasiProduk.ProductName ||
      !informasiProduk.Categories.GroupcategoryID ||
      !informasiProduk.GradeID ||
      !informasiProduk.ProductPhotos.some((item) => item.value !== null)
    ) {
      setDataToast({
        type: "error",
        message: "Lengkapi data minimal untuk menyimpan draft",
      });
      setShowToast(true);
      closeModal();
      return;
    }

    //LB - 0242 - 25.03
    trigger({
      IsDraft: true,
      ProductName: informasiProduk.ProductName,
      ProductDescription: detailProduk.ProductDescription || "",
      SaleType: informasiPenjualan.SaleType,
      Weight: pengirimanProduk.berat_pengiriman || 0,
      DimensionLength: pengirimanProduk.dimensi[0].value || 0,
      DimensionWidth: pengirimanProduk.dimensi[1].value || 0,
      DimensionHeight: pengirimanProduk.dimensi[2].value || 0,
      UrlVideo: informasiProduk.UrlVideo,
      ShippingCostBy: pengirimanProduk.biaya_pengiriman,
      ShippingType: pengirimanProduk.opsi_pengiriman,
      AssuranceType: pengirimanProduk.asuransi_pengiriman,
      Stock: informasiPenjualan.Stock || 0,
      Price: informasiPenjualan.Price || 0,
      SKUCode: informasiPenjualan.SKUCode,
      MinPurchase: informasiPenjualan.MinPurchase || 0,
      HaveVariant: false,
      GradeID: informasiProduk.GradeID,
      ConditionID: detailProduk.ConditionID || "",
      EtalaseID: informasiProduk.EtalaseID || "",
      Brand: detailProduk.Brand || { ID: null, BrandName: "" },
      Categories: informasiProduk.Categories,
      ProductPhotos: informasiProduk.ProductPhotos.filter(
        (item) => item.value !== null
      ),
      TypeVariants: informasiPenjualan.varian || [],
      Variants: informasiPenjualan.Variants || [],
      Wholesales: informasiPenjualan.Wholesales || [],
      Bonus: informasiPenjualan.Bonus || [],
      Specifications: formatSpecifications(),
    })
      .then(() => {
        addProductState.getState().resetProductStates();
        setDataToast({
          type: "success",
          message: "Produk berhasil disimpan ke draft",
        });
        setShowToast(true);
        router.push("/kelolaproduk/daftarproduk?tab=1");
      })
      .catch((error) => {
        console.log("Error saat menyimpan produk:", error);
        setDataToast({
          type: "error",
          message: "Gagal menyimpan produk",
        });
        setShowToast(true);
      });
  };

  return (
    <div className="flex flex-col items-center justify-center gap-3 py-6 px-8 w-[296px] relative">
      <div className="absolute top-3 right-3">
        <IconComponent
          src="/icons/closes.svg"
          color="primary"
          onclick={() => closeModal()}
        />
      </div>
      <span className="font-bold text-base text-neutral-900 w-[338px] text-center">
        Keluar halaman ini?
      </span>
      <span className="font-medium text-sm text-neutral-900 w-[264px] text-center">
        Data produk tidak akan tersimpan sebelum kamu klik Simpan
      </span>
      <div className="flex gap-2">
        <Button
          Class="!font-medium !h-8 text-xs"
          color="primary_secondary"
          onClick={() => {
            closeModal();
            router.back();
          }}
        >
          Ya, Keluar
        </Button>
        {/* LB - 0382, 25.03 */}
        {checkUrl != "edit" && (
          <Button
            Class="!font-medium !h-8 capitalize text-xs w-[121px]"
            color="primary"
            onClick={() => {
              handleSave(true);
              closeModal();
            }}
          >
            simpan draft
          </Button>
        )}
      </div>
    </div>
  );
};
