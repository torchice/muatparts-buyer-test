"use client";

import viewport from "@/store/zustand/common";
import TambahProdukPage from "./TambahProdukPage";
import TambahProdukPageResponsive from "./TambahProdukPageResponsive";
import { useSearchParams } from "next/navigation";
import SWRHandler from "@/services/useSWRHook";
import { useEffect, useState } from "react";
import addProductState from "@/store/zustand/produk/tambahProduk";
import Error from "next/error";
import ConfigUrl from "@/services/baseConfig";

const baseUrl = `${process.env.NEXT_PUBLIC_GLOBAL_API}v1/`;

const MainTambahProduk = () => {
  const [error, setError] = useState(null);
  const [data, setData] = useState(null);

  if (error) {
    return <Error statusCode={500} title={"error Loading Page"} />;
  }

  const { isMobile } = viewport();
  const { setProducts } = addProductState();
  const share = useSearchParams().get("share") || "";
  const productId = useSearchParams().get("id") || "";
  const isEdit = useSearchParams().get("type") || "";

  const {get} = ConfigUrl()

  const { useSWRHook } = SWRHandler;

  const { data: product } = useSWRHook(
    share === "true" ? `${baseUrl}muatparts/product/${productId}` : null
  );
  const existingProduct = product?.Data;

  const konversiKeDisplayWholesales = (wholesalesData) => {
    if (
      !wholesalesData ||
      !Array.isArray(wholesalesData) ||
      wholesalesData.length === 0
    ) {
      return [
        {
          jumlah_minimal: "",
          jumlah_maksimal: "Tidak Terbatas",
          harga: "",
        },
      ];
    }

    // Urutkan data berdasarkan MinPurchase
    const sortedData = [...wholesalesData].sort(
      (a, b) => a.MinPurchase - b.MinPurchase
    );

    // Konversi ke format displayWholesales
    return sortedData.map((item, index, array) => {
      let jumlah_maksimal;

      if (index === array.length - 1) {
        jumlah_maksimal = "Tidak Terbatas";
      } else {
        jumlah_maksimal = (array[index + 1].MinPurchase - 1).toString();
      }

      return {
        jumlah_minimal: item.MinPurchase.toString(),
        jumlah_maksimal: jumlah_maksimal,
        harga: item.Price.toString(),
      };
    });
  };

  useEffect(() => {
    if (existingProduct) {
      const existingCategories = {
        GroupcategoryID:
          existingProduct.Categories.Groupcategory?.value || null,
        CategoryID: existingProduct.Categories.Category?.value || null,
        SubcategoryID: existingProduct.Categories.Subcategory?.value || null,
        ItemID: existingProduct.Categories.Item?.value || null,
      };
      if (isEdit === "edit") {
        setProducts("informasiProduk", "ID", productId);
        setProducts("informasiProduk", "Status", existingProduct?.Status);
      }
      setProducts("informasiProduk", "Categories", existingCategories);
      
      const categoryNames = [];

      if (existingProduct.Categories.Groupcategory) {
        categoryNames.push(existingProduct.Categories.Groupcategory.name);
      }
      if (existingProduct.Categories.Category) {
        categoryNames.push(existingProduct.Categories.Category.name);
      }
      if (existingProduct.Categories.Subcategory) {
        categoryNames.push(existingProduct.Categories.Subcategory.name);
      }
      if (existingProduct.Categories.Item) {
        categoryNames.push(existingProduct.Categories.Item.name);
      }

      if (existingProduct.ConditionName) {
        setProducts("detailProduk", "conditionName", existingProduct.ConditionName);
      } else if (existingProduct.conditionName) {
        setProducts("detailProduk", "conditionName", existingProduct.conditionName);
      } else {
        get({
          path: `v1/muatparts/product/condition`,
        }).then(x=>{
          if (x?.data?.Data) {
            const matchedCondition = x?.data.Data.find(
              (item) => item.id === existingProduct.ConditionID
            );
            if (matchedCondition) {
              setProducts(
                "detailProduk",
                "conditionName",
                matchedCondition.conditionName
              );
            }
          }
        })
        
      }

      setProducts("informasiProduk", "category", categoryNames);
      setProducts(
        "informasiProduk",
        "ProductName",
        existingProduct.ProductName
      );
      setProducts("informasiProduk", "GradeID", existingProduct.GradeID);
      // FIX BUG DAFTAR PRODUK LB-0165
      // Check if we need to add null placeholders
      let updatedProductPhotos = [...existingProduct.ProductPhotos];

      // If the length is less than 4, add null values until length is 4
      if (updatedProductPhotos.length < 4) {
        const nullsToAdd = 4 - updatedProductPhotos.length;
        const nullPlaceholders = Array(nullsToAdd).fill({ value: null });
        updatedProductPhotos = [...updatedProductPhotos, ...nullPlaceholders];
      }

      // Now set the products with the potentially padded array
      setProducts("informasiProduk", "ProductPhotos", updatedProductPhotos);
      // FIX BUG DAFTAR PRODUK LB-0165
      setProducts(
        "informasiProduk",
        "UrlVideo",
        existingProduct.UrlVideo || ""
      );
      setProducts("informasiProduk", "EtalaseID", existingProduct.EtalaseID);

      const existingBrand = existingProduct.Brand
        ? {
            BrandName: existingProduct.Brand.name,
            ID: existingProduct.Brand.value,
          }
        : { ID: null, BrandName: "" };
      setProducts("detailProduk", "ConditionID", existingProduct.ConditionID);
      setProducts("detailProduk", "Brand", existingBrand);
      setProducts(
        "detailProduk",
        "ProductDescription",
        existingProduct.ProductDescription
      );

      const existingBonus = existingProduct.Bonus.map((item) => ({
        name: item.name,
        value: item.value,
      }));
      const existingWholesales = existingProduct.Wholesales.map((item, key) => {
        const isLastItem = existingProduct.Wholesales.length - 1 === key;
        return {
          ...item,
          jumlah_minimal: item.MinPurchase,
          jumlah_maksimal: !isLastItem
            ? existingProduct.Wholesales[key + 1].MinPurchase - 1
            : "Tidak Terbatas",
          harga: item.Price,
        };
      });
      setProducts("informasiPenjualan", "SaleType", existingProduct.SaleType);

      if (isEdit === "edit" && existingProduct.SaleType === "Grosir") {
        console.log(
          "Mode edit terdeteksi untuk produk Grosir, mengkonversi Wholesales"
        );

        // Simpan data Wholesales asli (format API)
        setProducts(
          "informasiPenjualan",
          "Wholesales",
          existingProduct.Wholesales
        );

        // Konversi ke format displayWholesales untuk UI
        const displayWholesalesData = konversiKeDisplayWholesales(
          existingProduct.Wholesales
        );
        console.log(
          "Data displayWholesales hasil konversi:",
          displayWholesalesData
        );

        // Set data displayWholesales untuk UI
        setProducts(
          "informasiPenjualan",
          "displayWholesales",
          displayWholesalesData
        );
      } else {
        // Jika bukan mode edit atau bukan tipe Grosir, gunakan logika yang sudah ada
        const existingWholesales = existingProduct.Wholesales.map(
          (item, key) => {
            const isLastItem = existingProduct.Wholesales.length - 1 === key;
            return {
              ...item,
              jumlah_minimal: item.MinPurchase,
              jumlah_maksimal: !isLastItem
                ? existingProduct.Wholesales[key + 1].MinPurchase - 1
                : "Tidak Terbatas",
              harga: item.Price,
            };
          }
        );
        // FIX BUG Pengecekan Ronda Muatparts LB-0092
        setProducts("informasiPenjualan", "Wholesales", existingProduct.Wholesales);
        setProducts("informasiPenjualan", "displayWholesales", existingWholesales);
      }

      setProducts(
        "informasiPenjualan",
        "MinPurchase",
        existingProduct.MinPurchase || 0
      );
      setProducts("informasiPenjualan", "Price", existingProduct.Price || 0);
      setProducts("informasiPenjualan", "Stock", existingProduct.Stock || 0);
      setProducts(
        "informasiPenjualan",
        "SKUCode",
        existingProduct.SKUCode || ""
      );
      setProducts("informasiPenjualan", "Bonus", existingBonus);
      let type_variants=existingProduct.TypeVariants.map((va,i,arr)=>({ID:va?.ID,
          Opsi:[...va?.Opsi,'']
        }))
      setProducts("informasiPenjualan", "varian", type_variants);
      setProducts("informasiPenjualan", "Variants", existingProduct.Variants);
      // FIX BUG Pengecekan Ronda Muatparts LB-0092
      setProducts("informasiPenjualan", "Wholesales", existingProduct.Wholesales);
      setProducts("informasiPenjualan", "displayWholesales", existingWholesales);

      const existingDimensi = [
        { title: "Panjang", value: existingProduct.DimensionLength },
        { title: "Lebar", value: existingProduct.DimensionWidth },
        { title: "Tinggi", value: existingProduct.DimensionHeight },
      ];
      setProducts("pengirimanProduk", "dimensi", existingDimensi);
      setProducts(
        "pengirimanProduk",
        "berat_pengiriman",
        existingProduct.Weight
      );
      setProducts(
        "pengirimanProduk",
        "biaya_pengiriman",
        existingProduct.ShippingCostBy
      );
      setProducts(
        "pengirimanProduk",
        "opsi_pengiriman",
        existingProduct.ShippingType
      );
      setProducts(
        "pengirimanProduk",
        "ShippingIDs",
        existingProduct.ShippingIDs
      );
      setProducts(
        "pengirimanProduk",
        "asuransi_pengiriman",
        existingProduct.AssuranceType
      );
    }
  }, [existingProduct]);

  useEffect(() => {
    // LB - 0172 produk
    if (!isEdit) addProductState.getState().resetProductStates();
  }, []);

  if (isMobile) return <TambahProdukPageResponsive />;

  return <TambahProdukPage />;
};

export default MainTambahProduk;
