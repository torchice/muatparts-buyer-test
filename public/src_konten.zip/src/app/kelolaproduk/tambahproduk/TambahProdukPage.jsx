"use client";

// LB - 178 Daftar Produk
import { useState, useContext, useRef, useEffect, useMemo } from "react";
// LB - 178 Daftar Produk

import { StateContext } from "@/common/StateContext";
import brand from "@/store/zustand/produk/brand";
import IconComponent from "@/components/IconComponent/IconComponent";
import BreadCrumb from "@/components/BreadCrumb/BreadCrumb";
import Input from "@/components/Input/Input";
import Button from "@/components/Button/Button";
import PengirimanProduk from "@/container/FormContainer/TambahProdukContainer/PengirimanProdukContainer/PengirimanProduk";
import ImageuploaderProduct from "@/components/ImageuploaderProduct/ImageuploaderProduct";
import InformasiPenjualanProduk from "@/container/FormContainer/TambahProdukContainer/InformasiPenjualan";
import InformasiProduk from "@/container/FormContainer/TambahProdukContainer/InformasiProduk";
import addProductState from "@/store/zustand/produk/tambahProduk";
import toast from "@/store/zustand/toast";
import Toast from "@/components/Toast/Toast";
import SWRHandler from "@/services/useSWRHook";
import DetailProduk from "@/container/FormContainer/TambahProdukContainer/DetailProduk";
import ContainerCadangan, {
  formDetailIsEmpty,
} from "@/components/SpesifikasiTambahanComponents/ContainerCadangan";
import { useCustomRouter } from "@/libs/CustomRoute";
import { useTranslation } from "@/context/TranslationProvider";
import { useSearchParams } from "next/navigation";
import TranslationSkeleton from "@/components/Skeleton/TranslationSkeleton";

const baseUrl = `${process.env.NEXT_PUBLIC_GLOBAL_API}v1/`;

const TambahProdukPage = ({ condition, brand_api }) => {
  const { handleModal } = useContext(StateContext);
  const searchname = useSearchParams();
  const router = useCustomRouter();

  const { t, tOrEmpty } = useTranslation();
  // LBM - Andrew - Spesifikasi Produk - MP - 005
  const {
    informasiPenjualan,
    informasiProduk,
    detailProduk,
    pengirimanProduk,
    validation,
    setProducts,
    setValidationWeb,
  } = addProductState();

  const isEdit = searchname.get("type");

  // LB - 0652, LB - 0653, LB - 0654 - 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2
  const getBred = useMemo(() => {
    return isEdit == "edit"
      ? ["dashboard", tOrEmpty("menuProductList"), tOrEmpty("menuUbahProduk")]
      : ["dashboard", tOrEmpty("menuProductList"), tOrEmpty("menuTambahProduk")];
  }, [isEdit, t]);

  // const {isMobile} = viewport()
  const { showToast, dataToast, setShowToast, setDataToast } = toast();

  // api create
  const { useSWRMutateHook, useSWRHook } = SWRHandler;
  const { data, error, trigger } = useSWRMutateHook(
    `${baseUrl}muatparts/product/create`,
    "POST"
  );
  const {
    data: updated_data,
    error: error_updated,
    trigger: trigger_updated,
  } = useSWRMutateHook(`${baseUrl}muatparts/product/update`, "PUT");

  // for BreadCrumb
  const onClickBred = (val) => {
    const idx = getBred.indexOf(val);
    const checkSpace = val.includes(" ") ? val.split(" ").join("") : val;
    router.replace(
      idx == 0 ? "/" + checkSpace : "/kelolaproduk/" + checkSpace + "?tab=1"
    );
  };

  // Kondisi Function
  const optionKondisi = condition?.Data?.map((item) => ({
    title: item.conditionDescription ? item.conditionName : "",
    name: item.conditionDescription
      ? item.conditionDescription
      : item.conditionName,
    value: item.id,
  }));

  // Etalase Function
  const optionEtalasePenjual = [
    {
      name: "Ban Dalam",
      value: "Ban Dalam",
    },
    {
      name: "Pelek",
      value: "Pelek",
    },
    {
      name: "Filter",
      value: "Filter",
    },
    {
      name: "Ban Luar",
      value: "Ban Luar",
    },
  ];

  const ConfirmationDataForm = () => {
    return handleModal({
      modalId: "ConfirmationFormAddWeb",
      withHeader: true,
      closeArea: false,
      hideCloseButton: false,
    });
  };

  // Format data spesifikasi sebelum submit
  const formatSpecifications = () => {
    console.log("Memformat data spesifikasi. detailProduk:", detailProduk);
    console.log("Raw Compatibility data:", detailProduk.Compatibility);

    // Format OEM Value (string tunggal)
    let oemValues = [];
    if (detailProduk.OEM && detailProduk.OEM.trim() !== "") {
      oemValues = [detailProduk.OEM];
      console.log("OEM value detected:", oemValues);
    }

    // Format OE Values (array)
    let oeValues = [];
    if (Array.isArray(detailProduk.OE) && detailProduk.OE.length > 0) {
      oeValues = detailProduk.OE.filter((item) => item && item.trim() !== "");
      console.log("OE values detected:", oeValues);
    }

    // Format Compatibility Values (array objek)
    let compatibilityValues = [];
    if (
      Array.isArray(detailProduk.Compatibility) &&
      detailProduk.Compatibility.length > 0
    ) {
      compatibilityValues = detailProduk.Compatibility.filter(
        (item) => item && typeof item === "object" && item.brandID
      );
      console.log("Compatibility values detected:", compatibilityValues);
    }

    const result = {
      compatibilityValues,
      oemValues,
      oeValues,
    };

    console.log("Final specifications data to be sent:", result);

    return result;
  };
  // Spesifikasi Produk
  //multi bahasa
  const messageProductNameRequired = t("messageProductNameRequired");
  const messageProductCategoryRequired = t("messageProductCategoryRequired");
  const messageProductGradeRequired = t("messageProductGradeRequired");
  const messagePhotoRequired = t("messagePhotoRequired");
  const messageConditionRequired = t("messageConditionRequired");
  const messageBrandRequired = t("messageBrandRequired");
  const messageDescriptionRequired = t("messageDescriptionRequired");
  const messageMinPurchaseRequired = t("messageMinPurchaseRequired");
  const messagePriceRequired = t("messagePriceRequired");
  const messageStockRequired = t("messageStockRequired");
  const messageMinWeightRequired = t("messageMinWeightRequired");
  const messageLengthRequired = t("messageLengthRequired");
  const messageWidthRequired = t("messageWidthRequired");
  const messageHeightRequired = t("messageHeightRequired");
  const messageEmptyFields = t("messageEmptyFields");
  const messageSuccessDraft = t("messageSuccessDraft");
  const messageSuccessAdd = t("messageSuccessAdd");
  // LBM - multibahasa
  const messagePriceMaxLimit = t("messagePriceMaxLimit");
  const messageStockMaxLimit = t("messageStockMaxLimit");
  const messageWeightMaxLimit = t("messageWeightMaxLimit");
  const messageLengthMaxLimit = t("messageLengthMaxLimit");
  const messageWidthMaxLimit = t("messageWidthMaxLimit");
  const messageHeightMaxLimit = t("messageHeightMaxLimit");
  //end mb

  // all validasi form tambah web
  const handleSave = (isDraft) => {
    const formattedSpecs = formatSpecifications();

    const hasFilledCompatibility =
      document.querySelectorAll(
        '.kompabilitas-row-container select[value]:not([value=""])'
      ).length > 0;
    const hasCompatibilityInState =
      Array.isArray(detailProduk.Compatibility) &&
      detailProduk.Compatibility.length > 0;

    if (hasFilledCompatibility && !hasCompatibilityInState) {
      setDataToast({
        type: "warning",
        message:
          "Data kompatibilitas belum tersimpan. Silakan klik lagi pada dropdown kompatibilitas sebelum menyimpan.",
      });
      setShowToast(true);
      return;
    }

    let validationErrors = {};
    console.log("Testing Informasi Produk:", informasiProduk);

    // informasi produk
    if (!informasiProduk.ProductName) {
      validationErrors.ProductName = t("messageProductNameRequired");
    }

    if (!informasiProduk.Categories.GroupcategoryID) {
      validationErrors.Categories = messageProductCategoryRequired;
    }

    if (!informasiProduk.GradeID) {
      validationErrors.GradeID = messageProductGradeRequired;
    }

    if (!informasiProduk.ProductPhotos.some((item) => item.value !== null)) {
      validationErrors.ProductPhotos = messagePhotoRequired;
    }

    if (!isDraft) {
      // detail produk
      if (!detailProduk.ConditionID) {
        validationErrors.ConditionID = messageConditionRequired;
      }

      if (!detailProduk.Brand.ID && !detailProduk.Brand.BrandName) {
        validationErrors.Brand = messageBrandRequired;
      }

      if (!detailProduk.ProductDescription) {
        validationErrors.ProductDescription = messageDescriptionRequired;
      }

      // informasi penjualan
      if (informasiPenjualan.SaleType === "Satuan/Ecer") {
        if (
          informasiPenjualan.MinPurchase === 0 ||
          !informasiPenjualan.MinPurchase
        ) {
          validationErrors.MinPurchase = messageMinPurchaseRequired;
        }

        if (
          (informasiPenjualan.Price === 0 || !informasiPenjualan.Price) &&
          !informasiPenjualan?.Variants?.length
        ) {
          validationErrors.Price = messagePriceRequired;
        }

        if (informasiPenjualan.Price > 999999999) {
          validationErrors.Price = messagePriceMaxLimit;
        }

        if (
          (informasiPenjualan.Stock === 0 || !informasiPenjualan.Stock) &&
          !informasiPenjualan?.Variants?.length
        ) {
          validationErrors.Stock = messageStockRequired;
        }

        if (informasiPenjualan.Stock > 99999) {
          validationErrors.Stock = messageStockMaxLimit;
        }
      }

      // pengiriman produk
      if (
        (pengirimanProduk.berat_pengiriman == 0 ||
          !pengirimanProduk.berat_pengiriman) &&
        !informasiPenjualan.Variants?.length
      ) {
        validationErrors.berat_pengiriman = messageMinWeightRequired;
      }

      if (pengirimanProduk.berat_pengiriman > 99999) {
        validationErrors.berat_pengiriman = messageWeightMaxLimit;
      }

      // LB - 0189 - PRIO : 8 - 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - Prio 8
      // dimensi validation
      const dimensi = pengirimanProduk.dimensi;
      const dimensiErrors = {
        panjang: "",
        lebar: "",
        tinggi: "",
      };
      // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0565
      let isDimensiValid = true;

      if (!dimensi[0].value || dimensi[0].value === 0) {
        dimensiErrors.panjang = messageLengthRequired;
        isDimensiValid = false;
      } else if (dimensi[0].value > 1000) {
        dimensiErrors.panjang = messageLengthMaxLimit;
        isDimensiValid = false;
      }
      if (!dimensi[1].value || dimensi[1].value === 0) {
        dimensiErrors.lebar = messageWidthRequired;
        isDimensiValid = false;
      } else if (dimensi[1].value > 1000) {
        dimensiErrors.lebar = messageWidthMaxLimit;
        isDimensiValid = false;
      }
      if (!dimensi[2].value || dimensi[2].value === 0) {
        dimensiErrors.tinggi = messageHeightRequired;
        isDimensiValid = false;
      } else if (dimensi[2].value > 1000) {
        dimensiErrors.tinggi = messageHeightMaxLimit;
        isDimensiValid = false;
      }
      if (!isDimensiValid) {
        validationErrors.dimensi = dimensiErrors;
      }
    }

    // pengiriman produk
    // if (
    //   (pengirimanProduk.berat_pengiriman == 0 ||
    //     !pengirimanProduk.berat_pengiriman) &&
    //   !informasiPenjualan.Variants?.length
    // ) {
    //   validationErrors.berat_pengiriman = messageMinWeightRequired;
    // }

    // // dimensi validation
    // const dimensiValue = [
    //   pengirimanProduk.dimensi[0].value,
    //   pengirimanProduk.dimensi[1].value,
    //   pengirimanProduk.dimensi[2].value,
    // ];
    // const hasInvalidDimensions = dimensiValue.some(
    //   (value) => !value || isNaN(value) || value === 0 || value === ""
    // );

    // if (hasInvalidDimensions) {
    //   validationErrors.dimensi = {
    //     panjang:
    //       !pengirimanProduk.dimensi[0].value ||
    //       pengirimanProduk.dimensi[0].value === 0 ||
    //       isNaN(pengirimanProduk.dimensi[0].value)
    //         ? messageLengthRequired
    //         : "",
    //     lebar:
    //       !pengirimanProduk.dimensi[1].value ||
    //       pengirimanProduk.dimensi[1].value === 0 ||
    //       isNaN(pengirimanProduk.dimensi[1].value)
    //         ? messageWidthRequired
    //         : "",
    //     tinggi:
    //       !pengirimanProduk.dimensi[2].value ||
    //       pengirimanProduk.dimensi[2].value === 0 ||
    //       isNaN(pengirimanProduk.dimensi[2].value)
    //         ? messageHeightRequired
    //         : "",
    //   };
    // }

    // Update validation state with all errors at once
    setValidationWeb(validationErrors);
    console.log("Validasinya nih", validationErrors);
    // Check if there are any validation errors
    if (Object.keys(validationErrors).length === 0) {
      if (
        informasiPenjualan.SaleType === "Satuan/Ecer" &&
        informasiPenjualan.Variants?.length
      )
        setProducts("informasiPenjualan", "HaveVariant", true);
      else setProducts("informasiPenjualan", "HaveVariant", false);

      const IsDraft = isDraft;

      const theTrigger =
        isEdit && isEdit === "edit" ? trigger_updated : trigger;

      const payload = {
        IsDraft,
        ID: informasiProduk?.ID || "",
        Status: informasiProduk?.Status || "",
        ProductName: informasiProduk.ProductName,
        ProductDescription: detailProduk.ProductDescription,
        SaleType: informasiPenjualan.SaleType,
        Weight: informasiPenjualan?.Variants?.length
          ? 0
          : pengirimanProduk.berat_pengiriman,
        DimensionLength:
          pengirimanProduk.dimensi[0].value == ""
            ? 0
            : pengirimanProduk.dimensi[0].value,
        DimensionWidth:
          pengirimanProduk.dimensi[1].value == ""
            ? 0
            : pengirimanProduk.dimensi[1].value,
        DimensionHeight:
          pengirimanProduk.dimensi[2].value == ""
            ? 0
            : pengirimanProduk.dimensi[2].value,
        UrlVideo: informasiProduk.UrlVideo,
        ShippingCostBy: pengirimanProduk.biaya_pengiriman,
        ShippingType: pengirimanProduk.opsi_pengiriman,
        AssuranceType: pengirimanProduk.asuransi_pengiriman,
        ShippingType: pengirimanProduk.opsi_pengiriman,
        ShippingIDs: pengirimanProduk.ShippingIDs,
        Stock:
          informasiPenjualan?.Variants.length &&
          informasiPenjualan.SaleType === "Satuan/Ecer"
            ? null
            : informasiPenjualan.Stock,
        Price:
          informasiPenjualan?.Variants.length &&
          informasiPenjualan.SaleType === "Satuan/Ecer"
            ? null
            : informasiPenjualan.Price,
        SKUCode: informasiPenjualan.SKUCode,
        // Status:,
        MinPurchase: informasiPenjualan.MinPurchase,
        HaveVariant:
          informasiPenjualan?.Variants.length &&
          informasiPenjualan.SaleType === "Satuan/Ecer"
            ? true
            : false,
        GradeID: informasiProduk.GradeID,
        ConditionID: detailProduk.ConditionID,
        EtalaseID: informasiProduk.EtalaseID,
        // Etalase:,
        Condition: detailProduk.conditionID,
        Grade: informasiProduk.GradeID,
        Brand: detailProduk.Brand,
        Categories: informasiProduk.Categories,
        ProductPhotos: informasiProduk.ProductPhotos.filter(
          (item) => item.value !== null
        ),
        TypeVariants: informasiPenjualan.varian,
        Variants: informasiPenjualan.Variants,
        Wholesales: informasiPenjualan.Wholesales,
        Bonus: informasiPenjualan.Bonus,

        // Spesifikasi Produk
        // Data spesifikasi tambahan
        Specifications: formattedSpecs, // Gunakan hasil dari formatSpecifications()
      };

      theTrigger(payload)
        .then((response) => {
          console.log(response, " ");
          addProductState.getState().resetProductStates();
          setDataToast({
            type: "success",
            message: IsDraft
              ? messageSuccessDraft
              : isEdit == "edit"
              ? "Berhasil memperbarui product"
              : messageSuccessAdd,
          });
          setShowToast(true);
          router.push("/kelolaproduk/daftarproduk?tab=1");
        })
        .catch((error) => {
          console.error("API Error:", error);
          if (error.status == 402) {
            return handleModal({
              modalId: "modal_tambah_rekening",
              withHeader: true,
              closeArea: false,
              hideCloseButton: false,
            });
          }
          if (error.status === 400) {
            // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0317
            if (error.response.data.Data.Message?.includes("SKU")) {
              setValidationWeb({ SKUCode: error.response.data.Data.Message });
              setShowToast(true);
              setDataToast({
                type: "error",
                message:
                  error.response.data.Data.Message ||
                  error.response.data.Message.Text,
              });
            }
            // IMP - Prevent atur harga produk saat promo aktif
            if (error.response.data.Data.Message?.includes("promo")) {
              setValidationWeb({ Price: error.response.data.Data.Message });
            }
          }
        });
    } else {
      setDataToast({
        type: "error",
        message: messageEmptyFields,
      });
      setShowToast(true);
    }
  };

  const menuAddProduct = t("menuAddProduct");
  return (
    <div className="block w-fit m-auto">
      <Toast />
      <BreadCrumb data={getBred} onclick={onClickBred} />
      <div className="flex gap-3 my-4">
        <IconComponent
          size="medium"
          color="primary"
          src="/icons/arrowbackblue.svg"
          classname="cursor-pointer"
          x
          onclick={() => ConfirmationDataForm()}
        />
        {/* LB - 0627 - 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 */}
        {/* Improvement Skeleton Wahyu */}
        <TranslationSkeleton
          parentClassName={"min-w-[200px] min-h-5"}
          className="capitalize text-neutral-900 font-bold text-xl"
          label={isEdit == "edit" ? "menuUbahProduk" : "menuTambahProduk"}
        />
      </div>
      {/* Informasi Produk */}
      <InformasiProduk />
      {/* Detail Produk */}
      <DetailProduk />
      {/* Spesifikasi Tambahan - Passing existingCategories */}
      {informasiProduk.Categories &&
        informasiProduk.Categories.GroupcategoryID &&
        informasiProduk.Categories.CategoryID && (
          <div>
            <ContainerCadangan
              key={`${informasiProduk.Categories.GroupcategoryID}-${informasiProduk.Categories.CategoryID}`}
              existingCategories={informasiProduk.Categories}
            />
          </div>
        )}
      {/* <SpesifikasiTambah /> */}
      {/* Informasi Penjualan */}
      <InformasiPenjualanProduk />
      {/* pengiriman produk */}
      <PengirimanProduk />
      {/* 3 button aksi */}

      <div className="flex gap-3 w-full items-center justify-end my-6">
        <Button
          onClick={() => ConfirmationDataForm()}
          color="primary_secondary"
        >
          {t("buttonCancel")}
        </Button>
        <Button onClick={() => handleSave(true)} color="primary_secondary">
          {t("buttonSaveDraft")}
        </Button>
        <Button onClick={() => handleSave(false)}>
          {" "}
          {t("buttonSaveDisplay")}{" "}
        </Button>
      </div>
    </div>
  );
};

export default TambahProdukPage;

export const BrowsePhoto = () => {
  return (
    <>
      <ImageuploaderProduct />
    </>
  );
};

export const ModalTambahBrand = () => {
  const { closeModal, props } = useContext(StateContext);
  const { dataBrand, setDataBrand, kompabilitas, setKompabilitas } = brand();
  const { setProducts } = addProductState();
  const { t } = useTranslation();
  useEffect(() => {
    // console.log(kompabilitas, " kompabilitas zu");
  }, [kompabilitas]);

  const inputRef = useRef();
  const [isErrorEdit, setIsErrorEdit] = useState({
    status: "",
    message: "",
  });

  const onChangeInput = () => {
    setIsErrorEdit({
      status: "",
      message: "",
    });
  };

  const onClickSimpan = () => {
    if (!inputRef.current.value) {
      setIsErrorEdit({
        status: "error",
        message: props
          ? `Nama ${props} wajib diisi`
          : t("messageBrandNameRequired"),
      });
    } else if (dataBrand.some((a) => a?.name === inputRef.current.value)) {
      setIsErrorEdit({
        status: "error",
        message: `${t("labelNamaBrand")} ${inputRef.current.value} ${t(
          "labelSudahAda"
        )}`,
      });
    } else {
      setIsErrorEdit({
        status: "",
        message: "",
      });

      if (props) {
        setKompabilitas(props.charAt(0).toUpperCase() + props.slice(1), {
          name: inputRef.current.value,
          value: inputRef.current.value,
        });
      } else {
        setDataBrand({
          id: null,
          name: inputRef.current.value,
        });
        setProducts("detailProduk", "Brand", {
          ID: null,
          BrandName: inputRef.current.value,
        });
      }
      closeModal();
    }
  };

  return (
    <div
      className={`flex flex-col items-center py-[36px] gap-[24px] px-[24px]`}
    >
      <p className={`text-neutral-900 font-[700] text-[16px] capitalize`}>
        {props ? `masukkan nama ${props}` : t("buttonAddBrand")}
      </p>
      <Input
        type="text"
        status={isErrorEdit.status}
        ref={inputRef}
        changeEvent={onChangeInput}
        width={{ width: "100%" }}
        placeholder={t("AppKelolaProdukMuatpartsSinglePickExample")}
        supportiveText={{ title: isErrorEdit.message }}
      />
      <div className={`flex gap-[8px]`}>
        <Button color="primary_secondary" onClick={() => closeModal()}>
          {t("buttonCancel")}
        </Button>
        <Button color="primary" onClick={onClickSimpan}>
          {t("buttonSave")}
        </Button>
      </div>
    </div>
  );
};

export const ConfirmationClosed = () => {
  const { closeModal } = useContext(StateContext);
  const router = useCustomRouter();
  const { t } = useTranslation();

  return (
    <div className="flex flex-col gap-6 justify-center items-center py-9 px-6 w-[338px] m-auto">
      <span className="text-neutral-900 text-sm font-medium text-center">
        {/* Data produk tidak akan tersimpan sebelum kamu klik simpan */}
        {t("messageUnsavedWarning")}
      </span>
      <div className="flex gap-2">
        <Button
          color="primary_secondary"
          Class="!max-w-[112px]"
          onClick={() => closeModal()}
        >
          {t("buttonCancel")}
        </Button>
        <Button
          Class="!max-w-[112px]"
          onClick={() => {
            // Reset semua product states
            addProductState.getState().resetProductStates();
            closeModal();
            router.replace("/kelolaproduk/daftarproduk?tab=1");
          }}
        >
          {t("buttonConfirmLeave")}
        </Button>
      </div>
    </div>
  );
};

export const ModalTambahRekening = () => {
  const { closeModal } = useContext(StateContext);
  const router = useCustomRouter();
  const { handleModal } = useContext(StateContext);
  const { t } = useTranslation();

  const openRekening = () => {
    return handleModal({
      modalId: "tambah_rekening_baru",
      withHeader: true,
      closeArea: false,
      hideCloseButton: false,
      sizeHeader: "bigger",
    });
  };

  return (
    <div className="flex flex-col gap-6 justify-center items-center py-9 px-6 w-[338px] m-auto">
      <span className="text-neutral-900 text-sm font-medium text-center">
        Kamu wajib menyimpan minimal 1 rekening untuk pencairan penghasilan
        tokomu.
      </span>
      <div className="flex gap-2">
        <Button
          color="primary"
          Class="!max-w-[164px]"
          onClick={() => openRekening()}
        >
          {t("buttonAddAccount")}
        </Button>
      </div>
    </div>
  );
  // LBM - Andrew - Spesifikasi Produk - MP - 005
};
