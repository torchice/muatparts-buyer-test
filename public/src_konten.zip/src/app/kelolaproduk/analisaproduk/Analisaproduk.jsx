
'use client'
import React, { useState } from 'react'
import AnalisaprodukResponsive from './AnalisaprodukResponsive'
import AnalisaprodukWeb from './AnalisaprodukWeb'
import SWRHandler from '@/services/useSWRHook'
import viewport from '@/store/zustand/common'

function Analisaproduk() {
  const [state,setState]=useState()
  const {useSWRHook,useSWRMutateHook}=SWRHandler
  const {isMobile} = viewport()
  if(typeof isMobile!=='boolean') return <></> //buat skeleton
  if(isMobile) return <AnalisaprodukResponsive/>
  return <AnalisaprodukWeb/>
}

export default Analisaproduk
  