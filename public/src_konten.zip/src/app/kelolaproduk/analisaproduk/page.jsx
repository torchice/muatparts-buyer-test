import Analisaproduk from "./Analisaproduk";

function Page() {
  return <Analisaproduk />;
}

export default Page;
