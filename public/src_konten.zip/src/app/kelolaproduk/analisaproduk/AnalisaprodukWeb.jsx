'use client';
import React, { useState, useEffect, useContext, useRef, useMemo } from "react";
import { Header } from '@/components/AnalisaProdukComponent/Header';
import { StatsCard } from '@/components/AnalisaProdukComponent/StatsCard';
import { ProductTable } from '@/components/AnalisaProdukComponent/ProductTable';
import { Pagination } from '@/components/AnalisaProdukComponent/Pagination';
import { useProductAnalysis, useProductCategories, useProductBrands } from '@/components/AnalisaProdukComponent/useProductAnalysis';
import { ITEMS_PER_PAGE } from '@/components/AnalisaProdukComponent/MockData';

import Input from "@/components/AnalisaProdukComponent/Input";
import Filter from "@/components/Filter/Filter";
import style from "./Analisaproduk.module.scss";
import IconComponent from "@/components/IconComponent/IconComponent";

import "@/components/KelolaPesananComponent/kelolapesanan.css"
import { useForm } from "react-hook-form";
import SWRHandler from "@/services/useSWRHook";
import { last } from "lodash";


// 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0017
const AnalisaprodukWeb = ({
    loading = false,
    search = "",
    setSearch = () => {},
    statusProduct = "",
}) => {
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(ITEMS_PER_PAGE);
    const [filters, setFilters] = useState({
        period: 'all',
        search: '',
        category: '',
        brand: '',
        status: '',
        sortBy: ''
    });
    const [aturMassal, setAturMassal] = useState("");

    // Use custom hooks with error handling
    const { 
        data: products = [], 
        summary = {}, 
        totalProducts = 0,
        isLoading 
    } = useProductAnalysis({
        ...filters,
        page: currentPage,
        pageSize: itemsPerPage
    });

    // const { categories = [] } = useProductCategories();
    // const { brands = [] } = useProductBrands();

    const { control, getValues, setValue, watch } = useForm();
  const formProps = {
    control,
    getValues,
    setValue,
    watch,
  };

  const {useSWRHook,useSWRMutateHook}=SWRHandler
  const baseUrl = `${process.env.NEXT_PUBLIC_GLOBAL_API}v1/`;
  const { data: filter } = useSWRHook(
    `${baseUrl}muatparts/product/owned_filters`
  );

  const filterType = {
    brand: "Brand",
    category: "Kategori",
    condition: "Kondisi",
    status: "Status",
    type: "Tipe Penjualan",
  };
  const filterData = useMemo(
    () =>
      Object.entries(filter?.Data || [])
        .filter(([key]) => key === "category" || key === "brand")
        .map(([key, value]) => {
          const type = filterType[key];
          const isCategory = key === "category";
          const filterable = isCategory || key === "brand";
          return {
            key,
            filterable,
            isMultiselect: filterable || key === "condition",
            options: value.map((item, key) => {
              const label = isCategory ? last(item.value) : item.value;
              const name = `${type}-${key}`;
              return { name, label, value: item.id };
            }),
            type,
          };
        }),
    [filter?.Data]
  );

    const [isOpen, setIsOpen] = useState(false);
    const [searchValue, setSearchValue] = useState('');

    // Process filter data safely
    const productFilterData = Array.isArray(filterData) 
        ? filterData.reduce((arr, curr) => {
            if (curr?.key === "status" && statusProduct !== "") {
                return arr;
            }
            return [...arr, curr];
        }, [])
        : [];

    // Process selected filters safely
    const selectedFilters = typeof watch === 'function' 
        ? Object.entries(watch()).reduce((arr, [key, value]) => {
            if (value?.checked) {
                const [type] = key.split("-");
                const currentType = filterData?.find((item) => item.type === type);
                const option = currentType?.options?.find(
                    (option) => option.name === key
                );
                return option ? [...arr, { ...option }] : arr;
            }
            return arr;
        }, [])
        : [];

    const handlePageChange = (page) => {
        setCurrentPage(page);
    };

    const handleItemsPerPageChange = (newItemsPerPage) => {
        setItemsPerPage(newItemsPerPage);
        setCurrentPage(1);
    };

    const handleFilterChange = (newFilters) => {
        setFilters(prev => ({ ...prev, ...newFilters }));
        setCurrentPage(1);
    };

    const handleSearch = (e) => {
        const value = e.target.value;
        setSearchValue(value); // Update nilai search lokal
        
        if (e.key === "Enter") {
            handleFilterChange({ search: value }); // Update filter ketika Enter ditekan
        }
    };
    
    // Fungsi untuk membersihkan pencarian
    const clearSearch = () => {
        setSearchValue('');
        handleFilterChange({ search: '' });
    };


    const handleSelectFilter = ({ checked }, type, value) => {
      setFilters((prevState) => {
        const defaultValue =
          type === "category" || type === "brand" || type === "condition"
            ? []
            : "";
        let filterValue = prevState[type] || defaultValue;
        if (
          checked &&
          (type === "category" || type === "brand" || type === "condition")
        ) {
          filterValue = [...filterValue, value];
        } else if (checked) {
          filterValue = value;
        } else if (
          type === "category" ||
          type === "brand" ||
          type === "condition"
        ) {
          filterValue = filterValue.filter(
            (item) => JSON.stringify(item) !== JSON.stringify(value)
          );
        } else {
          filterValue = "";
        }
        return {
          ...prevState,
          [type]: filterValue,
        };
      });
    };
    const handleClearFilter = () =>
      setFilters((prev) => ({
        ...prev,
        brand: "",
        category: "",
      }));

    return (
        <div className="container mx-auto space-y-8">
            <Header 
                onFilterChange={handleFilterChange}
                filters={filters}
            />
            
            <div className="flex flex-row gap-2 flex-wrap">
                {/* Improvement fix wording pak Bryan */}
                <StatsCard
                    title="Produk Dilihat"
                    value={summary?.totalViews || 0}
                    variant="biru"
                    icon={<img src="/muatparts/icons/information.svg" alt="" className="w-4 h-4" />}
                    isLoading={isLoading}
                />
                <StatsCard
                    title="Produk di Troli"
                    value={summary?.totalCart || 0}
                    variant="biru"
                    icon={<img src="/muatparts/icons/information.svg" alt="" className="w-4 h-4" />}
                    isLoading={isLoading}
                />
                <StatsCard
                    title="Total Pesanan"
                    value={summary?.totalOrders || 0}
                    variant="biru"
                    icon={<img src="/muatparts/icons/information.svg" alt="" className="w-4 h-4" />}
                    isLoading={isLoading}
                />
                <StatsCard
                    title="Total Pendapatan"
                    value={`Rp ${((summary?.totalRevenue || 0) > 999999998
                      ? "999.999.999+"
                      : (summary?.totalRevenue || 0).toLocaleString())}`}
                    variant="hijau"
                    icon={<img src="/muatparts/icons/information.svg" alt="" className="w-4 h-4" />}
                    isLoading={isLoading}
                />
                <StatsCard
                    title="Konversi"
                    value={`${(summary?.conversionRate || 0).toString().replace(".",",")}%`}
                    variant="hijau"
                    icon={<img src="/muatparts/icons/information.svg" alt="" className="w-4 h-4" />}
                    isLoading={isLoading}
                />
                <StatsCard
                    title="Produk Terjual"
                    value={summary?.totalSold || 0}
                    variant="kuning"
                    icon={<img src="/muatparts/icons/information-orange.svg" alt="" className="w-4 h-4" />}
                    isLoading={isLoading}
                />
            </div>

            <div className="space-y-5 bg-white rounded-lg shadow">
                <div className="flex items-center justify-between pt-[20px] pb-[0px] px-[24px]">
                    <div className="flex items-center">
                        <div className="flex items-center gap-4">
                            <h2 className="AvenirBold18px Color000000">Daftar Produk</h2>
                            <Input
                                placeholder="Cari Nama Produk/SKU"
                                className={style.inputSearch}
                                value={searchValue} // Gunakan state searchValue
                                onChange={(e) => {
                                    const value = e.target.value;
                                    setSearchValue(value);
                                }}
                                onKeyUp={handleSearch}
                                startAdornment={
                                    <IconComponent src="/icons/search.svg" className="w-4 h-4" />
                                }
                                endAdornment={
                                    searchValue && ( // Gunakan searchValue untuk kondisional
                                        <button
                                            onClick={clearSearch}
                                            className="p-1"
                                        >
                                            <IconComponent src="/icons/silang.svg" className="w-4 h-4" />
                                        </button>
                                    )
                                }
                            />
                            <Filter
                                data={productFilterData}
                                control={control}
                                getValues={getValues}
                                isActive={selectedFilters.length > 0}
                                isOpen={isOpen}
                                onSelect={handleSelectFilter}
                                setIsOpen={setIsOpen}
                                setValue={setValue}
                                watch={watch}
                            />
                        </div>
                    </div>
                    <div className="text-right">
                        <div className="AvenirDemi16px Color000000">
                            Total : {totalProducts} Produk
                        </div>
                    </div>
                </div>

                <div className="mt-4 px-6">
                            <FilterBubble
                                onAllClear={handleClearFilter}
                                onItemClear={handleSelectFilter}
                                selectedFilters={selectedFilters}
                                setValue={setValue}
                            />
                        </div>

                <ProductTable products={products} loading={isLoading} />
            </div>
            <Pagination
                currentPage={currentPage}
                totalPages={Math.ceil(totalProducts / itemsPerPage)}
                onPageChange={handlePageChange}
                onItemsPerPageChange={handleItemsPerPageChange}
                itemsPerPage={itemsPerPage}
            />
        </div>
    );
};

export default AnalisaprodukWeb;

const FilterBubble = ({
    onAllClear,
    onItemClear,
    selectedFilters,
    setValue,
}) => {
    const [leftArrowClassname, setLeftArrowClassname] = useState(
      style.filter_scroll_disabled
    );
    const [rightArrowClassname, setRightArrowClassname] = useState(
      style.filter_scroll
    );
    const [scrollWidth, setScrollWidth] = useState(0);
    const containerRef = useRef();
    const filterRef = useRef();
  
    const isOverflow = scrollWidth > 787;
  
    useEffect(() => {
      if (containerRef.current) {
        setScrollWidth(containerRef.current.scrollWidth);
      }
    }, [selectedFilters]);
  
    const handleResetFilter = () => {
      selectedFilters.forEach((filter) =>
        setValue(filter.name, { checked: false, value: undefined })
      );
      onAllClear();
    };
  
    const handleScrollFilter = (direction) => () => {
      if (!containerRef.current) {
        return;
      }
      const scrollValue = { left: -100, right: 100 };
      containerRef.current.scrollBy({
        left: scrollValue[direction],
        behavior: "smooth",
      });
      const maxScrollLeft =
        containerRef.current.scrollWidth - containerRef.current.clientWidth;
      if (containerRef.current.scrollLeft === 0) {
        setLeftArrowClassname(style.filter_scroll_disabled);
      } else {
        setLeftArrowClassname(style.filter_scroll);
      }
      if (containerRef.current.scrollLeft >= maxScrollLeft) {
        setRightArrowClassname(style.filter_scroll_disabled);
      } else {
        setRightArrowClassname(style.filter_scroll);
      }
    };
  
    const filterType = {
      brand: "Brand",
      category: "Kategori",
      condition: "Kondisi",
      status: "Status",
      type: "Tipe Penjualan",
    };
    const handleRemoveFilter =
      ({ name, value }) =>
      () => {
        const newValue = { checked: false, value: undefined };
        const [type] = name.split("-");
        const typeProperty = Object.entries(filterType).find(
          ([key, value]) => value === type
        )[0];
        setValue(name, newValue);
        onItemClear(newValue, typeProperty, value);
      };
  
    if (selectedFilters.length === 0) {
      return null;
    }
  
    return (
      <div className="flex flex-row gap-x-3 mt-5">
        <span
          className="font-bold text-[12px] leading-[14.4px] text-primary-700 self-center cursor-pointer min-w-[113px]"
          onClick={handleResetFilter}
        >
          Hapus Semua Filter
        </span>
        {isOverflow && (
          <IconComponent
            loader={false}
            src="/icons/chevron-left.svg"
            height={28}
            width={28}
            classname={`border-[1px] rounded-2xl border-neutral-500 ${leftArrowClassname}`}
            onclick={handleScrollFilter("left")}
          />
        )}
        <div className="max-w-[787px] overflow-x-hidden" ref={containerRef}>
          <div className="flex flex-nowrap w-full gap-x-3" ref={filterRef}>
            {selectedFilters.map((filter, key) => (
              <div
                className="flex flex-row gap-x-1 px-3 py-[7px] rounded-2xl border-[1px] border-primary-700 items-center"
                key={key}
              >
                <div className="max-w-[162px]">
                  <p className="text-[10px] leading-[13px] font-semibold text-primary-700 truncate">
                    {filter.label}
                  </p>
                </div>
                <IconComponent
                  loader={false}
                  src="/icons/silang.svg"
                  height={7}
                  width={7}
                  classname="stroke-primary-700"
                  onclick={handleRemoveFilter(filter)}
                />
              </div>
            ))}
          </div>
        </div>
        {isOverflow && (
          <IconComponent
            loader={false}
            src="/icons/chevron-right.svg"
            height={28}
            width={28}
            classname={`border-[1px] rounded-2xl border-neutral-500 ${rightArrowClassname}`}
            onclick={handleScrollFilter("right")}
          />
        )}
      </div>
    );
};
  