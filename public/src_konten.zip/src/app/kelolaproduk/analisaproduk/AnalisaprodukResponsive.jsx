import React, { useState, useRef, useEffect } from "react";
import "@/components/KelolaPesananComponent/kelolapesanan.css";
import { useProductAnalysis, useProductCategories, useProductBrands } from '@/components/AnalisaProdukComponent/useProductAnalysis';
import SWRHandler from '@/services/useSWRHook';

const { useSWRMutateHook } = SWRHandler;
const API_URL = process.env.NEXT_PUBLIC_WITHOUT_API_URL || 'https://api-example.com';

const Index = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [bottomSheetConfig, setBottomSheetConfig] = useState({
    isOpen: false,
    type: 'totalPendapatan' // tipe bisa jadi: 'totalPendapatan', 'info', 'sorting', 'daftarProduk'
  });
  const [selectedSort, setSelectedSort] = useState({ title: 'Total Pendapatan' });
  const [sortConfig, setSortConfig] = useState('');
  const [selectedStat, setSelectedStat] = useState('Total Pendapatan');
  const [currentPage, setCurrentPage] = useState(1);
  const [filters, setFilters] = useState({
    period: 'all',
    search: '',
    category: '',
    brand: '',
    status: '',
    sortBy: ''
  });

  // Integrasi hooks API dari useProductAnalysis
  const { 
    data: products = [], 
    summary = {}, 
    totalProducts = 0,
    isLoading 
  } = useProductAnalysis({
    ...filters,
    page: currentPage,
    pageSize: 10
  });

  const { categories = [] } = useProductCategories();
  const { brands = [] } = useProductBrands();

  // Integrasi hook untuk ekspor data
  const { trigger: triggerExport, isMutating: isExporting } = useSWRMutateHook(
    `${API_URL}/product-analysis/export`,
    "POST"
  );

  // Helper function untuk mengecek apakah sort sudah dipilih
  const isSortSelected = () => {
    return sortConfig !== '';
  };

  // Event handlers
  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
    
    if (e.key === "Enter") {
      setFilters(prevFilters => ({
        ...prevFilters,
        search: e.target.value
      }));
      setCurrentPage(1);
    }
  };

  const clearSearch = () => {
    setSearchTerm('');
    setFilters(prevFilters => ({
      ...prevFilters,
      search: ''
    }));
  };

  const handleFilter = () => {
    // Implementasi filter logic (jika diperlukan)
  };

  const handleSort = () => {
    setBottomSheetConfig({
      isOpen: true,
      type: 'sorting'
    });
  };

  const handlePeriodChange = (period) => {
    setFilters(prevFilters => ({
      ...prevFilters,
      period
    }));
    setCurrentPage(1);
  };

  const handleShare = () => {
    // Implement share logic (jika diperlukan)
  };

  const handleExport = async () => {
    try {
      const response = await triggerExport(filters);
      
      // Pastikan response mengandung data yang diperlukan
      if (response?.data?.Data) {
        // Buka URL unduhan di tab baru
        window.open(response.data.Data, '_blank');
      }
    } catch (error) {
      console.error('Gagal mengunduh data:', error);
    }
  };

  const handleSortChange = (value) => {
    if (value?.title) {
      setSelectedSort(value);
      
      // Tentukan sortBy untuk API berdasarkan title
      let sortByValue = '';
      switch(value.title) {
        case 'Produk Dilihat':
          sortByValue = 'views';
          break;
        case 'Pesanan':
          sortByValue = 'orders';
          break;
        case 'Konversi':
          sortByValue = 'conversion';
          break;
        case 'Komplain':
          sortByValue = 'complaints';
          break;
        case 'Terjual':
          sortByValue = 'sold';
          break;
        case 'Total Pendapatan':
          sortByValue = 'revenue';
          break;
        case 'Troli':
          sortByValue = 'cart';
          break;
        case 'Favorit':
          sortByValue = 'favorites';
          break;
        case 'Status':
          sortByValue = 'status';
          break;
        default:
          sortByValue = '';
      }
      
      setFilters(prevFilters => ({
        ...prevFilters,
        sortBy: sortByValue
      }));
    }
  };

  // Fungsi untuk memproses angka menjadi format mata uang
  const formatCurrency = (amount) => {
    return amount.toLocaleString('id-ID');
  };

  // Bottom Sheet Data untuk Total Pendapatan (tanpa deskripsi)
  const BottomSheetDataTotalPendapatan = [
    { title: "Produk Dilihat" },
    { title: "Pesanan" },
    { title: "Konversi" },
    { title: "Komplain" },
    { title: "Terjual" },
    { title: "Total Pendapatan" },
    { title: "Troli" },
    { title: "Favorit" },
    { title: "Status" }
  ];

  // Bottom Sheet Data untuk Info Statistik
  const BottomSheetDataStatistik = [
    { title: "Produk Dilihat", description: "Total halaman produk yang dibuka melalui aplikasi dan website muatparts" },
    { title: "Produk di Troli", description: "Total produk yang ditambahkan oleh pembeli ke Troli" },
    { title: "Total Pesanan", description: "Total pesanan yang berhasil dibayarkan" },
    { title: "Total Pendapatan", description: "Total pendapatan dari pesanan yang selesai" },
    { title: "Konversi", description: "Persentase jumlah pesanan terhadap jumlah produk dilihat" },
    { title: "Produk Terjual", description: "Total Produk dari pesanan yang telah selesai" }
  ];

  // Bottom Sheet Data untuk Daftar Produk
  const BottomSheetDataDaftarProduk = [
    { 
      title: "Dilihat", 
      description: "Jumlah halaman produk yang dibuka melalui aplikasi dan website muatparts" 
    },
    { 
      title: "Pesanan", 
      description: "Jumlah pesanan yang berhasil dibayarkan" 
    },
    { 
      title: "Konversi", 
      description: "Persentase total pesanan terhadap total produk dilihat" 
    },
    { 
      title: "Komplain", 
      description: "Jumlah produk dari pesanan yang dikomplain" 
    },
    { 
      title: "Terjual", 
      description: "Jumlah Produk dari pesanan yang selesai" 
    },
    { 
      title: "Total Pendapatan", 
      description: "Jumlah pendapatan dari pesanan yang selesai" 
    }
  ];

  // Bottom Sheet Data untuk Sorting
  const BottomSheetDataSorting = [
    {
      section: "Nama Produk",
      options: [
        { title: "A-Z", value: "name_asc" },
        { title: "Z-A", value: "name_desc" }
      ]
    },
    {
      section: "Total Pendapatan",
      options: [
        { title: "Tertinggi", value: "revenue_highest" },
        { title: "Terendah", value: "revenue_lowest" }
      ]
    }
  ];

  // ProductListItem Component
  const ProductListItem = ({ title, description, onSelect, isSelected, showDescription = false }) => (
    <div 
      className="pb-4 mb-4 border-b border-solid border-b-stone-300 cursor-pointer" 
      onClick={() => onSelect?.(title)}
    >
      <div className={`flex ${!showDescription ? 'items-center justify-between' : 'flex-col'}`}>
        <div>
          <div className="text-sm text-black AvenirDemi14px">{title}</div>
          {showDescription && description && (
            <div className="text-xs leading-3 text-neutral-500 mt-1 AvenirNormal12px">{description}</div>
          )}
        </div>
        {!showDescription && (
          <div className="w-5 h-5 border border-gray-300 rounded-full flex items-center justify-center">
            {isSelected && (
              <div className="w-3 h-3 bg-[#176CF7] rounded-full" />
            )}
          </div>
        )}
      </div>
    </div>
  );

  // SortingSection Component
  const SortingSection = ({ section, options }) => (
    <div className="mb-6">
      <div className="text-sm font-semibold mb-4">{section}</div>
      {options.map((option, index) => (
        <div 
          key={index}
          className="flex items-center mb-4 cursor-pointer"
          onClick={() => {
            setSortConfig(option.value);
            
            // Update sorting API berdasarkan opsi yang dipilih
            let newSortBy = '';
            if (option.value === 'name_asc') newSortBy = 'name:asc';
            else if (option.value === 'name_desc') newSortBy = 'name:desc';
            else if (option.value === 'revenue_highest') newSortBy = 'revenue:desc';
            else if (option.value === 'revenue_lowest') newSortBy = 'revenue:asc';
            
            setFilters(prevFilters => ({
              ...prevFilters,
              sortBy: newSortBy
            }));
            
            setBottomSheetConfig({ ...bottomSheetConfig, isOpen: false });
          }}
        >
          <div className="w-5 h-5 border border-gray-300 rounded-full flex items-center justify-center mr-3">
            {sortConfig === option.value && (
              <div className="w-3 h-3 bg-primary-600 rounded-full" />
            )}
          </div>
          <span className="text-sm">{option.title}</span>
        </div>
      ))}
    </div>
  );

  // BottomSheet Component
  const BottomSheet = () => {
    const [scrollPosition, setScrollPosition] = useState(0);
    const contentRef = useRef(null);
    
    if (!bottomSheetConfig.isOpen) return null;

    const handleScroll = (e) => {
      const element = e.target;
      const scrollHeight = element.scrollHeight - element.clientHeight;
      const scrollTop = element.scrollTop;
      const scrollPercentage = (scrollTop / scrollHeight) * 320;
      setScrollPosition(scrollPercentage);
    };

    return (
      <div className="fixed top-0 left-0 w-full h-full bg-black bg-opacity-50 z-50">
        <div className={`fixed bottom-0 left-0 px-4 pt-1 pb-6 bg-white shadow-sm ${bottomSheetConfig.type === 'sorting' ? 'h-[320px]' : 'h-[578px]'} rounded-t-2xl w-[360px] max-sm:px-3 max-sm:pt-1 max-sm:pb-5 max-sm:w-full max-sm:h-auto max-sm:rounded-t-2xl`}>
          <div className="relative h-full">
            <div className="relative pt-1 mb-6 text-center">
              <div>
                <svg width="38" height="4" viewBox="0 0 38 4" fill="none" xmlns="http://www.w3.org/2000/svg" className="handle mx-auto">
                  <path d="M0 2C0 0.895431 0.89543 0 2 0H36C37.1046 0 38 0.895431 38 2C38 3.10457 37.1046 4 36 4H2C0.89543 4 0 3.10457 0 2Z" fill="#D9D9D9" />
                </svg>
              </div>
              <button 
                className="absolute left-0 top-6 cursor-pointer" 
                onClick={() => setBottomSheetConfig({ ...bottomSheetConfig, isOpen: false })} 
                aria-label="Close"
              >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="close-icon">
                  <path d="M18.36 18.36L5.64001 5.64" stroke="#0080FF" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="bevel" />
                  <path d="M18.36 5.64L5.64001 18.36" stroke="#0080FF" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="bevel" />
                </svg>
              </button>
              <h2 className="mt-6 text-sm font-bold text-black AvenirBold14px">
                {bottomSheetConfig.type === 'info' ? 'Statistikmu' : 
                 bottomSheetConfig.type === 'daftarProduk' ? 'Daftar Produk' : 
                 bottomSheetConfig.type === 'sorting' ? 'Urutkan' : 'Pilih Data Statistik'}
              </h2>
            </div>
            <div 
              ref={contentRef}
              onScroll={handleScroll}
              className={`overflow-y-auto pr-4 ${bottomSheetConfig.type === 'sorting' ? 'h-[calc(100%_-_80px)]' : 'h-[calc(100%_-_140px)]'} max-sm:pr-3 no-scrollbar`}
            >
              {bottomSheetConfig.type === 'info' ? (
                BottomSheetDataStatistik.map((item, index) => (
                  <ProductListItem 
                    key={index} 
                    title={item.title} 
                    description={item.description}
                    showDescription={true}
                  />
                ))
              ) : bottomSheetConfig.type === 'daftarProduk' ? (
                BottomSheetDataDaftarProduk.map((item, index) => (
                  <ProductListItem 
                    key={index} 
                    title={item.title} 
                    description={item.description}
                    showDescription={true}
                  />
                ))
              ) : bottomSheetConfig.type === 'totalPendapatan' ? (
                BottomSheetDataTotalPendapatan.map((item, index) => (
                  <ProductListItem 
                    key={index} 
                    title={item.title}
                    isSelected={selectedStat === item.title}
                    onSelect={(title) => {
                      setSelectedStat(title);
                    }}
                    showDescription={false}
                  />
                ))
              ) : (
                BottomSheetDataSorting.map((section, index) => (
                  <SortingSection 
                    key={index}
                    section={section.section}
                    options={section.options}
                  />
                ))
              )}
            </div>
            {bottomSheetConfig.type === 'totalPendapatan' && (
              <div className="">
                <button 
                  className="w-full bg-[#176CF7] text-white py-3 rounded-[100px] font-semibold text-sm"
                  onClick={() => {
                    setSelectedSort({ title: selectedStat });
                    handleSortChange({ title: selectedStat });
                    setBottomSheetConfig({ ...bottomSheetConfig, isOpen: false });
                  }}
                >
                  Terapkan
                </button>
              </div>
            )}
            {bottomSheetConfig.type === 'totalPendapatan' && (
              <div className="absolute right-1 w-1 rounded-md bg-zinc-300 h-[358px] top-[63px]">
                <div 
                  className="absolute w-1 rounded-md bg-neutral-500 h-[38px]" 
                  style={{ top: `${scrollPosition}px` }}
                />
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  // Stats Component - Menggunakan data dari API
  const Stats = () => (
    <section className="bg-white mb-2 p-4">
      <div className="flex items-center mb-4">
        <h2 className="text-sm font-bold grow text-black flex items-center gap-1">
          Statistikmu
          <svg
            width="16"
            height="16"
            viewBox="0 0 16 16"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="cursor-pointer"
            onClick={() => setBottomSheetConfig({ isOpen: true, type: 'info' })}
          >
            <circle cx="8" cy="8" r="5.91667" stroke="#555555" strokeWidth="1.5" />
            <rect x="7.41667" y="7" width="1.16667" height="4.91667" rx="0.583333" fill="#555555" stroke="#555555" strokeWidth="0.5" />
            <rect x="7.41667" y="4.5" width="1.16667" height="1.16667" rx="0.583333" fill="#555555" stroke="#555555" strokeWidth="0.5" />
          </svg>
        </h2>
        {/* <div className="flex gap-2">
          <select 
            className="text-xs bg-white border border-gray-300 rounded-md py-1 px-2"
            onChange={(e) => handlePeriodChange(e.target.value)}
            value={filters.period}
          >
            <option value="all">Semua Periode</option>
            <option value="this-month">Bulan Ini</option>
            <option value="last-month">Bulan Lalu</option>
            <option value="custom">Kustom</option>
          </select>
          <button 
            className="text-xs bg-white border border-gray-300 rounded-md py-1 px-2 flex items-center gap-1"
            onClick={handleExport}
            disabled={isExporting}
          >
            <svg 
              width="12" 
              height="12" 
              viewBox="0 0 16 16" 
              fill="none" 
              xmlns="http://www.w3.org/2000/svg"
            >
              <path d="M14 10V12.6667C14 13.0203 13.8595 13.3594 13.6095 13.6095C13.3594 13.8595 13.0203 14 12.6667 14H3.33333C2.97971 14 2.64057 13.8595 2.39052 13.6095C2.14048 13.3594 2 13.0203 2 12.6667V10" stroke="#0F172A" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M5 6.66666L8 9.66666L11 6.66666" stroke="#0F172A" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M8 9.66666V2" stroke="#0F172A" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            {isExporting ? 'Mengunduh...' : 'Unduh'}
          </button>
        </div> */}
      </div>

      <div className="grid grid-cols-[repeat(2,1fr)] gap-2 max-sm:grid-cols-[1fr]">
        <div className="flex flex-col gap-2 p-3 rounded-md BgE2F2FF border border-gray-200">
          <span className="text-xs text-black">Produk Dilihat</span>
          <span className="text-base font-bold text-[#176CF7]">
            {summary.totalViews || 0}
          </span>
        </div>

        <div className="flex flex-col gap-2 p-3 rounded-md BgE2F2FF border border-gray-200">
          <span className="text-xs text-black">Produk di Troli</span>
          <span className="text-base font-bold text-[#176CF7]">
            {summary.totalCart || 0}
          </span>
        </div>

        <div className="flex flex-col gap-2 p-3 rounded-md BgE2F2FF border border-gray-200">
          <span className="text-xs text-black">Total Pesanan</span>
          <span className="text-base font-bold text-[#176CF7]">
            {summary.totalOrders || 0}
          </span>
        </div>

        <div className="flex flex-col gap-2 p-3 rounded-md BgFFF9C1 border border-gray-200">
          <span className="text-xs text-black">Produk Terjual</span>
          <span className="text-base font-bold text-[#FF7A00]">
            {summary.totalSold || 0}
          </span>
        </div>

        <div className="flex flex-col gap-2 p-3 rounded-md BgE3F5ED border border-gray-200">
          <span className="text-xs text-black">Total Pendapatan</span>
          <span className="text-base font-bold text-[#0FBB81]">
            Rp {formatCurrency(summary.totalRevenue || 0)}
          </span>
        </div>

        <div className="flex flex-col gap-2 p-3 rounded-md BgE3F5ED border border-gray-200">
          <span className="text-xs text-black">Konversi</span>
          <span className="text-base font-bold text-[#0FBB81]">
            {summary.conversionRate || 0}%
          </span>
        </div>
      </div>
    </section>
  );

  // Search Component
  const Search = () => (
    <div className="flex overflow-hidden flex-col self-stretch px-3 py-4 leading-none bg-white border-b border-solid border-b-stone-300 w-full">
      <div className="flex gap-2 items-center px-[12px] pt-[8px] pb-[7px] w-full text-sm font-semibold bg-white rounded-md border border-solid border-neutral-500 h-[32px] text-neutral-500">
        <img
          loading="lazy"
          src="https://cdn.builder.io/api/v1/image/assets/TEMP/e33c43a4b0d48295b62a684c31db4ce8e974b27bba750927b8ca2abc460991ab"
          className="object-contain shrink-0 self-stretch my-auto w-[16px] h-[16px] aspect-square"
          alt="Search icon"
        />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          onKeyUp={handleSearch}
          placeholder="Cari nama produk/SKU"
          className="flex-1 shrink self-stretch my-auto basis-0 bg-transparent outline-none AvenirDemi14px"
        />
        {searchTerm && (
          <button
            onClick={clearSearch}
            className="p-1"
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M18.36 18.36L5.64001 5.64" stroke="#555555" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="bevel" />
              <path d="M18.36 5.64L5.64001 18.36" stroke="#555555" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="bevel" />
            </svg>
          </button>
        )}
      </div>

      <div className="flex gap-10 justify-between items-center mt-4 w-full font-medium text-black">
        <div className="flex gap-2 items-center self-stretch my-auto text-sm whitespace-nowrap">
          <button className="flex overflow-hidden flex-col justify-center self-stretch px-3 py-2 my-auto rounded-3xl border border-solid bg-zinc-100 border-zinc-100 max-w-[262px]">
            <div className="flex gap-2 items-center">
              <span className="self-stretch my-auto text-ellipsis">Filter</span>
              <div className="flex shrink-0 self-stretch my-auto w-3.5 h-3.5">
                <img
                  src="https://cdn.builder.io/api/v1/image/assets/TEMP/28fb4afd28f39d6e1737d2f11298835a6055f2555f545c1096d9e7775109fdbb"
                  alt="Filter icon"
                  className="w-full h-full object-contain"
                />
              </div>
            </div>
          </button>
          <button 
            onClick={handleSort}
            className={`flex overflow-hidden flex-col justify-center self-stretch px-3 py-2 my-auto rounded-3xl border border-solid ${isSortSelected() ? 'border-[#176CF7] bg-white' : 'bg-zinc-100 border-zinc-100'} max-w-[262px]`}
          >
            <div className="flex gap-2 items-center">
              <span className={`self-stretch my-auto text-ellipsis ${isSortSelected() ? 'text-[#176CF7]' : ''}`}>
                Urutkan
              </span>
              <div className="flex shrink-0 self-stretch my-auto w-3.5 h-3.5">
                <img
                  src={isSortSelected() ? "/muatparts/kelolapesanan/icon-sort-active.svg" : "/muatparts/kelolapesanan/icon-sort-inactive.svg"}
                  alt="Sort icon"
                  className="w-full h-full object-contain"
                />
              </div>
            </div>
          </button>
        </div>
        <div className="self-stretch my-auto text-xs">{totalProducts || 0} Produk</div>
      </div>
    </div>
  );

  // ProductList Component dengan menggunakan data dari API
  const ProductList = () => (
    <div className="bg-white w-full max-sm:w-full">
      <div className="flex justify-between items-center p-4 h-16 bg-white">
        <div className="flex gap-2 items-center">
          <div className="text-sm font-bold text-black">Daftar Produk</div>
          <div 
            className="cursor-pointer"
            onClick={() => setBottomSheetConfig({ isOpen: true, type: 'daftarProduk' })}
          >
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle cx="8" cy="8" r="5.91667" stroke="#555555" strokeWidth="1.5" />
              <rect x="7.41669" y="7" width="1.16667" height="4.91667" rx="0.583333" fill="#555555" stroke="#555555" strokeWidth="0.5" />
              <rect x="7.41669" y="4.5" width="1.16667" height="1.16667" rx="0.583333" fill="#555555" stroke="#555555" strokeWidth="0.5" />
            </svg>
          </div>
        </div>
        <button 
          onClick={() => setBottomSheetConfig({ isOpen: true, type: 'totalPendapatan' })}
          className="flex gap-3 items-center p-3 h-8 bg-white rounded-md border border-solid border-neutral-500 w-fit max-sm:w-[140px]"
        >
          <div className="text-sm text-black">{selectedSort.title}</div>
          <div>
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" className="dropdown-icon">
              <path d="M4 6L7.45378 9.73569C7.61123 9.90498 7.82421 10 8.04622 10C8.26822 10 8.48121 9.90498 8.63866 9.73569L12 6.09998" stroke="#555555" strokeLinecap="round" strokeLinejoin="bevel" />
            </svg>
          </div>
        </button>
      </div>
      <div className="flex justify-between px-4 py-3 bg-white border-b border-solid border-b-stone-300">
        <div className="text-xs text-black w-[216px]">Nama Produk</div>
        <div className="text-xs text-right text-black w-[100px]">Total Pendapatan</div>
      </div>
      
      <div className="bg-white">
        {isLoading ? (
          <div className="flex justify-center items-center py-8">
            <div className="text-sm text-gray-500">Memuat data...</div>
          </div>
        ) : products.length > 0 ? (
          products.map((product, index) => (
            <div key={index} className="px-4 py-3 bg-white border-b border-solid border-b-neutral-100">
              <div className="flex gap-2 items-center">
                <img 
                  src={product.mainImage || "https://cdn.builder.io/api/v1/image/assets/TEMP/fdb11016bd980165abb81a10a569090a6eb69631"} 
                  alt="" 
                  className="w-8 h-8 rounded" 
                />
                <div className="flex flex-1 justify-between max-sm:flex-row">
                  <div className="overflow-hidden text-xs text-black whitespace-nowrap text-ellipsis w-[168px]">
                    {product.name}
                  </div>
                  <div className="text-xs font-bold text-right text-black w-[108px]">
                    Rp {formatCurrency(product.analytics?.revenue || 0)}
                  </div>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="flex justify-center items-center py-8">
            <div className="text-sm text-gray-500">Tidak ada data</div>
          </div>
        )}
      </div>
    </div>
  );

  // Pagination Component
  const Pagination = () => {
    // Tentukan total halaman berdasarkan total produk dan jumlah yang ditampilkan per halaman
    const totalPages = Math.ceil(totalProducts / 10);
    
    // Generate array of page numbers
    const pageNumbers = [];
    for (let i = 1; i <= totalPages; i++) {
      pageNumbers.push(i);
    }
    
    if (totalPages <= 1) return null;
    
    return (
      <div className="flex justify-center items-center py-4 bg-white">
        <button 
          className="w-8 h-8 flex items-center justify-center rounded-md"
          onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
          disabled={currentPage === 1}
        >
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M10 12L6 8L10 4" stroke="#555555" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </button>
        
        {pageNumbers.map(page => (
          <button
            key={page}
            onClick={() => setCurrentPage(page)}
            className={`w-8 h-8 mx-1 rounded-md flex items-center justify-center ${
              currentPage === page ? 'bg-[#176CF7] text-white' : 'text-gray-700'
            }`}
          >
            {page}
          </button>
        ))}
        
        <button 
          className="w-8 h-8 flex items-center justify-center rounded-md"
          onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
          disabled={currentPage === totalPages}
        >
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M6 12L10 8L6 4" stroke="#555555" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </button>
      </div>
    );
  };

  // Main Component Return
  return (
    <div className="w-full min-h-screen bg-[#F1F1F1] max-sm:w-full">
      <Stats />
      <Search />
      <ProductList />
      <Pagination />
      <BottomSheet />
    </div>
  );
};

// Export Component
export default Index;