"use client";

import React, {
  useState,
  useEffect,
  useContext,
  useRef,
  useMemo,
  Fragment,
} from "react";
import { StateContext } from "@/common/StateContext";
import Button from "@/components/Button/Button";
import Card from "@/components/Card/Card";
import toast from "@/store/zustand/toast";
import TabMenu from "@/components/Menu/TabMenu";
import Input from "@/components/Input/Input";
import IconComponent from "@/components/IconComponent/IconComponent";
import style from "./DaftarProdukPage.module.scss";
import TableComponent from "@/components/TableComponent/TableComponent";
import DataNotFound from "@/components/DataNotFound/DataNotFound";
import Dropdown from "@/components/Dropdown/Dropdown";
import Toast from "@/components/Toast/Toast";
import ListDataProduk from "./(partials)/ListDataProduk";
import Filter from "@/components/Filter/Filter";
import SWRHandler from "@/services/useSWRHook";

import { useSearchParams } from "next/navigation";
//s3
import { useTranslation } from "@/context/TranslationProvider";
import { useCustomRouter } from "@/libs/CustomRoute";
import ImageComponent from "@/components/ImageComponent/ImageComponent";
import menuZus from "@/store/zustand/menu";
import { metaSearchParams } from "@/libs/services";
import TranslationSkeleton from "@/components/Skeleton/TranslationSkeleton";
//andy s3

// export const tableHeader = [
//   { title: "Gambar", val: "" },
//   { title: t('columnName'), val: "name" },
//   { title: "Kategori", val: "category" },
//   { title: "Stok", val: "stock" },
//   { title: "Harga Jual", val: "price" },
//   { title: "Terjual", val: "" },
//   { title: "Status", val: "" },
// ];
//dipindah kebawah

const DaftarProdukPage = ({
  filterData,
  product,
  params,
  control,
  getValues,
  setValue,
  watch,
  tabMenu,
  sort,
  loading,
  handleClearFilter,
  handleSelectFilter,
  search,
  setSearch,
  setProductFilter,
  statusProduct,
  productMutate,
  additionalParam,
  totalProduct,
  currentPage,
  pageSize,
  onPageChange,
  onPageSizeChange,
  dataCount,
  // FIX BUG DAFTAR PRODUK LB-0193
  isDisabledFilter,
  // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0245
  lastAction,
  setLastAction,
}) => {
  //dipindah
  const { t, tOrEmpty } = useTranslation();

  const tableHeader = useMemo(() => {
    // Memastikan translasi sudah ada
    // Karena, apabila title tidak ada, maka table header akan error
    const header = [
      { title: t(`columnImage`), val: "" },
      { title: t(`columnName`), val: "name" },
      { title: t(`columnCategory`), val: "category" },
      { title: t(`columnStock`), val: "stock" },
      { title: t(`columnPrice`), val: "price" },
      // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0417
      { title: t(`columnSold`), val: "sold" },
      { title: t(`columnStatus`), val: "" },
    ];
    const sortable = header
      .filter((item) => item.val !== "")
      .map((item) => item.title);
    return { header, sortable };
  }, [t]);

  //end dpindah
  //start s3
  //{t('KontrakHargaDetailButtonHubungiTransporter')}
  //cara pakai S3 lang

  const linkTab = useSearchParams().get("tab");

  const { useSWRHook, useSWRMutateHook } = SWRHandler;
  const [getFilter, setFilter] = useState({
    "status[0]": "Draft",
    "status[1]": "Active",
    "category[0]": [],
    "brand[0]": "f9601c8b-4f80-4f5e-af35-e70fbef86e1c",
    "condition[0]": "049d33b1-645b-49ff-b440-d7ad3b625b15",
    "type[0]": "Grosir",
    "type[1]": "Satuan%2FEcer",
    page: "1",
    page_size: "80",
    orderby: "name",
    ordermode: "asc",
  });

  const {
    data: export_list,
    error: error_export_list,
    trigger: trigger_export_list,
    isMutating: mutate_export_list,
  } = useSWRMutateHook(
    process.env.NEXT_PUBLIC_GLOBAL_API +
      `v1/muatparts/product/export?status[0]=Draft&orderby=stock&ordermode=desc`,
    "GET"
  );
  const { showToast, setShowBottomsheet, dataToast } = toast();
  const router = useCustomRouter();
  const [aturMassal, setAturMassal] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const { handleModal } = useContext(StateContext);
  const { setMenuZ } = menuZus();

  // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0652, LB - 0653, LB - 0654
  // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0860, LB - 0861
  const productFilterData = useMemo(() => {
    const joinedFilter = filterData.reduce((arr, curr) => {
      if (curr.key === "status" && statusProduct !== "") {
        return arr;
      }
      return [...arr, curr];
    }, []);

    const translatedFilter = joinedFilter.map((item) => ({
      ...item,
      type: t(`labelFilter_${item.key}`),
      options: item.options.map((option) => {
        // LBM - EKA - MULTIBAHASA - 9 Mei 2025
        let labelKey = `labelFilter_${option.value}`;
        if (option.label === "baru" || option.label === "bekas") labelKey = `labelFilter_${option.label}`;
        const translated = t(labelKey);
        
        // Jika memang ada translate, maka return translate
        // Ditandai dengan hasil translate tidak sama dengan labelKey
        if (translated !== labelKey) {
          return { ...option, label: translated };
        }

        // Jika tidak ada translate, maka return tanpa translate
        return option;
      }),
    }));
    console.log("🚀 ~ translatedFilter ~ translatedFilter:", translatedFilter);

    return translatedFilter;
  }, [filterData, statusProduct, t]);

  useEffect(() => {
    setMenuZ({ id: 1, value: "semua" });
  }, []);

  useEffect(() => {
    if (error_export_list?.status === 400) {
      console.log("error", error_export_list);
    }
    if (export_list?.status === 200) {
      console.log("success", export_list);
      window.open(export_list?.data?.Data, "_blank");
    }
  }, [mutate_export_list]);
  /*
  useEffect(() => {
    // if (!searchParams?.tab) router.push(`?tab=1&lang=${lang}`);
    if (!searchParams?.tab) router.push(`?tab=1`);
  }, [searchParams, params]);
*/
  useEffect(() => {
    aturMassal &&
      handleModal({
        modalId: "aktifkanproduk",
        withHeader: false,
        closeArea: false,
        hideCloseButton: true,
        props: { filterData, type: aturMassal, productMutate: productMutate },
      });
  }, [aturMassal]);

  const onClickUnduh = () => {
    trigger_export_list();
  };

  const handleSearch = (e) => {
    if (e.key === "Enter") {
      setProductFilter((prevState) => ({ ...prevState, search }));
      // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0245
      setLastAction("search");
    }
  };

  const selectedFilters = Object.entries(watch()).reduce(
    (arr, [key, value]) => {
      if (value?.checked) {
        const [type] = key.split("-");
        const currentType = filterData.find((item) => item.type === type);
        const option = currentType.options.find(
          (option) => option.name === key
        );
        return [...arr, { ...option }];
      }
      return arr;
    },
    []
  );
  return (
    <>
      <Toast />
      {/* Desktop Version */}
      <div className={`${style.desktop}`}>
        {!dataCount?.all && !loading ? (
          <BelumAdaProdukPage />
        ) : (
          <>
            <div className="flex justify-between items-center mb-4">
              <TranslationSkeleton
                parentClassName={"min-w-[200px] min-h-5"}
                className="font-bold text-xl text-neutral-900"
                label={t("titleProductList")}
              />
              <div className="flex gap-3">
                <Button
                  Class="!font-medium"
                  iconLeft="/icons/Plus.svg"
                  color="primary_secondary"
                  onClick={() =>
                    router.push("/kelolaproduk/aturprodukmassal?tab=1")
                  }
                >
                  {/* Improvement Skeleton Wahyu */}
                  <TranslationSkeleton
                    label="buttonBulkAdd"
                    parentClassName="min-w-[80px] min-h-3"
                  />
                </Button>
                <Button
                  Class="!font-medium"
                  iconLeft="/icons/Plus.svg"
                  onClick={() =>
                    router.push("/kelolaproduk/tambahproduk?page=1")
                  }
                >
                  <TranslationSkeleton
                    label="buttonAdd"
                    parentClassName="min-w-[40px] min-h-3"
                  />
                </Button>
                <Button
                  Class={`!font-medium ${
                    !product?.Data?.length ||
                    !Array.isArray(product?.Data) ||
                    (!product && "!border !border-neutral-400")
                  }`}
                  iconLeft={
                    <IconComponent
                      src={"/icons/download.svg"}
                      classname={`${
                        !product?.Data?.length ||
                        !Array.isArray(product?.Data) ||
                        !product
                          ? "icon-gray"
                          : "icon-white"
                      }`}
                    />
                  }
                  onClick={onClickUnduh}
                  disabled={
                    !product?.Data?.length ||
                    !Array.isArray(product?.Data) ||
                    !product
                  }
                >
                  <TranslationSkeleton
                    label="labelButtonUnduh"
                    parentClassName="min-w-[40px] min-h-3"
                  />
                </Button>
              </div>
            </div>
            <TabMenu classname="mt-4" menu={tabMenu} />
            <div className="bg-white py-5 rounded-xl w-full mt-4">
              <div className=" pt-0 px-6">
                {/* pencarian */}
                <div className="flex justify-between items-center">
                  <div className="flex flex-row gap-x-3">
                    <Input
                      placeholder={tOrEmpty(`inputSearch`)}
                      classname={style.inputSearch}
                      icon={{
                        left: (
                          <span className="w-4 h-4">
                            <IconComponent src={"/icons/search.svg"} />
                          </span>
                        ),
                        right: search ? (
                          <span
                            className="w-4 h-4 cursor-pointer"
                            onClick={(e) => {
                              e.stopPropagation();
                              setSearch("");
                              setProductFilter((prevState) => ({
                                ...prevState,
                                search: "",
                              }));
                            }}
                          >
                            <IconComponent src={"/icons/silang.svg"} />
                          </span>
                        ) : (
                          ""
                        ),
                      }}
                      value={search}
                      changeEvent={(e) => setSearch(e.target.value)}
                      onKeyUp={handleSearch}
                    />
                    <Filter
                      data={productFilterData}
                      control={control}
                      getValues={getValues}
                      isActive={selectedFilters.length > 0}
                      isOpen={isOpen}
                      onSelect={handleSelectFilter}
                      setIsOpen={setIsOpen}
                      setValue={setValue}
                      watch={watch}
                      // FIX BUG DAFTAR PRODUK LB-0193
                      disabled={
                        (!product?.Data?.length ||
                          !Array.isArray(product?.Data) ||
                          !product) &&
                        isDisabledFilter
                      }
                    />
                  </div>
                  <div
                    className={`${style.containerDropdownAturmassal} flex items-center gap-3 justify-end`}
                  >
                    <span className="text-base text-neutral-900 font-semibold">
                      {/* Improvement fix wording pak Bryan */}
                      {t("labelTotalNProducts").replace(
                        "{count}",
                        totalProduct
                      )}
                    </span>
                    <Dropdown
                      fixedPlaceholder
                      placeholder={tOrEmpty("dropdownBulkAction")}
                      classname={`${style.dropdownAturMassal} ${
                        !product?.Data?.length ||
                        !Array.isArray(product?.Data) ||
                        !product
                          ? `${style.disableDropdwon} !border !border-neutral-600 !bg-neutral-200 `
                          : ""
                      }`}
                      options={[
                        {
                          name: t("buttonActivate"),
                          value: "aktif",
                        },
                        {
                          name: t("buttonEditProduct"),
                          value: "ubah",
                        },
                        {
                          name: t("buttonDeactivate"),
                          value: "nonaktif",
                        },
                        {
                          name: t("buttonBulkDelete"),
                          value: "hapus",
                        },
                      ]}
                      onSelected={(e) => setAturMassal(e)}
                      disabled={
                        !product?.Data?.length ||
                        !Array.isArray(product?.Data) ||
                        !product
                      }
                    />
                  </div>
                </div>
                <FilterBubble
                  onAllClear={handleClearFilter}
                  onItemClear={handleSelectFilter}
                  selectedFilters={selectedFilters}
                  setValue={setValue}
                />
              </div>
              <div className="mt-5">
                {tableHeader && (
                  <TableComponent
                    colums={tableHeader.header.map((key) => key.title)}
                    withSortColumn={tableHeader.sortable}
                    onChangeSort={sort}
                  >
                    {loading ? (
                      Array(3)
                        .fill(0)
                        .map((_, rowIndex) => (
                          <tr key={`loading-row-${rowIndex}`}>
                            <td className={style.td_custom}>
                              <div className="animate-pulse bg-gray-200 h-[56px] w-[56px] rounded" />
                            </td>
                            <td className={style.td_custom}>
                              <div className="flex flex-col gap-[12px]">
                                <div className="animate-pulse bg-gray-200 h-4 w-full rounded" />
                                <div className="animate-pulse bg-gray-200 h-3 w-1/2 rounded" />
                                <div className="animate-pulse bg-gray-200 h-3 w-1/2 rounded" />
                              </div>
                            </td>
                            <td className={style.td_custom}>
                              <div className="flex flex-col gap-1">
                                <div className="animate-pulse bg-gray-200 h-3 w-3/4 rounded" />
                                <div className="animate-pulse bg-gray-200 h-3 w-1/2 rounded" />
                                <div className="animate-pulse bg-gray-200 h-3 w-2/3 rounded" />
                                <div className="animate-pulse bg-gray-200 h-3 w-1/3 rounded" />
                              </div>
                            </td>
                            <td className={style.td_custom}>
                              <div className="animate-pulse bg-gray-200 h-4 w-1/2 rounded" />
                            </td>
                            <td className={style.td_custom}>
                              <div className="animate-pulse bg-gray-200 h-4 w-full rounded" />
                            </td>
                            <td className={style.td_custom}>
                              <div className="animate-pulse bg-gray-200 h-4 w-1/2 rounded" />
                            </td>
                            <td className={style.td_custom}>
                              <div className="flex gap-2">
                                <div className="animate-pulse bg-gray-200 h-4 w-1/2 rounded" />
                                <div className="animate-pulse bg-gray-200 h-4 w-1/2 rounded" />
                              </div>
                            </td>
                          </tr>
                        ))
                    ) : product?.Data && product.Data.length > 0 ? (
                      <ListDataProduk
                        data={product}
                        productMutate={productMutate}
                        additionalParam={additionalParam}
                      />
                    ) : (
                      <DataNotFound
                        // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0245
                        title={
                          lastAction === "filter"
                            ? `Data tidak Ditemukan. Mohon coba hapus beberapa filter`
                            : lastAction === "search"
                            ? "Keyword tidak ditemukan"
                            : undefined
                        }
                        image={`/img/data-not-found.svg`}
                        classname={`my-[20px]`}
                      />
                    )}
                  </TableComponent>
                )}

                {/* pagination, sepurane ges gae AI. aku ngelu remap code daftare */}
                {totalProduct > 0 && (
                  <div className="flex items-center justify-between px-6 mt-4 border-neutral-200 pt-4">
                    <div className="flex items-center gap-2">
                      {totalProduct > 0 &&
                        Array.from({
                          length: Math.min(
                            Math.ceil(totalProduct / pageSize),
                            10
                          ),
                        }).map((_, index) => (
                          <button
                            key={index + 1}
                            onClick={() => onPageChange(index + 1)}
                            className={`w-8 h-8 text-sm flex items-center justify-center rounded-md ${
                              currentPage === index + 1
                                ? "bg-[#C22716] text-white font-bold"
                                : "text-neutral-600 font-medium hover:bg-neutral-50"
                            }`}
                          >
                            {index + 1}
                          </button>
                        ))}
                    </div>

                    <div className="flex items-center gap-1">
                      <p className="font-semibold text-xs text-neutral-600 pr-4">
                        {t("buttonShowDetails")}
                      </p>
                      <div className="flex gap-1 items-center">
                        {[10, 20, 40].map((item, idx) => (
                          <button
                            key={idx}
                            onClick={() => onPageSizeChange(item)}
                            className={`w-8 h-8 text-sm flex items-center justify-center rounded-md ${
                              pageSize === item
                                ? "bg-[#C22716] text-white font-bold"
                                : "text-neutral-600 font-medium hover:bg-neutral-50"
                            }`}
                          >
                            {item}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
                {/* pagination, sepurane ges gae AI. aku ngelu remap code daftare */}
              </div>
            </div>
          </>
        )}
      </div>
    </>
  );
};

export default DaftarProdukPage;

export const BelumAdaProdukPage = () => {
  const router = useCustomRouter();

  const { t } = useTranslation();

  const searchParams = useSearchParams();

  return (
    <>
      <span className="sm:hidden font-bold text-xl text-neutral-900 mb-4">
        {t("titleProductList")}
      </span>

      <div className="sm:flex hidden p-4 border-b-[1px] border-b-neutral-400 bg-white">
        Div buat search dan filter
      </div>
      <Card classname="flex flex-col gap-2 sm:h-screen sm:mt-0 mt-4 sm:py-0 py-14 items-center justify-center border-none sm:rounded-none rounded-xl">
        <ImageComponent
          src={`/img/daftarprodukicon.png`}
          width={96}
          height={77}
          alt=""
        />
        <span className="font-semibold text-neutral-600 text-base">
          {t("labelNotAvailableProduct")}
        </span>
        <span className="font-medium text-neutral-600 text-xs">
          {t("labelAddYourFirstProductNow")}
        </span>
        <div className="sm:hidden flex gap-3">
          <Button
            Class="!h-8 !max-w-none !w-[217px] whitespace-nowrap"
            iconLeft="/icons/Plus.svg"
            color="primary_secondary"
            onClick={() => router.push("/kelolaproduk/aturprodukmassal?tab=1")}
          >
            {t("buttonBulkAdd")}
          </Button>

          <Button
            Class="!h-8 !max-w-none !w-[169px] whitespace-nowrap"
            iconLeft="/icons/Plus.svg"
            onClick={() => router.push("/kelolaproduk/tambahproduk?page=1")}
          >
            {t("buttonAdd")}
          </Button>
        </div>
      </Card>
    </>
  );
};

const FilterBubble = ({
  onAllClear,
  onItemClear,
  selectedFilters,
  setValue,
}) => {
  // FIX BUG DAFTAR PRODUK LB-0192
  const filterType = {
    brand: "Brand",
    category: "Kategori",
    condition: "Kondisi",
    status: "Status",
    type: "Tipe Penjualan",
  };
  const [leftArrowClassname, setLeftArrowClassname] = useState(
    style.filter_scroll_disabled
  );
  const [rightArrowClassname, setRightArrowClassname] = useState(
    style.filter_scroll
  );
  const [scrollWidth, setScrollWidth] = useState(0);
  const containerRef = useRef();
  const filterRef = useRef();

  const isOverflow = scrollWidth > 787;
  const { t } = useTranslation();

  useEffect(() => {
    if (containerRef.current) {
      setScrollWidth(containerRef.current.scrollWidth);
    }
  }, [selectedFilters]);

  const handleResetFilter = () => {
    selectedFilters.forEach((filter) =>
      setValue(filter.name, { checked: false, value: undefined })
    );
    onAllClear();
  };

  const handleScrollFilter = (direction) => () => {
    if (!containerRef.current) {
      return;
    }
    const scrollValue = { left: -100, right: 100 };
    containerRef.current.scrollBy({
      left: scrollValue[direction],
      behavior: "smooth",
    });
    const maxScrollLeft =
      containerRef.current.scrollWidth - containerRef.current.clientWidth;
    if (containerRef.current.scrollLeft === 0) {
      setLeftArrowClassname(style.filter_scroll_disabled);
    } else {
      setLeftArrowClassname(style.filter_scroll);
    }
    if (containerRef.current.scrollLeft >= maxScrollLeft) {
      setRightArrowClassname(style.filter_scroll_disabled);
    } else {
      setRightArrowClassname(style.filter_scroll);
    }
  };

  const handleRemoveFilter =
    ({ name, value }) =>
    () => {
      const newValue = { checked: false, value: undefined };
      const [type] = name.split("-");
      const typeProperty = Object.entries(filterType).find(
        ([key, value]) => value === type
      )[0];
      setValue(name, newValue);
      onItemClear(newValue, typeProperty, value);
    };

  if (selectedFilters.length === 0) {
    return null;
  }

  return (
    <div className="flex flex-row gap-x-3 mt-5">
      <span
        className="font-bold text-[12px] leading-[14.4px] text-primary-700 self-center cursor-pointer min-w-[113px]"
        onClick={handleResetFilter}
      >
        {t("buttonClearFilters")}
      </span>
      {isOverflow && (
        <IconComponent
          loader={false}
          src="/icons/chevron-left.svg"
          height={28}
          width={28}
          classname={`border-[1px] rounded-2xl border-neutral-500 ${leftArrowClassname}`}
          onclick={handleScrollFilter("left")}
        />
      )}
      <div className="max-w-[787px] overflow-x-hidden" ref={containerRef}>
        <div className="flex flex-nowrap w-full gap-x-3" ref={filterRef}>
          {selectedFilters.map((filter, key) => (
            <div
              className="flex flex-row gap-x-1 px-3 py-[7px] rounded-2xl border-[1px] border-primary-700 items-center"
              key={key}
            >
              <div className="max-w-[162px]">
                <p className="text-[10px] leading-[13px] font-semibold text-primary-700 truncate">
                  {filter.label}
                </p>
              </div>
              <IconComponent
                loader={false}
                src="/icons/silang.svg"
                height={10}
                width={10}
                classname="stroke-primary-700"
                onclick={handleRemoveFilter(filter)}
              />
            </div>
          ))}
        </div>
      </div>
      {isOverflow && (
        <IconComponent
          loader={false}
          src="/icons/chevron-right.svg"
          height={28}
          width={28}
          classname={`border-[1px] rounded-2xl border-neutral-500 ${rightArrowClassname}`}
          onclick={handleScrollFilter("right")}
        />
      )}
    </div>
  );
};
