"use client";

import viewport from "@/store/zustand/common";
import DaftarProdukPage from "./DaftarProdukPage";
import DaftarProdukPageResponsive from "./DaftarProdukPageResponsive";
import SWRHandler from "@/services/useSWRHook";
import { useMemo, useState, useEffect } from "react";
import last from "lodash/last";
import { useForm } from "react-hook-form";
import menuZus from "@/store/zustand/menu";
import { useTranslation } from "@/context/TranslationProvider";
import { useSearchParams } from "next/navigation";
import { useCustomRouter } from "@/libs/CustomRoute";
import TranslationSkeleton from "@/components/Skeleton/TranslationSkeleton";

import { authZustand as useToken } from "@/store/auth/authZustand";
import axios from "axios";
import bahasaZus from "@/store/zustand/bahasa";

const MainTambahProduk = (props /*, initialI18nStore, initialLocale */) => {

  const { t, tOrEmpty } = useTranslation();
  const { bahasa } = bahasaZus();
  
  const filterType = {
    brand: "Brand",
    category: "Kategori",
    condition: "Kondisi",
    status: "Status",
    type: "Tipe Penjualan",
  };

  
  const tableHeader = [
    { title: t(`columnImage`), val: "" },
    { title: t(`columnName`), val: "name" },
    { title: t(`columnCategory`), val: "category" },
    { title: t(`columnStock`), val: "stock" },
    { title: t(`columnPrice`), val: "price" },
    // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0417
    { title: t(`columnSold`), val: "sold" },
    { title: t(`columnStatus`), val: "" },
  ];

  const tabMenu = [
    { id: 1, name: "Semua", notif: null },
    { id: 2, name: "Aktif", notif: null },
    { id: 3, name: "Stok Habis", notif: null },
    { id: 4, name: "Nonaktif", notif: null },
    { id: 5, name: "Draf", notif: null },
  ];

  const baseUrl = `${process.env.NEXT_PUBLIC_GLOBAL_API}v1/`;
  const searchParams = useSearchParams();
  const [activeTab, _] = useState(searchParams.get("tab") || 1);
  const { isMobile } = viewport();
  const { menuZ, setMenuZ } = menuZus();
  const [statusProduct, setStatusProduct] = useState("");
  const [orderby, setOrderby] = useState("");
  const [ordermode, setOrdermode] = useState("");
  const router = useCustomRouter();
  // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0245
  const [lastAction, setLastAction] = useState("")

  const [search, setSearch] = useState("");
  const [productFilter, setProductFilter] = useState({});
  // FIX BUG DAFTAR PRODUK LB-0193
  const isDisabledFilter = useMemo(() => {
    if (typeof productFilter !== 'object' || productFilter === null) {
      return false;
    }

    const searchKey = 'search';

    if (!Object.prototype.hasOwnProperty.call(productFilter, searchKey)) {
      return false;
    }

    if (typeof productFilter[searchKey] !== 'string' || productFilter[searchKey].trim() === '') {
      return false;
    }

    for (const key in productFilter) {
      if (key !== searchKey && Object.prototype.hasOwnProperty.call(productFilter, key)) {
        const value = productFilter[key];
        if (typeof value === 'string' && value.trim() !== '') {
          return false;
        }
        if (Array.isArray(value) && value.length !== 0) {
          return false;
        }
        if (typeof value === 'object' && value !== null && Object.keys(value).length !== 0) {
          return false;
        }
      }
    }

    return true;
  }, [JSON.stringify(productFilter)]);

  const additionalParam = useMemo(() => {
    const newParams = [];
    if (productFilter?.search) {
      newParams.push(`keyword=${productFilter.search}`);
    }
    if (statusProduct) {
      newParams.push(`status[0]=${statusProduct}`);
      // FIX BUG Pengecekan Ronda Muatparts LB-0244
    } else if (productFilter?.status?.length > 0) {
      productFilter.status.forEach((item, key) =>
        newParams.push(`status[${key}]=${item}`)
      );
    }
    if (productFilter?.category?.length > 0) {
      productFilter.category.forEach((item, key) =>
        newParams.push(`category[${key}]=${JSON.stringify(item)}`)
      );
    }
    if (productFilter?.brand?.length > 0) {
      productFilter.brand.forEach((item, key) =>
        newParams.push(`brand[${key}]=${item}`)
      );
    }
    if (productFilter?.condition?.length > 0) {
      productFilter.condition.forEach((item, key) =>
        newParams.push(`condition[${key}]=${item}`)
      );
    }
    // FIX BUG Pengecekan Ronda Muatparts LB-0244
    if (productFilter?.type?.length > 0) {
      productFilter.type.forEach((item, key) =>
        newParams.push(`type[${key}]=${item}`)
      );
    }
    if (orderby && ordermode) {
      newParams.push(`orderby=${orderby}`);
      newParams.push(`ordermode=${ordermode}`);
    }
    if (newParams.length === 0) {
      return "";
    }
    return `&${newParams.join("&")}`;
  }, [productFilter, orderby, ordermode, statusProduct]);
  // Fetching API
  const { useSWRHook } = SWRHandler;


  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  // FIX BUG DAFTAR PRODUK LB-0123
  const isFirstTimerFilter = !additionalParam && currentPage === 1 && pageSize === 10
  const [dataCount, setDataCount] = useState(null);
  const {
    data: resProduct,
    error: product_error,
    isLoading: product_loading,
    mutate: productMutate,
  } = useSWRHook(
    `${baseUrl}muatparts/product/lists?page_size=${pageSize}&page=${currentPage}${additionalParam}`,
    null,
    (error) => {
      console.log("callback", error);
    }
  );
  // Improvement fix wording pak Bryan
  const tab = [
    // FIX BUG Pengecekan Ronda Muatparts LB-0294
    // LBM - OLIVER - FIX WIDTH LABEL TAB - MP - 005
    // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0902
    { id: 1, name: <TranslationSkeleton parentClassName={"min-h-5"} label={t('tabAllProduct')} />, notif: resProduct?.DataCount?.all || 0 },
    { id: 2, name: <TranslationSkeleton parentClassName={"min-h-5"} label={t('tabActive')} />, notif: resProduct?.DataCount?.active || 0 },
    { id: 3, name: <TranslationSkeleton parentClassName={"min-h-5"} label={t('tabOutStock')} />, notif: resProduct?.DataCount?.emptyStock || 0 },
    { id: 4, name: <TranslationSkeleton parentClassName={"min-h-5"} label={t('tabInactive')} />, notif: resProduct?.DataCount?.inactive || 0 },
    { id: 5, name: <TranslationSkeleton parentClassName={"min-h-5"} label={t('tabDraft')} />, notif: resProduct?.DataCount?.draft || 0 },
  ]
  //FIX 25.03 LB - 0463
  const tabResponsive = [
    // {/* 25 . 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0548 */}
    { id: 1, name: "WebKelolaPesananSellerMuatpartsSemua", notif: resProduct?.DataCount?.all || 0 },
    { id: 2, name: "tabActive", notif: resProduct?.DataCount?.active || 0 },
    { id: 3, name: "tabOutStock", notif: resProduct?.DataCount?.emptyStock || 0 },
    { id: 4, name: "tabInactive", notif: resProduct?.DataCount?.inactive || 0 },
    { id: 5, name: "tabDraft", notif: resProduct?.DataCount?.draft || 0 },
  ]
  const handlePageChange = (newPage) => {
    setCurrentPage(newPage);
    productMutate(
      // Optional: Trigger manual refetch
      `${baseUrl}muatparts/product/lists?page_size=${pageSize}&page=${newPage}${additionalParam}`,
      null,
      null,
      false
    );
  };

  const handlePageSizeChange = (newSize) => {
    setPageSize(newSize);
    setCurrentPage(1); // Reset ke halaman 1
    productMutate(
      `${baseUrl}muatparts/product/lists?page_size=${newSize}&page=1${additionalParam}`,
      null,
      null,
      false
    );
  };

  const [product, setProduct] = useState();
  const [totalProduct, setTotalProduct] = useState(0);


  useEffect(() => {
    const testActive = t('tabAllProduct') ;
    
    if(resProduct?.DataCount?.all>0&&!dataCount) setDataCount(resProduct?.DataCount)
    if (resProduct?.Data?.length) {
      setProduct({Data: resProduct.Data})
    }else{
      setProduct({
        Data: []
      });
    } 
    // productMutate(
    //   `muatparts/product/lists?page_size=20&page=1${additionalParam}&status[0]=${statusProduct}`
    // );
    setTotalProduct(resProduct?.Pagination?.Total);
  }, [resProduct, totalProduct]);

  const getDataSort = (e) => {
    // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0542
    if (e?.type === "app") {
      setOrderby(e.val === null ? "" : e.val);
      setOrdermode(e.key === null ? "" : e.key);
    } else {
      const filtered = tableHeader?.find((key) => key?.title === e?.id);
      if (!filtered) {
        setOrderby("");
        setOrdermode("");
        return;
      }
      setOrderby(filtered.val);
      setOrdermode(e.sortBy);
    }
  };

  // LBM - EKA - MULTIBAHASA - 9 Mei 2025
  // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0860
  // 25. 11 - QC Plan - Web - Ronda Live Mei - LB - 0104
  const { data: filter } = useSWRHook(
    `${baseUrl}muatparts/product/owned_filters${statusProduct ? `?tab=${statusProduct}` : ""}`,
    undefined,
    undefined,
    {
      headers: {
        // LBM - EKA - MULTIBAHASA - 14 Mei 2025
        languageid: bahasa?.languangeid,
      },
    }
  );

  const { control, getValues, setValue, watch } = useForm();

  useEffect(() => {
    if (Object.keys(menuZ).length === 0) {
      const findMenu = tabMenu.find((key) => key.id == activeTab);
      setMenuZ({
        id: findMenu?.id || 1,
        value: findMenu?.name || t('tabAllProduct') ,
      });
    }
  }, [menuZ, activeTab, tabMenu]);

  useEffect(() => {
    if (Object.keys(menuZ).length !== 0) {
      switch (menuZ.id) {
        case 1:
          setStatusProduct("");
          break;
        // FIX BUG Pengecekan Ronda Muatparts LB-0244
        case 2:
          setStatusProduct("Active");
          setProductFilter(prevState => ({ ...prevState, status: [] }))
          break;
        case 3:
          setStatusProduct("Empty");
          setProductFilter(prevState => ({ ...prevState, status: [] }))
          break;
        case 4:
          setStatusProduct("Inactive");
          setProductFilter(prevState => ({ ...prevState, status: [] }))
          break;
        case 5:
          setStatusProduct("Draft");
          setProductFilter(prevState => ({ ...prevState, status: [] }))
          break;
      }
    }
  }, [menuZ]);

  const filterData = useMemo(
    () =>
      Object.entries(filter?.Data || []).map(([key, value]) => {
        // console.log("key",key, value)
        const type = filterType[key];
        const isCategory = key === "category";
        const filterable = isCategory || key === "brand";
        return {
          key,
          filterable,
          // FIX BUG Pengecekan Ronda Muatparts LB-0244
          isMultiselect: true,
          options: value.map((item, key) => {
            const label = isCategory ? last(item.value) : item.value;
            const name = `${type}-${key}`;
            return { name, label, value: item.id };
          }),
          type,
        };
      }),
    [filter?.Data]
  );

  const handleSelectFilter = ({ checked }, type, value) => {
    setProductFilter((prevState) => {
      // FIX BUG Pengecekan Ronda Muatparts LB-0244
      const defaultValue = [];
      let filterValue = prevState[type] || defaultValue;
      if (checked) {
        filterValue = [...filterValue, value];
      } else {
        filterValue = filterValue.filter(
          (item) => JSON.stringify(item) !== JSON.stringify(value)
        );
      }
      return {
        ...prevState,
        [type]: filterValue,
      };
    });
    // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0245
    setLastAction("filter")
  };
  const handleClearFilter = () => setProductFilter({});

  const formProps = {
    control,
    getValues,
    setValue,
    watch,
  };

  if (isMobile)
    return (
      <DaftarProdukPageResponsive
        filterData={filterData}
        product={product}
        tabMenu={tabResponsive}
        sort={getDataSort}
        orderby={orderby}
        ordermode={ordermode}
        productMutate={productMutate}
        // FIX BUG DAFTAR PRODUK LB-0123
        isFirstTimerFilter={isFirstTimerFilter}
        // FIX BUG Pengecekan Ronda Muatparts LB-0243
        // FIX BUG Pengecekan Ronda Muatparts LB-0307
        search={search}
        setSearch={setSearch}
        setProductFilter={setProductFilter}
        isDisabledFilter={isDisabledFilter}
        setPageSize={setPageSize}
        //andy 25.03 466
        totalProduct={totalProduct}
        loading={product_loading}
      />
    );

  return (
    <DaftarProdukPage
      {...props}
      {...formProps}
      filterData={filterData}
      handleClearFilter={handleClearFilter}
      handleSelectFilter={handleSelectFilter}
      additionalParam={additionalParam}
      productMutate={productMutate}
      product={product}
      tabMenu={tab}
      loading={product_loading}
      sort={getDataSort}
      search={search}
      dataCount={dataCount}
      setProductFilter={setProductFilter}
      setSearch={setSearch}
      statusProduct={statusProduct}
      // buat paginatipn
      totalProduct={totalProduct}
      currentPage={currentPage}
      pageSize={pageSize}
      onPageChange={handlePageChange}
      onPageSizeChange={handlePageSizeChange}
      // FIX BUG DAFTAR PRODUK LB-0193
      isDisabledFilter={isDisabledFilter}
      // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0245
      lastAction={lastAction}
      setLastAction={setLastAction}
    />
  );
};

export default MainTambahProduk;
