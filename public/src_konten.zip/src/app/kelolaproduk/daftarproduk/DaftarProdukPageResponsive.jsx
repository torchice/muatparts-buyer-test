import {
  useState,
  useEffect,
  useContext,
  useMemo,
  Fragment,
  useCallback,
} from "react";
import Bottomsheet from "@/components/Bottomsheet/Bottomsheet";
import CardProdukResponsive from "./(partials)/CardProdukResponsive";
import { StateContext } from "@/common/StateContext";
import style from "./DaftarProdukPage.module.scss";
import Toast from "@/components/Toast/Toast";
import toast from "@/store/zustand/toast";
import { BelumAdaProdukPage } from "./DaftarProdukPage";
import Checkbox from "@/components/Checkbox/Checkbox";
import Bubble from "@/components/Bubble/Bubble";
import Input from "@/components/Input/Input";
import Filter, { FilterMobilePopup } from "@/components/Filter/Filter";
import aturmasalProduk from "@/store/zustand/produk/aturmasalProduk";
import headerZustand from "@/store/zustand/header";
import RadioButton from "@/components/Radio/RadioButton";
import menuZus from "@/store/zustand/menu";
import { useTranslation } from "@/context/TranslationProvider";
import IconComponent from "@/components/IconComponent/IconComponent";
import DataNotFound from "@/components/DataNotFound/DataNotFound";
import { useHeader } from "@/common/ResponsiveContext";

export const SortingResponsive = [
  {
    title: "nama produk",
    key: "name",
    children: [
      { title: "A-Z", value: "asc" },
      { title: "Z-A", value: "desc" },
    ],
  },
  {
    title: "kategori",
    key: "category",
    children: [
      { title: "A-Z", value: "asc" },
      { title: "Z-A", value: "desc" },
    ],
  },
  {
    title: "stok",
    key: "stock",
    children: [
      { title: "Tertinggi", value: "desc" },
      { title: "Terendah", value: "asc" },
    ],
  },
  {
    title: "harga jual",
    key: "price",
    children: [
      { title: "Tertinggi", value: "desc" },
      { title: "Terendah", value: "asc" },
    ],
  },
  {
    title: "terjual",
    key: "sold",
    children: [
      { title: "Tertinggi", value: "desc" },
      { title: "Terendah", value: "asc" },
    ],
  },
];

// FIX BUG DAFTAR PRODUK LB-0123
// FIX BUG Pengecekan Ronda Muatparts LB-0243
// FIX BUG Pengecekan Ronda Muatparts LB-0307
const DaftarProdukPageResponsive = ({
  filterData,
  tabMenu,
  product,
  sort,
  orderby,
  ordermode,
  productMutate,
  isFirstTimerFilter,
  search,
  setSearch,
  setProductFilter,
  isDisabledFilter,
  setPageSize,
  totalProduct,
  loading,
}) => {
  // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0475
  const { setAppBar } = useHeader();
  const { setTitle, setIconList } = headerZustand();
  const {
    showToast,
    dataToast,
    setShowBottomsheet,
    setTitleBottomsheet,
    setDataBottomsheet,
    setShowNavMenu,
  } = toast();
  const { handleModal } = useContext(StateContext);
  const defaultFilterValue = useMemo(
    () =>
      filterData.reduce((obj, curr) => {
        if (curr.isMultiselect) {
          return { ...obj, [curr.key]: [] };
        }
        return { ...obj, [curr.key]: "" };
      }, {}),
    [filterData]
  );
  const [isOpenFilter, setIsOpenFilter] = useState(false);
  const [tabActive, setTabActive] = useState(null);
  const [filterValue, setFilterValue] = useState(defaultFilterValue);
  const isActiveFilter =
    JSON.stringify(defaultFilterValue) !== JSON.stringify(filterValue);

  // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0543
  const { menuZ } = menuZus();
  const productFilterData = filterData.reduce((arr, curr) => {
    // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0543
    if (curr.key === "status" && menuZ.value !== "Semua") {
      return arr;
    }
    return [...arr, curr];
  }, []);

  const handleClick = useCallback(() => {
    setTitleBottomsheet("Urutkan");
    setShowBottomsheet(true);
    setDataBottomsheet(
      <TemplateSortingResp
        sort={sort}
        orderby={orderby}
        ordermode={ordermode}
      />
    );
  }, [orderby, ordermode]);

  const handleReset = () => {
    sort(null);
    setShowBottomsheet(false);
  };

  useEffect(() => {
    // setShowNavMenu(true)
    setFilterValue(defaultFilterValue);
  }, [JSON.stringify(defaultFilterValue)]);

  useEffect(() => {
    // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0475
    setAppBar({
      renderActionButton: (
        <button
          className="flex flex-col gap-y-0.5 items-center z-[11]"
          onClick={handleClick}
        >
          {!orderby && !ordermode ? (
            <IconComponent
              classname="icon-white"
              size="medium"
              src="/icons/sorting.svg"
            />
          ) : (
            <div className="rounded-[20px] size-[24px] bg-neutral-50 flex items-center justify-center">
              <IconComponent classname="icon-red" src="/icons/sorting.svg" />
            </div>
          )}
          <span className="font-semibold text-[10px] leading-[10px] text-neutral-50">
            Urutkan
          </span>
        </button>
      ),
      title: "Daftar Produk",
      appBarType: "header_title",
    });
  }, [orderby, ordermode]);
  console.log("CAKRA : ", SortingResponsive);
  return (
    <>
      {/* <Bottomsheet label="Atur" withReset onClickReset={handleReset}/> */}
      {/* 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0542 */}
      <Bottomsheet
        withReset
        onClickReset={() => {
          sort({
            title: "",
            subtitle: "",
            val: null,
            key: null,
            type: "app",
          });
          setShowBottomsheet(false);
        }}
      />
      <Toast />
      <div className={`${style.mobile}`}>
        <HeaderResponsive
          data={product}
          isActiveFilter={isActiveFilter}
          setIsOpenFilter={setIsOpenFilter}
          menu={tabMenu}
          onTabActive={(a) => setTabActive(a)}
          // FIX BUG DAFTAR PRODUK LB-0123
          isFirstTimerFilter={isFirstTimerFilter}
          // FIX BUG Pengecekan Ronda Muatparts LB-0243
          // FIX BUG Pengecekan Ronda Muatparts LB-0307
          search={search}
          setSearch={setSearch}
          setProductFilter={setProductFilter}
          isDisabledFilter={isDisabledFilter}
          //25.03 LB 466
          totalProduct={totalProduct}
          loading={loading}
        />
        {/* LB - 0476, 25.03 */}
        {/* FIX BUG DAFTAR PRODUK LB-0123 */}
        {/* 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0902 */}
        {loading || product?.Data?.length > 0 ? (
          <CardProdukResponsive
            mutate={productMutate}
            tabActive={tabActive}
            showCheck={isOpenFilter}
            data={product}
            isFirstTimerFilter={isFirstTimerFilter}
            setPageSize={setPageSize}
            loading={loading}
          />
        ) : product?.Data?.length === 0 && !search ? (
          <BelumAdaProdukPage />
        ) : product?.Data?.length === 0 && search ? (
          <DataNotFound
            image={`/img/data-not-found.svg`}
            classname="h-screen"
            textClass=""
          >
            <p
              className={`w-[180px] text-center text-[16px] text-neutral-600 font-[600]`}
            >
              Keyword
              <br /> tidak ditemukan
            </p>
          </DataNotFound>
        ) : null}
      </div>
      {isOpenFilter ? (
        <FilterMobilePopup
          // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0543
          data={productFilterData}
          setIsOpen={setIsOpenFilter}
          setValue={setFilterValue}
          value={filterValue}
          // FIX BUG Pengecekan Ronda Muatparts LB-0243
          // FIX BUG Pengecekan Ronda Muatparts LB-0307
          setProductFilter={setProductFilter}
        />
      ) : null}
    </>
  );
};

export default DaftarProdukPageResponsive;

export const HeaderResponsive = ({
  data,
  setIsOpen,
  isActiveFilter,
  setIsOpenFilter,
  menu,
  loading,
  onTabActive = () => {},
  // FIX BUG DAFTAR PRODUK LB-0123
  isFirstTimerFilter,
  // FIX BUG Pengecekan Ronda Muatparts LB-0243
  // FIX BUG Pengecekan Ronda Muatparts LB-0307
  search,
  setSearch,
  setProductFilter,
  isDisabledFilter,
  totalProduct,
}) => {
  // 25 . 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0548
  const {tOrEmpty} = useTranslation()
  const { isActiveMassal, setIsActiveMassal, setIsAllChecked } =
    aturmasalProduk();
  const { menuZ, setMenuZ } = menuZus();
  const { langReady } = useTranslation();

  const [isTabActive, setTabActive] = useState(1);
  const onClickTab = (e) => {
    setMenuZ({ id: e.id, value: e.name });
    setTabActive(e.id);
  };

  // console.log(menuZ);

  const onClickSekaligus = () => {
    setIsActiveMassal(!isActiveMassal);
  };
  useEffect(() => {
    onTabActive(menu.find((a) => a.id == isTabActive));
  }, [isTabActive]);

  // FIX BUG Pengecekan Ronda Muatparts LB-0243
  // FIX BUG Pengecekan Ronda Muatparts LB-0307
  const handleSearch = (e) => {
    if (e.key === "Enter") {
      setProductFilter((prevState) => ({ ...prevState, search }));
    }
  };
  return (
    <div
      // FIX BUG DAFTAR PRODUK LB-0123
      className={`bg-neutral-50 fixed min-w-full mt-2.5 px-4 py-5 flex flex-col gap-y-4 z-[1]
      ${
        data?.length > 0 ? "shadow-md" : "border-b-[1px] border-b-neutral-400"
      }`}
    >
      {/* Search */}
      <div className={`w-[90vw]`}>
        {/* FIX BUG Pengecekan Ronda Muatparts LB-0243 */}
        {/* FIX BUG Pengecekan Ronda Muatparts LB-0307 */}
        <Input
          icon={{
            left: "/icons/search.svg",
            right: search ? (
              <span
                className="w-4 h-4 cursor-pointer"
                onClick={(e) => {
                  e.stopPropagation();
                  setSearch("");
                  setProductFilter((prevState) => ({
                    ...prevState,
                    search: "",
                  }));
                }}
              >
                <IconComponent src={"/icons/silang.svg"} />
              </span>
            ) : (
              ""
            ),
          }}
          placeholder="Cari nama produk/SKU"
          value={search}
          changeEvent={(e) => setSearch(e.target.value)}
          onKeyUp={handleSearch}
        />
      </div>
      {/* Filter & Tab */}
      <div className={`flex gap-[4px] relative`}>
        {/* FIX BUG Pengecekan Ronda Muatparts LB-0243 */}
        {/* FIX BUG Pengecekan Ronda Muatparts LB-0307 */}
        <Filter
          isActive={isActiveFilter}
          setIsOpen={setIsOpenFilter}
          disabled={
            (!data?.Data?.length || !Array.isArray(data?.Data) || !data) &&
            isDisabledFilter
          }
        />
        <div className={`flex gap-[4px] ${style.container_tab}`}>
          {/* FIX BUG Pengecekan Ronda Muatparts LB-0243 */}
          {/* FIX BUG Pengecekan Ronda Muatparts LB-0307 */}
          {menu
            .filter((item) => item.notif !== 0)
            .map((item, key) => {
              return (
                <Fragment key={key}>
                  {/* FIX BUG DAFTAR PRODUK LB-0123 */}
                  <Bubble
                    fill={item.id === isTabActive}
                    classname={`${
                      item.id === isTabActive
                        ? style.bubble_active
                        : style.bubble_inactive
                    } select-none !text-nowrap !w-100 cursor-pointer !h-[30px] font-medium text-[14px] leading-[15.4px]`}
                  >
                    <div
                      onClick={() =>
                        onClickTab({ id: item.id, name: item.name })
                      }
                    >
                      {/* FIX BUG Pengecekan Ronda Muatparts LB-0294 */}
                      {/* item.name butuh loading multibahasa, hidden dulu kalau belum ready */}
                      {langReady && `${tOrEmpty(item.name)} (${item.notif})`}
                    </div>
                  </Bubble>
                </Fragment>
              );
            })}
        </div>
      </div>
      {/* Ubah Massal */}
      {/* FIX BUG DAFTAR PRODUK LB-0123 */}
      {isFirstTimerFilter && data?.Data?.length === 0 ? null : (
        <div className={`flex justify-between items-center w-[90vw]`}>
          {isActiveMassal ? (
            <>
              <Checkbox
                onChange={(e) => {
                  setIsAllChecked(e.checked);
                }}
              >
                <div
                  className={`text-neutral-900 font-[500] text-[12px] leading-[13.2px]`}
                >
                  Pilih Semua
                </div>
              </Checkbox>
              <div
                className={`text-primary-700 font-[600] text-[14px] leading-[15.4px] cursor-pointer select-none`}
                onClick={onClickSekaligus}
              >
                Batalkan
              </div>
            </>
          ) : (
            <>
              {loading ? (
                <div className="animate-pulse rounded-md p-3 max-w-[36px] w-full h-1 flex flex-col gap-2 bg-slate-300" />
              ) : (
                <div
                  className={`text-neutral-900 font-medium text-[12px] leading-[13.2px]`}
                >
                  {`${totalProduct} Produk`}
                </div>
              )}
              <button
                className={`text-primary-700 font-semibold text-[14px] leading-[15.4px] select-none`}
                onClick={onClickSekaligus}
              >
                Atur Massal
              </button>
            </>
          )}
        </div>
      )}
    </div>
  );
};

export const TemplateSortingResp = ({ sort, orderby, ordermode }) => {
  const { setShowBottomsheet } = toast();

  return (
    <>
      <div className="flex flex-col gap-2">
        {SortingResponsive.map((key, idx) => {
          return (
            <div key={idx} className="flex flex-col gap-2">
              <span className="text-black font-semibold text-sm capitalize">
                {key.title}
              </span>
              {key.children.map((ky, ix) => {
                return (
                  <Fragment key={ix}>
                    <RadioButton
                      name="radioSorting"
                      value={ky.value}
                      label={ky.title}
                      checked={orderby === key.key && ordermode === ky.value}
                      onClick={() => {
                        sort({
                          title: key.title,
                          subtitle: ky.title,
                          val: key.key,
                          key: ky.value,
                          type: "app",
                        });
                        setShowBottomsheet(false);
                      }}
                      classnameLabel="text-black font-semibold text-sm capitalize"
                    />
                  </Fragment>
                );
              })}
              <hr className="!my-[10px]" />
            </div>
          );
        })}
      </div>
    </>
  );
};
