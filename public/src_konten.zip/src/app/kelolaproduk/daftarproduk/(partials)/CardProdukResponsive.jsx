"use client";

import { Fragment, useState, useEffect, useContext, useRef } from "react";
import style from "../DaftarProdukPage.module.scss";
import toast from "@/store/zustand/toast";
import { StateContext } from "@/common/StateContext";
import {
  EditStockModal,
  EditStockVariantModal,
  StatusProduct,
} from "./ListDataProduk";
import Button from "@/components/Button/Button";
import Input from "@/components/Input/Input";
import { ThousandSeparator } from "@/libs/NumberFormat";
import Checkbox from "@/components/Checkbox/Checkbox";
import aturmasalProduk from "@/store/zustand/produk/aturmasalProduk";
import NavSelectedMobile from "@/components/Bottomsheet/NavSelectedMobile";
import ImageComponent from "@/components/ImageComponent/ImageComponent";
import { useCustomRouter } from "@/libs/CustomRoute";
import ModalComponent from "@/components/Modals/ModalComponent";
import SWRHandler from "@/services/useSWRHook";
import ToastApp from "@/components/ToastApp/ToastApp";
import InfiniteScrollContainer from "@/container/InfiniteScrollContainer/InfiniteScrollContainer";
import { Loader2 } from "lucide-react";

const AturBottomsheet = [
  "lihat preview produk",
  "salin",
  "ubah",
  "bagikan",
  "aktif",
  "nonaktif",
  "hapus",
];

// FIX BUG DAFTAR PRODUK LB-0123
const CardProdukResponsive = ({
  data,
  isMassal,
  tabActive,
  mutate,
  isFirstTimerFilter,
  setPageSize = () => {},
  loading,
}) => {
  const [changeHarga, setChangeHarga] = useState();
  const router = useCustomRouter();
  const { handleModal } = useContext(StateContext);
  const {
    setShowBottomsheet,
    setDataBottomsheet,
    setShowNavMenu,
    setTitleBottomsheet,
  } = toast();
  const [dataMassal, setDataMassal] = useState([]);
  const [getModal, setModal] = useState("");
  const [showToastApp, setShowToastApp] = useState({
    show: false,
    text: "",
  });
  const [getAction, setAction] = useState("");
  const { isActiveMassal, setIsActiveMassal, setIsAllChecked, isAllChecked } =
    aturmasalProduk();
  const { useSWRMutateHook } = SWRHandler;
  const { trigger: trigger_bulk_action } = useSWRMutateHook(
    `${process.env.NEXT_PUBLIC_GLOBAL_API}v1/muatparts/product/bulkaction`,
    "PUT"
  );
  const prevTabIdRef = useRef(null);
  const isInitialMount = useRef(true);

  useEffect(() => {
    if (dataMassal.length > 0) {
      setShowNavMenu();
    } else {
      setShowNavMenu(true);
    }
  }, [dataMassal]);
  useEffect(() => {
    if (isAllChecked) setDataMassal(data?.Data);
    else setDataMassal([]);
  }, [isAllChecked, data?.Data]);
  useEffect(() => {
    if (!isActiveMassal) {
      setDataMassal([]);
      setIsAllChecked(false);
    }
  }, [isActiveMassal]);
  useEffect(() => {
    // tabActive terus terusan ke update, jadinya ini workaround biar gak reset state aturMasal
    const currentTabId = tabActive?.id;

    if (isInitialMount.current) {
      isInitialMount.current = false;
      prevTabIdRef.current = currentTabId;
      return;
    }

    if (currentTabId && currentTabId !== prevTabIdRef.current) {
      console.log("Tab changed from", prevTabIdRef.current, "to", currentTabId);
      prevTabIdRef.current = currentTabId;
      setDataMassal([]);
      setIsAllChecked(false);
      setIsActiveMassal(false);
    }
  }, [tabActive?.id]);

  const OptionsCard = (value) => {
    console.log(value, AturBottomsheet, " isi list bottomsheet");
    const ListOptions = AturBottomsheet.filter((ky) => {
      if (value.Status === "Non Aktif") return ky !== "nonaktif";
      else return ky !== value?.Status.toLowerCase();
    });
    setDataBottomsheet(
      <div className="flex flex-col gap-4 capitalize">
        {ListOptions?.map((item, idx) => {
          let last = idx + 1 !== ListOptions.length;
          return (
            <div
              key={idx + 1}
              className="flex flex-col gap-4 cursor-pointer"
              onClick={() => HandleAtur(item, value)}
            >
              <span
                className={`text-sm ${
                  !last ? "text-error-400" : "text-neutral-900"
                } font-semibold`}
              >
                {item}
              </span>
              {last && (
                <hr className="border-[0.5px] border-neutral-400 !m-0" />
              )}
            </div>
          );
        })}
      </div>
    );
    setShowBottomsheet(true);
  };

  const shareThroughApps = [
    {
      link: (productName) =>
        `https://wa.me/+6287765071995?text=https://www.muatmuat.com`,
      title: "Whatsapp",
      url: "/img/whatsapp.png",
    },
    {
      link: (productName) =>
        `https://t.me/share/url?url=https://www.muatmuat.com`,
      title: "Telegram",
      url: "/img/telegram.png",
    },
    {
      link: (productName) => `Bagikan produk ${productName}`,
      title: "Facebook",
      url: "/img/facebook.png",
    },
    {
      link: (productName) => `Bagikan produk ${productName}`,
      title: "Instagram",
      url: "/img/instagram.png",
    },
    {
      link: (productName) =>
        `https://twitter.com/intent/tweet?text=https://www.muatmuat.com`,
      title: "X",
      url: "/img/twitter.png",
    },
    {
      link: (productName) => `mailto:?body=https://www.muatmuat.com`,
      title: "Email",
      url: "/img/gmail.png",
    },
    {
      link: () => ``,
      onClick: async (e) => {
        // const text = "https://www.muatmuat.com";
        try {
          const res = await triggerShareProduct();
          // console.log(res);
          const text = res.data.Data.shortenedLink;
          e.preventDefault();
          if (navigator.clipboard) {
            navigator.clipboard.writeText(text);
          } else {
            const input = document.createElement("textarea");
            input.value = text;
            document.body.appendChild(input);
            input.select();
            document.execCommand("copy");
            document.body.removeChild(input);
          }
        } catch (err) {
          console.log(err);
        }
      },
      title: "Salin Tautan",
      url: "/img/copy-link.png",
    },
  ];

  const HandleAtur = (act, value) => {
    setShowBottomsheet(false);
    if (act == "aktif" || act == "nonaktif" || act == "hapus") {
      return handleModal({
        modalId: "konfirmasiproduk",
        withHeader: false,
        closeArea: false,
        hideCloseButton: true,
        props: { data: [act, value], type: "app", mutate: mutate },
      });
    } else if (act === "salin")
      router.push(
        `/kelolaproduk/tambahproduk?page=1&share=true&id=${value.ID}`
      );
    else if (act === "ubah")
      router.push(
        `/kelolaproduk/tambahproduk?page=1&share=true&id=${value.ID}&type=edit`
      );
    else if (act === "bagikan") {
      console.log(value);

      setShowBottomsheet(true);
      setTitleBottomsheet("Bagikan Produk");
      setDataBottomsheet(
        <div className="flex flex-col gap-y-6">
          <div className="border-[#c4c4c4] border-[1px] rounded-md p-3 flex flex-row gap-x-3">
            <img className="w-14 h-14" src={value?.Photo} alt={value?.Name} />
            <div className="flex flex-col gap-y-3">
              <span
                className={`font-bold text-black text-sm leading-[14.4px] line-clamp-2`}
              >
                {value?.Name}
              </span>
              <span className="font-medium text-black text-sm leading-[13px]">
                {`Brand : ${value?.Brand}`}
              </span>
              <span className="font-medium text-black text-sm leading-[13px]">
                {`Harga : ${[
                  `Rp ${
                    value?.MinPrice
                      ? value?.MinPrice.toLocaleString("id-ID")
                      : 0
                  }`,
                  `Rp ${
                    value?.MaxPrice
                      ? value?.MaxPrice.toLocaleString("id-ID")
                      : 0
                  }`,
                ].join(" - ")}`}
              </span>
            </div>
          </div>
          <span className="font-medium text-black text-sm leading-[13px] -mt-[10px] -mb-[10px]">
            Bagikan melalui
          </span>
          <div className="flex flex-wrap justify-center gap-x-6 gap-y-[30px]">
            {shareThroughApps.map((app, key) => {
              const href = app.link(value?.Name);
              if (href === "") {
                return (
                  <div
                    className="flex flex-col gap-y-2 items-center hover:no-underline cursor-pointer"
                    key={key}
                    onClick={app.onClick}
                  >
                    <div className="rounded-3xl p-1 border-[0.5px] border-[#c4c4c4]">
                      <ImageComponent
                        src={app.url}
                        alt={app.title}
                        width={28}
                        height={28}
                      />
                    </div>
                    <span className="font-medium text-black text-[10px] leading-[13px]">
                      {app.title}
                    </span>
                  </div>
                );
              }
              return (
                <a
                  href={href}
                  className="flex flex-col gap-y-2 items-center hover:no-underline w-[45px]"
                  key={key}
                  onClick={app.onClick}
                  rel="noreferrer"
                  target="_blank"
                >
                  <div className="rounded-3xl p-1 border-[0.5px] border-[#c4c4c4]">
                    <ImageComponent
                      src={app.url}
                      alt={app.title}
                      width={28}
                      height={28}
                    />
                  </div>
                  <span className="font-medium text-black text-[10px] leading-[13px]">
                    {app.title}
                  </span>
                </a>
              );
            })}
          </div>
        </div>
      );
    } else
      return router.push(
        `${process.env.NEXT_PUBLIC_BUYER_WEB}${value?.StoreName}/${value?.Name}`
      );
  };

  const UbahHarga = (item) => {
    setShowBottomsheet(true);
    //LB 467 25.03

    setTitleBottomsheet("Atur Harga");
    if (item.HaveVariant) {
      console.log("291");
      return setDataBottomsheet(
        <AturHargaVarian
          data={item}
          res={setChangeHarga}
          productMutate={mutate}
          onClose={() => setShowBottomsheet(false)}
        />
      );
    } else if (item.SalesType==='Grosir'){
      return setDataBottomsheet(
        <AturHargaGrosir 
          data={item} 
          res={setChangeHarga} 
          productMutate={mutate} 
          onClose={()=>{setShowBottomsheet(false)}}
        />
      )
    }
    console.log("298");
    return setDataBottomsheet(
      <AturHarga data={item} res={setChangeHarga} productMutate={mutate} />
    );
  };
  function UbahStock(params) {
    handleModal({
      // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0174
      props: {
        data: { Data: [params] },
        id: params?.ID,
        productMutate: mutate,
      },
    });
    setShowBottomsheet(true);
    setTitleBottomsheet("Atur Stok");
    setDataBottomsheet(<EditStockModal title={params.Name} />);
  }
  function UbahStockVarian(params, id, namaProduk) {
    handleModal({
      // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0174
      props: {
        data: { Data: params },
        id: id,
        product_name: namaProduk,
        productMutate: mutate,
      },
    });
    //LB 471 25.03
    setShowBottomsheet(true);
    setTitleBottomsheet("Atur Stok");
    setDataBottomsheet(<EditStockVariantModal />);
  }
  async function handleAction() {
    await trigger_bulk_action({
      items: dataMassal?.map((val) => val?.ID),
      action: getAction,
    });
    if (getAction === "active")
      setShowToastApp({
        show: true,
        text: `Berhasil Mengaktifkan ${dataMassal.length} Produk`,
      });
    if (getAction === "inactive")
      setShowToastApp({
        show: true,
        text: `Berhasil Menonaktifkan ${dataMassal.length} Produk`,
      });
    if (getAction === "delete")
      setShowToastApp({
        show: true,
        text: `Berhasil Menghapus ${dataMassal.length} Produk`,
      });
    setModal("");
    mutate(
      `${
        process.env.NEXT_PUBLIC_GLOBAL_API
      }v1/muatparts/product/lists?page=1&page_size=100${
        getAction !== "delete" && `&status[0]=${getAction}`
      }`,
      null,
      null,
      false
    );
  }
  const onChangeProduk = (data) => {
    if (data.checked) setDataMassal((prevItem) => [...prevItem, data.value]);
    else
      setDataMassal((prevItem) =>
        prevItem.filter((item) => item.ID !== data.value.ID)
      );
  };
  return (
    <>
      <ToastApp
        show={showToastApp.show}
        setShow={() => setShowToastApp({ text: "", show: false })}
        onClose={() => setShowToastApp({ text: "", show: false })}
        status="success"
        text={showToastApp.text}
        timer={3000}
      />
      <ModalComponent
        title="Atur"
        type="BottomSheet"
        full
        isOpen={getModal === "atur"}
        setClose={() => setModal("")}
      >
        <ul className="flex flex-col gap-4 w-full py-6 px-4">
          {/* {(tabActive?.name==='Semua Produk'||tabActive?.name==="Aktif"||tabActive?.name==="Nonaktif"||tabActive?.name==="Draft")&&<li><div className="pb-4 w-full border-b border-neutral-400 semi-sm">Ubah Informasi Produk</div></li>} */}
          {/* {(tabActive?.name==="Stok Habis"||tabActive?.name==='Semua Produk')&&<li><div className="pb-4 w-full border-b border-neutral-400 semi-sm">Salin</div></li>} */}
          {/* 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0548 */}
          {/* 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0269 */}
          {/* 25 . 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0548 */}
          {(tabActive?.name === "tabInactive" ||
            // tabActive?.name === "tabDraft" ||
            tabActive?.name === "tabOutStock" ||
            tabActive?.name === "WebKelolaPesananSellerMuatpartsSemua") && (
            <li>
              <div
                onClick={() => {
                  setModal("action_modal");
                  setAction("active");
                }}
                className="pb-4 w-full border-b border-neutral-400 semi-sm"
              >
                Aktifkan
              </div>
            </li>
          )}
          {(tabActive?.name === "tabActive" ||
            // tabActive?.name === "tabDraft" ||
            tabActive?.name === "tabOutStock" ||
            tabActive?.name === "WebKelolaPesananSellerMuatpartsSemua") && (
            <li>
              <div
                onClick={() => {
                  setModal("action_modal");
                  setAction("inactive");
                }}
                className="pb-4 w-full border-b border-neutral-400 semi-sm"
              >
                Nonaktifkan
              </div>
            </li>
          )}
          <li>
            <div
              onClick={() => {
                setModal("action_modal");
                setAction("delete");
              }}
              className="pb-4 w-full border-b border-neutral-400 semi-sm text-error-500"
            >
              Hapus Massal
            </div>
          </li>
        </ul>
      </ModalComponent>
      <ModalComponent
        full
        hideHeader
        isOpen={getModal === "action_modal"}
        setClose={() => setModal("")}
      >
        <div className="flex flex-col items-center gap-4 w-[280px] px-2 py-4">
          <span className="bold-base text-center">
            {getAction === "active"
              ? "Aktifkan"
              : getAction === "inactive"
              ? "Nonaktifkan"
              : getAction === "delete"
              ? "Hapus"
              : ""}{" "}
            {dataMassal?.length} Produk
          </span>
          <span className="medium-sm text-center">
            Apakah kamu yakin ingin{" "}
            {getAction === "active"
              ? "mengaktifkan"
              : getAction === "inactive"
              ? "menonaktifkan"
              : getAction === "delete"
              ? "menghapus"
              : ""}{" "}
            produk?
          </span>
          <div className="flex gap-2 mt-1">
            <Button
              Class="!h-8"
              color="primary_secondary"
              onClick={() => setModal("")}
            >
              Batal
            </Button>
            <Button Class="!h-8" onClick={handleAction}>
              Ya
            </Button>
          </div>
        </div>
      </ModalComponent>
      {dataMassal.length > 0 && (
        <NavSelectedMobile
          onclick={() => setModal("atur")}
          label={`Atur ${dataMassal.length} Produk Sekaligus`}
        />
      )}
      {/* FIX BUG DAFTAR PRODUK LB-0123 */}
      <div className={`flex flex-col gap-[8px] pt-[168px] pb-24`}>
        {/* 24. THP 2 - MOD001 - MP - 005 - QC Plan - Web - MuatParts - Paket 011 A - Seller - Daftar Produk - LB - 0195 */}
        <InfiniteScrollContainer
          currentPage={1}
          setPageChange={(a) => {
            if (a * 10 == Math.ceil(tabActive?.notif / 10) * 10 + 10) return;
            else setPageSize(a * 10);
          }}
        >
          {loading
            // Improvement fix wording pak Bryan
            ? [...Array(5)].map((_, index) => (
                <div
                  key={index}
                  className={`bg-neutral-50 py-[12px] px-[16px] flex flex-col gap-y-3 relative`}
                >
                  <div className="absolute top-2 right-1">
                    <div className="animate-pulse rounded-md w-6 h-6 bg-slate-300" />
                  </div>
                  <div className={`flex gap-[12px]`}>
                    <div className="size-full max-w-[68px] max-h-[68px]">
                      <div className="animate-pulse rounded-md w-[68px] h-[68px] bg-slate-300" />
                    </div>
                    <div className={`flex flex-col gap-y-3 w-full`}>
                      <div className="animate-pulse rounded-md h-5 w-3/4 bg-slate-300" />
                      <div className="animate-pulse rounded-md h-4 w-1/3 bg-slate-300" />
                      <div className="animate-pulse rounded-md h-4 w-1/4 bg-slate-300" />
                      <div className="flex gap-x-2">
                        <div className="animate-pulse rounded-md h-6 w-[86px] bg-slate-300" />
                        <div className="animate-pulse rounded-md h-6 w-[86px] bg-slate-300" />
                      </div>
                    </div>
                  </div>
                  <div className={`flex gap-x-2 items-center w-full`}>
                    <div className="animate-pulse rounded-md h-7 w-full bg-slate-300" />
                    <div className="animate-pulse rounded-md h-7 w-full bg-slate-300" />
                  </div>
                </div>
              ))
            : data?.Data?.length > 0
            ? data.Data.map((item, index) => {
                return (
                  <div
                    key={index}
                    className={`bg-neutral-50 py-[12px] px-[16px] flex flex-col gap-y-3 relative`}
                  >
                    {/* FIX BUG DAFTAR PRODUK LB-0123 */}
                    <div className="absolute top-2 right-1">
                      <ImageComponent
                        src={`/img/icon-product-mobile-3dots.svg`}
                        className={`cursor-pointer`}
                        onClick={() => OptionsCard(item)}
                        width={24}
                        height={24}
                        alt="icon-3dots-product"
                      />
                    </div>
                    <div className={`flex gap-[12px]`}>
                      {isActiveMassal && (
                        <div>
                          <Checkbox
                            label=""
                            onChange={onChangeProduk}
                            value={item}
                            checked={dataMassal.some((a) => a?.ID === item?.ID)}
                          />
                        </div>
                      )}
                      <div className="size-full max-w-[68px] max-h-[68px]">
                        <ImageComponent
                          src={item?.Photo}
                          width={68}
                          height={68}
                          className={`rounded`}
                          alt="product-image"
                        />
                      </div>
                      <div className={`flex flex-col gap-y-3 w-full`}>
                        {/* 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0582 */}
                        <h1
                          className={`${style.title_product_mobile} line-clamp-2 mr-4`}
                        >
                          {item.Name}
                        </h1>
                        <p className={`${style.price_product_mobile}`}>
                          {item.PriceLabel}
                        </p>
                        <p className={`${style.stock_product_mobile}`}>
                          {`Stok : ${item.Stock}`}
                        </p>
                        <div className={`flex gap-x-2 items-center`}>
                          <StatusProduct
                            status={item.Status}
                            classname={`!h-6 max-h-full w-[86px] !p-0 flex items-center justify-center text-[14px] leading-[15.4px]`}
                          />
                          {item.HaveVariant && (
                            <StatusProduct
                              classname={`w-[86px] !h-6 max-h-full !p-0 flex items-center justify-center text-[14px] leading-[15.4px]`}
                              status="Varian"
                            />
                          )}
                        </div>
                      </div>
                    </div>
                    {/* FIX BUG DAFTAR PRODUK LB-0123 */}
                    {/* 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0272 */}
                    {!isActiveMassal && (
                      <div className={`flex gap-x-2 items-center w-full`}>
                        <Button
                          color="primary_secondary"
                          // FIX BUG DAFTAR PRODUK LB-0123
                          Class={`max-w-full w-full h-7 flex items-center justify-center`}
                          onClick={() => UbahHarga(item)}
                        >
                          Ubah Harga
                        </Button>
                        <Button
                          color="primary_secondary"
                          // FIX BUG DAFTAR PRODUK LB-0123
                          Class={`max-w-full w-full h-7 flex items-center justify-center`}
                          onClick={() => {
                            if (!item.HaveVariant) UbahStock(item);
                            else
                              UbahStockVarian(
                                data?.Data,
                                item?.ID,
                                item?.product_name
                              );
                          }}
                        >
                          Ubah Stok
                        </Button>
                      </div>
                    )}
                  </div>
                );
              })
            : null}
        </InfiniteScrollContainer>
      </div>
    </>
  );
};

export default CardProdukResponsive;

export const AturHarga = ({ data, res, productMutate }) => {
  const [harga, setHarga] = useState(data.end_sell_price);
  const [isError, setIsError] = useState({
    status: "",
    message: "",
  });
  const { setShowBottomsheet, setShowToast, setDataToast } = toast();
  const { useSWRMutateHook } = SWRHandler;
  const {
    data: bulk,
    error: bulk_error,
    trigger: bulk_trigger,
    isMutating,
  } = useSWRMutateHook(
    process.env.NEXT_PUBLIC_GLOBAL_API +
      `v1/muatparts/product/price/${data.ID}`,
    "PUT"
  );
  const SaveUbahHarga = () => {
    if (!harga)
      return setIsError({
        status: "error",
        message: "Harga jual wajib diisi",
      });
    if (harga == 0)
      return setIsError({
        status: "error",
        message: "Harga jual yang diisi minimal 99",
      });
    bulk_trigger({ price: harga }).then(() => {
      setShowBottomsheet(false);
      setShowToast(true);
      setDataToast({
        type: "success",
        message: "Berhasil memperbarui harga",
      });
      productMutate(
        `${process.env.NEXT_PUBLIC_GLOBAL_API}v1/muatparts/product/lists?page_size=10&page=1`,
        null,
        null,
        false
      );
    });

    return res(harga, data);
  };
  console.log("517", data);
  //25.03 468
  const priceValueBottomSheet = parseInt(
    data.PriceLabel.replace(/[^\d]/g, ""),
    10
  );

  console.log("wasup2", harga);
  return (
    <div className="flex flex-col gap-3">
      <span className="text-sm text-neutral-900 font-semibold truncate w-full">
        {data.Name}
      </span>
      {/* LB - 0469, 25.03 */}
      <Input
        status={isError.status}
        supportiveText={{ title: isError.message }}
        type="text"
        placeholder="Masukkan Harga Produk"
        classname={style.inputBerat}
        text={{ left: "Rp" }}
        value={
          harga
            ? ThousandSeparator(harga)
            : data.MaxPrice
            ? ThousandSeparator(data.MaxPrice)
            : ""
        }
        changeEvent={(e) =>
          setHarga(parseInt(e.target.value.replaceAll(/\./g, ""), 10))
        }
      />
      <Button Class="min-w-full" onClick={() => SaveUbahHarga()}>
        Simpan
      </Button>
    </div>
  );
};
// 25. 11 - QC Plan - Web - Ronda Live Mei - LB - 0105
export const AturHargaGrosir = ({data, productMutate, onClose}) => {
  const { setShowBottomsheet, setShowToast, setDataToast } = toast();
  const [isMassal, setIsMassal] = useState(false);
  const [hargaMassal, setHargaMassal] = useState(0);
  const [isError, setIsError] = useState({
    status: "",
    message: "",
  });

  const { useSWRMutateHook } = SWRHandler;
  const {
    data: bulk,
    error: bulk_error,
    trigger: bulk_trigger,
    isMutating,
  } = useSWRMutateHook(
    process.env.NEXT_PUBLIC_GLOBAL_API +
      `v1/muatparts/product/price/wholesales/${data.ID}`,
    "PUT"
  );

  // state for data varian
  const [dataVarian, setDataVarian] = useState(data.wholesales.map((key) => key));
  const [dataVarianError, setDataVarianError] = useState(
    data.wholesales.map(() => {
      return { res: false, message: "" };
    })
  );
  const ValidateHarga = () => {
    if (isMassal) {
      if (!hargaMassal)
        return setIsError({
          status: "error",
          message: "Harga jual wajib diisi",
        });
      if (hargaMassal == 0)
        return setIsError({
          status: "error",
          message: "Harga jual yang diisi minimal 99",
        });

      setShowBottomsheet(false);
      setShowToast(true);
      setDataToast({
        type: "success",
        message: "Berhasil memperbarui harga",
      });

      return bulk_trigger({ price: hargaMassal }).then(() => {
        setShowToast(true);
        setDataToast({
          type: "success",
          message: "Berhasil memperbarui harga",
        });
        productMutate(
          `${process.env.NEXT_PUBLIC_GLOBAL_API}v1/muatparts/product/lists?page_size=10&page=1`,
          null,
          null,
          false
        );
        onClose?.();
      });
    } else {
      const errors = dataVarian.map((key) => {
        let error = { res: false, message: "" };
        if (key.price < 99 || key.price > 999999999) {
          error = {
            res: true,
            message: "Masukkan harga Rp99 s/d Rp999.999.999",
          };
        }
        if (isNaN(key.price) || !key.price) {
          error = { res: true, message: "Harga jual wajib diisi" };
        }

        return error;
      });
      setDataVarianError(errors);
      // console.log(dataVarian)
      return bulk_trigger({ data: dataVarian }).then(() => {
        setShowToast(true);
        setDataToast({
          type: "success",
          message: "Berhasil memperbarui harga",
        });
        productMutate(
          `${process.env.NEXT_PUBLIC_GLOBAL_API}v1/muatparts/product/lists?page_size=10&page=1`,
          null,
          null,
          false
        );
        onClose?.();
      });
    }
  };
  return (
    <div className="flex flex-col gap-3">
      <span className="text-sm text-neutral-900 font-semibold w-full border-b border-neutral-300 pb-2">
        {data.Name}
      </span>
      <div className="flex flex-col gap-4 overflow-auto h-fit max-h-[250px]">
        {dataVarian.map((key, idx) => {
            return (
              <Fragment key={idx}>
                {/* {idx === 0 && <hr />} */}
                <div
                  key={idx}
                  className="flex justify-between items-center w-full flex-wrap"
                >
                  <div className="flex flex-col w-[50%] break-words">
                    <span className="text-sm text-neutral-900 font-semibold w-full">
                      {key.minPurchase} - {key.maxPurchase===0?"Tidak Terbatas":key.maxPurchase}
                    </span>
                    {/* <span className="text-sm text-neutral-700 font-medium w-full">
                      SKU : {key.sku}
                    </span> */}
                  </div>
                  <Input
                    status={dataVarianError[idx]["res"] && "error"}
                    supportiveText={{ title: dataVarianError[idx]["message"] }}
                    type="text"
                    placeholder="Harga Jual"
                    classname={`${style.inputBerat} !w-[50%]`}
                    text={{ left: "Rp" }}
                    value={
                      ThousandSeparator(dataVarian[idx]["price"])
                        ? ThousandSeparator(dataVarian[idx]["price"])
                        : ""
                    }
                    changeEvent={(e) => {
                      setDataVarian(() => {
                        const dataVarianClone = [...dataVarian];
                        dataVarianClone[idx]["price"] = e.target.value
                          ? parseInt(e.target.value.replaceAll(/\./g, ""), 10)
                          : 0;
                        return dataVarianClone;
                      });
                    }}
                  />
                </div>
              </Fragment>
            );
          })}
      </div>
      <Button disabled={isMutating} Class="min-w-full" onClick={() => ValidateHarga()}>
        {isMutating?<Loader2 className="size-4 animate-spin text-neutral-500"/>:"Simpan"}
      </Button>
    </div>
  );
}

export const AturHargaVarian = ({ data, productMutate, onClose }) => {
  const { setShowBottomsheet, setShowToast, setDataToast } = toast();
  const [isMassal, setIsMassal] = useState(false);
  const [hargaMassal, setHargaMassal] = useState(0);
  const [isError, setIsError] = useState({
    status: "",
    message: "",
  });

  const { useSWRMutateHook } = SWRHandler;
  const {
    data: bulk,
    error: bulk_error,
    trigger: bulk_trigger,
    isMutating,
  } = useSWRMutateHook(
    process.env.NEXT_PUBLIC_GLOBAL_API +
      `v1/muatparts/product/price/variants/${data.ID}?isMassal=${isMassal}`,
    "PUT"
  );

  // state for data varian
  const [dataVarian, setDataVarian] = useState(data.variant.map((key) => key));
  const [dataVarianError, setDataVarianError] = useState(
    data.variant.map(() => {
      return { res: false, message: "" };
    })
  );
  const ValidateHarga = () => {
    if (isMassal) {
      if (!hargaMassal)
        return setIsError({
          status: "error",
          message: "Harga jual wajib diisi",
        });
      if (hargaMassal == 0)
        return setIsError({
          status: "error",
          message: "Harga jual yang diisi minimal 99",
        });

      setShowBottomsheet(false);
      setShowToast(true);
      setDataToast({
        type: "success",
        message: "Berhasil memperbarui harga",
      });

      return bulk_trigger({ price: hargaMassal }).then(() => {
        setShowToast(true);
        setDataToast({
          type: "success",
          message: "Berhasil memperbarui harga",
        });
        productMutate(
          `${process.env.NEXT_PUBLIC_GLOBAL_API}v1/muatparts/product/lists?page_size=10&page=1`,
          null,
          null,
          false
        );
        onClose?.();
      });
    } else {
      const errors = dataVarian.map((key) => {
        let error = { res: false, message: "" };
        if (key.price < 99 || key.price > 999999999) {
          error = {
            res: true,
            message: "Masukkan harga Rp99 s/d Rp999.999.999",
          };
        }
        if (isNaN(key.price) || !key.price) {
          error = { res: true, message: "Harga jual wajib diisi" };
        }

        return error;
      });
      setDataVarianError(errors);
      return bulk_trigger({ data: dataVarian }).then(() => {
        setShowToast(true);
        setDataToast({
          type: "success",
          message: "Berhasil memperbarui harga",
        });
        productMutate(
          `${process.env.NEXT_PUBLIC_GLOBAL_API}v1/muatparts/product/lists?page_size=10&page=1`,
          null,
          null,
          false
        );
        onClose?.();
      });
    }
  };

  useEffect(() => {
    // if (dataVarianError.every((key) => key.res === false)) {
    //   setShowBottomsheet(false);
    //   setShowToast(true);
    //   setDataToast({
    //     type: "success",
    //     message: "Berhasil memperbarui harga",
    //   });
    //   return res(dataVarian);
    // }
  }, [dataVarianError]);

  // useEffect(() => {
  //   (dataVarian, dataVarianError, " datavarian");
  // }, [dataVarian, dataVarianError]);
  //25.03 468
  console.log("wasup1", hargaMassal);
  return (
    <div className="flex flex-col gap-3">
      <span className="text-sm text-neutral-900 font-semibold w-full">
        {data.Name}
      </span>
      <div>
        <Checkbox
          label="Ubah Harga Secara Massal"
          onChange={() => {
            setHargaMassal(0);
            setIsMassal(!isMassal);
          }}
        />
      </div>
      {isMassal && (
        <>
          <Input
            status={isError.status}
            supportiveText={{ title: isError.message }}
            type="text"
            placeholder="Masukkan Berat Produk"
            classname={style.inputBerat}
            text={{ left: "Rp" }}
            value={hargaMassal ? ThousandSeparator(hargaMassal) : ""}
            changeEvent={(e) => {
              if (e.target.value)
                setHargaMassal(
                  parseInt(e.target.value.replaceAll(/\./g, ""), 10)
                );
              else setHargaMassal(0);
            }}
          />
          <span className="text-xs text-neutral-700 font-medium w-full">
            Catatan : Perubahan akan diterapkan untuk semua varian
          </span>
        </>
      )}
      <div className="flex flex-col gap-4 overflow-auto h-fit max-h-[350px]">
        {!isMassal &&
          dataVarian.map((key, idx) => {
            return (
              <Fragment key={idx}>
                {idx === 0 && <hr />}
                <div
                  key={idx}
                  className="flex justify-between items-center w-full flex-wrap"
                >
                  <div className="flex flex-col w-[50%] break-words">
                    <span className="text-sm text-neutral-900 font-semibold w-full">
                      {key.type}
                    </span>
                    <span className="text-sm text-neutral-700 font-medium w-full">
                      SKU : {key.sku}
                    </span>
                  </div>
                  <Input
                    status={dataVarianError[idx]["res"] && "error"}
                    supportiveText={{ title: dataVarianError[idx]["message"] }}
                    type="text"
                    placeholder="Harga Jual"
                    classname={`${style.inputBerat} !w-[50%]`}
                    text={{ left: "Rp" }}
                    value={
                      ThousandSeparator(dataVarian[idx]["price"])
                        ? ThousandSeparator(dataVarian[idx]["price"])
                        : ""
                    }
                    changeEvent={(e) => {
                      setDataVarian(() => {
                        const dataVarianClone = [...dataVarian];
                        dataVarianClone[idx]["price"] = e.target.value
                          ? parseInt(e.target.value.replaceAll(/\./g, ""), 10)
                          : 0;
                        return dataVarianClone;
                      });
                    }}
                  />
                </div>
              </Fragment>
            );
          })}
      </div>
      <Button Class="min-w-full" onClick={() => ValidateHarga()}>
        Simpan
      </Button>
    </div>
  );
};
