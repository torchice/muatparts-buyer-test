"use client";

import { useState, useEffect, useContext, useMemo, useRef } from "react";
import TableComponent from "@/components/TableComponent/TableComponent";
import Tooltip from "@/components/Tooltip/Tooltip";
import { StateContext } from "@/common/StateContext";
import Input from "@/components/Input/Input";
import IconComponent from "@/components/IconComponent/IconComponent";
import Button from "@/components/Button/Button";
import ListDataProduk from "./ListDataProduk";
import AturMasal from "@/store/zustand/produk/aturmasalProduk";
import toast from "@/store/zustand/toast";
import DataNotFound from "@/components/DataNotFound/DataNotFound";
import SWRHandler from "@/services/useSWRHook";
import { useForm } from "react-hook-form";
import Filter from "@/components/Filter/Filter";
import { filterType } from "../page";
import { useTranslation } from "@/context/TranslationProvider";

export const AktifkanProdukModal = () => {
  const { t } = useTranslation();

  const tableHeader = [
    { title: t(`columnImage`), val: "" },
    { title: t(`columnName`), val: "name" },
    { title: t(`columnCategory`), val: "category" },
    { title: t(`columnStock`), val: "stock" },
    { title: t(`columnPrice`), val: "price" },
    // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0417
    { title: t(`columnSold`), val: "sold" },
    { title: t(`columnStatus`), val: "" },
  ];
  const { handleModal, props, closeModal } = useContext(StateContext);
  const isActiveOrInactive =
    props.type[0].name === "Aktifkan" || props.type[0].name === "Nonaktifkan";
  const modalFilterData = props.filterData.reduce((arr, curr) => {
    if (
      (!isActiveOrInactive && curr.key === "status") ||
      curr.key !== "status"
    ) {
      return [...arr, curr];
    }
    return arr;
  }, []);
  const tableRef = useRef();
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [orderby, setOrderby] = useState("");
  const [ordermode, setOrdermode] = useState("");
  const [productFilter, setProductFilter] = useState({});
  const additionalParam = useMemo(() => {
    const statusParamObj = { Aktifkan: "Inactive", Nonaktifkan: "Active" };
    const newParams = [];
    if (productFilter?.search) {
      newParams.push(`keyword=${productFilter.search}`);
    }
    if (
      props.type[0].name === "Aktifkan" ||
      props.type[0].name === "Nonaktifkan"
    ) {
      newParams.push(`status[0]=${statusParamObj[props.type[0].name]}`);
    } else if (productFilter?.status) {
      newParams.push(`status[0]=${productFilter.status}`);
    }
    if (productFilter?.category?.length > 0) {
      productFilter.category.forEach((item, key) =>
        newParams.push(`category[${key}]=${JSON.stringify(item)}`)
      );
    }
    if (productFilter?.brand?.length > 0) {
      productFilter.brand.forEach((item, key) =>
        newParams.push(`brand[${key}]=${item}`)
      );
    }
    if (productFilter?.condition) {
      newParams.push(`condition[0]=${productFilter.condition}`);
    }
    if (productFilter?.type) {
      newParams.push(`type=${productFilter.type}`);
    }
    if (orderby && ordermode) {
      newParams.push(`orderby=${orderby}`);
      newParams.push(`ordermode=${ordermode}`);
    }
    if (newParams.length === 0) {
      return "";
    }
    return `&${newParams.join("&")}`;
  }, [props?.type[0]?.name, productFilter, orderby, ordermode]);
  const { useSWRHook } = SWRHandler;
  const {
    data,
    mutate,
    isLoading: loading,
  } = useSWRHook(
    `${
      process.env.NEXT_PUBLIC_GLOBAL_API
    }v1/muatparts/product/lists?page_size=20&page=1&${
      additionalParam ? additionalParam : null
    }`
  );

  const [selected, setSelected] = useState([]);
  const [checked, setChecked] = useState([]);

  const { control, getValues, handleSubmit, setValue, watch } = useForm();
  const filterValue = watch();

  const { setListProduk } = AturMasal();
  const action =
    props?.type[0]?.name?.toLowerCase() == "aktifkan"
      ? "mengaktifkan"
      : props?.type[0]?.name?.toLowerCase() == "nonaktifkan"
      ? "menonaktifkan"
      : props?.type[0]?.name?.toLowerCase().includes("ubah")
      ? "ubah informasi produk"
      : "menghapus";

  const getDataSort = (e) => {
    const filtered = tableHeader?.find((key) => key?.title === e?.id);
    if (!filtered) {
      setOrderby("");
      setOrdermode("");
      return;
    }
    setOrderby(filtered.val);
    setOrdermode(e.sortBy);
  };

  const handleSearch = (e) => {
    if (e.key === "Enter") {
      setProductFilter((prevState) => ({ ...prevState, search }));
      tableRef.current.scrollTop = 0;
    }
  };

  const handleSelectFilter = ({ checked }, type, value) => {
    setProductFilter((prevState) => {
      const typeProperty = Object.entries(filterType).find(
        ([key, value]) => value === type
      )[0];
      const defaultValue =
        typeProperty === "category" || typeProperty === "brand" ? [] : "";
      let filterValue = prevState[typeProperty] || defaultValue;
      if (
        checked &&
        (typeProperty === "category" || typeProperty === "brand")
      ) {
        filterValue = [...filterValue, value];
      } else if (checked) {
        filterValue = value;
      } else if (typeProperty === "category" || typeProperty === "brand") {
        filterValue = filterValue.filter(
          (item) => JSON.stringify(item) !== JSON.stringify(value)
        );
      } else {
        filterValue = "";
      }
      return {
        ...prevState,
        [typeProperty]: filterValue,
      };
    });
  };

  useEffect(() => {
    setListProduk([]);
  }, []);

  const selectedFilters = Object.entries(filterValue).reduce(
    (arr, [key, value]) => {
      if (value?.checked) {
        const [type] = key.split("-");
        const currentType = modalFilterData.find((item) => item.type === type);
        const option = currentType.options.find(
          (option) => option.name === key
        );
        return [...arr, option];
      }
      return arr;
    },
    []
  );

  return (
    <>
      <div className="flex flex-col gap-4 items-center justify-center p-5 text-neutral-900 relative">
        <IconComponent
          size="medium"
          classname="absolute right-2 top-2 cursor-pointer"
          color="primary"
          src="/icons/silang.svg"
          onclick={() => closeModal()}
        />
        <span className="capitalize font-bold text-base -mt-8">
          {props?.type[0]?.name}{" "}
          {!props?.type[0]?.name.toLowerCase().includes("hapus") &&
            !props?.type[0]?.name.toLowerCase().includes("informasi") &&
            "Produk"}
        </span>
        <div className="w-[1064px] p-3 border rounded-md flex flex-col gap-5">
          <div className="flex flex-row gap-x-3">
            <Input
              placeholder="Cari Nama Produk/SKU"
              classname="w-[262px] pl-[1]"
              icon={{
                left: (
                  <span className="w-4 h-4">
                    <IconComponent src={"/icons/search.svg"} />
                  </span>
                ),
                right: search ? (
                  <span
                    className="w-4 h-4 cursor-pointer"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSearch("");
                      setProductFilter((prevState) => ({
                        ...prevState,
                        search: "",
                      }));
                      tableRef.current.scrollTop = 0;
                    }}
                  >
                    <IconComponent src={"/icons/silang.svg"} />
                  </span>
                ) : (
                  ""
                ),
              }}
              value={search}
              changeEvent={(e) => setSearch(e.target.value)}
              onKeyUp={handleSearch}
            />
            <Filter
              data={modalFilterData}
              control={control}
              getValues={getValues}
              isActive={selectedFilters.length > 0}
              isOpen={isOpen}
              onSelect={handleSelectFilter}
              setIsOpen={setIsOpen}
              setValue={setValue}
              watch={watch}
            />
          </div>
          {/* tabel */}
          <div className="max-h-[248px] overflow-y-scroll" ref={tableRef}>
            <TableComponent
              checkboxField={["Gambar"]}
              colums={tableHeader.map((key) => key.title)}
              withSortColumn
              onChangeChecked={(e) => {
                if (e?.checked) {
                  setSelected(data?.Data);
                  setChecked(Array(data?.Data?.length).fill(true));
                } else {
                  setSelected([]);
                  setChecked(Array(data?.Data?.length).fill(false));
                }
              }}
              onChangeSort={getDataSort}
            >
              {loading ? (
                // Improvement fix wording pak Bryan
                [...Array(5)].map((_, index) => (
                  <tr key={index} className="align-top">
                    <td className="flex gap-2 p-3">
                      <div className="animate-pulse rounded-md w-6 h-6 bg-slate-300" />
                      <div className="animate-pulse rounded-md w-14 h-14 bg-slate-300" />
                    </td>
                    <td className="p-3">
                      <div className="flex flex-col gap-3">
                        <div className="animate-pulse rounded-md h-5 w-3/4 bg-slate-300" />
                        <div className="animate-pulse rounded-md h-4 w-1/2 bg-slate-300" />
                        <div className="animate-pulse rounded-md h-4 w-1/3 bg-slate-300" />
                      </div>
                    </td>
                    <td className="p-3">
                      <div className="animate-pulse rounded-md h-4 w-2/3 bg-slate-300" />
                    </td>
                    <td className="p-3">
                      <div className="animate-pulse rounded-md h-4 w-1/4 bg-slate-300" />
                    </td>
                    <td className="p-3">
                      <div className="animate-pulse rounded-md h-4 w-1/3 bg-slate-300" />
                    </td>
                    <td className="p-3">
                      <div className="animate-pulse rounded-md h-4 w-1/4 bg-slate-300" />
                    </td>
                    <td className="p-3">
                      <div className="animate-pulse rounded-md h-6 w-20 bg-slate-300" />
                    </td>
                  </tr>
                ))
              ) : data?.Data.length > 0 ? (
                <ListDataProduk
                  data={data}
                  selected={selected}
                  setSelected={setSelected}
                  allChecked={checked?.some((val) => val) || false}
                  isCheckbox={true}
                  onModal={props.type}
                  productMutate={mutate}
                />
              ) : null}
            </TableComponent>
          </div>
          {data?.Data.length == 0 && (
            <DataNotFound
              title="Keyword tidak ditemukan"
              image={`/img/data-not-found.svg`}
              classname={`my-[20px]`}
            />
          )}
        </div>
        <div className="flex justify-between w-full items-center">
          <span className="capitalize font-bold text-xs">
            Terpilih : {selected.length} produk
          </span>
          {selected.length > 0 ? (
            <>
              <Button
                onClick={() => {
                  setListProduk(selected);
                  handleModal({
                    modalId: "konfirmasiproduk",
                    withHeader: true,
                    closeArea: false,
                    hideCloseButton: false,
                    props: {
                      data: selected,
                      type: props.type,
                      additionalParam,
                      productMutate: props?.productMutate,
                    },
                  });
                }}
                Class="!font-semibold"
                color={
                  props?.type[0]?.name?.includes("aktif")
                    ? "primary"
                    : props?.type[0]?.name?.includes("nonaktif")
                    ? "error"
                    : props?.type[0]?.name?.includes("ubah")
                    ? "primary"
                    : "error"
                }
              >
                {props.type[0].name}
              </Button>
            </>
          ) : (
            <Tooltip
              classname="!-ml-4 text-center"
              text={`Pilih minimal 1 produk untuk ${action} produk`}
              position="top"
            >
              <Button Class="!font-semibold" color="primary" disabled={true}>
                {props.type[0].name}
              </Button>
            </Tooltip>
          )}
        </div>
      </div>
    </>
  );
};

export const KonfirmasiProdukModal = () => {
  const { props, closeModal } = useContext(StateContext);
  const { listProduk, setListProduk } = AturMasal();
  const { setShowToast, setDataToast } = toast();
  const { useSWRMutateHook, useSWRHook } = SWRHandler;
  const { mutate: mutateProductAktifkan } = useSWRHook(
    `${
      process.env.NEXT_PUBLIC_GLOBAL_API
    }v1/muatparts/product/lists?page_size=20&page=1&${
      props?.additionalParam ? props?.additionalParam : null
    }`
  );
  const { trigger: trigger_bulk_action } = useSWRMutateHook(
    `${process.env.NEXT_PUBLIC_GLOBAL_API}v1/muatparts/product/bulkaction`,
    "PUT"
  );
  const action =
    props?.type[0]?.name?.toLowerCase() == "aktifkan"
      ? "mengaktifkan"
      : props?.type[0]?.name?.toLowerCase() == "nonaktifkan"
      ? "menonaktifkan"
      : props?.type[0]?.name?.toLowerCase().includes("ubah")
      ? "ubah informasi produk"
      : "menghapus";

  const reset = () => {
    closeModal();
  };

  //LB - 0274, 25.03
  async function handleAction(params) {
    let actionType;
    let itemsToProcess = [];

    if (params?.data && Array.isArray(params.data) && params.data.length > 0) {
      if (params.data[0] === "hapus") actionType = "hapus";
      else if (params.data[0] === "nonaktif") actionType = "nonaktif";
      else if (params.data[0] === "aktif") actionType = "aktif";

      if (params.data[1] && params.data[1].ID) {
        itemsToProcess = [params.data[1].ID];
      } else {
        itemsToProcess = listProduk?.map((val) => val?.ID) || [];
      }
    } else if (typeof params === "string") {
      if (params === "hapus") actionType = "hapus";
      else if (params === "nonaktif") actionType = "nonaktif";
      else if (params === "aktif") actionType = "aktif";

      itemsToProcess = listProduk?.map((val) => val?.ID) || [];
    } else if (params?.type && params?.type[0]?.value) {
      actionType = params.type[0].value;
      itemsToProcess = listProduk?.map((val) => val?.ID) || [];
    }

    const actionApiMap = {
      hapus: "delete",
      nonaktif: "inactive",
      aktif: "active",
    };

    if (itemsToProcess.length > 0 && actionType && actionApiMap[actionType]) {
      try {
        await trigger_bulk_action({
          items: itemsToProcess,
          action: actionApiMap[actionType],
        });

        const actionVerb = {
          hapus: "menghapus",
          nonaktif: "menonaktifkan",
          aktif: "mengaktifkan",
        };

        const successMessage = `Berhasil ${actionVerb[actionType]} ${
          itemsToProcess.length > 1
            ? `${itemsToProcess.length} produk`
            : "produk"
        }`;

        setDataToast({
          type: "success",
          message: successMessage,
        });

        if (props?.productMutate) {
          await props.productMutate();
        }

        if (mutateProductAktifkan) {
          await mutateProductAktifkan();
        }

        if (props?.mutate) {
          await props.mutate();
        }

        setShowToast(true);
        reset();
      } catch (error) {
        console.error("Error saat melakukan bulk action:", error);
        setDataToast({
          type: "error",
          message: `Gagal ${
            actionType === "hapus"
              ? "menghapus"
              : actionType === "nonaktif"
              ? "menonaktifkan"
              : "mengaktifkan"
          } produk. Silakan coba lagi.`,
        });
        setShowToast(true);
      }
    } else {
      console.error(
        "Tidak dapat menentukan jenis aksi atau tidak ada item yang dipilih"
      );
    }
  }

  return props?.type == "app" ? (
    <div className="flex flex-col items-center justify-center gap-3 py-6 px-8 w-[296px] relative">
      <div className="absolute top-3 right-3">
        <IconComponent
          src="/icons/closes.svg"
          color="primary"
          onclick={() => closeModal()}
        />
      </div>
      <span className="font-bold text-base text-neutral-900 w-[338px] text-center capitalize">
        {props.data[0]} produk
      </span>
      {console.log(props)}
      <span className="font-medium text-sm text-neutral-900 w-[264px] text-center">
        Apakah kamu yakin ingin meng{props.data[0]}
        {!props.data[0].includes("hapus") && "kan"} {props.data[1].Name}?
      </span>
      <div className="flex gap-2">
        <Button
          Class="!font-medium !h-8"
          color="primary_secondary"
          onClick={() => closeModal()}
        >
          Batal
        </Button>
        <Button
          Class="!font-medium !h-8 capitalize"
          color="primary"
          onClick={() => {
            return handleAction(props);
            setDataToast({
              type: "success",
              message: `Berhasil meng${props.data[0]} produk`,
            });
            setShowToast(true);
            closeModal();
          }}
        >
          Setuju
        </Button>
      </div>
    </div>
  ) : (
    <div className="flex flex-col items-center justify-center gap-5 py-9 px-6">
      <span className="font-bold text-base text-neutral-900 w-[338px] text-center">
        Apakah kamu yakin {action} produk?
      </span>
      <div className="font-medium border rounded-md overflow-auto w-[330px] h-[188px] flex flex-col px-2 py-3 gap-3">
        {listProduk.map((key, index) => {
          return (
            <>
              <div key={index} className="">
                <span className="text-neutral-900 w-[314px] !leading-[14.4px] text-xs">
                  {key.Name}
                </span>
              </div>
              {listProduk.length - 1 !== index && (
                <hr className="border-neutral-400 m-0" />
              )}
            </>
          );
        })}
      </div>
      <div className="flex gap-2">
        <Button
          Class="!font-medium !h-8"
          color="primary_secondary"
          onClick={() => {
            setListProduk([]);
            reset();
          }}
        >
          Batal
        </Button>
        <Button
          Class="!font-medium !h-8 capitalize"
          color="primary"
          onClick={() => {
            handleAction(props?.type?.[0]?.value);
          }}
        >
          {props.type[0].name}
        </Button>
      </div>
    </div>
  );
};
