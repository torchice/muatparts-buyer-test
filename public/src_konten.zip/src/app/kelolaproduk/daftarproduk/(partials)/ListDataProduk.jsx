"use client";

import React, { useState, useEffect, useContext, useRef } from "react";
import Badges from "@/components/Badges/Badges";
import Checkbox from "@/components/Checkbox/Checkbox";
import style from "../DaftarProdukPage.module.scss";
import IconComponent from "@/components/IconComponent/IconComponent";
import { StateContext } from "@/common/StateContext";
import Input from "@/components/Input/Input";
import Button from "@/components/Button/Button";
import toast from "@/store/zustand/toast";
import Dropdown from "@/components/Dropdown/Dropdown";
import Modal from "@/components/Modals/modal";
import styles from "./ListDataProduk.module.scss";
import viewport from "@/store/zustand/common";
import SWRHandler from "@/services/useSWRHook";
import ImageComponent from "@/components/ImageComponent/ImageComponent";
import { useCustomRouter } from "@/libs/CustomRoute";
import { modal } from "@/store/zustand/modal";
import ConfigUrl from "@/services/baseConfig";
import { useSWRConfig } from "swr";
import { ThousandSeparator } from "@/libs/NumberFormat";
import { useTranslation } from "@/context/TranslationProvider";

export const ListDataProduk = ({
  data,
  selected = [],
  setSelected = () => {},
  allChecked = false,
  isCheckbox = false,
  onModal = "",
  productMutate,
  additionalParam,
}) => {
  const { setModalOpen, setModalConfig, setModalContent } = modal();

  // LB - 0652, LB - 0653, LB - 0654 - 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2
  const { t } = useTranslation();
  const router = useCustomRouter();
  const { mutate } = useSWRConfig();
  const { handleModal } = useContext(StateContext);
  const { useSWRHook, useSWRMutateHook } = SWRHandler;
  const {
    data: bulk,
    error: bulk_error,
    trigger: bulk_trigger,
    isMutating,
  } = useSWRMutateHook(
    process.env.NEXT_PUBLIC_GLOBAL_API + `v1/muatparts/product/bulkaction`,
    "PUT"
  );

  const [productID, setProductID] = useState(null);

  const {
    data: product_detail,
    error: product_detail_error,
    mutate: mutate_product_list,
  } = useSWRHook(
    productID &&
      process.env.NEXT_PUBLIC_GLOBAL_API + `v1/muatparts/product/${productID}`,
    null
  );

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [indexCheckbox, setIndexCheckbox] = useState(
    data?.Data.map(() => allChecked)
  );
  const [modalType, setModalType] = useState();
  const [selectedProduct, setSelectedProduct] = useState();
  const { setShowToast, setDataToast } = toast();
  const [bulkAction, setBulkAction] = useState("");

  const {
    data: dataShareProduct,
    error: errorShareProduct,
    trigger: triggerShareProduct,
  } = useSWRMutateHook(
    selectedProduct
      ? `${process.env.NEXT_PUBLIC_GLOBAL_API}v1/muatparts/product/share/${selectedProduct?.ID}`
      : null,
    "GET"
  );
  const shortenedLink = dataShareProduct?.data
    ? dataShareProduct?.data.Data.shortenedLink
    : "";

  useEffect(() => {
    if (selectedProduct?.ID) {
      triggerShareProduct();
    }
  }, [selectedProduct?.ID]);

  useEffect(() => {
    if (bulk_error?.status === 400) {
      console.log("error", bulk_error);
      setDataToast({
        type: "error",
        message: `${bulk_error?.response?.data?.Data?.Message}`,
      });
      setShowToast(true);
    }
    if (bulk?.status === 200) {
      setDataToast({
        type: "success",
        message: `Berhasil ${bulkAction} produk`,
      });
      setShowToast(true);

      productMutate(
        `${process.env.NEXT_PUBLIC_GLOBAL_API}v1/muatparts/product/lists?page_size=10&page=1${additionalParam}`,
        null,
        null,
        false
      );
    }
  }, [isMutating]);

  const handleChecked = (e, index) => {
    const updatedCheckboxState = [...indexCheckbox];
    updatedCheckboxState[index] = e.checked;
    setIndexCheckbox(updatedCheckboxState);

    if (e.checked) {
      setSelected([...selected, e.value]);
    } else {
      setSelected(selected?.filter((key) => key.ID !== e.value.ID));
    }
  };
  // console.log(indexCheckbox)
  useEffect(() => {
    setIndexCheckbox(data?.Data.map(() => allChecked));
    if (allChecked) setSelected(data?.Data);
    else setSelected([]);
    //(selected, " selected");
  }, [allChecked]);

  const onClickEditStock = (id) => {
    const dataProduk = data?.Data?.find((item) => item.ID === id);
    if (dataProduk.HaveVariant && dataProduk.variant.length > 0) {
      handleModal({
        modalId: "edit_stock_variant",
        withHeader: true,
        closeArea: false,
        hideCloseButton: false,
        props: {
          data,
          product_name: dataProduk.Name,
          id,
          productMutate,
          additionalParam,
        },
        sizeHeader: "big",
      });
    } else {
      handleModal({
        modalId: "edit_stock",
        withHeader: true,
        closeArea: false,
        hideCloseButton: false,
        props: { data, id, productMutate, additionalParam },
      });
    }
  };

  const onClickEditHarga = (id) => {
    const dataProduk = data?.Data?.find((item) => item.ID === id);
    if (dataProduk.HaveVariant && dataProduk.variant.length > 0) {
      handleModal({
        modalId: "edit_harga_variant",
        withHeader: true,
        closeArea: false,
        hideCloseButton: false,
        props: {
          data,
          product_name: dataProduk.Name,
          id,
          productMutate,
          additionalParam,
        },
        sizeHeader: "big",
      });
    } else if (
      dataProduk.SalesType === "Grosir" &&
      dataProduk.wholesales.length > 0
    ) {
      setModalConfig({
        withHeader: true,
        withClose: true,
        classname: "!w-[386px] !h-fit",
      });
      setModalContent(
        <UbahHargaGrosir
          productMutate={productMutate}
          additionalParam={additionalParam}
          data={dataProduk}
        />
      );
      setModalOpen(true);
    } else {
      handleModal({
        modalId: "edit_harga",
        withHeader: true,
        closeArea: false,
        hideCloseButton: false,
        props: { data, id, productMutate, additionalParam },
      });
    }
  };

  // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0858
  const optionDropdown = [
    {
      name: t("labelPreviewProduk"),
      value: "preview_produk",
    },
    {
      name: t("AppPromosiSellerMuatpartsSalin"),
      value: "salin",
    },
    {
      name: t("AppMuatpartsProfilSellerIndexUbah"),
      value: "ubah",
    },
    {
      name: t("labelShareBuyer"),
      value: "bagikan",
    },
    {
      name: t("buttonActivate"),
      value: "active",
    },
    {
      name: t("buttonDeactivate"),
      value: "inactive",
    },
    {
      name: t("buttonDelete"),
      value: "delete",
    },
  ];

  const getShareText = (product) => {
    // console.log("get",product)
    return `Temukan ${product.Name} seharga ${product.PriceLabel}. Dapatkan sekarang juga di Muatparts!`;
  };

  const shareThroughApps = [
    {
      link: (product) =>
        `https://wa.me/?text=${getShareText(product)}${
          shortenedLink ? "%0a" + shortenedLink : ""
        }`,
      title: "Whatsapp",
      url: "/img/whatsapp.png",
    },
    {
      link: (product) =>
        `https://t.me/share/url?text=${shortenedLink}&url=${getShareText(
          product
        )}`,
      title: "Telegram",
      url: "/img/telegram.png",
    },
    {
      link: (product) =>
        `https://www.facebook.com/sharer/sharer.php?u=${shortenedLink}&quote=${getShareText(
          product
        )}`,
      title: "Facebook",
      url: "/img/facebook.png",
    },
    {
      link: (product) => `Bagikan produk ${product}`,
      title: "Instagram",
      url: "/img/instagram.png",
    },
    {
      link: (product) =>
        `https://twitter.com/intent/tweet?text=${getShareText(
          product
        )}&url=${shortenedLink}`,
      title: "x",
      url: "/img/twitter.png",
    },
    {
      link: (product) =>
        `mailto:?body=${getShareText(product)}${
          shortenedLink ? "%0a" + shortenedLink : ""
        }`,
      title: "Email",
      url: "/img/gmail.png",
    },
    {
      link: () => ``,
      onClick: (e) => {
        try {
          const text = shortenedLink;
          e.preventDefault();
          if (navigator.clipboard) {
            navigator.clipboard.writeText(text);
          } else {
            const input = document.createElement("textarea");
            input.value = text;
            document.body.appendChild(input);
            input.select();
            document.execCommand("copy");
            document.body.removeChild(input);
          }
        } catch (err) {
          console.log(err);
        }
      },
      title: "Salin Tautan",
      url: "/img/copy-link.png",
    },
  ];

  const onClickManageProduk = async (id, action) => {
    switch (action) {
      case "active":
        setBulkAction("mengaktifkan");
        break;
      case "inactive":
        setBulkAction("menonaktifkan");
        break;
      case "delete":
        setBulkAction("menghapus");
        break;
    }
    await bulk_trigger({ items: [id], action }).then(() =>
      mutate_product_list(
        process.env.NEXT_PUBLIC_GLOBAL_API + `muatparts/product/${productID}`
      )
    );

    setIsModalOpen(false);
  };

  const modalData = {
    active: {
      action: (id) => {
        onClickManageProduk(id, "active");
      },
      desc: (productName) => `Apakah kamu yakin mengaktifkan ${productName} ?`,
    },
    inactive: {
      action: (id) => {
        onClickManageProduk(id, "inactive");
      },
      desc: (productName) => `Apakah kamu yakin menonaktifkan ${productName} ?`,
    },
    delete: {
      action: (id) => {
        onClickManageProduk(id, "delete");
      },
      desc: (productName) => `Apakah kamu yakin menghapus ${productName} ?`,
    },
  };

  const onClickSalin = (product) => {
    // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0480
    window.location.href =
      process.env.NEXT_PUBLIC_ASSET_REVERSE +
      `/kelolaproduk/tambahproduk?page=1&share=true&id=${product.id}`;
  };

  const onClickUbah = (product) => {
    router.push(
      `/kelolaproduk/tambahproduk?page=1&share=true&id=${product.id}&type=edit`
    );
  };

  const onClickPreviewProduk = (item) => {
    router.push(
      `${process.env.NEXT_PUBLIC_BUYER_WEB}${item?.StoreName}/${item?.product_name}`
    );
  };

  const onManageProduct = (item, type) => {
    // alert('Nonaktifkan')
    setIsModalOpen(true);
    setModalType(type);
    setSelectedProduct(item);
  };

  const onSelectedAtur = (item) => (val) => {
    switch (val[0].value) {
      case "preview_produk":
        onClickPreviewProduk(item);
        break;
      case "salin":
        onClickSalin(item);
        break;
      case "ubah":
        onClickUbah(item);
        break;
      case "bagikan":
        onManageProduct(item, "share");
        break;
      case "active":
        onManageProduct(item, "active");
        break;
      case "inactive":
        onManageProduct(item, "inactive");
        break;
      case "delete":
        onManageProduct(item, "delete");
        break;
      default:
        break;
    }
  };

  return (
    <>
      {data?.Data.map((item, index) => {
        return (
          <>
            <tr className={`align-top`} key={index}>
              <td className={`${style.td_custom} flex gap-2`}>
                {isCheckbox && (
                  <Checkbox
                    key={`checkbox-${index}-${indexCheckbox[index]}`}
                    label=""
                    onChange={(e) => handleChecked(e, index)}
                    checked={indexCheckbox[index]}
                    value={item}
                  />
                )}
                {/* <Image
                      src={item?.Photo}
                      width={56}
                      height={56}
                      alt="image_produk"
                    /> */}
                <img
                  src={item.Photo}
                  className={`${style.image_product}`}
                  alt="image_produk"
                  width="56"
                  height="56"
                />
              </td>
              <td className={`${style.td_custom}`}>
                <div className={`flex flex-col gap-[12px]`}>
                  <p
                    className={`${style.head_text_produk} ${style.head_produk_clamp}`}
                  >
                    {item.Name}
                  </p>
                  <p className={`${style.sub_text_produk}`}>
                    SKU : {item.SKU ? item.SKU : "-"}
                  </p>
                  <p className={`${style.sub_text_produk}`}>
                    Brand : {item.Brand}
                  </p>
                </div>
              </td>
              <td className={`${style.td_custom}`}>
                {item.Category?.filter((item) => item != null).map(
                  (category, index) => {
                    return (
                      <div className={`flex`} key={index}>
                        <p
                          className={`${style.sub_text_produk} ${style.category_clamp}`}
                        >
                          {category}
                        </p>
                        {index !== item.Category.length - 1 && (
                          <img
                            src={
                              process.env.NEXT_PUBLIC_ASSET_REVERSE +
                              "/icons/arrow-right-category.svg"
                            }
                            alt="arrow category"
                          />
                        )}
                      </div>
                    );
                  }
                )}
              </td>
              <td className={`${style.td_custom}`}>
                <div className={`flex gap-[4px] items-center`}>
                  <p className={`${style.sub_text_produk}`}>{item.Stock}</p>
                  {!onModal && (
                    <IconComponent
                      src="/icons/edit-gray.svg"
                      classname={`cursor-pointer ${style.icon_edit}`}
                      alt="edit-stok"
                      width={10}
                      height={10}
                      onclick={() => onClickEditStock(item.ID)}
                    />
                  )}
                </div>
              </td>
              <td className={`${style.td_custom}`}>
                <div className={`flex gap-[5px] items-center`}>
                  <p className={`${style.sub_text_produk}`}>
                    {item.PriceLabel}
                  </p>
                  {!onModal && (
                    <IconComponent
                      src="/icons/edit-gray.svg"
                      classname={`cursor-pointer ${style.icon_edit}`}
                      alt="edit-harga-jual"
                      width={10}
                      height={10}
                      onclick={() => onClickEditHarga(item.ID)}
                    />
                  )}
                </div>
              </td>
              <td className={`${style.td_custom}`}>
                <p className={`${style.sub_text_produk}`}>{item.Sold}</p>
              </td>
              <td className={`${style.td_custom} flex gap-[20px]`}>
                <StatusProduct status={item.Status} t={t} />
                {!onModal && (
                  <Dropdown
                    classname={`!w-[72px] ${style.dropdown_atur}`}
                    placeholder={t("buttonSettings")}
                    options={optionDropdown}
                    onSelected={onSelectedAtur({
                      ...item,
                      id: item.ID,
                      product_name: item.Name,
                    })}
                    fixedPlaceholder={true}
                  />
                )}
              </td>
            </tr>
            {!onModal && (
              <tr
                className={`${
                  index !== data.length - 1 ? style.border_bottom : ""
                }`}
              >
                {item.HaveVariant && (
                  <td className={`${style.td_custom} !pt-0`} colSpan="8">
                    <ListVarianProduk
                      data={data}
                      id={item.ID}
                      name={item.Name}
                      productMutate={productMutate}
                      additionalParam={additionalParam}
                      t={t}
                    />
                  </td>
                )}
              </tr>
            )}
          </>
        );
      })}
      {/* Modal Bagikan Produk */}
      {isModalOpen && modalType === "share" ? (
        <Modal
          isBig
          isOpen={isModalOpen}
          setIsOpen={setIsModalOpen}
          closeArea={false}
          closeBtn={true}
        >
          <div className="flex flex-col gap-y-6">
            <div className="font-bold text-black text-[16px] leading-[19.2px] self-center">
              Bagikan Produk
            </div>
            <div className="border-[#c4c4c4] border-[1px] rounded-xl p-3 flex flex-row gap-x-3">
              <img
                className="w-14 h-14"
                src={selectedProduct.Photo}
                alt={selectedProduct.product_name}
              />
              <div className="flex flex-col gap-y-3">
                <span
                  className={`font-bold text-black text-[12px] leading-[14.4px] ${styles.modal_product_name}`}
                >
                  {selectedProduct.product_name}
                </span>
                <span className="font-medium text-black text-[10px] leading-[13px]">
                  {`Brand : ${selectedProduct.Brand}`}
                </span>
                <span className="font-medium text-black text-[10px] leading-[13px]">
                  {/* 24. THP 2 - MOD001 - MP - 005 - QC Plan - Web - MuatParts - Paket 011 A - Seller - Daftar Produk - LB - 0167 */}
                  {`Harga : ${
                    selectedProduct?.MinPrice === selectedProduct?.MaxPrice
                      ? selectedProduct?.MinPrice
                        ? selectedProduct?.MinPrice.toLocaleString("id-ID")
                        : 0
                      : [
                          `Rp${
                            selectedProduct?.MinPrice
                              ? selectedProduct?.MinPrice.toLocaleString(
                                  "id-ID"
                                )
                              : 0
                          }`,
                          `Rp${
                            selectedProduct?.MaxPrice
                              ? selectedProduct?.MaxPrice.toLocaleString(
                                  "id-ID"
                                )
                              : 0
                          }`,
                        ].join(" - ")
                  }`}
                </span>
              </div>
            </div>
            <div className="flex flex-col gap-y-[14px] items-start">
              <span className="font-medium text-black text-[14px] leading-[16.8px]">
                Bagikan Melalui
              </span>
              <div className="flex flex-row gap-x-3">
                {shareThroughApps.map((app, key) => {
                  const href = app.link(selectedProduct);
                  if (href === "") {
                    return (
                      <div
                        className="flex flex-col gap-y-2 items-center hover:no-underline cursor-pointer"
                        key={key}
                        onClick={app.onClick}
                      >
                        <div className="rounded-3xl p-1 border-[0.5px] border-[#c4c4c4]">
                          <ImageComponent
                            src={app.url}
                            alt={app.title}
                            width={28}
                            height={28}
                          />
                        </div>
                        <span className="font-medium text-black text-[10px] leading-[13px]">
                          {app.title}
                        </span>
                      </div>
                    );
                  }
                  return (
                    <a
                      href={href}
                      className="flex flex-col gap-y-2 items-center hover:no-underline w-[45px]"
                      key={key}
                      onClick={app.onClick}
                      rel="noreferrer"
                      target="_blank"
                    >
                      <div className="rounded-3xl p-1 border-[0.5px] border-[#c4c4c4]">
                        <ImageComponent
                          src={app.url}
                          alt={app.title}
                          width={28}
                          height={28}
                        />
                      </div>
                      <span className="font-medium text-black text-[10px] leading-[13px]">
                        {app.title}
                      </span>
                    </a>
                  );
                })}
              </div>
            </div>
          </div>
        </Modal>
      ) : null}
      {/* Modal Aktifkan Nonaktifkan Hapus Produk */}
      {isModalOpen &&
      (modalType === "active" ||
        modalType === "inactive" ||
        modalType === "delete") ? (
        <Modal
          isOpen={isModalOpen}
          setIsOpen={setIsModalOpen}
          closeArea={false}
          closeBtn={true}
          desc={modalData[modalType].desc(selectedProduct.product_name)}
          action1={{
            action: () => setIsModalOpen(false),
            text: "Batal",
            style: "outline",
            color: "#176CF7",
            customStyle: {
              width: "112px",
            },
          }}
          action2={{
            action: () => modalData[modalType].action(selectedProduct.id),
            text: "Ya",
            style: "full",
            color: "#176CF7",
            customStyle: {
              width: "112px",
              color: "#ffffff",
            },
          }}
        />
      ) : null}
    </>
  );
};

export default ListDataProduk;

export const StatusProduct = ({ status, classname, t = () => {} }) => {
  // 25 . 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0548
  const {t:translate} = useTranslation()
  let model = "";
  let type = "";
  let statusText = "";

  if (status == "Aktif") {
    type = "success";
    model = "secondary";
    statusText = translate("statusProdukAktif");
  } else if (status == "Non Aktif") {
    type = "error";
    model = "secondary";
    statusText = translate("statusProdukNonAktif");
  } else if (status == "Varian") {
    type = "info";
    model = "secondary";
    statusText = translate("statusProdukVarian");
  } else if (status === "Draft") {
    type = "inactive";
    model = "secondary";
    statusText = translate("statusProdukDraft");
  } else if (status === "Stock Habis" || status === "Stok Habis") {
    type = "warning";
    model = "secondary";
    statusText = translate("statusProdukStokHabis");
  }

  return (
    <Badges
      model={model}
      type={type}
      // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0546
      classname={`pb-[8px] pt-[9px] px-[24.5px] !max-w-[86px] w-[86px] !font-[600] ${
        status === "Non Aktif" && "!py-[8px] !px-[10px]"
      } ${
        (status === "Stock Habis" || status === "Stok Habis") &&
        "!py-[5px] !px-[5px]"
      } ${classname}`}
    >
      {statusText}
    </Badges>
  );
};

const ListVarianProduk = ({
  data,
  name,
  id,
  productMutate,
  additionalParam,
  t,
}) => {
  const [isOpen, setOpen] = useState(false);
  const { handleModal } = useContext(StateContext);
  const dataProduk = data?.Data?.find((item) => item.ID === id);
  const onClickExpand = () => setOpen((prev) => !prev);

  const onClickEditStockVariant = (id) => {
    // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0301
    handleModal({
      modalId: "edit_stock_variant",
      withHeader: true,
      closeArea: false,
      hideCloseButton: false,
      props: { data, product_name: name, id, productMutate },
      sizeHeader: "big",
    });
  };

  const onClickEditHargaVariant = () => {
    handleModal({
      modalId: "edit_harga_variant",
      withHeader: true,
      closeArea: false,
      hideCloseButton: false,
      props: { data, product_name: name, id, productMutate, additionalParam },
      sizeHeader: "big",
    });
  };

  return (
    <div
      className={`bg-neutral-100 py-[20px] px-[24px] rounded-[12px] border-[1px] border-neutral-400`}
    >
      <div className={`flex justify-between items-center`}>
        <p className={`${style.head_text_produk}`}>
          {t("lihatVarianProduk")} ({dataProduk?.variant.length})
        </p>
        <div
          className={`flex items-center cursor-pointer gap-[4px]`}
          onClick={onClickExpand}
        >
          <p className={`font-[500] text-[12px] text-primary-700 select-none`}>
            {isOpen ? t("labelSembunyikan") : t("labelTampilkan")}
          </p>
          <ImageComponent
            src="/icons/arrow-blue-down.svg"
            alt="arrow"
            className={`${
              isOpen ? "rotate-180" : "rotate-0"
            } transition-transform`}
            width="16"
            height="16"
          />
        </div>
      </div>
      <div className={`mt-[20px] ${isOpen ? `block h-fit` : `hidden h-0`}`}>
        <table className={`w-100`}>
          <tbody>
            {dataProduk?.variant.map((item, index) => {
              return (
                <>
                  <tr className={`${style.border_top}`} key={index}>
                    <td className={`${style.td_custom} w-[6.5vw]`}></td>
                    <td className={`${style.td_custom} w-[36.3vw]`}>
                      <div className={`flex flex-col gap-[12px]`}>
                        <p className={`${style.head_text_produk}`}>
                          {item.type}
                        </p>
                        <p className={`${style.sub_text_produk}`}>
                          SKU : {item.sku}
                        </p>
                      </div>
                    </td>
                    <td className={`${style.td_custom} w-[8vw]`}>
                      <div className={`flex gap-[4px] items-center`}>
                        <p className={`${style.sub_text_produk}`}>
                          {item.stock}
                        </p>
                        <IconComponent
                          src="/icons/edit-gray.svg"
                          classname={`cursor-pointer ${style.icon_edit}`}
                          alt="edit-variant-stok"
                          width={10}
                          height={10}
                          onclick={() => onClickEditStockVariant(id)}
                        />
                      </div>
                    </td>
                    <td className={`${style.td_custom} w-[14.5vw]`}>
                      <div className={`flex gap-[4px] items-center`}>
                        <p className={`${style.sub_text_produk}`}>
                          {/* 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0564 */}
                          <span>{item.priceLabel}</span>
                        </p>
                        <IconComponent
                          src="/icons/edit-gray.svg"
                          classname={`cursor-pointer ${style.icon_edit}`}
                          alt="edit-harga-variant"
                          width={10}
                          height={10}
                          onclick={() => onClickEditHargaVariant()}
                        />
                      </div>
                    </td>
                    <td className={`${style.td_custom} w-[22vw]`}>
                      <p className={`${style.sub_text_produk}`}>
                        {item.variant_sold}
                      </p>
                    </td>
                  </tr>
                </>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export const EditStockModal = ({ title }) => {
  // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0301
  const { props, closeModal, handleModal } = useContext(StateContext);
  const { setShowToast, setDataToast, setShowBottomsheet } = toast();
  const { isMobile } = viewport();
  const editStockRef = useRef();
  const dataProduk = props?.data?.Data?.filter((item) => item.ID === props.id);
  const [inputEdit, setInputEdit] = useState(dataProduk[0]?.Stock);
  const { useSWRMutateHook } = SWRHandler;
  const {
    data: bulk,
    error: bulk_error,
    trigger: bulk_trigger,
    isMutating,
  } = useSWRMutateHook(
    process.env.NEXT_PUBLIC_GLOBAL_API +
      `v1/muatparts/product/stock/${props.id}?isAll=false&stock=${inputEdit}`,
    "PUT"
  );
  const [isErrorEdit, setIsErrorEdit] = useState({
    status: "",
    message: "",
  });
  const onClickSimpanEditStock = async () => {
    // if (parseInt(inputEdit) < 0) { //LB - 0181 - Daftar Produk
    //   setIsErrorEdit({
    //     status: "error",
    //     message: `Stock Min. 1`,
    //   });
    //   return;
    // } else {
    //   setIsErrorEdit({
    //     status: null,
    //     message: "",
    //   });
    // }
    if (Number(editStockRef.current.value) < 0) {
      setIsErrorEdit({
        status: "error",
        message: "Stok wajib diisi",
      });
    } else {
      setIsErrorEdit({
        status: null,
        message: "",
      });
      !isMobile && closeModal();

      if (isMobile) {
        setDataToast({
          type: "success",
          message: `Berhasil memberbarui stok`,
        });
        await bulk_trigger();
        setShowToast(true);
        closeModal();
        setShowBottomsheet(false);
      } else {
        await bulk_trigger();
        handleModal({
          modalId: "modal_message",
          withHeader: true,
          closeArea: false,
          hideCloseButton: false,
          props: {
            message: "Berhasil memberbarui stok",
          },
        });
      }
    }
    props.productMutate(
      `${process.env.NEXT_PUBLIC_GLOBAL_API}v1/muatparts/product/lists?page_size=10&page=1${props.additionalParam}`,
      null,
      null,
      false
    );
  };
  const onChangeEditStok = (e) => {
    setIsErrorEdit({
      status: null,
      message: "",
    });

    let inputValue =
      e.target.value < dataProduk?.[0]?.["MinBuy"]
        ? dataProduk?.[0]?.["MinBuy"]
        : e.target.value;

    inputValue = inputValue.replace(/[^0-9]/g, "");
    if (parseInt(inputValue) < 0) {
      //LB - 0181 - Daftar Produk
      setIsErrorEdit({
        status: "error",
        message: `Stock Min. 1`,
      });
    } else {
      setIsErrorEdit({
        status: null,
        message: "",
      });
    }
    if (parseInt(inputValue) < 0) {
      inputValue = "0";
    }

    setInputEdit(inputValue);
  };
  if (isMobile) {
    return (
      <div className={`${style.main_responsive}`}>
        {/* LB - 0473, 25.03 */}
        <p className="text-neutral-900 font-semibold text-sm mb-3">{title}</p>
        <Input
          type="text"
          status={isErrorEdit.status}
          ref={editStockRef}
          changeEvent={onChangeEditStok}
          value={inputEdit}
          width={{ width: "100%" }}
          placeholder="Masukkan Stok"
          supportiveText={{ title: isErrorEdit.message }}
        />
        <Button
          Class="mt-4 max-w-none w-full"
          color="primary"
          onClick={onClickSimpanEditStock}
        >
          Simpan
        </Button>
      </div>
    );
  }

  // 24. THP 2 - MOD001 - MP - 005 - QC Plan - Web - MuatParts - Paket 011 A - Seller - Daftar Produk - LB - 0094
  return (
    <>
      <div
        className={
          "flex flex-col items-center text-neutral-900 py-[36px] px-[24px]"
        }
      >
        <p className={`text-neutral-900 font-[700] text-[16px] mb-3`}>
          Atur Stock
        </p>
        <span
          className={`text-neutral-900 font-[500] text-[14px] text-center max-w-[336px] mb-5`}
        >
          {dataProduk[0].Name}
        </span>
        <Input
          type="text"
          status={isErrorEdit.status}
          ref={editStockRef}
          changeEvent={onChangeEditStok}
          value={inputEdit}
          width={{ width: "100%" }}
          placeholder=""
          supportiveText={{ title: isErrorEdit.message }}
        />
        <div className={`flex gap-[8px] mt-6`}>
          <Button color="primary_secondary" onClick={() => closeModal()}>
            Batal
          </Button>
          <Button color="primary" onClick={onClickSimpanEditStock}>
            Simpan
          </Button>
        </div>
      </div>
    </>
  );
};

export const EditStockVariantModal = () => {
  // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0301
  const { props, closeModal } = useContext(StateContext);
  const { setShowToast, setDataToast, setShowBottomsheet } = toast();
  const { isMobile } = viewport();
  const editMassal = useRef();
  const inputRef = useRef([]);
  const dataProduk = props?.data?.Data?.filter((item) => item.ID === props.id);
  const dataProdukVariant = dataProduk?.[0]?.variant;
  const [massal, setMassal] = useState(false);
  const [inputMassal, setInputMassal] = useState("");
  const [massalText, setMassalText] = useState({
    status: "",
    message: "Catatan : Perubahan akan diterapkan untuk semua varian",
  });
  const [errorText, setErrorText] = useState([]);
  const [inputVal, setInputVal] = useState([]);
  const { useSWRMutateHook } = SWRHandler;
  const { trigger } = useSWRMutateHook(
    `${process.env.NEXT_PUBLIC_GLOBAL_API}v1/muatparts/product/stock/variants/${props?.id}?isMassal=${massal}`,
    "put"
  );
  useEffect(() => {
    const newInputVal = dataProdukVariant?.map((item) =>
      Number(item.stock.replace(/\./g, ""))
    );
    setInputVal(newInputVal);
  }, [dataProdukVariant]);
  const onChangeMassal = (e) => {
    setMassalText({
      status: "",
      message: "Catatan : Perubahan akan diterapkan untuk semua varian",
    });

    let inputValue = e.target.value;

    inputValue = inputValue.replace(/[^0-9]/g, "");

    if (parseInt(inputValue) < 0) {
      inputValue = "0";
    }

    setInputMassal(inputValue);
  };
  const onChangeInput = (e, index) => {
    setInputVal((item) => {
      const prevItem = [...item];
      prevItem[index] = e.target.value;
      return prevItem;
    });
  };
  // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0174
  const onClickSimpan = () => {
    if (massal) {
      if (!editMassal.current.value) {
        setMassalText({
          status: "error",
          message: "Stock wajib diisi",
        });
        return;
      }
      const data = [];
      dataProdukVariant.map((item, index) => {
        data.push({
          id: dataProdukVariant[index].id,
          stock: Number(inputMassal),
        });
      });
      trigger({ products: data }).then((a) => {
        props?.productMutate(
          `${process.env.NEXT_PUBLIC_GLOBAL_API}muatparts/product/lists?page_size=10&page=1${props.additionalParam}`,
          null,
          null,
          false
        );
        setDataToast({
          type: "success",
          message: "Berhasil memberbarui stok",
        });
        setShowToast(true);
        setShowBottomsheet(false);
      });
    } else {
      const newErrorText = {};
      let hasError = false;
      const data = [];
      dataProdukVariant.map((item, index) => {
        const inputValue = inputRef.current[index]?.value;
        data.push({
          id: dataProdukVariant[index].id,
          stock: Number(inputValue.replaceAll(".", "")),
        });
        if (!inputValue) {
          newErrorText[index] = {
            status: "error",
            message: "Stock wajib diisi",
          };
          hasError = true;
        }
      });
      if (hasError) {
        setErrorText(newErrorText);
        return;
      }
      trigger({ products: data }).then((a) => {
        props?.productMutate(
          `${process.env.NEXT_PUBLIC_GLOBAL_API}muatparts/product/lists?page_size=10&page=1${props.additionalParam}`,
          null,
          null,
          false
        );
        setDataToast({
          type: "success",
          message: "Berhasil memberbarui stok",
        });
        setShowToast(true);
      });
      setShowBottomsheet(false);
    }
    closeModal();
  };

  // 24. THP 2 - MOD001 - MP - 005 - QC Plan - Web - MuatParts - Paket 011 A - Seller - Daftar Produk - LB - 0094
  return (
    <>
      <div
        className={`flex flex-col  text-neutral-900 ${
          !isMobile ? "py-[36px] px-[24px]" : "gap-[24px] p-none"
        }`}
      >
        {!isMobile && (
          <p className={`text-neutral-900 font-[700] text-[16px] text-center mb-3`}>
            Atur Stock
          </p>
        )}
        <span
          className={`text-neutral-900  text-[14px] ${
            isMobile ? "text-left font-semibold" : "mx-auto text-center font-[500] mb-5"
          } max-w-[336px]`}
        >
          {props?.product_name}
        </span>
        {/* 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0172 & LB - 0474 */}
        <div className={`flex flex-col gap-[12px]`}>
          <div>
            <Checkbox
              label="Ubah Stok Secara Massal"
              classname={`!font-[500]`}
              onChange={(e) => setMassal(e.checked)}
            />
          </div>
          <div className={`flex flex-col gap-[12px]`}>
            {massal ? (
              <Input
                ref={editMassal}
                width={{ width: "100%" }}
                status={massalText.status}
                placeholder="Masukkan Stok"
                supportiveText={{ title: massalText.message }}
                value={inputMassal}
                changeEvent={onChangeMassal}
              />
            ) : (
              dataProdukVariant?.map((item, index) => {
                return (
                  <div
                    className={`flex justify-between max-h-[198px]`}
                    key={index}
                  >
                    <div>
                      <p
                        className={`text-neutral-900 text-[14px] font-[600] w-[198px]`}
                      >
                        Tipe {item.type}
                      </p>
                      <span
                        className={`text-neutral-900 text-[12px] font-[500]`}
                      >
                        SKU : {item.sku}
                      </span>
                    </div>
                    <div>
                      <Input
                        type="number"
                        placeholder=""
                        status={errorText[index]?.status || ""}
                        supportiveText={{
                          title: errorText[index]?.message || "",
                        }}
                        // 25. 03 - QC Plan - Web - Pengecekan Ronda Muatparts - Tahap 2 - LB - 0491
                        value={
                          inputVal[index]
                            ? ThousandSeparator(inputVal[index])
                            : 0
                        }
                        ref={(el) => (inputRef.current[index] = el)}
                        changeEvent={(e) => onChangeInput(e, index)}
                      />
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
        {isMobile ? (
          <Button
            Class="max-w-none w-full"
            color="primary"
            onClick={onClickSimpan}
          >
            Simpan
          </Button>
        ) : (
          <div className={`flex justify-center gap-[8px] mt-6`}>
            <Button color="primary_secondary" onClick={() => closeModal()}>
              Batal
            </Button>
            <Button color="primary" onClick={onClickSimpan}>
              Simpan
            </Button>
          </div>
        )}
      </div>
    </>
  );
};

export const EditHargaModal = () => {
  // 24. THP 2 - MOD001 - MP - 005 - QC Plan - Web - MuatParts - Paket 011 A - Seller - Daftar Produk - LB - 0126
  const { props, closeModal } = useContext(StateContext);
  const { setShowToast, setDataToast } = toast();
  const editHargaRef = useRef();
  const dataProduk = props?.data?.Data?.filter((item) => item.ID === props.id);
  const { useSWRMutateHook } = SWRHandler;
  const {
    data: bulk,
    error: bulk_error,
    trigger: bulk_trigger,
    isMutating,
  } = useSWRMutateHook(
    process.env.NEXT_PUBLIC_GLOBAL_API +
      `v1/muatparts/product/price/${props.id}`,
    "PUT"
  );
  const [inputEdit, setInputEdit] = useState(
    dataProduk[0]?.start_sell_price
      ? Intl.NumberFormat("id-ID").format(dataProduk[0]?.start_sell_price)
      : Intl.NumberFormat("id-ID").format(dataProduk[0]?.MinPrice)
  );
  const [isErrorEdit, setIsErrorEdit] = useState({
    status: "",
    message: "",
  });

  const onClickSimpan = async () => {
    if (!editHargaRef.current.value) {
      setIsErrorEdit({
        status: "error",
        message: "Harga wajib diisi",
      });
    } else {
      const price = Number(editHargaRef.current.value.replace(/\./g, ""));
      console.log("asdd", price);
      if (price >= 99 && price <= 10000000 * 0 + 999999999) {

        // IMP - Prevent atur harga produk saat promo aktif
        await bulk_trigger({
          price,
        })
          .then(() => {
            closeModal();
            setDataToast({
              type: "success",
              message: `Berhasil memberbarui harga`,
            });
            setShowToast(true);

            const baseUrl = `${process.env.NEXT_PUBLIC_GLOBAL_API}v1/`;
            props.productMutate(
              `${baseUrl}muatparts/product/lists?page_size=10&page=1${props.additionalParam}`,
              null,
              null,
              false
            );
          })
          .catch((err) => {
            setIsErrorEdit({
              status: "error",
              message: err.response.data.Data.Message.Message,
            });
          });
      } else {
        setIsErrorEdit({
          status: "error",
          message: "Masukkan Harga Rp99 s/d Rp 999.999.999",
        });
        return;
      }
    }
  };

  const onChangeEditHarga = (e) => {
    setIsErrorEdit({
      status: null,
      message: "",
    });

    let inputValue = e.target.value;

    inputValue = inputValue.replace(/[^0-9]/g, "");

    setInputEdit(Intl.NumberFormat("id-ID").format(inputValue));
  };
  return (
    <div
      className={
        "flex flex-col gap-[24px] items-center text-neutral-900 py-[36px] px-[24px]"
      }
    >
      <p className={`text-neutral-900 font-[700] text-[16px]`}>Atur Harga</p>
      <span
        className={`text-neutral-900 font-[500] text-[14px] text-center max-w-[336px]`}
      >
        {dataProduk[0].Name}
      </span>
      <Input
        type="text"
        status={isErrorEdit.status}
        ref={editHargaRef}
        changeEvent={onChangeEditHarga}
        value={inputEdit}
        width={{ width: "100%" }}
        placeholder=""
        supportiveText={{ title: isErrorEdit.message }}
        text={{ left: "Rp" }}
      />
      <div className={`flex gap-[8px]`}>
        <Button color="primary_secondary" onClick={() => closeModal()}>
          Batal
        </Button>
        <Button color="primary" onClick={onClickSimpan}>
          Simpan
        </Button>
      </div>
    </div>
  );
};

export const EditHargaVariantModal = () => {
  // 24. THP 2 - MOD001 - MP - 005 - QC Plan - Web - MuatParts - Paket 011 A - Seller - Daftar Produk - LB - 0126
  const { props, closeModal } = useContext(StateContext);
  const [inputMassal, setInputMassal] = useState("");
  const { setShowToast, setDataToast } = toast();
  const editMassal = useRef();
  const inputRef = useRef([]);
  const dataProduk = props?.data?.Data?.filter((item) => item.ID === props.id);
  const dataProdukVariant = dataProduk[0].variant;
  const [massal, setMassal] = useState(false);
  const [massalText, setMassalText] = useState({
    status: "",
    message: "Catatan : Perubahan akan diterapkan untuk semua varian",
  });
  const [errorText, setErrorText] = useState([]);
  const [inputVal, setInputVal] = useState([]);
  const { useSWRMutateHook } = SWRHandler;
  const {
    data: bulk,
    error: bulk_error,
    trigger: bulk_trigger,
    isMutating,
  } = useSWRMutateHook(
    process.env.NEXT_PUBLIC_GLOBAL_API +
      `v1/muatparts/product/price/variants/${props.id}?isMassal=${massal}`,
    "PUT"
  );
  useEffect(() => {
    const newInputVal = dataProdukVariant.map((item) =>
      Intl.NumberFormat("id-ID").format(item.price)
    );
    setInputVal(newInputVal);
  }, dataProdukVariant);
  const onChangeInput = (e, index) => {
    setInputVal((item) => {
      const prevItem = [...item];
      prevItem[index] = e.target.value;
      return prevItem;
    });
  };

  const onChangeHargaVariantMassal = (e) => {
    setMassalText({
      status: null,
      message: "Catatan : Perubahan akan diterapkan untuk semua varian",
    });
    let inputValue = e.target.value;

    inputValue = inputValue.replace(/[^0-9]/g, "");

    setInputMassal(Intl.NumberFormat("id-ID").format(inputValue));
  };

  const onClickSimpanHargaVariant = async () => {
    if (massal) {
      // Check is the massal form have a value
      if (!editMassal.current.value) {
        setMassalText({
          status: "error",
          message: "Harga wajib diisi",
        });
        return;
      } else {
        // Check Inputed Number Massal
        const price = Number(editMassal.current.value.replace(/\./g, ""));
        if (price >= 99 && price <= 10000000 * 0 + 999999999) {
          await bulk_trigger({
            price,
          })
            .then(() => {
              closeModal();
              setDataToast({
                type: "success",
                message: `Berhasil memberbarui harga`,
              });
              setShowToast(true);


              const baseUrl = `${process.env.NEXT_PUBLIC_GLOBAL_API}v1/`;
              props.productMutate(
                `${baseUrl}muatparts/product/lists?page_size=10&page=1${props.additionalParam}`,
                null,
                null,
                false
              );
            })
            .catch((err) => {
              setMassalText({
                status: "error",
                message: err.response.data.Data.Message.Message,
              });
            });
        } else {
          setMassalText({
            status: "error",
            message: "Masukkan Harga Rp99 s/d Rp 999.999.999",
          });
          return;
        }
      }
    } else {
      // Non Massal
      const newErrorText = {};
      let hasError = false;
      const data = [];
      dataProdukVariant.map((item, index) => {
        const inputValue = inputRef.current[index]?.value;
        if (!inputValue) {
          newErrorText[index] = {
            status: "error",
            message: "Harga wajib diisi",
          };
          hasError = true;
        } else {
          const price = Number(inputValue.replace(/\./g, ""));
          if (price >= 99 && price <= 10000000 * 0 + 999999999) {
            data.push({
              price,
              id: dataProdukVariant[index].id,
            });
          } else {
            newErrorText[index] = {
              status: "error",
              message: "Masukkan Harga Rp99 s/d Rp 999.999.999",
            };
            hasError = true;
          }
        }
      });

      if (hasError) {
        setErrorText(newErrorText);
        return;
      }
      await bulk_trigger({
        data: [...data],
      })
        .then(() => {
          const baseUrl = `${process.env.NEXT_PUBLIC_GLOBAL_API}v1/`;
          props.productMutate(
            `${baseUrl}muatparts/product/lists?page_size=10&page=1${props.additionalParam}`,
            null,
            null,
            false
          );
          closeModal();
          setDataToast({
            type: "success",
            message: "Berhasil memberbarui harga",
          });
          setShowToast(true);
        })
        .catch((err) => {
          dataProdukVariant.map((item, index) => {
            newErrorText[index] = {
              status: "error",
              message: err.response.data.Data.Message.Message,
            };

            setInputVal((item) => {
              const prevItem = [...item];
              prevItem[index] = Intl.NumberFormat("id-ID").format(
                dataProdukVariant[index].price
              );
              return prevItem;
            });
          });
          setErrorText(newErrorText);
        });
    }
  };
  return (
    <div
      className={
        "flex flex-col gap-[24px] text-neutral-900 py-[36px] px-[24px]"
      }
    >
      <p className={`text-neutral-900 font-[700] text-[16px] text-center`}>
        Atur Harga
      </p>
      <span
        className={`text-neutral-900 font-[500] text-[14px] text-center max-w-[336px]`}
      >
        {props.product_name}
      </span>
      <div className={`flex flex-col gap-[12px]`}>
        <div>
          <Checkbox
            label="Ubah Harga Secara Massal"
            classname={`!font-[500]`}
            onChange={(e) => setMassal(e.checked)}
          />
        </div>
        <div className={`flex flex-col gap-[12px]`}>
          {massal ? (
            <Input
              ref={editMassal}
              text={{ left: "Rp" }}
              width={{ width: "100%" }}
              status={massalText.status}
              placeholder="Masukkan Harga"
              supportiveText={{ title: massalText.message }}
              value={inputMassal}
              changeEvent={onChangeHargaVariantMassal}
            />
          ) : (
            dataProdukVariant?.map((item, index) => {
              return (
                <div
                  className={`flex justify-between max-h-[198px]`}
                  key={index}
                >
                  <div>
                    <p
                      className={`text-neutral-900 text-[14px] font-[600] w-[198px]`}
                    >
                      Tipe {item.type}
                    </p>
                    <span className={`text-neutral-900 text-[12px] font-[500]`}>
                      SKU : {item.sku}
                    </span>
                  </div>
                  <div>
                    <Input
                      placeholder=""
                      status={errorText[index]?.status || ""}
                      supportiveText={{
                        title: errorText[index]?.message || "",
                      }}
                      value={inputVal[index]}
                      ref={(el) => (inputRef.current[index] = el)}
                      text={{ left: "Rp" }}
                      changeEvent={(e) => onChangeInput(e, index)}
                    />
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
      <div className={`flex justify-center gap-[8px]`}>
        <Button color="primary_secondary" onClick={() => closeModal()}>
          Batal
        </Button>
        <Button color="primary" onClick={onClickSimpanHargaVariant}>
          Simpan
        </Button>
      </div>
    </div>
  );
};
export const ShareProductModal = () => {};

export const UbahHargaGrosir = ({ data, productMutate, additionalParam }) => {
  const MIN_PRICE = 99;
  const MAX_PRICE = 999999999;

  const { setModalOpen } = modal();
  const { setDataToast, setShowToast } = toast();
  const { put } = ConfigUrl();

  const formatPrice = (value) => {
    if (!value) return "";

    const numericValue = value.toString().replace(/\D/g, "");
    return new Intl.NumberFormat("id-ID").format(numericValue);
  };

  const [prices, setPrices] = useState(
    data.wholesales.map((item) => ({
      ...item,
      formattedPrice: formatPrice(item.price),
      error: "",
    }))
  );

  const validatePrice = (price, index, allPrices) => {
    if (!price) return "Harga wajib diisi";

    const numericPrice = parseInt(price.replace(/\D/g, ""), 10);

    if (numericPrice === 0) {
      return `Masukkan Harga Rp${MIN_PRICE} s/d Rp${new Intl.NumberFormat(
        "id-ID"
      ).format(MAX_PRICE)}`;
    }

    if (numericPrice < MIN_PRICE || numericPrice > MAX_PRICE) {
      return `Masukkan Harga Rp${MIN_PRICE} s/d Rp${new Intl.NumberFormat(
        "id-ID"
      ).format(MAX_PRICE)}`;
    }

    if (index > 0) {
      const previousPrice = parseInt(
        allPrices[index - 1].formattedPrice.replace(/\D/g, ""),
        10
      );
      // Changed condition: current price should be lower than previous price
      if (numericPrice >= previousPrice) {
        return `Harga harus lebih rendah dari Rp${new Intl.NumberFormat(
          "id-ID"
        ).format(previousPrice)}`;
      }
    }

    return "";
  };

  const handlePriceChange = (id, value, currentIndex) => {
    setPrices((prevPrices) => {
      const newPrices = prevPrices.map((item) =>
        item.id === id ? { ...item, formattedPrice: formatPrice(value) } : item
      );

      const error = validatePrice(value, currentIndex, newPrices);

      return newPrices.map((item, idx) =>
        idx === currentIndex ? { ...item, error } : item
      );
    });
  };

  const handleSubmit = async () => {
    const newPrices = prices.map((item, index) => ({
      ...item,
      error: validatePrice(item.formattedPrice, index, prices),
    }));

    setPrices(newPrices);

    const hasErrors = newPrices.some((item) => item.error);
    const hasEmptyPrices = newPrices.some((item) => !item.formattedPrice);

    if (hasErrors || hasEmptyPrices) {
      return;
    }

    const payload = {
      data: prices.map((item) => ({
        id: item.id,
        price: parseInt(item.formattedPrice.replace(/\D/g, ""), 10),
        minPurchase: item.minPurchase,
      })),
    };

    put({
      path: `v1/muatparts/product/price/wholesales/${data.ID}`,
      data: payload,
    }).then((x) => {
      if (x.status === 200) {
        // LB - 0173, 25.03
        const baseUrl = `${process.env.NEXT_PUBLIC_GLOBAL_API}v1/`;
        productMutate(
          `${baseUrl}muatparts/product/lists?page_size=10&page=1${additionalParam}`,
          null,
          null,
          false
        );
        setModalOpen(false);
        setShowToast(true);
        setDataToast({
          type: "success",
          message: "Berhasil memberbarui harga",
        });
      }
    });
  };

  return (
    // 24. THP 2 - MOD001 - MP - 005 - QC Plan - Web - MuatParts - Paket 011 A - Seller - Daftar Produk - LB - 0168
    <div className="flex flex-col py-9 gap-y-6 text-neutral-900 items-center">
      <p className="font-bold text-[16px] leading-[19.2px]">Atur Harga</p>
      <p className="font-medium text-[14px] leading-[16.8px]">{data.Name}</p>
      <div className="flex flex-col gap-y-3 max-h-[152px] overflow-auto ml-6 mr-2 pr-2">
        {prices.map((item, idx) => (
          <div className="flex flex-col gap-y-1.5">
            <div key={item.id} className="flex items-center gap-x-2">
              <div className="flex flex-col w-[100px]">
                <span className="w-[100px] text-[14px] leading-[16.8px] font-semibold line-clamp-2">
                  {item.minPurchase} -{" "}
                  {prices.length - 1 === idx
                    ? "Tidak Terbatas"
                    : item.maxPurchase}
                </span>
              </div>
              <div className="flex flex-col gap-1">
                <Input
                  text={{ left: "Rp" }}
                  classname="w-[229px]"
                  placeholder="Masukkan Harga"
                  value={item.formattedPrice}
                  changeEvent={(e) =>
                    handlePriceChange(item.id, e.target.value, idx)
                  }
                  maxLength={10}
                  status={item.error && "error"}
                  // supportiveText={{
                  //   title: (
                  //     <span className="text-xs text-error-500 font-medium">
                  //       {item.error}
                  //     </span>
                  //   ),
                  // }}
                />
              </div>
            </div>
            {item.error ? (
              <div className="flex items-center gap-x-2">
                <div className="w-[100px]" />
                <span className="font-medium text-[12px] leading-[14.4px] text-error-400">
                  {item.error}
                </span>
              </div>
            ) : null}
          </div>
        ))}
      </div>
      <div className="flex items-center gap-x-2">
        <Button
          color="primary_secondary"
          Class="!h-8 !min-h-8 !font-semibold"
          onClick={() => setModalOpen(false)}
        >
          Batal
        </Button>
        <Button Class="!h-8 !min-h-8 !font-semibold" onClick={handleSubmit}>
          Simpan
        </Button>
      </div>
    </div>
  );
};