"use client"
import React, {useEffect} from 'react'
import style from './NoAccess.module.scss'
import ImageComponent from '@/components/ImageComponent/ImageComponent'

const NoAccess = () => {
  
  useEffect(() => {
    document.body.style.overflow='hidden'
  }, [])

  return (
    <div className={`min-h-screen`}>
      <div className={`flex flex-col items-center justify-center pt-20 select-none`}>
        <ImageComponent src={`/img/noaccess.svg`} width={250} height={250} alt="no access image"/>
        <h1 className={`${style.head_noaccess}`}>Maaf, Anda tidak memiliki Hak Akses</h1>
        <div className={`${style.sub_noaccess}`}>
          <p>Anda tidak memiliki Hak Akses terhadap fitur/menu ini.</p>
          <p>Hubungi Pemilik Akun untuk meminta akses bila Anda membutuhkannya.</p>
        </div>
      </div>
    </div>
  )
}

export default NoAccess