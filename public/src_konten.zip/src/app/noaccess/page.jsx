import React from 'react'
import NoAccess from './NoAccess'

const page = () => {
  return (
    <NoAccess/>
  )
}

export default page